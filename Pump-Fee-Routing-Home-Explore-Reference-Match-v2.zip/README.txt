Pump-Fee-Routing — Home Explore Reference Match v2

Scope:
- ONLY the Explore preview block on the Home page.
- Static two-image composition like the supplied reference.
- Removes the extra token name/ticker/MC/sent row from under the Home Explore images.
- Moves “Explore” and “Open →” to the bottom overlay.
- Uses real token image_url values; handles ipfs:// and ar:// image URIs.
- If only one token exists, it is reused for the second visual panel until another token exists.
- If an image URL is unavailable, a neutral dark fallback is shown (no T letter).
- No motion/animation.
- Payments and every block below Explore are untouched.
- No Launch/wallet/routing/claims/payout/indexer logic changes.
- No automatic server restart.
