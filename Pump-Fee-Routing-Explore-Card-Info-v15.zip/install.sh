#!/usr/bin/env bash
set -euo pipefail

echo "== Explore Card Info v15 =="

for f in src/app.js src/styles.css; do
  if [ ! -f "$f" ]; then
    echo "ERROR: $f not found. Run this from the existing Replit project workspace."
    exit 1
  fi
done

python3 <<'PY'
from pathlib import Path

app_path = Path("src/app.js")
css_path = Path("src/styles.css")

app = app_path.read_text()
css = css_path.read_text()

old = """            return `<div class="home-explore-v8-primary-card">
              <div class="home-explore-v8-media">
                ${renderTokenArt(token, 'primary')}
                <div class="home-top-token-age" data-explore-age-badge="v14">${esc(ageText || '')}</div>
                ${renderRecipient(token)}
                <div class="home-explore-v8-copy">
                  <div class="home-explore-v8-title"><strong>${esc(token.name || 'Token')}</strong><span>${esc(token.symbol || '')}</span></div>
                  <div class="home-explore-v8-stats"><span>${fmtMc(token.mc ?? token.market_cap_usd)} MC</span><b>${fmtMoney(token.sent || 0)}</b></div>
                </div>
              </div>
            </div>`;"""

new = """            return `<div class="home-explore-v8-primary-card" data-explore-card-info="v15">
              <div class="home-explore-v8-media">
                ${renderTokenArt(token, 'primary')}
                <div class="home-top-token-age" data-explore-age-badge="v14">${esc(ageText || '')}</div>
                ${renderRecipient(token)}
              </div>
              <div class="home-explore-v8-copy">
                <div class="home-explore-v8-title">
                  <strong>${esc(token.name || 'Token')}</strong>
                  <span>${esc(token.symbol || '')}</span>
                </div>
                <div class="home-explore-v8-stats">
                  <span>${fmtMc(token.mc ?? token.market_cap_usd)} MC</span>
                  <b><strong>${fmtMoney(token.sent || 0)}</strong><small>Sent</small></b>
                </div>
              </div>
            </div>`;"""

if 'data-explore-card-info="v15"' in app:
    print("PASS Explore card info structure already installed")
elif old in app:
    app = app.replace(old, new, 1)
    print("PASS token information moved below image")
else:
    raise SystemExit("ERROR: current Explore primary-card block was not found. Nothing changed.")

app_path.write_text(app)

marker = "/* explore-card-info-v15 */"
css_patch = r"""
/* explore-card-info-v15 */

/* The left Explore token is a real card:
   image area -> token information -> shared Explore/Open footer. */
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"]{
  box-sizing:border-box;
  display:grid;
  grid-template-rows:minmax(0,1fr) 62px;
  padding-bottom:42px;
  background:#0b0b0b;
}

/* Image stays completely separate from the text section. */
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] > .home-explore-v8-media{
  width:100%;
  height:auto;
  min-height:0;
  overflow:hidden;
  background:#0a0a0a;
}

/* Recipient pill remains on the image, near its lower-left edge. */
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-recipient{
  left:12px;
  bottom:10px;
}

/* Name / ticker / MC / Sent are no longer an image overlay. */
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] > .home-explore-v8-copy{
  position:relative;
  left:auto;
  right:auto;
  bottom:auto;
  z-index:6;
  box-sizing:border-box;
  display:grid;
  align-content:center;
  gap:5px;
  width:100%;
  min-width:0;
  padding:9px 13px 10px;
  border-top:1px solid #272727;
  background:#0b0b0b;
}

/* First row: token name + ticker. */
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-title{
  display:flex;
  align-items:baseline;
  gap:7px;
  min-width:0;
}
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-title strong{
  min-width:0;
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
  color:#efefef;
  font-size:12px;
  line-height:1.15;
  font-weight:650;
}
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-title span{
  flex:0 0 auto;
  color:#6f6f6f;
  font-size:9px;
  line-height:1.15;
  font-weight:450;
}

/* Second row: market cap on the left, amount + Sent on the right. */
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-stats{
  display:flex;
  align-items:baseline;
  justify-content:space-between;
  gap:10px;
  min-width:0;
  color:#696969;
  font-size:9px;
  line-height:1.15;
}
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-stats > b{
  display:flex;
  align-items:baseline;
  gap:4px;
  flex:0 0 auto;
  color:#e8e8e8;
  font-size:12px;
  line-height:1.15;
  font-weight:650;
}
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-stats > b > strong{
  color:inherit;
  font:inherit;
}
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-stats > b > small{
  color:#666;
  font-size:9px;
  line-height:1.15;
  font-weight:450;
}

/* The old wide fade is no longer needed over the token information.
   Keep a smaller footer fade only for the shared Explore / Open row. */
.home-explore-reference-v8 .home-explore-v8-bottom-shade{
  height:18%;
  background:linear-gradient(180deg,rgba(23,23,23,0) 0%,rgba(23,23,23,.48) 52%,#171717 100%);
}

@media (max-width:640px){
  .home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"]{
    grid-template-rows:minmax(0,1fr) 53px;
    padding-bottom:36px;
  }
  .home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-recipient{
    left:8px;
    bottom:8px;
  }
  .home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] > .home-explore-v8-copy{
    gap:3px;
    padding:7px 10px 8px;
  }
  .home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-title strong{
    font-size:10px;
  }
  .home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-title span{
    font-size:7px;
  }
  .home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-stats{
    font-size:7px;
  }
  .home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-stats > b{
    gap:3px;
    font-size:10px;
  }
  .home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-stats > b > small{
    font-size:7px;
  }
  .home-explore-reference-v8 .home-explore-v8-bottom-shade{
    height:17%;
  }
}
"""

if marker not in css:
    css += "\n" + css_patch + "\n"
    print("PASS Explore v15 CSS added")
else:
    print("PASS Explore v15 CSS already installed")

css_path.write_text(css)

# Static verification before npm check.
a = app_path.read_text()
c = css_path.read_text()

checks = {
    "v15 card marker": 'data-explore-card-info="v15"' in a,
    "copy is outside media": '${renderRecipient(token)}\\n              </div>\\n              <div class="home-explore-v8-copy">' in a,
    "Sent label": '<small>Sent</small>' in a,
    "MC preserved": '${fmtMc(token.mc ?? token.market_cap_usd)} MC' in a,
    "age badge preserved": 'data-explore-age-badge="v14"' in a,
    "v15 CSS marker": marker in c,
    "recipient image overlay preserved": 'bottom:10px;' in c,
}
for label, ok in checks.items():
    if not ok:
        raise SystemExit(f"ERROR: verification failed: {label}")
    print("PASS", label)
PY

echo
echo "== Project checks =="
npm run check

echo
echo "== Git diff =="
git diff --stat

git add src/app.js src/styles.css

if git diff --cached --quiet; then
  echo "No new changes to commit (patch may already be installed)."
else
  git commit -m "Separate Explore token image and stats"
  git push
fi

echo
echo "DONE: Explore Card Info v15 installed, checked, committed, and pushed."
echo "No server restart was performed."
echo "Restart Run/Console manually once, then reload the page."
