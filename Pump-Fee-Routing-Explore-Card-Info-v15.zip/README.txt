Pump Fee Routing — Explore Card Info v15

This patch changes ONLY the LEFT token card inside the Home Explore module.

Result:
- The token image is its own upper section.
- The token age remains in the top-right of the image.
- The X recipient pill remains on the image.
- Token name + ticker move into a separate information area below the image.
- Market Cap is shown on the left of the second row.
- Sent amount is shown on the right as: $0.00 Sent.
- The old text-on-image overlay is removed.
- The shared Explore / Open footer remains in place.

The right Explore card is not changed.
Payments, Analytics and other modules are not changed.
No automatic server restart is performed.

Install in the EXISTING Replit Shell:

rm -rf /tmp/explore-card-info-v15
mkdir -p /tmp/explore-card-info-v15
unzip -o Pump-Fee-Routing-Explore-Card-Info-v15.zip -d /tmp/explore-card-info-v15
bash /tmp/explore-card-info-v15/install.sh

The installer runs npm run check, commits and pushes.
Restart Run/Console manually once after installation.
