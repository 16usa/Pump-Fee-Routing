from pathlib import Path

path = Path('src/styles.css')
css = path.read_text()

marker = '/* top-tokens-name-badge-match-launch-v24-8 */'
if marker not in css:
    css += r'''

/* top-tokens-name-badge-match-launch-v24-8
   Top Tokens recipient chip: make the name and verified badge match
   the size used in the Launch block identity row. */
.home-top-token-recipient b{
  font-size: 16px;
  line-height: 1;
  font-weight: 700;
}

.home-top-token-recipient .x-verified-badge.x-verified-compact{
  width: 13px;
  height: 13px;
  flex-basis: 13px;
  margin-left: 4px;
  vertical-align: -2px;
}

@media (max-width: 640px){
  .home-top-token-recipient b{
    font-size: 16px;
  }

  .home-top-token-recipient .x-verified-badge.x-verified-compact{
    width: 13px;
    height: 13px;
    flex-basis: 13px;
    margin-left: 4px;
  }
}
'''
    path.write_text(css)
    print('src/styles.css: Top Tokens name and badge now match Launch identity sizing')
else:
    print('src/styles.css: patch already installed')

print('PASS: CSS patch prepared')
