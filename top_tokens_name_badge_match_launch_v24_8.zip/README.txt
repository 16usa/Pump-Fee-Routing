Top Tokens Name + Badge Match Launch v24.8

Changes only the recipient chip inside Top Tokens cards:
- makes the GG text size match the Launch block identity row;
- makes the blue verified badge size match the Launch block identity row;
- keeps the existing chip/avatar layout otherwise;
- no automatic server restart.

Install in the existing Replit Shell:

rm -rf /tmp/top_tokens_name_badge_match_launch_v24_8 && mkdir -p /tmp/top_tokens_name_badge_match_launch_v24_8 && unzip -o top_tokens_name_badge_match_launch_v24_8.zip -d /tmp/top_tokens_name_badge_match_launch_v24_8 && bash /tmp/top_tokens_name_badge_match_launch_v24_8/install.sh
