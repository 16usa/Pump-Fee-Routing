Typography Scale 110% — v24.58

What this patch does
- Increases every px-based CSS font-size in src/styles.css by exactly 10%.
- Also scales px values inside font-size clamp(...) expressions.
- Leaves non-px font sizes such as 0, inherit, and em untouched.
- Leaves unitless line-height values untouched so existing vertical proportions remain intact.
- Does not change padding, card dimensions, margins, borders, images, or 3D/UI geometry.

Why this approach
The project currently contains roughly one thousand explicit font-size declarations,
many of them in px and many later overrides. A single root font-size:110% would not
affect those px rules, so this patch scales the actual source values.

Safety / rollback
Before changing anything, install.sh saves the exact current src/styles.css to:
.patch-backups/typography_scale_110_v24_58/styles.css.before

If you do not like the result, run:
bash /tmp/typography_scale_110_v24_58/rollback.sh

That restores the exact stylesheet that existed immediately before installation,
runs npm run check, commits the rollback, and pushes it.

No automatic server restart is performed.
