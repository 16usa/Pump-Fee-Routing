#!/usr/bin/env bash
set -euo pipefail
PATCH_NAME="typography_scale_110_v24_58"
CSS="src/styles.css"
MARKER="typography-scale-110-v24-58"
BACKUP=".patch-backups/${PATCH_NAME}/styles.css.before"

if [ ! -f "$CSS" ]; then
  echo "ERROR: missing $CSS"
  echo "Run this from the existing Replit project root."
  exit 1
fi

if grep -q "$MARKER" "$CSS"; then
  echo "PASS: ${PATCH_NAME} is already installed."
  exit 0
fi

echo "==> Backing up current typography"
mkdir -p "$(dirname "$BACKUP")"
cp "$CSS" "$BACKUP"

echo "==> Applying +10% typography scale"
python3 "$(dirname "$0")/patch.py"

echo "==> Verifying marker"
grep -q "$MARKER" "$CSS"

echo "==> Running project check"
npm run check

echo "==> Git diff"
git diff --stat -- "$CSS"

git add "$CSS"
if git diff --cached --quiet; then
  echo "==> No new changes to commit."
else
  git commit -m "Increase site typography by 10 percent"
  git push origin main
fi

echo
echo "PASS: ${PATCH_NAME} installed."
echo "No server restart was performed."
echo "To restore the exact previous typography, run rollback.sh from this patch."
