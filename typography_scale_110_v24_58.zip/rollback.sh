#!/usr/bin/env bash
set -euo pipefail
PATCH_NAME="typography_scale_110_v24_58"
CSS="src/styles.css"
BACKUP=".patch-backups/${PATCH_NAME}/styles.css.before"

if [ ! -f "$BACKUP" ]; then
  echo "ERROR: rollback backup not found: $BACKUP"
  exit 1
fi

echo "==> Restoring exact pre-patch stylesheet"
cp "$BACKUP" "$CSS"

echo "==> Running project check"
npm run check

echo "==> Git diff"
git diff --stat -- "$CSS"

git add "$CSS"
if git diff --cached --quiet; then
  echo "==> No rollback changes to commit."
else
  git commit -m "Rollback 10 percent typography increase"
  git push origin main
fi

echo
echo "PASS: typography restored to the exact pre-v24.58 version."
echo "No server restart was performed."
