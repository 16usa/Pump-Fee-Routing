from pathlib import Path
import re

CSS = Path('src/styles.css')
MARKER = '/* typography-scale-110-v24-58 */'

if not CSS.exists():
    raise SystemExit('ERROR: src/styles.css not found. Run from the existing Replit project root.')

src = CSS.read_text()
if MARKER in src:
    print('PASS: typography_scale_110_v24_58 is already installed.')
    raise SystemExit(0)

font_size_decl = re.compile(r'(?P<prefix>font-size\s*:\s*)(?P<value>[^;}]+)', re.I)
px_number = re.compile(r'(?<![A-Za-z0-9_.-])(\d+(?:\.\d+)?)px\b', re.I)
changed_declarations = 0
changed_values = 0

def fmt(n):
    s = f'{n:.3f}'.rstrip('0').rstrip('.')
    return s or '0'

def scale_value(value):
    global changed_values
    local = 0
    def repl(m):
        nonlocal local
        n = float(m.group(1))
        if n == 0:
            return m.group(0)
        local += 1
        return f'{fmt(n * 1.10)}px'
    out = px_number.sub(repl, value)
    changed_values += local
    return out, local

def decl_repl(m):
    global changed_declarations
    value, count = scale_value(m.group('value'))
    if count:
        changed_declarations += 1
    return m.group('prefix') + value

new_src = font_size_decl.sub(decl_repl, src)
if changed_declarations == 0:
    raise SystemExit('ERROR: no px-based font-size declarations were found.')

new_src += f'''\n\n{MARKER}\n/*\n  Global typography experiment:\n  every px-based font-size in this stylesheet was increased by 10%.\n  Unitless line-height values were intentionally left unchanged so vertical\n  proportions follow the enlarged type naturally.\n  Roll back with rollback.sh from the patch package.\n*/\n'''
CSS.write_text(new_src)
print(f'PASS: scaled {changed_declarations} font-size declarations.')
print(f'PASS: scaled {changed_values} px values, including px values inside clamp().')
print('PASS: non-px sizes (0, inherit, em) were left unchanged.')
