Pump Fee Routing — Launch Demo Rotator v1

Adds the missing Launch page elements inspired by UsePaid:
- the small Terms of Use note under the Launch button
- one animated demo notification card above the preview card
- 10 total scenes in one loop: 5, 10, 20, 50, 100 dollars × 2 card states
- soft transitions between scenes
- keeps the rest of the Launch form and preview intact

Installer checks, commits, and pushes origin/main.
No automatic server restart.
