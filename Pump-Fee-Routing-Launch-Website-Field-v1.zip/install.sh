#!/usr/bin/env bash
set -euo pipefail

[ -f src/app.js ] || { echo "Missing src/app.js. Run from the Pump-Fee-Routing project root."; exit 1; }

# Only protect the file this patch edits. Old ZIPs and .conversation files do not block installation.
if [ -n "$(git status --porcelain -- src/app.js)" ]; then
  echo "STOP: src/app.js has uncommitted changes."
  git status --short -- src/app.js
  exit 2
fi

python3 - <<'PY'

from pathlib import Path
import base64

def dec(s): return base64.b64decode(s).decode()
def repl(text, old64, new64, label):
    old,new=dec(old64),dec(new64)
    if old not in text:
        raise SystemExit(f"{label} anchor not found")
    return text.replace(old,new,1)

p=Path('src/app.js')
app=p.read_text()

if 'id="launchWebsite"' in app:
    raise SystemExit('Launch Website field v1 is already installed.')

app=repl(app,'ICAgICAgICAgIDxkaXYgY2xhc3M9ImxhdW5jaC1maWVsZCI+CiAgICAgICAgICAgIDxsYWJlbD5Tb2NpYWwgbGlua3MgPHNtYWxsPihvcHRpb25hbCk8L3NtYWxsPjwvbGFiZWw+CiAgICAgICAgICAgIDxwIGNsYXNzPSJsYXVuY2gtaGVscCI+WW91IGNhbiB1c2UgdGhlIHJlZ2lzdGVyZWQgdG9rZW4gcGFnZSBhcyB0aGUgd2Vic2l0ZSBsaW5rLjwvcD4KICAgICAgICAgICAgPGRpdiBjbGFzcz0ibGF1bmNoLXR3byI+PGlucHV0IGlkPSJsYXVuY2hUZWxlZ3JhbSIgcGxhY2Vob2xkZXI9IlRlbGVncmFtIj48aW5wdXQgaWQ9ImxhdW5jaFgiIHBsYWNlaG9sZGVyPSJYIj48L2Rpdj4KICAgICAgICAgIDwvZGl2Pg==','ICAgICAgICAgIDxkaXYgY2xhc3M9ImxhdW5jaC1maWVsZCI+CiAgICAgICAgICAgIDxsYWJlbD5Tb2NpYWwgbGlua3MgPHNtYWxsPihvcHRpb25hbCk8L3NtYWxsPjwvbGFiZWw+CiAgICAgICAgICAgIDxwIGNsYXNzPSJsYXVuY2gtaGVscCI+WW91IGNhbiB1c2UgdGhlIHJlZ2lzdGVyZWQgdG9rZW4gcGFnZSBhcyB0aGUgd2Vic2l0ZSBsaW5rLjwvcD4KICAgICAgICAgICAgPGlucHV0IGlkPSJsYXVuY2hXZWJzaXRlIiB0eXBlPSJ1cmwiIGlucHV0bW9kZT0idXJsIiBhdXRvY29tcGxldGU9InVybCIgYXV0b2NhcGl0YWxpemU9Im5vbmUiIHNwZWxsY2hlY2s9ImZhbHNlIiBwbGFjZWhvbGRlcj0iaHR0cHM6Ly95b3Vyc2l0ZS5jb20iPgogICAgICAgICAgICA8ZGl2IGNsYXNzPSJsYXVuY2gtdHdvIj48aW5wdXQgaWQ9ImxhdW5jaFRlbGVncmFtIiBwbGFjZWhvbGRlcj0iVGVsZWdyYW0iPjxpbnB1dCBpZD0ibGF1bmNoWCIgcGxhY2Vob2xkZXI9IlgiPjwvZGl2PgogICAgICAgICAgPC9kaXY+','Social links block')
app=repl(app,'ICBjb25zdCB0d2l0dGVyPWRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJyNsYXVuY2hYJyk/LnZhbHVlLnRyaW0oKXx8Jyc7CiAgY29uc3QgdGVsZWdyYW09ZG9jdW1lbnQucXVlcnlTZWxlY3RvcignI2xhdW5jaFRlbGVncmFtJyk/LnZhbHVlLnRyaW0oKXx8Jyc7CiAgY29uc3QgZmlsZT1kb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcjbGF1bmNoSW1hZ2UnKT8uZmlsZXM/LlswXTs=','ICBjb25zdCB3ZWJzaXRlPWRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJyNsYXVuY2hXZWJzaXRlJyk/LnZhbHVlLnRyaW0oKXx8Jyc7CiAgY29uc3QgdHdpdHRlcj1kb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcjbGF1bmNoWCcpPy52YWx1ZS50cmltKCl8fCcnOwogIGNvbnN0IHRlbGVncmFtPWRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJyNsYXVuY2hUZWxlZ3JhbScpPy52YWx1ZS50cmltKCl8fCcnOwogIGNvbnN0IGZpbGU9ZG9jdW1lbnQucXVlcnlTZWxlY3RvcignI2xhdW5jaEltYWdlJyk/LmZpbGVzPy5bMF07','Launch metadata collection')
app=repl(app,'ICAgICAgZGVzY3JpcHRpb24sCiAgICAgIHR3aXR0ZXIsCiAgICAgIHRlbGVncmFtLAogICAgICBpbWFnZV9iYXNlNjQ6aW1hZ2VCYXNlNjQs','ICAgICAgZGVzY3JpcHRpb24sCiAgICAgIHdlYnNpdGUsCiAgICAgIHR3aXR0ZXIsCiAgICAgIHRlbGVncmFtLAogICAgICBpbWFnZV9iYXNlNjQ6aW1hZ2VCYXNlNjQs','Launch metadata payload')

p.write_text(app)
print('Launch Website field v1 installed.')

PY

node --check src/app.js
npm run check

node <<'NODE'
const fs=require('fs');
const app=fs.readFileSync('src/app.js','utf8');
const checks=[
  ['Website field', app.includes('id="launchWebsite"')],
  ['Website placeholder', app.includes('placeholder="https://yoursite.com"')],
  ['Website read before launch', app.includes("document.querySelector('#launchWebsite')")],
  ['Website sent to metadata', app.includes('description,\n      website,\n      twitter,\n      telegram,')],
];
let bad=0;
for(const [name,ok] of checks){
  console.log(`${ok?'PASS':'FAIL'} ${name}`);
  if(!ok)bad++;
}
if(bad)process.exit(1);
NODE

git add src/app.js

if git diff --cached --quiet; then
  echo "No staged changes; nothing to commit."
else
  git commit -m "Add website field to Launch"
fi

git push origin main

echo
echo "DONE: Launch Website field checked, committed, and pushed to GitHub."
echo "Old ZIP files and .conversation entries were intentionally ignored."
echo "No server restart was performed."
echo "Restart Console/Run manually once to load the updated Launch page."
