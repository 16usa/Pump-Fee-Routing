Pump Fee Routing — Launch Website Field v1

Adds the missing optional Website field under Social links, above Telegram and X.
The value is passed into the existing Pump metadata upload as `website`.
No other Launch layout or behavior is changed.

Installer checks only src/app.js, so old ZIP files and .conversation changes do not block it.
It runs syntax/project checks, commits, and pushes origin/main. No automatic restart.
