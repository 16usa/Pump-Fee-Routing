Pump Fee Routing — Payments Reference Match v16

Changes only the HOME Payments preview block:
- up to 3 real recent payments
- dark rounded rows like the supplied reference
- amount + recipient on the left
- token -> recipient route visuals in the middle
- time on the right
- bottom fade
- Payments / Open -> footer at the bottom
- honest empty state when no real payments exist
- no automatic restart

Install:
rm -rf /tmp/payments-reference-match-v16
mkdir -p /tmp/payments-reference-match-v16
unzip -o Pump-Fee-Routing-Payments-Reference-Match-v16.zip -d /tmp/payments-reference-match-v16
bash /tmp/payments-reference-match-v16/install.sh
