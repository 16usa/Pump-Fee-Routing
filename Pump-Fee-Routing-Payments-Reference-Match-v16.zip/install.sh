#!/usr/bin/env bash
set -euo pipefail

echo "== Payments Reference Match v16 =="

for f in src/app.js src/styles.css; do
  if [ ! -f "$f" ]; then
    echo "ERROR: $f not found. Run this from the existing Replit project workspace."
    exit 1
  fi
done

python3 <<'PYCODE'
from pathlib import Path
import re

app_path = Path("src/app.js")
css_path = Path("src/styles.css")
app = app_path.read_text()
css = css_path.read_text()

app_marker = 'data-payments-reference="v16"'
css_marker = '/* payments-reference-match-v16 */'

if 'function homePreviewDeck(h,top)' not in app:
    raise SystemExit("ERROR: homePreviewDeck() not found.")

app = app.replace(
    "const payments=(h.payments||[]).filter(Boolean).slice(0,5);",
    "const payments=(h.payments||[]).filter(Boolean).slice(0,3);"
)

if app_marker not in app:
    start = app.find("  const paymentMini=(p)=>{")
    end = app.find("\n\n  const leadProfile=", start)
    if start < 0 or end < 0:
        raise SystemExit("ERROR: paymentMini renderer block not found.")

    new_payment = '''  const paymentMini=(p)=>{
    if(!p) return '';
    const amount=p.amount_usd??p.amount??0;
    const handle=String(p.recipient_handle||p.handle||p.to||'').replace(/^@/,'').trim();
    const to=p.display_name||handle||'recipient';
    const profile=profiles.find(x=>String(x?.handle||'').replace(/^@/,'').trim().toLowerCase()===handle.toLowerCase())||null;
    const mint=String(p.mint||p.token_mint||p.mints||'').split(',').filter(Boolean)[0]?.trim()||'';
    const token=tokens.find(x=>String(x?.mint||x?.contract||'').trim()===mint)||null;
    const tokenInitial=esc(initials(token?.symbol||token?.name||'P'));
    const tokenDirect=String(token?.image_url||'').trim();
    const tokenVisual=mint
      ? `<span class="home-v2-payment-route-token"><img src="/api/token-image/${encodeURIComponent(mint)}" alt="" loading="eager" decoding="async" onerror="${tokenDirect?`this.onerror=function(){this.style.display='none';this.nextElementSibling.style.display='grid'};this.src='${esc(tokenDirect)}'`:`this.style.display='none';this.nextElementSibling.style.display='grid'`}"><i style="display:none">${tokenInitial}</i></span>`
      : `<span class="home-v2-payment-route-token"><i>${tokenInitial}</i></span>`;
    const recipientVisual=handle
      ? recipientAvatar(handle,to,false,profile?.avatar_url||'')
      : avatar(to,false,'');
    const verified=(p.verified||profile?.verified)?'<em class="home-v2-payment-verified">✓</em>':'';
    return `<div class="home-v2-payment-mini home-v2-payment-ref-row">
      <div class="home-v2-payment-copy">
        <strong>${fmtMoney(amount)}</strong>
        <span>sent to <b>${esc(to)}</b>${verified}</span>
      </div>
      <div class="home-v2-payment-route">
        ${tokenVisual}
        <span class="home-v2-payment-swap">⇄</span>
        <span class="home-v2-payment-recipient">${recipientVisual}<i>X</i></span>
      </div>
      <time>${esc(ago(p.sent_at||p.created_at))}</time>
    </div>`;
  };'''

    app = app[:start] + new_payment + app[end:]

    old_card = '''      <a class="home-preview-card home-ref-card home-v2-payments-card" href="#/money">
        <div class="home-preview-label"><b>Payments</b><span>Open →</span></div>
        ${payments.length
          ? `<div class="home-v2-payments-list">${payments.map(paymentMini).join('')}</div>`
          : `<div class="home-v2-empty-row"><i></i><b>$</b><i></i><span>No payouts recorded yet.</span></div>`}
      </a>'''
    new_card = '''      <a class="home-preview-card home-ref-card home-v2-payments-card" data-payments-reference="v16" href="#/money">
        <div class="home-v2-payments-stage">
          ${payments.length
            ? `<div class="home-v2-payments-list">${payments.map(paymentMini).join('')}</div>`
            : `<div class="home-v2-payments-empty-ref"><i></i><b>$</b><i></i><span>No payouts recorded yet.</span></div>`}
          <div class="home-v2-payments-bottom-shade" aria-hidden="true"></div>
          <div class="home-v2-payments-footer"><strong>Payments</strong><span>Open →</span></div>
        </div>
      </a>'''
    if old_card not in app:
        raise SystemExit("ERROR: old Payments preview card markup not found.")
    app = app.replace(old_card, new_card, 1)
    app_path.write_text(app)
    print("PASS Payments preview markup updated")
else:
    print("PASS Payments v16 markup already installed")

css = css_path.read_text()
if css_marker not in css:
    css_patch = r'''
/* payments-reference-match-v16 */

.home-reference-v2-previews .home-preview-card.home-v2-payments-card[data-payments-reference="v16"]{
  position:relative;
  display:block;
  min-height:246px;
  padding:12px;
  overflow:hidden;
  border:1px solid #303030;
  border-radius:20px;
  background:#171717;
  box-shadow:none;
  isolation:isolate;
}
.home-v2-payments-card[data-payments-reference="v16"] .home-v2-payments-stage{
  position:relative;
  min-height:220px;
  padding-bottom:42px;
}
.home-v2-payments-card[data-payments-reference="v16"] .home-v2-payments-list{
  position:relative;
  z-index:1;
  display:grid;
  gap:8px;
}
.home-v2-payments-card[data-payments-reference="v16"] .home-v2-payment-ref-row{
  min-height:54px;
  display:grid;
  grid-template-columns:minmax(0,1fr) auto 28px;
  align-items:center;
  gap:10px;
  padding:8px 11px;
  border:0;
  border-radius:13px;
  background:#080808;
  box-shadow:0 7px 18px rgba(0,0,0,.30);
}
.home-v2-payments-card[data-payments-reference="v16"] .home-v2-payment-copy{
  min-width:0;
  display:grid;
  gap:1px;
}
.home-v2-payments-card[data-payments-reference="v16"] .home-v2-payment-copy>strong{
  color:#f2f2f2;
  font-size:19px;
  line-height:1;
  font-weight:520;
  letter-spacing:-.035em;
}
.home-v2-payments-card[data-payments-reference="v16"] .home-v2-payment-copy>span{
  min-width:0;
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
  color:#777;
  font-size:10px;
  line-height:1.15;
}
.home-v2-payments-card[data-payments-reference="v16"] .home-v2-payment-copy>span b{
  color:#e7e7e7;
  font-size:11px;
  font-weight:650;
}
.home-v2-payment-verified{
  display:inline-grid;
  place-items:center;
  width:11px;
  height:11px;
  margin-left:4px;
  border-radius:50%;
  background:#1597e5;
  color:#fff;
  font-size:7px;
  font-style:normal;
  vertical-align:1px;
}
.home-v2-payments-card[data-payments-reference="v16"] .home-v2-payment-route{
  display:flex;
  align-items:center;
  justify-content:center;
  gap:8px;
  min-width:82px;
}
.home-v2-payment-route-token,
.home-v2-payment-recipient{
  position:relative;
  width:30px;
  height:30px;
  flex:0 0 30px;
}
.home-v2-payment-route-token{
  overflow:hidden;
  border-radius:50%;
  background:#111;
}
.home-v2-payment-route-token img,
.home-v2-payment-route-token>i{
  position:absolute;
  inset:0;
  width:100%;
  height:100%;
  border-radius:50%;
}
.home-v2-payment-route-token img{
  display:block;
  object-fit:cover;
}
.home-v2-payment-route-token>i{
  display:grid;
  place-items:center;
  background:radial-gradient(circle at 38% 30%,#333,#111 62%,#080808);
  color:#aaa;
  font-size:10px;
  font-style:normal;
  font-weight:700;
}
.home-v2-payment-swap{
  color:#666;
  font-size:15px;
  line-height:1;
}
.home-v2-payment-recipient>.avatar{
  width:30px;
  height:30px;
  border:0;
}
.home-v2-payment-recipient>i{
  position:absolute;
  right:-2px;
  bottom:-2px;
  z-index:3;
  display:grid;
  place-items:center;
  width:12px;
  height:12px;
  border-radius:3px;
  background:#0a0a0a;
  color:#f0f0f0;
  font-size:8px;
  font-style:normal;
  line-height:1;
}
.home-v2-payments-card[data-payments-reference="v16"] .home-v2-payment-ref-row>time{
  justify-self:end;
  color:#737373;
  font-size:8px;
  line-height:1;
  white-space:nowrap;
}
.home-v2-payments-card[data-payments-reference="v16"] .home-v2-payments-empty-ref{
  min-height:150px;
  display:flex;
  align-items:center;
  justify-content:center;
  gap:8px;
  color:#666;
  font-size:9px;
}
.home-v2-payments-card[data-payments-reference="v16"] .home-v2-payments-empty-ref>i{
  width:34px;
  height:34px;
  border:1px solid #292929;
  border-radius:50%;
  background:#101010;
}
.home-v2-payments-card[data-payments-reference="v16"] .home-v2-payments-empty-ref>b{
  color:#707070;
  font-size:18px;
}
.home-v2-payments-bottom-shade{
  position:absolute;
  left:-12px;
  right:-12px;
  bottom:-12px;
  z-index:2;
  height:76px;
  pointer-events:none;
  background:linear-gradient(180deg,rgba(23,23,23,0) 0%,rgba(23,23,23,.56) 58%,#171717 100%);
}
.home-v2-payments-footer{
  position:absolute;
  left:6px;
  right:6px;
  bottom:3px;
  z-index:3;
  display:flex;
  align-items:center;
  justify-content:space-between;
  pointer-events:none;
}
.home-v2-payments-footer strong,
.home-v2-payments-footer span{
  color:#777;
  font-size:12px;
  line-height:1;
  font-weight:450;
  letter-spacing:0;
  white-space:nowrap;
}
@media(max-width:640px){
  .home-reference-v2-previews .home-preview-card.home-v2-payments-card[data-payments-reference="v16"]{
    min-height:218px;
    padding:9px;
    border-radius:16px;
  }
  .home-v2-payments-card[data-payments-reference="v16"] .home-v2-payments-stage{
    min-height:198px;
    padding-bottom:36px;
  }
  .home-v2-payments-card[data-payments-reference="v16"] .home-v2-payments-list{gap:7px}
  .home-v2-payments-card[data-payments-reference="v16"] .home-v2-payment-ref-row{
    min-height:49px;
    grid-template-columns:minmax(0,1fr) auto 25px;
    gap:7px;
    padding:7px 9px;
    border-radius:11px;
  }
  .home-v2-payments-card[data-payments-reference="v16"] .home-v2-payment-copy>strong{font-size:17px}
  .home-v2-payments-card[data-payments-reference="v16"] .home-v2-payment-copy>span{font-size:8.5px}
  .home-v2-payments-card[data-payments-reference="v16"] .home-v2-payment-copy>span b{font-size:9px}
  .home-v2-payment-route-token,
  .home-v2-payment-recipient,
  .home-v2-payment-recipient>.avatar{
    width:27px;
    height:27px;
    flex-basis:27px;
  }
  .home-v2-payments-card[data-payments-reference="v16"] .home-v2-payment-route{
    gap:6px;
    min-width:74px;
  }
  .home-v2-payment-swap{font-size:13px}
  .home-v2-payments-card[data-payments-reference="v16"] .home-v2-payment-ref-row>time{font-size:7px}
  .home-v2-payments-bottom-shade{
    left:-9px;
    right:-9px;
    bottom:-9px;
    height:67px;
  }
  .home-v2-payments-footer{
    left:4px;
    right:4px;
    bottom:2px;
  }
  .home-v2-payments-footer strong,
  .home-v2-payments-footer span{font-size:11px}
}
'''
    css_path.write_text(css.rstrip() + "\n\n" + css_patch + "\n")
    print("PASS Payments reference CSS added")
else:
    print("PASS Payments v16 CSS already installed")

app = app_path.read_text()
css = css_path.read_text()
checks = {
    "payment marker": app_marker in app,
    "three payment rows": ".slice(0,3)" in app,
    "payment route markup": "home-v2-payment-route" in app,
    "payments footer markup": "home-v2-payments-footer" in app,
    "CSS marker": css_marker in css,
}
for label, ok in checks.items():
    if not ok:
        raise SystemExit(f"ERROR: verification failed: {label}")
    print("PASS", label)
PYCODE

echo
echo "== Project checks =="
npm run check

echo
echo "== Git diff =="
git diff --stat

git add src/app.js src/styles.css

if git diff --cached --quiet; then
  echo "No new changes to commit."
else
  git commit -m "Match Payments preview to reference layout"
  git push
fi

echo
echo "DONE: Payments Reference Match v16 installed, checked, committed, and pushed."
echo "No server restart was performed."
echo "Restart Run/Console manually once, then reload the page."
