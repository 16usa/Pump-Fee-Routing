#!/usr/bin/env bash
set -euo pipefail

for f in src/app.js src/styles.css server/api.js; do
  [ -f "$f" ] || { echo "Missing $f"; exit 1; }
done

cp src/app.js /tmp/Pump-Fee-Routing-app-before-home-explore-v6.js
cp src/styles.css /tmp/Pump-Fee-Routing-styles-before-home-explore-v6.css
cp server/api.js /tmp/Pump-Fee-Routing-api-before-home-explore-v6.js

restore() {
  cp /tmp/Pump-Fee-Routing-app-before-home-explore-v6.js src/app.js
  cp /tmp/Pump-Fee-Routing-styles-before-home-explore-v6.css src/styles.css
  cp /tmp/Pump-Fee-Routing-api-before-home-explore-v6.js server/api.js
}

python3 - <<'PY2'
from pathlib import Path
import re

app_path = Path('src/app.js')
styles_path = Path('src/styles.css')
api_path = Path('server/api.js')

new_block = r'''
      <a class="home-preview-card home-ref-card home-ref-explore-card home-explore-reference-v6" href="#/explore">
        ${(() => {
          const withVisual = tokens.filter(t => String(t?.mint || t?.contract || t?.image_url || '').trim());
          const primary = withVisual[0] || tokens[0] || null;
          const secondary = withVisual.find(t => t !== primary) || primary || null;

          const findProfile = (token) => {
            const handle = String(token?.profile || token?.recipient_handle || token?.recipient_handles || '').replace(/^@/, '').trim().toLowerCase();
            if (!handle) return null;
            return profiles.find(p => String(p?.handle || '').replace(/^@/, '').trim().toLowerCase() === handle) || null;
          };

          const renderTokenArt = (token, className) => {
            const mint = String(token?.mint || token?.contract || '').trim();
            const direct = String(token?.image_url || '').trim();
            if (mint) {
              return `<img class="home-explore-v6-art ${className}" src="/api/token-image/${encodeURIComponent(mint)}" alt="" loading="eager" decoding="async" onerror="this.style.display='none';this.nextElementSibling.style.display='block'"><span class="home-explore-v6-fallback ${className}" style="display:none"></span>`;
            }
            if (direct) {
              return `<img class="home-explore-v6-art ${className}" src="${esc(direct)}" alt="" loading="eager" decoding="async" onerror="this.style.display='none';this.nextElementSibling.style.display='block'"><span class="home-explore-v6-fallback ${className}" style="display:none"></span>`;
            }
            return `<span class="home-explore-v6-fallback ${className}"></span>`;
          };

          const renderRecipient = (token) => {
            const profile = findProfile(token);
            const handle = String(token?.profile || token?.recipient_handle || token?.recipient_handles || '').replace(/^@/, '').trim();
            const label = profile?.display_name || handle || 'Recipient';
            const avatarUrl = String(profile?.avatar_url || '').trim();
            return `<div class="home-explore-v6-recipient"><i>$</i>${avatar(label, false, avatarUrl)}<b>${esc(label)}</b></div>`;
          };

          const renderPrimary = (token) => {
            if (!token) {
              return `<div class="home-explore-v6-module is-primary is-empty">
                <div class="home-explore-v6-media home-explore-v6-media-primary">${renderTokenArt(null, 'primary')}</div>
                <div class="home-explore-v6-copy">
                  <div class="home-explore-v6-row"><strong>Token</strong><b>$0.00</b></div>
                  <div class="home-explore-v6-meta"><span>—</span><span>$0 MC</span></div>
                </div>
              </div>`;
            }
            return `<div class="home-explore-v6-module is-primary">
              <div class="home-explore-v6-media home-explore-v6-media-primary">
                ${renderTokenArt(token, 'primary')}
                <div class="home-explore-v6-venue">${platformBadge(token.platform || 'Pump')}</div>
                ${renderRecipient(token)}
              </div>
              <div class="home-explore-v6-copy">
                <div class="home-explore-v6-row"><strong>${esc(token.name || 'Token')}</strong><b>${fmtMoney(token.sent || 0)}</b></div>
                <div class="home-explore-v6-meta"><span>${esc(token.symbol || 'TOKEN')}</span><span>${fmtMc(token.mc ?? token.market_cap_usd)} MC</span></div>
              </div>
            </div>`;
          };

          const renderSecondary = (token) => {
            return `<div class="home-explore-v6-open-card${token ? '' : ' is-empty'}">
              <div class="home-explore-v6-open-media">${renderTokenArt(token, 'secondary')}</div>
              <div class="home-explore-v6-open-fade" aria-hidden="true"></div>
              <div class="home-explore-v6-open-label">Open →</div>
            </div>`;
          };

          return `<div class="home-explore-v6-stage">
            <div class="home-explore-v6-primary-slot">${renderPrimary(primary)}</div>
            <div class="home-explore-v6-secondary-slot">${renderSecondary(secondary)}</div>
            <div class="home-explore-v6-explore-label">Explore</div>
            <div class="home-explore-v6-stage-fade" aria-hidden="true"></div>
          </div>`;
        })()}
      </a>
'''

css_patch = r'''
/* home-explore-reference-match-v6 */
.home-reference-v2-previews .home-preview-card.home-ref-explore-card.home-explore-reference-v6{position:relative;min-height:0;aspect-ratio:1.34/1;padding:0;overflow:hidden;border:1px solid #303030;border-radius:20px;background:#171717;color:#fff;text-decoration:none;box-shadow:none;isolation:isolate}
.home-explore-reference-v6,.home-explore-reference-v6 *{animation:none!important}
.home-explore-v6-stage{position:absolute;inset:0;overflow:hidden;background:linear-gradient(180deg,#1a1a1a 0%,#171717 100%)}
.home-explore-v6-stage::before{content:'';position:absolute;inset:0;background:radial-gradient(circle at 22% 28%, rgba(255,255,255,.07) 0, rgba(255,255,255,.02) 18%, transparent 34%),radial-gradient(circle at 80% 24%, rgba(255,255,255,.04) 0, rgba(255,255,255,.015) 20%, transparent 38%);pointer-events:none}
.home-explore-v6-primary-slot{position:absolute;left:3.2%;top:4.8%;width:50.2%;height:63.2%;z-index:2}
.home-explore-v6-secondary-slot{position:absolute;right:-1.2%;top:40.5%;width:39.8%;height:39.8%;z-index:3}
.home-explore-v6-module,.home-explore-v6-open-card{position:absolute;inset:0;overflow:hidden;border:1px solid #2a2a2a;border-radius:15px;background:#0d0d0d;box-shadow:0 10px 24px rgba(0,0,0,.22)}
.home-explore-v6-media,.home-explore-v6-open-media{position:relative;overflow:hidden;background:#0a0a0a}
.home-explore-v6-media-primary{height:73%}.home-explore-v6-open-media{height:100%}
.home-explore-v6-art,.home-explore-v6-fallback{position:absolute;inset:0;width:100%;height:100%}
.home-explore-v6-art{display:block;object-fit:cover;object-position:center;transform:none!important;transition:none!important;filter:saturate(.96) contrast(1.02)}
.home-explore-v6-fallback{display:block;background:radial-gradient(circle at 50% 40%, rgba(255,255,255,.08) 0, rgba(255,255,255,.03) 20%, transparent 45%), linear-gradient(160deg,#1e1e1e 0%,#0f0f0f 58%,#090909 100%)}
.home-explore-v6-venue{position:absolute;right:10px;top:10px;min-height:22px;display:flex;align-items:center;padding:3px 8px;border:1px solid rgba(255,255,255,.13);border-radius:999px;background:rgba(10,10,10,.78);color:#b7b7b7;font-size:10px;backdrop-filter:blur(7px);-webkit-backdrop-filter:blur(7px)}
.home-explore-v6-recipient{position:absolute;left:12px;bottom:12px;max-width:84%;min-height:34px;display:flex;align-items:center;gap:7px;padding:5px 12px 5px 7px;overflow:hidden;border:1px solid rgba(255,255,255,.16);border-radius:999px;background:rgba(5,5,5,.92);box-shadow:0 3px 14px rgba(0,0,0,.25);white-space:nowrap}
.home-explore-v6-recipient>i{width:22px;height:22px;flex:0 0 22px;display:grid;place-items:center;border-radius:50%;background:#151515;color:#d8d8d8;font-size:11px;line-height:1;font-style:normal;font-weight:750}
.home-explore-v6-recipient .avatar{width:23px;height:23px;flex:0 0 23px;margin-left:-11px;border:1px solid #262626;font-size:8px}
.home-explore-v6-recipient>b{min-width:0;overflow:hidden;text-overflow:ellipsis;color:#f1f1f1;font-size:11px;font-weight:650}
.home-explore-v6-copy{position:relative;height:27%;display:grid;align-content:start;gap:5px;padding:11px 12px 10px;background:linear-gradient(180deg,rgba(10,10,10,.96) 0%, rgba(12,12,12,.99) 100%)}
.home-explore-v6-row{display:flex;align-items:baseline;justify-content:space-between;gap:8px}.home-explore-v6-row strong{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#efefef;font-size:12px;font-weight:630}.home-explore-v6-row b{flex:0 0 auto;color:#e0e0e0;font-size:13px;font-weight:650}
.home-explore-v6-meta{display:flex;align-items:baseline;justify-content:space-between;gap:8px;color:#676767;font-size:9px}.home-explore-v6-meta span:first-child{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.home-explore-v6-open-card{border-radius:16px}.home-explore-v6-open-fade{position:absolute;inset:auto 0 0 0;height:46%;background:linear-gradient(180deg,rgba(11,11,11,0) 0%, rgba(11,11,11,.30) 36%, rgba(11,11,11,.88) 100%);z-index:2;pointer-events:none}
.home-explore-v6-open-label{position:absolute;right:16px;bottom:16px;z-index:3;color:#dcdcdc;font-size:17px;line-height:1;font-weight:420;letter-spacing:-.02em}
.home-explore-v6-explore-label{position:absolute;left:4.2%;bottom:5.6%;z-index:5;color:#f1f1f1;font-size:18px;line-height:1;font-weight:500;letter-spacing:-.025em;pointer-events:none}
.home-explore-v6-stage-fade{position:absolute;left:0;right:0;bottom:0;height:32%;z-index:4;pointer-events:none;background:linear-gradient(180deg,rgba(23,23,23,0) 0%, rgba(23,23,23,.06) 22%, rgba(23,23,23,.92) 100%)}
@media (max-width:640px){.home-reference-v2-previews .home-preview-card.home-ref-explore-card.home-explore-reference-v6{aspect-ratio:1.34/1;border-radius:16px}.home-explore-v6-module,.home-explore-v6-open-card{border-radius:12px}.home-explore-v6-primary-slot{left:2.8%;top:4.6%;width:49.4%;height:62.8%}.home-explore-v6-secondary-slot{right:-2.2%;top:46.2%;width:40.4%;height:39.2%}.home-explore-v6-venue{right:8px;top:8px;font-size:8px;min-height:19px;padding:3px 6px}.home-explore-v6-recipient{left:8px;bottom:8px;min-height:28px;gap:5px;padding:4px 9px 4px 5px}.home-explore-v6-recipient>i{width:19px;height:19px;flex-basis:19px;font-size:9px}.home-explore-v6-recipient .avatar{width:19px;height:19px;flex-basis:19px;margin-left:-9px;font-size:7px}.home-explore-v6-recipient>b{font-size:9px}.home-explore-v6-copy{padding:7px 9px 8px;gap:3px}.home-explore-v6-row strong{font-size:10px}.home-explore-v6-row b{font-size:10px}.home-explore-v6-meta{font-size:7px}.home-explore-v6-open-label{right:12px;bottom:12px;font-size:16px}.home-explore-v6-explore-label{font-size:16px;left:4%;bottom:5.2%}}
'''

api_helpers = r'''
/* home-explore-token-image-v6 */
function normalizePumpTokenImage(raw,mint=''){
  let value=String(raw||'').trim();
  if(!value) return '';
  let cid='';
  if(/^ipfs:\/\//i.test(value)){
    cid=value.replace(/^ipfs:\/\//i,'').replace(/^ipfs\//i,'').split(/[/?#]/)[0];
  }else{
    const m=value.match(/\/ipfs\/([^/?#]+)/i);
    if(m) cid=m[1];
  }
  if(cid){
    const src=`https://ipfs.io/ipfs/${cid}`;
    return `https://images.pump.fun/coin-image/${encodeURIComponent(mint)}?variant=public&ipfs=${encodeURIComponent(cid)}&src=${encodeURIComponent(src)}`;
  }
  if(/^https?:\/\//i.test(value)) return value;
  if(/^ar:\/\//i.test(value)) return `https://arweave.net/${value.replace(/^ar:\/\//i,'')}`;
  return '';
}

async function resolvePumpTokenImage(mint){
  const stored=getToken(mint);
  const storedImage=normalizePumpTokenImage(stored?.image_url||'',mint);
  if(storedImage) return storedImage;
  const urls=[...new Set([
    config.pumpMetadataUrlTemplate.replace('{mint}',encodeURIComponent(mint)),
    `https://frontend-api-v3.pump.fun/coins-v2/${encodeURIComponent(mint)}`,
    `https://frontend-api-v3.pump.fun/coins/${encodeURIComponent(mint)}`
  ])];
  for(const target of urls){
    try{
      const r=await fetch(target,{headers:{accept:'application/json'},signal:AbortSignal.timeout(12000)});
      if(!r.ok) continue;
      const meta=await r.json();
      const raw=meta?.image_uri || meta?.image || meta?.metadata?.image_uri || meta?.metadata?.image || meta?.coin_metadata?.image_uri || meta?.coin_metadata?.image || '';
      const image=normalizePumpTokenImage(raw,mint);
      if(image) return image;
    }catch{}
  }
  return '';
}
'''

api_route = r'''
    if(req.method==='GET'&&url.pathname.startsWith('/api/token-image/')){
      const mint=decodeURIComponent(url.pathname.slice('/api/token-image/'.length)).trim();
      if(!/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(mint)) return json(res,400,{error:'Invalid mint'});
      const image=await resolvePumpTokenImage(mint);
      if(!image) return json(res,404,{error:'Token image not found'});
      res.writeHead(302,{location:image,'cache-control':'public, max-age=300'});
      return res.end();
    }
'''

app = app_path.read_text()
markers = [
  '      <a class="home-preview-card home-ref-card home-ref-explore-card home-explore-reference-v6" href="#/explore">',
  '      <a class="home-preview-card home-ref-card home-ref-explore-card home-explore-reference-v5" href="#/explore">',
  '      <a class="home-preview-card home-ref-card home-ref-explore-card home-explore-modules-v4" href="#/explore">',
  '      <a class="home-preview-card home-ref-card home-ref-explore-card home-explore-reference-v3" href="#/explore">',
  '      <a class="home-preview-card home-ref-card home-ref-explore-card home-explore-reference-v2" href="#/explore">',
  '      <a class="home-preview-card home-ref-card home-ref-explore-card" href="#/explore">'
]
start = -1
for marker in markers:
    start = app.find(marker)
    if start >= 0:
        break
if start < 0:
    raise SystemExit('Could not locate Home Explore preview.')
end_marker = '      <a class="home-preview-card home-ref-card home-v2-payments-card" href="#/money">'
end = app.find(end_marker, start)
if end < 0:
    raise SystemExit('Could not locate Payments after Home Explore.')
app = app[:start] + new_block + app[end:]
app_path.write_text(app)

api = api_path.read_text()
for helper_marker in ['/* home-explore-token-image-v6', '/* home-explore-token-image-v5', '/* home-explore-token-image-v3']:
    hs = api.find(helper_marker)
    if hs >= 0:
        he = api.find('export async function handleApi', hs)
        if he < 0:
            raise SystemExit('Could not refresh existing Explore image helper.')
        api = api[:hs] + api[he:]
        break
anchor = 'export async function handleApi(req,res,url){'
pos = api.find(anchor)
if pos < 0:
    raise SystemExit('API handler anchor not found.')
api = api[:pos] + api_helpers + '\n' + api[pos:]
api = re.sub(r"\n\s*if\(req\.method===['\"]GET['\"]&&url\.pathname\.startsWith\(['\"]/api/token-image/['\"]\)\)\{.*?\n\s*\}\n", '\n', api, flags=re.S)
route_anchor = '  try{\n'
ri = api.find(route_anchor, api.find('export async function handleApi'))
if ri < 0:
    raise SystemExit('API try anchor not found.')
ri += len(route_anchor)
api = api[:ri] + api_route + api[ri:]
api_path.write_text(api)

css = styles_path.read_text()
for marker in ['/* home-explore-reference-match-v6', '/* home-explore-reference-match-v5', '/* home-explore-modules-v4', '/* home-explore-reference-match-v3', '/* home-explore-reference-match-v2', '/* home-explore-static-reference-v1']:
    p = css.find(marker)
    if p >= 0:
        css = css[:p].rstrip() + '\n'
css += '\n\n' + css_patch + '\n'
styles_path.write_text(css)
print('Home Explore Reference Match v6 installed.')
PY2

if ! node --check src/app.js; then
  restore
  echo "src/app.js syntax failed; restored originals."
  exit 2
fi
if ! node --check server/api.js; then
  restore
  echo "server/api.js syntax failed; restored originals."
  exit 3
fi
if ! npm run check; then
  restore
  echo "Project check failed; restored originals."
  exit 4
fi

node <<'NODE'
const fs=require('fs');
const app=fs.readFileSync('src/app.js','utf8');
const css=fs.readFileSync('src/styles.css','utf8');
const api=fs.readFileSync('server/api.js','utf8');
const s=app.indexOf('home-explore-reference-v6');
const e=app.indexOf('home-v2-payments-card',s);
const block=app.slice(s,e);
const checks=[
  ['Explore v6 marker', s>=0],
  ['primary slot', block.includes('home-explore-v6-primary-slot')],
  ['secondary slot', block.includes('home-explore-v6-secondary-slot')],
  ['explore label only', block.includes('home-explore-v6-explore-label') && !block.includes('home-explore-v5-footer')],
  ['single open label location', block.includes('home-explore-v6-open-label') && !block.includes('<span>Open →</span>')],
  ['recipient pill', block.includes('home-explore-v6-recipient')],
  ['token image resolver used', block.includes('/api/token-image/')],
  ['CSS v6 marker', css.includes('home-explore-reference-match-v6')],
  ['server image route', api.includes("url.pathname.startsWith('/api/token-image/')")],
  ['Pump image helper', api.includes('normalizePumpTokenImage')],
  ['Payments preserved', e>=0],
  ['wallet code preserved', app.includes('function connectWallet')]
];
let bad=0;
for(const [name,ok] of checks){
  console.log((ok?'PASS':'FAIL')+' '+name);
  if(!ok) bad++;
}
if(bad) process.exit(1);
NODE

git add src/app.js src/styles.css server/api.js
if git diff --cached --quiet; then
  echo "No new changes to commit."
else
  git commit -m "Refine Home Explore preview closer to reference"
  git push origin main
fi

echo
echo "DONE: Home Explore Reference Match v6 installed, checked, committed, and pushed."
echo "Scope: Home Explore preview + its token-image resolver only."
echo "It keeps the rest of Home untouched."
echo "No server restart was performed."
echo "Restart Console/Run manually once, then reload Home."
