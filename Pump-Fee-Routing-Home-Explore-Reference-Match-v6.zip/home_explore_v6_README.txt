Pump Fee Routing — Home Explore Reference Match v6

What this patch changes
- Rebuilds only the Home -> Explore preview block.
- Removes the duplicate external "Open →".
- Leaves only one "Open →" inside the right mini-card.
- Removes the big text fallback letter and uses a neutral dark fallback instead.
- Makes the left side behave like a module card, not a plain image block.
- Keeps the rest of Home unchanged.

Install from Replit Shell
rm -rf /tmp/home-explore-v6
mkdir -p /tmp/home-explore-v6
unzip -o /mnt/data/Pump-Fee-Routing-Home-Explore-Reference-Match-v6.zip -d /tmp/home-explore-v6
bash /tmp/home-explore-v6/install.sh

After install
- Restart Console/Run manually once.
- Reload the Home page and check only the Explore block first.
