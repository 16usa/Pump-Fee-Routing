Pump Fee Routing — Home Explore Reference Match v6

What this patch does
- Repairs the Home > Explore preview block again to match the reference more closely.
- Removes the duplicate lower "Open →" so only the single in-card Open remains on the right teaser card.
- Keeps the Explore label at the lower-left of the overall block.
- Makes the left preview behave like a composed module instead of a generic placeholder layout.
- Preserves the Pump token-image resolver route used by the Explore preview.

Install from the existing workspace shell:
rm -rf /tmp/home-explore-v6
mkdir -p /tmp/home-explore-v6
unzip -o /mnt/data/Pump-Fee-Routing-Home-Explore-Reference-Match-v6.zip -d /tmp/home-explore-v6
bash /tmp/home-explore-v6/install.sh

Notes
- No automatic server restart is performed.
- After install, restart Console/Run manually once and reload Home.
