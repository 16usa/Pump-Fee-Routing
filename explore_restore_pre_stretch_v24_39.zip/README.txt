Explore Restore Pre-Stretch v24.39

This temporarily rolls the Explore projected card back to the geometry from before the stretch attempt:
- left/top remain flush
- width returns to 56%
- card height returns to auto
- image returns to 1:1 aspect ratio
- right preview returns to 30%
- previous bottom spacing returns

Use this instead of v24.38 for now.
No automatic server restart.
