from pathlib import Path

css_path = Path("src/styles.css")
if not css_path.exists():
    raise SystemExit("ERROR: src/styles.css not found. Run from the existing Replit project root.")

css = css_path.read_text()
marker = "/* explore-restore-pre-stretch-v24-39 */"

if ".home-explore-top-token-card" not in css or 'data-explore-projection="top-token-v24-32"' not in css:
    raise SystemExit("ERROR: Explore projected Top Token card selectors not found in src/styles.css")

if marker not in css:
    css += r'''

/* explore-restore-pre-stretch-v24-39
   Return Explore projected card to the pre-stretch geometry. */
.home-explore-reference-v8 .home-explore-v8-primary-slot{
  left:0 !important;
  top:0 !important;
  bottom:12px !important;
  width:56% !important;
  height:auto !important;
  min-height:0 !important;
  display:flex !important;
  align-items:flex-start !important;
  justify-content:flex-start !important;
  overflow:visible !important;
}

.home-explore-reference-v8
.home-explore-top-token-card[data-top-token-layout="v21"][data-explore-projection="top-token-v24-32"]{
  position:relative !important;
  inset:auto !important;
  width:100% !important;
  height:auto !important;
  min-height:0 !important;
  display:block !important;
  margin:0 !important;
}

.home-explore-reference-v8
.home-explore-top-token-card[data-top-token-layout="v21"][data-explore-projection="top-token-v24-32"]
.home-top-token-media{
  width:100% !important;
  height:auto !important;
  min-height:0 !important;
  aspect-ratio:1/1 !important;
}

.home-explore-reference-v8 .home-explore-v8-secondary-slot{
  right:0 !important;
  top:12% !important;
  bottom:12px !important;
  width:30% !important;
  height:auto !important;
}

@media(max-width:640px){
  .home-explore-reference-v8 .home-explore-v8-primary-slot{
    left:0 !important;
    top:0 !important;
    bottom:10px !important;
    width:56% !important;
    height:auto !important;
  }

  .home-explore-reference-v8
  .home-explore-top-token-card[data-top-token-layout="v21"][data-explore-projection="top-token-v24-32"]{
    height:auto !important;
  }

  .home-explore-reference-v8
  .home-explore-top-token-card[data-top-token-layout="v21"][data-explore-projection="top-token-v24-32"]
  .home-top-token-media{
    aspect-ratio:1/1 !important;
  }

  .home-explore-reference-v8 .home-explore-v8-secondary-slot{
    top:12% !important;
    bottom:10px !important;
    width:30% !important;
  }
}
'''
    css_path.write_text(css)
    print("PASS: Explore preview restored to the pre-stretch geometry.")
else:
    print("No changes needed; v24.39 already installed.")
