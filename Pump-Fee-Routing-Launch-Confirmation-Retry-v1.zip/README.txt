Pump Fee Routing — Launch Confirmation Retry v1

Fixes the confirmation stage after a user signs a token launch or fee-routing transaction.

Observed problem:
- Wallet returned a transaction signature.
- UI showed "Waiting for confirmation".
- Backend polls Solana for ~22.5 seconds.
- If the RPC still has no confirmed status, it returns:
  "Transaction is not confirmed yet. Retry in a few seconds."
- The old UI then changed the button back to "Launch token", which could cause a second
  token launch attempt if pressed again.

Fix:
- Retry confirmation for the SAME token transaction.
- Keep the submitted mint/signature in currentLaunch.
- If still pending, button becomes "Retry confirmation".
- Clicking it checks the SAME transaction; it does not build/sign a new token transaction.
- Apply the same behavior to the second fee-routing transaction.
- Preserve existing mobile wallet fixes.

Important:
This patch protects future attempts in the current page session.
For the transaction submitted before this patch, check the wallet activity/transaction status
before launching another token, because the old page did not persist enough state across restart.

Installer validates, commits, and pushes origin/main.
No automatic server restart.
