#!/usr/bin/env bash
set -euo pipefail

python3 - <<'PY'
from pathlib import Path

app_path = Path("src/app.js")
css_path = Path("src/styles.css")

if not app_path.exists() or not css_path.exists():
    raise SystemExit("Run this from the Pump-Fee-Routing project root.")

app = app_path.read_text()

start = app.find("function homePage(){")
end = app.find("function explorePage(){", start)
if start < 0 or end < 0:
    raise SystemExit("Could not locate homePage()/explorePage() in src/app.js")

replacement = r'''function homeHeroCard(h,top){
  const t=top[0]||null;
  const p=(h.profiles||[])[0]||null;
  const handle=t?.profile||t?.recipient_handle||p?.handle||'';
  const display=p?.display_name||handle||'Waiting for first routed token';
  const sent=Number(t?.sent||0);
  return `<div class="home-hero-card">
    <div class="home-hero-card-head"><span>Fees route to</span><b>${handle?`@${esc(handle)}`:'Treasury'}</b></div>
    <div class="home-hero-token">
      <div class="home-hero-art">${t?avatar(t.symbol||t.name,true,t.image_url):'<div class="home-hero-placeholder">P</div>'}</div>
      <div class="home-hero-token-copy">
        <small>${handle?`@${esc(handle)}`:'No routed token yet'}</small>
        <strong>${t?esc(t.name):'Waiting for first token'}</strong>
        <span>${t?`${esc(t.symbol||'')} · ${fmtMc(t.mc??t.market_cap_usd)} MC`:'Permanent 100% fee route required'}</span>
      </div>
    </div>
    <div class="home-route-rail"><span></span><i></i><span></span></div>
    <div class="home-payout-box">
      <small>Paying out</small>
      <strong>${fmtMoney(sent)}</strong>
      <span>${handle?`${esc(display)} · @${esc(handle)}`:'No recipient registered yet'}</span>
      <em>${sent>0?'Sent via configured payout rail':'Waiting for confirmed fees'}</em>
    </div>
  </div>`;
}

function homePreviewDeck(h,top){
  const t=top[0]||null;
  const pay=(h.payments||[])[0]||null;
  const money=h.money||{};
  const profile=(h.profiles||[])[0]||null;
  return `<section class="home-preview-shell">
    <div class="wrap home-preview-head"><span>Live protocol</span><small>Swipe to explore</small></div>
    <div class="home-preview-track">
      <a class="home-preview-card" href="#/explore">
        <div class="home-preview-label"><b>Explore</b><span>Open →</span></div>
        ${t?`<div class="home-preview-token">${avatar(t.symbol||t.name,true,t.image_url)}<div><small>@${esc(t.profile||t.recipient_handle||'')}</small><strong>${esc(t.name)} <i>${esc(t.symbol||'')}</i></strong><span>${fmtMc(t.mc??t.market_cap_usd)} MC · ${fmtMoney(t.sent)} Sent</span></div></div>`:'<div class="home-preview-empty">No routed tokens yet</div>'}
      </a>
      <a class="home-preview-card" href="#/money">
        <div class="home-preview-label"><b>Payments</b><span>Open →</span></div>
        ${pay?`<div class="home-preview-payment"><strong>${fmtMoney(pay.amount_usd??pay.amount??0)}</strong><span>sent to ${esc(pay.display_name||pay.recipient_handle||'recipient')}</span><small>${esc(ago(pay.sent_at||pay.created_at))}</small></div>`:'<div class="home-preview-empty">No payments yet</div>'}
      </a>
      <a class="home-preview-card" href="#/money">
        <div class="home-preview-label"><b>Analytics</b><span>Open →</span></div>
        <div class="home-preview-analytics"><small>Total paid</small><strong>${fmtMoney(money.totalPaid||0)}</strong><div class="home-mini-chart">${Array.from({length:18},(_,i)=>`<i style="height:${18+((i*17)%52)}%"></i>`).join('')}</div></div>
      </a>
      <a class="home-preview-card" href="#/launch">
        <div class="home-preview-label"><b>Launch</b><span>Open →</span></div>
        <div class="home-preview-route"><small>Fees route to</small><strong>${profile?`@${esc(profile.handle)}`:'Treasury'}</strong><span>100% permanent creator-fee route</span><div><i></i><b>${fmtMoney(0)}</b></div></div>
      </a>
      <a class="home-preview-card" href="#/docs">
        <div class="home-preview-label"><b>Docs</b><span>Open →</span></div>
        <div class="home-preview-doc"><small>Sharing config</small><strong>Attribution is per-mint</strong><code>mint → treasury → recipient ledger</code><span>Detection, claiming and payouts</span></div>
      </a>
    </div>
  </section>`;
}

function homeMostPayments(h){
  const top=h.money?.topPaid||[];
  return `<section class="wrap section home-most-payments">${sectionTitle('Most Payments')}
    <div class="rank-list">${top.length?top.slice(0,6).map(x=>`<a class="rank-card" href="#/profile/${encodeURIComponent(x.handle)}">${avatar(x.display_name||x.handle)}<div><b>${esc(x.display_name||x.handle)}</b><span>@${esc(x.handle)}</span></div><strong>${fmtMoney(x.received)}</strong></a>`).join(''):'<div class="empty">No completed payments yet.</div>'}</div>
  </section>`;
}

function homeOffRamp(h){
  const exchanges=h.money?.exchange||[];
  return `<section class="wrap section">${sectionTitle('Off-ramp')}
    <div class="tabs small-tabs"><button class="active">All</button><button disabled>Deposits</button><button disabled>Swaps</button><button disabled>ACH</button></div>
    <div class="tx-list">${exchanges.length?exchanges.slice(0,6).map(txCard).join(''):'<div class="empty">No off-ramp activity yet.</div>'}</div>
  </section>`;
}

function homeOnRamp(){
  return `<section class="wrap section">${sectionTitle('On-ramp')}
    <div class="tx-list"><div class="empty">No on-ramp activity yet.</div></div>
  </section>`;
}

function homePage(){
  const h=state.home||{tokens:[],profiles:[],payments:[],money:{}};
  const top=h.tokens||[];
  return `<main class="home-page">
    <section class="hero wrap home-hero">
      <div class="hero-copy">
        <h1>Route token fees<br>through X Money</h1>
        <p>Point a token's creator fees at any X handle and we pay them out in dollars through X Money. Launch on Pump and Pons.</p>
        <div class="hero-buttons">
          <button class="btn-light" data-action="open-launch">Launch a token</button>
          <a class="text-link" href="#/docs">Read the docs <span>→</span></a>
        </div>
      </div>
      ${homeHeroCard(h,top)}
    </section>

    ${top.length?`<section class="marquee home-marquee"><div class="marquee-track">${top.slice(0,16).concat(top.slice(0,16)).map(t=>`<a class="marquee-item" href="#/token/${encodeURIComponent(t.mint||t.contract)}">${avatar(t.symbol)}<div><small>@${esc(t.profile)} · ${esc(t.age)}</small><b>${esc(t.name)} <i>${esc(t.symbol)}</i></b><span>${fmtMc(t.mc)} MC · ${fmtMoney(t.sent)} Sent</span></div></a>`).join('')}</div></section>`:''}

    ${homePreviewDeck(h,top)}

    <section class="wrap section home-top-tokens">
      ${sectionTitle('Top Tokens','#/explore')}
      <div class="tabs"><button class="active">● Pump</button><button disabled>■ Pons</button><button>All</button></div>
      <div class="token-grid">${top.slice(0,12).map(t=>tokenCard(t,true)).join('')||'<div class="empty">No registered tokens yet.</div>'}</div>
      ${top.length?pager(1,Math.max(1,Math.ceil(top.length/12))):''}
    </section>

    <section class="wrap section profiles-section">
      ${sectionTitle('Top X Profiles')}
      <div class="profile-grid">${(h.profiles||[]).slice(0,6).map(p=>`<a class="profile-card" href="#/profile/${encodeURIComponent(p.handle)}">${avatar(p.display_name||p.handle)}<div><b>${esc(p.display_name||p.handle)}</b><span>@${esc(p.handle)}</span></div><div class="profile-value"><strong>${fmtNum(p.token_count)}</strong><span>Tokens</span><b>${fmtMoney(p.received)}</b><small>Received</small></div></a>`).join('')||'<div class="empty">Profiles appear after tokens register.</div>'}</div>
    </section>

    <section class="wrap section">
      ${sectionTitle('Recent payments')}
      <div class="payment-list">${(h.payments||[]).slice(0,6).map(paymentCard).join('')||'<div class="empty">No payouts recorded yet.</div>'}</div>
    </section>

    ${homeMostPayments(h)}
    ${homeOffRamp(h)}
    ${homeOnRamp()}
    ${footer()}
  </main>`;
}
'''

app = app[:start] + replacement + app[end:]
app_path.write_text(app)

css = css_path.read_text()
marker = "/* home-v1-usepaid */"
styles = r'''
/* home-v1-usepaid */
.home-page{overflow:hidden}
.home-hero{padding-top:72px;padding-bottom:42px;min-height:510px}
.home-hero .hero-copy{align-self:center}
.home-hero .hero-copy h1{font-size:clamp(46px,6.4vw,74px);line-height:.94;letter-spacing:-.06em;font-weight:650}
.home-hero .hero-copy>p{max-width:555px;margin:22px 0 26px;color:#8e8e8e;font-size:15px;line-height:1.58}
.home-hero-card{width:min(100%,390px);justify-self:end;background:#090909;border:1px solid #1f1f1f;border-radius:20px;padding:18px;box-shadow:0 35px 100px rgba(0,0,0,.55)}
.home-hero-card-head{display:flex;align-items:center;justify-content:space-between;color:#6e6e6e;font-size:10px}
.home-hero-card-head b{color:#d8d8d8;font-size:10px;font-weight:600}
.home-hero-token{display:flex;gap:12px;align-items:center;margin-top:23px}
.home-hero-art{width:72px;height:72px;border-radius:12px;background:#111;display:grid;place-items:center;overflow:hidden;flex:0 0 auto}
.home-hero-art .avatar{width:72px;height:72px;border-radius:12px;font-size:24px}
.home-hero-placeholder{font-weight:900;font-style:italic;font-size:28px}
.home-hero-token-copy{display:grid;min-width:0}
.home-hero-token-copy small,.home-hero-token-copy span{font-size:9px;color:#666}
.home-hero-token-copy strong{font-size:15px;margin:4px 0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.home-route-rail{display:flex;align-items:center;gap:8px;margin:20px 0 13px}
.home-route-rail span{height:1px;background:#242424;flex:1}
.home-route-rail i{display:block;width:7px;height:7px;border-radius:50%;background:#eee;box-shadow:0 0 16px rgba(255,255,255,.55)}
.home-payout-box{border:1px solid #252525;background:#111;border-radius:13px;padding:15px;display:grid}
.home-payout-box small,.home-payout-box span,.home-payout-box em{font-size:9px;color:#656565;font-style:normal}
.home-payout-box strong{font-size:27px;letter-spacing:-.045em;margin:5px 0}
.home-payout-box em{margin-top:8px;color:#8b8b8b}
.home-preview-shell{padding:42px 0 26px}
.home-preview-head{display:flex;justify-content:space-between;margin-bottom:12px;color:#656565;font-size:9px}
.home-preview-track{display:flex;gap:10px;overflow-x:auto;padding:0 max(16px,calc((100vw - 1080px)/2)) 14px;scroll-snap-type:x mandatory;scrollbar-width:none}
.home-preview-track::-webkit-scrollbar{display:none}
.home-preview-card{scroll-snap-align:start;flex:0 0 300px;min-height:205px;border:1px solid #1f1f1f;background:#0b0b0b;border-radius:17px;padding:14px;display:flex;flex-direction:column}
.home-preview-label{display:flex;justify-content:space-between;align-items:center;font-size:10px;margin-bottom:16px}
.home-preview-label span{color:#777}
.home-preview-token{display:flex;gap:10px;align-items:center;margin-top:auto;margin-bottom:auto}
.home-preview-token .avatar{width:64px;height:64px;border-radius:12px;font-size:22px}
.home-preview-token>div:last-child{display:grid;min-width:0}
.home-preview-token small,.home-preview-token span{font-size:9px;color:#6a6a6a}
.home-preview-token strong{font-size:13px;margin:4px 0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.home-preview-token i{font-style:normal;color:#666;font-weight:500}
.home-preview-empty{margin:auto;color:#5f5f5f;font-size:10px}
.home-preview-payment{margin:auto 0;display:grid}
.home-preview-payment strong,.home-preview-analytics strong{font-size:30px;letter-spacing:-.05em}
.home-preview-payment span,.home-preview-payment small,.home-preview-analytics small{font-size:9px;color:#6b6b6b}
.home-preview-payment small{margin-top:10px}
.home-preview-analytics{margin:auto 0;display:grid}
.home-mini-chart{height:50px;display:flex;gap:3px;align-items:end;margin-top:18px}
.home-mini-chart i{display:block;flex:1;background:#2a2a2a;border-radius:2px 2px 0 0}
.home-preview-route,.home-preview-doc{display:grid;margin:auto 0}
.home-preview-route small,.home-preview-route span,.home-preview-doc small,.home-preview-doc span{font-size:9px;color:#686868}
.home-preview-route>strong,.home-preview-doc>strong{font-size:15px;margin:5px 0 8px}
.home-preview-route>div{margin-top:18px;border-top:1px solid #242424;padding-top:12px;display:flex;justify-content:space-between;align-items:center}
.home-preview-route>div i{width:7px;height:7px;border-radius:50%;background:#fff}
.home-preview-route>div b{font-size:20px}
.home-preview-doc code{margin:12px 0;padding:10px;border:1px solid #222;background:#060606;border-radius:9px;color:#8b8b8b;font-size:9px}
.home-top-tokens{padding-top:42px}
.home-most-payments .rank-list{max-width:none}
.home-page .section-title h2{font-size:18px}
.home-page .section{padding-top:42px;padding-bottom:42px}
.home-page footer{margin-top:20px}
@media(max-width:640px){
  .home-hero{padding-top:56px;padding-bottom:30px}
  .home-hero .hero-copy h1{font-size:48px}
  .home-hero .hero-copy>p{font-size:13px;line-height:1.58}
  .home-hero-card{margin-top:38px;width:100%;max-width:none;padding:15px;border-radius:17px}
  .home-hero-art,.home-hero-art .avatar{width:64px;height:64px}
  .home-payout-box strong{font-size:24px}
  .home-preview-shell{padding-top:25px}
  .home-preview-track{padding-left:10px;padding-right:10px}
  .home-preview-card{flex-basis:270px;min-height:190px}
  .home-page .section{padding-top:34px;padding-bottom:34px}
}
'''
if marker not in css:
    css_path.write_text(css + "\n" + styles + "\n")
else:
    raise SystemExit("home-v1-usepaid patch is already installed.")

print("Home v1 patch installed.")
PY

npm run check
echo
echo "Done. No server restart was performed."
echo "Refresh the browser after the running server serves the updated files."
