Pump Fee Routing — Home v1
Reworks the homepage only. Backend/Solana/database are untouched.
Install from project root: bash install.sh
No automatic restart.
