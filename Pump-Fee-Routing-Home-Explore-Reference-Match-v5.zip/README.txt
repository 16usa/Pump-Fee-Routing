Pump-Fee-Routing-Home-Explore-Reference-Match-v5

Scope
- Repairs only the Home -> Explore preview block.
- Keeps the rest of Home untouched.
- Rebuilds the Explore preview as a static reference-style composition from live mini-modules.
- Re-adds or refreshes the backend token-image resolver used by the Explore preview.

What changes
- Left side becomes a live token mini-card with image/fallback, recipient pill, and compact token info.
- Right side becomes a cropped secondary teaser panel with image/fallback and "Open →".
- Geometry, spacing, and overlay treatment are tightened to better match the reference.
- No motion is added.

Install from your existing workspace shell
1) rm -rf /tmp/home-explore-v5
2) mkdir -p /tmp/home-explore-v5
3) unzip -o Pump-Fee-Routing-Home-Explore-Reference-Match-v5.zip -d /tmp/home-explore-v5
4) bash /tmp/home-explore-v5/install.sh

Notes
- No server restart is performed by the patch.
- Restart manually from the console after install.
