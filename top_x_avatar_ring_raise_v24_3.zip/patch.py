
from pathlib import Path

path=Path("src/styles.css")
css=path.read_text()

marker="/* top-x-avatar-ring-raise-v24-3 */"
if marker not in css:
    css += r'''
/* top-x-avatar-ring-raise-v24-3
   Remove the outer translucent avatar ring and raise avatar/content
   by roughly half of the previous adjustment. */
.home-profile-feature[data-profile-layout="v22"] .home-profile-avatar{
  bottom:-15px;
}

.home-profile-feature[data-profile-layout="v22"] .home-profile-avatar .avatar{
  box-shadow:none !important;
}

.home-profile-feature[data-profile-layout="v22"] .home-profile-feature-body{
  padding-top:23px;
}

@media(max-width:640px){
  .home-profile-feature[data-profile-layout="v22"] .home-profile-avatar{
    bottom:-14px;
  }

  .home-profile-feature[data-profile-layout="v22"] .home-profile-avatar .avatar{
    box-shadow:none !important;
  }

  .home-profile-feature[data-profile-layout="v22"] .home-profile-feature-body{
    padding-top:20px;
  }
}
'''
    path.write_text(css)
    print("src/styles.css: outer avatar ring removed and block raised again")
else:
    print("src/styles.css: patch already installed")

print("PASS: CSS patch prepared")
