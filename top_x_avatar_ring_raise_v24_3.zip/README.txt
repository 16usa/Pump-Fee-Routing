Top X Avatar Ring + Raise v24.3

Changes:
- removes the outer translucent/second ring around the avatar;
- keeps the main avatar border;
- raises the avatar by about half of the previous adjustment;
- raises GG / @username / Paid Profile / stats with it;
- avatar size stays unchanged;
- no automatic server restart.

Install in the existing Replit Shell:

rm -rf /tmp/top_x_avatar_ring_raise_v24_3 && mkdir -p /tmp/top_x_avatar_ring_raise_v24_3 && unzip -o top_x_avatar_ring_raise_v24_3.zip -d /tmp/top_x_avatar_ring_raise_v24_3 && bash /tmp/top_x_avatar_ring_raise_v24_3/install.sh
