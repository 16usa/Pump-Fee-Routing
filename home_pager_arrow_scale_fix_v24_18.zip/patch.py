from pathlib import Path

path = Path('src/styles.css')
if not path.exists():
    raise SystemExit('ERROR: src/styles.css not found. Run from the existing Replit project root.')

css = path.read_text()
marker = '/* home-pager-arrow-scale-fix-v24-18 */'

if marker not in css:
    css += '''\n\n/* home-pager-arrow-scale-fix-v24-18\n   Safe override: does not depend on the exact v24.16 block text.\n   Keep page number at FEES ROUTE TO size, while arrows retain\n   their original visual proportion and therefore stay larger. */\n.home-top-token-pager,\n.home-top-profiles-pager,\n.home-recent-payments-pager,\n.home-most-payments-pager,\n.home-off-pager,\n.home-on-pager{\n  font-size:11px !important;\n  line-height:1 !important;\n}\n\n.home-top-token-pager button,\n.home-top-profiles-pager button,\n.home-recent-payments-pager button,\n.home-most-payments-pager button,\n.home-off-pager button,\n.home-on-pager button{\n  font-size:21px !important;\n  line-height:1 !important;\n  width:auto !important;\n  height:auto !important;\n}\n\n@media(max-width:640px){\n  .home-top-token-pager,\n  .home-top-profiles-pager,\n  .home-recent-payments-pager,\n  .home-most-payments-pager,\n  .home-off-pager,\n  .home-on-pager{\n    font-size:9px !important;\n    line-height:1 !important;\n  }\n\n  .home-top-token-pager button,\n  .home-top-profiles-pager button,\n  .home-recent-payments-pager button,\n  .home-most-payments-pager button,\n  .home-off-pager button,\n  .home-on-pager button{\n    font-size:17px !important;\n    line-height:1 !important;\n    width:auto !important;\n    height:auto !important;\n  }\n}\n'''
    path.write_text(css)
    print('PASS: pager arrows enlarged proportionally via safe final override')
else:
    print('Patch already installed')
