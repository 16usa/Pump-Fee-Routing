#!/usr/bin/env bash
set -euo pipefail

PATCH_NAME="home_pager_arrow_scale_fix_v24_18"
CSS="src/styles.css"

if [ ! -f "$CSS" ]; then
  echo "ERROR: missing $CSS"
  echo "Run this from the existing Replit project root."
  exit 1
fi

echo "==> Installing ${PATCH_NAME}"
mkdir -p ".patch-backups/${PATCH_NAME}"
cp "$CSS" ".patch-backups/${PATCH_NAME}/styles.css.before"

python3 "$(dirname "$0")/patch.py"

echo "==> Running project check"
npm run check

echo "==> Git diff"
git diff -- src/styles.css

git add src/styles.css
if git diff --cached --quiet; then
  echo "==> No new changes to commit."
else
  git commit -m "Fix home pager arrow scale"
  git push origin main
fi

echo
echo "PASS: ${PATCH_NAME} installed."
echo "No server restart was performed."
