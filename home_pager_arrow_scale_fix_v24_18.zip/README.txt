Home Pager Arrow Scale Fix v24.18

Why v24.17 failed:
The installer searched for an exact older CSS block and your current file had different spacing/content, so it stopped before changing anything.

v24.18 does not search/replace the old block. It adds a final override at the end of styles.css.

Result:
- page number: 11px desktop / 9px mobile
- arrows: 21px desktop / 17px mobile
- applies to Top Tokens, Top X Profiles, Recent Payments, Most Payments, Off Ramp, On Ramp
- no automatic restart

Install:
rm -rf /tmp/home_pager_arrow_scale_fix_v24_18 && mkdir -p /tmp/home_pager_arrow_scale_fix_v24_18 && unzip -o home_pager_arrow_scale_fix_v24_18.zip -d /tmp/home_pager_arrow_scale_fix_v24_18 && bash /tmp/home_pager_arrow_scale_fix_v24_18/install.sh
