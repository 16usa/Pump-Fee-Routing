#!/usr/bin/env bash
set -euo pipefail

echo "== Explore Image/Divider Cleanup v15.7 =="

if [ ! -f src/styles.css ]; then
  echo "ERROR: src/styles.css not found. Run this from the existing Replit project workspace."
  exit 1
fi

python3 <<'PYCODE'
from pathlib import Path

css_path = Path('src/styles.css')
css = css_path.read_text()

if 'home-explore-reference-v8' not in css:
    raise SystemExit('ERROR: expected Explore v8 CSS not found.')

marker = '/* explore-image-frame-cleanup-v15-7 */'
patch = r'''
/* explore-image-frame-cleanup-v15-7 */

/* Remove the line directly under the LEFT image. */
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] > .home-explore-v8-copy{
  border-top:0 !important;
  box-shadow:none !important;
}

/* Remove the inner right-side divider on the LEFT card. */
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"]{
  border-right:0 !important;
}

/* Keep the overall Explore block/card construction, but remove frames only around the media/images. */
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] > .home-explore-v8-media,
.home-explore-reference-v8 .home-explore-v8-secondary-card,
.home-explore-reference-v8 .home-explore-v8-secondary-card > .home-explore-v8-media{
  border:0 !important;
  outline:0 !important;
  box-shadow:none !important;
}
'''

if marker not in css:
    css_path.write_text(css.rstrip() + '\n\n' + patch + '\n')
    print('PASS cleanup CSS appended')
else:
    print('PASS cleanup CSS already present')

css2 = css_path.read_text()
checks = {
    'marker': marker in css2,
    'copy top border removed': 'border-top:0 !important;' in css2,
    'primary right divider removed': 'border-right:0 !important;' in css2,
    'media border removed': 'home-explore-v8-secondary-card > .home-explore-v8-media' in css2,
}
for label, ok in checks.items():
    if not ok:
        raise SystemExit(f'ERROR: verification failed: {label}')
    print('PASS', label)
PYCODE

echo
if [ -f package.json ]; then
  echo "== Project checks =="
  npm run check || echo "WARN: npm run check failed, continuing"
  echo
fi

echo "== Git diff =="
git diff --stat || true

git add src/styles.css
if git diff --cached --quiet; then
  echo "No new changes to commit."
else
  git commit -m "Clean up Explore image frames and inner dividers"
  git push
fi

echo
echo "DONE: Explore image/divider cleanup v15.7 installed, committed, and pushed."
echo "No server restart was performed. Restart manually from the Replit console, then reload the page."
