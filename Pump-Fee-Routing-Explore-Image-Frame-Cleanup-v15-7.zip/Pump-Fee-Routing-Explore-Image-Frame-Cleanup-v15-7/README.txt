Pump Fee Routing — Explore Image/Divider Cleanup v15.7

What this patch does:
- removes the horizontal line under the LEFT image in Explore
- removes the inner right-side divider on the LEFT Explore card
- removes the frame around the RIGHT image
- keeps the overall Explore block structure intact

Install from your existing Replit workspace shell:

rm -rf /tmp/explore-image-frame-cleanup-v15-7
mkdir -p /tmp/explore-image-frame-cleanup-v15-7
unzip -o Pump-Fee-Routing-Explore-Image-Frame-Cleanup-v15-7.zip -d /tmp/explore-image-frame-cleanup-v15-7
bash /tmp/explore-image-frame-cleanup-v15-7/install.sh

No automatic restart is performed.
