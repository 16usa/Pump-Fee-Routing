Pump Fee Routing — Home Explore Geometry v8

Scope
- Home page Explore preview only.
- Removes the separate top Explore/Open header.
- Moves Explore / Open to the bottom overlay like the reference.
- Makes the overall Explore block shorter and denser.
- Left module is flush to top/left/bottom.
- Right module is flush to right/bottom.
- Reduces the gap between the two modules.
- Preserves all existing token/profile data rendering and token-image resolver.
- Does not touch Payments, Analytics, Launch logic, wallet logic, or server startup.

Install from the existing Replit workspace Shell:
rm -rf /tmp/home-explore-v8
mkdir -p /tmp/home-explore-v8
unzip -o Pump-Fee-Routing-Home-Explore-Geometry-v8.zip -d /tmp/home-explore-v8
bash /tmp/home-explore-v8/install.sh

No automatic server restart is performed.
Restart Console/Run manually once after installation.
