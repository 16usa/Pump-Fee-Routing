#!/usr/bin/env bash
set -euo pipefail

echo "== Top Token Pump Logo v21.1 =="

for f in src/app.js src/styles.css; do
  if [ ! -f "$f" ]; then
    echo "ERROR: $f not found. Run this from the existing Replit project workspace."
    exit 1
  fi
done

python3 <<'PYCODE'
from pathlib import Path

app_path = Path("src/app.js")
css_path = Path("src/styles.css")
app = app_path.read_text()
css = css_path.read_text()

if 'data-top-token-layout="v21"' not in app:
    raise SystemExit("ERROR: Top Tokens v21 card layout is not installed.")

app_marker = 'data-top-token-pump-logo="v21-1"'
css_marker = '/* top-token-pump-logo-v21-1 */'

if app_marker not in app:
    old = '''      <div class="home-top-token-platform">${platformBadge(t.platform||'Pump')}</div>'''
    new = '''      <div class="home-top-token-platform" data-top-token-pump-logo="v21-1" aria-label="${esc(t.platform||'Pump')}">
        ${String(t.platform||'Pump').toLowerCase().includes('pump')
          ? `<span class="home-top-token-pump-logo" aria-hidden="true">
              <svg viewBox="0 0 24 24" role="presentation" focusable="false">
                <g transform="rotate(-42 12 12)">
                  <rect x="7" y="3" width="10" height="18" rx="5" fill="#f2f2f2"/>
                  <path d="M7 12h10v4a5 5 0 0 1-5 5 5 5 0 0 1-5-5v-4Z" fill="#63d7a4"/>
                </g>
              </svg>
            </span>`
          : platformBadge(t.platform||'Pump')}
      </div>'''
    if old not in app:
        raise SystemExit("ERROR: current Top Tokens platform badge markup not found.")
    app = app.replace(old, new, 1)
    app_path.write_text(app)
    print("PASS Top Tokens Pump logo markup installed")
else:
    print("PASS v21.1 markup already installed")

if css_marker not in css:
    patch = r'''
/* top-token-pump-logo-v21-1 */

.home-top-token-card[data-top-token-layout="v21"]
.home-top-token-platform[data-top-token-pump-logo="v21-1"]{
  width:34px;
  height:34px;
  min-width:34px;
  min-height:34px;
  padding:0;
  display:grid;
  place-items:center;
  border:0;
  border-radius:50%;
  background:rgba(29,29,29,.88);
  box-shadow:0 1px 0 rgba(255,255,255,.05);
  backdrop-filter:blur(8px);
  -webkit-backdrop-filter:blur(8px);
  overflow:hidden;
}

.home-top-token-card[data-top-token-layout="v21"]
.home-top-token-platform[data-top-token-pump-logo="v21-1"] .home-top-token-pump-logo{
  width:20px;
  height:20px;
  display:grid;
  place-items:center;
}

.home-top-token-card[data-top-token-layout="v21"]
.home-top-token-platform[data-top-token-pump-logo="v21-1"] .home-top-token-pump-logo svg{
  width:20px;
  height:20px;
  display:block;
}

.home-top-token-card[data-top-token-layout="v21"]
.home-top-token-platform[data-top-token-pump-logo="v21-1"] .platform-badge{
  margin:0;
  padding:0;
}

@media(max-width:640px){
  .home-top-token-card[data-top-token-layout="v21"]
  .home-top-token-platform[data-top-token-pump-logo="v21-1"]{
    width:32px;
    height:32px;
    min-width:32px;
    min-height:32px;
  }

  .home-top-token-card[data-top-token-layout="v21"]
  .home-top-token-platform[data-top-token-pump-logo="v21-1"] .home-top-token-pump-logo,
  .home-top-token-card[data-top-token-layout="v21"]
  .home-top-token-platform[data-top-token-pump-logo="v21-1"] .home-top-token-pump-logo svg{
    width:19px;
    height:19px;
  }
}
'''
    css_path.write_text(css.rstrip() + "\n\n" + patch + "\n")
    print("PASS round Pump badge CSS added")
else:
    print("PASS v21.1 CSS already installed")

app = app_path.read_text()
css = css_path.read_text()
checks = {
    "markup marker": app_marker in app,
    "inline Pump logo present": "home-top-token-pump-logo" in app,
    "CSS marker": css_marker in css,
}
for label, ok in checks.items():
    if not ok:
        raise SystemExit(f"ERROR: verification failed: {label}")
    print("PASS", label)
PYCODE

echo
echo "== Project checks =="
npm run check

echo
echo "== Git diff =="
git diff --stat

git add src/app.js src/styles.css

if git diff --cached --quiet; then
  echo "No new changes to commit."
else
  git commit -m "Use round Pump logo badge in Top Tokens cards"
  git push
fi

echo
echo "DONE: Top Token Pump Logo v21.1 installed, checked, committed, and pushed."
echo "No server restart was performed."
echo "Restart Run/Console manually once, then reload the page."
