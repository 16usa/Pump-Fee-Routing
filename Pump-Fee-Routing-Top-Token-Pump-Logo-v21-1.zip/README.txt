Pump Fee Routing — Top Token Pump Logo v21.1

Scope: ONLY the platform badge at the top-left of Top Tokens card images.

Changes:
- keeps the same dark/glass color/style
- turns the badge into a circle
- removes the white dot
- removes the word Pump
- puts a Pump.fun-style green/white capsule logo in the center

Nothing else in Top Tokens or other sections is changed.
No automatic server restart.

Install:
rm -rf /tmp/top-token-pump-logo-v21-1
mkdir -p /tmp/top-token-pump-logo-v21-1
unzip -o Pump-Fee-Routing-Top-Token-Pump-Logo-v21-1.zip -d /tmp/top-token-pump-logo-v21-1
bash /tmp/top-token-pump-logo-v21-1/install.sh
