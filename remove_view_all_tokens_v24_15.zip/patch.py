from pathlib import Path

path=Path('src/app.js')
if not path.exists():
    raise SystemExit('ERROR: src/app.js not found. Run from the existing project root.')

s=path.read_text()
needle='<a class="home-top-tokens-view" href="#/explore">View all tokens →</a>'

if needle in s:
    s=s.replace(needle,'',1)
    path.write_text(s)
    print('PASS: removed View all tokens link')
elif 'View all tokens' not in s:
    print('PASS: View all tokens is already removed')
else:
    raise SystemExit('ERROR: View all tokens still exists but markup changed; inspect src/app.js')
