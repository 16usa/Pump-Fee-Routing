Remove View All Tokens v24.15

Removes only the "View all tokens →" link under the Top Tokens section.
No other layout or styling changes.
No automatic restart.

Install in the existing Replit Shell:

rm -rf /tmp/remove_view_all_tokens_v24_15 && mkdir -p /tmp/remove_view_all_tokens_v24_15 && unzip -o remove_view_all_tokens_v24_15.zip -d /tmp/remove_view_all_tokens_v24_15 && bash /tmp/remove_view_all_tokens_v24_15/install.sh
