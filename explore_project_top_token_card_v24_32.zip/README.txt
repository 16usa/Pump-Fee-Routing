Explore Project Top Token Card v24.32

Based on the current GitHub project:
16usa/Pump-Fee-Routing

What changes:
- LEFT side of Explore now uses the exact Top Tokens card structure and Top Tokens CSS classes.
- Same image, Pump badge, time badge, recipient/avatar/name/verified pill, token name/ticker, and MC row.
- The full card ends above the shared Explore/Open footer with a clean bottom gap.
- Right side remains the second static image/crop.
- Maximum two token images in Explore.
- No animation and no new product functions.
- No server restart.

Install from the existing Replit Shell:

rm -rf /tmp/explore_project_top_token_card_v24_32 && mkdir -p /tmp/explore_project_top_token_card_v24_32 && unzip -o explore_project_top_token_card_v24_32.zip -d /tmp/explore_project_top_token_card_v24_32 && bash /tmp/explore_project_top_token_card_v24_32/install.sh
