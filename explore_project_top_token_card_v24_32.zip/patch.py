from pathlib import Path

app_path = Path("src/app.js")
css_path = Path("src/styles.css")

if not app_path.exists() or not css_path.exists():
    raise SystemExit("ERROR: src/app.js or src/styles.css not found. Run from the existing Replit project root.")

app = app_path.read_text()
css = css_path.read_text()

projection_marker = 'data-explore-projection="top-token-v24-32"'
css_marker = "/* explore-project-top-token-card-v24-32 */"

if projection_marker not in app:
    start_marker = "          const renderPrimary = (token) => {"
    end_marker = "          const renderSecondary = (token) => {"

    start = app.find(start_marker)
    end = app.find(end_marker, start + len(start_marker))

    if start < 0 or end < 0:
        raise SystemExit("ERROR: Explore renderPrimary block not found in src/app.js. Project structure changed; no files modified.")

    replacement = r'''          const renderPrimary = (token) => {
            if (!token) {
              return `<div class="home-top-token-card home-explore-top-token-card is-empty" data-top-token-layout="v21" data-explore-projection="top-token-v24-32">
                <div class="home-top-token-media">${renderTokenArt(null, 'primary')}</div>
                <div class="home-top-token-body">
                  <div class="home-top-token-title"><strong>Token</strong><span></span></div>
                  <div class="home-top-token-market"><strong>$0</strong><span>MC</span></div>
                </div>
              </div>`;
            }

            const handle = String(token.profile || token.recipient_handle || token.recipient_handles || '').replace(/^@/, '').trim();
            const profile = findProfile(token);
            const identity = xIdentity(handle,{...token,...(profile||{})});
            const ageText = token.age || ago(token.created_at);
            const mc = token.mc ?? token.market_cap_usd;

            return `<div class="home-top-token-card home-explore-top-token-card" data-top-token-layout="v21" data-explore-projection="top-token-v24-32">
              <div class="home-top-token-media">
                ${tokenMedia(token,'home-top-token-fallback')}
                <div class="home-top-token-platform" data-top-token-pump-logo="v21-1" aria-label="${esc(token.platform||'Pump')}">
                  ${String(token.platform||'Pump').toLowerCase().includes('pump')
                    ? `<span class="home-top-token-pump-logo" aria-hidden="true"><svg viewBox="0 0 24 24" role="presentation" focusable="false"><g transform="rotate(-42 12 12)"><rect x="7" y="3" width="10" height="18" rx="5" fill="#f2f2f2"/><path d="M7 12h10v4a5 5 0 0 1-5 5 5 5 0 0 1-5-5v-4Z" fill="#63d7a4"/></g></svg></span>`
                    : platformBadge(token.platform||'Pump')}
                </div>
                <div class="home-top-token-age">${esc(ageText||'')}</div>
                <div class="home-top-token-recipient">
                  <i class="home-top-token-money-mark">$</i>
                  ${handle?recipientAvatar(handle,identity.name,false,identity.avatarUrl):avatar(token.symbol||'T')}
                  <b class="x-recipient-name">${handle?`${esc(identity.name)}${xVerifiedBadge(identity.verified,identity.verifiedType,'x-verified-compact')}`:'Recipient'}</b>
                </div>
              </div>
              <div class="home-top-token-body">
                <div class="home-top-token-title"><strong>${esc(token.name)}</strong><span>${esc(token.symbol||'')}</span></div>
                <div class="home-top-token-market"><strong>${fmtMc(mc)}</strong><span>MC</span></div>
              </div>
            </div>`;
          };

'''
    app = app[:start] + replacement + app[end:]
    app_path.write_text(app)
    print("PASS: Explore left preview now renders the exact Top Tokens card structure")
else:
    print("APP: projection already installed")

if css_marker not in css:
    css += r'''

/* explore-project-top-token-card-v24-32
   Project the exact Top Tokens card into the LEFT side of Explore.
   The card ends above the shared Explore/Open footer with a clean gap.
   Right side remains the static second-image magazine crop. */
.home-explore-reference-v8 .home-explore-v8-primary-slot{
  left:2.5% !important;
  top:4% !important;
  bottom:54px !important;
  width:48% !important;
  height:auto !important;
  z-index:4 !important;
  display:flex !important;
  align-items:flex-start !important;
  justify-content:flex-start !important;
  overflow:visible !important;
}

.home-explore-reference-v8 .home-explore-top-token-card[data-top-token-layout="v21"][data-explore-projection="top-token-v24-32"]{
  position:relative !important;
  inset:auto !important;
  box-sizing:border-box !important;
  width:100% !important;
  height:auto !important;
  min-width:0 !important;
  margin:0 !important;
  color:#fff !important;
  background:#141414 !important;
  border:1px solid #252525 !important;
  border-radius:13px !important;
  box-shadow:none !important;
  overflow:hidden !important;
  pointer-events:none !important;
}

.home-explore-reference-v8 .home-explore-top-token-card[data-top-token-layout="v21"] .home-top-token-media{
  position:relative !important;
  width:100% !important;
  height:auto !important;
  aspect-ratio:1/1 !important;
}

.home-explore-reference-v8 .home-explore-top-token-card[data-top-token-layout="v21"] .home-top-token-media>img{
  width:100% !important;
  height:100% !important;
  object-fit:cover !important;
  object-position:center !important;
  filter:none !important;
  transform:none !important;
}

.home-explore-reference-v8 .home-explore-v8-secondary-slot{
  right:0 !important;
  top:14% !important;
  bottom:54px !important;
  width:33% !important;
  height:auto !important;
  z-index:3 !important;
}

.home-explore-reference-v8 .home-explore-v8-bottom-shade{
  height:17% !important;
  z-index:7 !important;
}

.home-explore-reference-v8 .home-explore-v8-footer{
  left:18px !important;
  right:18px !important;
  bottom:14px !important;
  z-index:9 !important;
}

.home-explore-reference-v8 .home-explore-v8-stage::after{
  display:none !important;
}

@media(max-width:640px){
  .home-explore-reference-v8 .home-explore-v8-primary-slot{
    left:2.5% !important;
    top:3.5% !important;
    bottom:46px !important;
    width:48% !important;
  }

  .home-explore-reference-v8 .home-explore-top-token-card[data-top-token-layout="v21"][data-explore-projection="top-token-v24-32"]{
    border-radius:12px !important;
  }

  .home-explore-reference-v8 .home-explore-v8-secondary-slot{
    top:14% !important;
    bottom:46px !important;
    width:33% !important;
  }

  .home-explore-reference-v8 .home-explore-v8-footer{
    left:12px !important;
    right:12px !important;
    bottom:10px !important;
  }
}
'''
    css_path.write_text(css)
    print("PASS: Explore geometry now leaves the full Top Tokens card above Explore/Open")
else:
    print("CSS: projection styles already installed")

print("PASS: v24.32 ready")
