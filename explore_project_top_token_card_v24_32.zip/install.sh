#!/usr/bin/env bash
set -euo pipefail

PATCH_NAME="explore_project_top_token_card_v24_32"
APP="src/app.js"
CSS="src/styles.css"

if [ ! -f "$APP" ] || [ ! -f "$CSS" ]; then
  echo "ERROR: missing src/app.js or src/styles.css"
  echo "Run this from the existing Replit project root."
  exit 1
fi

echo "==> Installing ${PATCH_NAME}"
mkdir -p ".patch-backups/${PATCH_NAME}"
cp "$APP" ".patch-backups/${PATCH_NAME}/app.js.before"
cp "$CSS" ".patch-backups/${PATCH_NAME}/styles.css.before"

python3 "$(dirname "$0")/patch.py"

echo "==> Verifying projection marker"
grep -q 'data-explore-projection="top-token-v24-32"' "$APP"
grep -q 'explore-project-top-token-card-v24-32' "$CSS"

echo "==> Running project check"
npm run check

echo "==> Git diff"
git diff -- src/app.js src/styles.css

git add src/app.js src/styles.css

if git diff --cached --quiet; then
  echo "==> No new changes to commit."
else
  git commit -m "Project Top Tokens card into Explore preview"
  git push origin main
fi

echo
echo "PASS: ${PATCH_NAME} installed."
echo "No server restart was performed."
