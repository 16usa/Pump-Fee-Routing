Explore Magazine Static v24.31

Goal:
Make the existing Explore preview feel like a premium store / fashion magazine,
while keeping the existing card structure and existing information.

What stays unchanged:
- the Explore card structure;
- token data;
- recipient pill;
- name/ticker;
- MC/Sent;
- Explore / Open footer;
- maximum of two existing token images;
- no animation.

What changes:
- left image becomes the dominant editorial image;
- right image becomes a narrow, darker monochrome crop;
- stronger magazine-style spacing and typography;
- soft vignette / fade into the existing card background;
- no new text or functions are added.

No automatic server restart.

Install in the existing Replit Shell:

rm -rf /tmp/explore_magazine_static_v24_31 && mkdir -p /tmp/explore_magazine_static_v24_31 && unzip -o explore_magazine_static_v24_31.zip -d /tmp/explore_magazine_static_v24_31 && bash /tmp/explore_magazine_static_v24_31/install.sh
