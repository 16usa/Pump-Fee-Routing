# Pump-Fee-Routing — Opt-out / Reactivation v1

This patch:
- makes X opt-out reversible through verified X sign-in;
- adds Reactivate UI and API;
- keeps previously diverted amounts protocol-side after reactivation;
- separates opt-out visibility from system/chain visibility;
- prevents discovery/re-index from resurfacing opted-out tokens;
- blocks new tokens for opted-out handles from public lists;
- cancels locally queued payouts on opt-out;
- hides opted-out recipients from public payment/profile surfaces;
- preserves pre-reactivation unclaimed lamports as protocol-reserved;
- makes opt-out work even if the X handle had no recipient row yet;
- includes an admin reactivate endpoint;
- does not restart the server.

Install from the existing Replit workspace:

    unzip -o Pump-Fee-Routing-Optout-Reactivation-v1.zip -d /tmp/optout-reactivation-v1
    bash /tmp/optout-reactivation-v1/install.sh

The installer backs up touched files under:
`.patch-backups/optout_reactivation_v1/`

It runs `node --check`, `npm run check`, and `git diff --check`, then commits/pushes when Git credentials are available.
