#!/usr/bin/env python3
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path.cwd()
BACKUP = ROOT / ".patch-backups" / "optout_reactivation_v1"

FILES = [
    "server/db.js",
    "server/payouts.js",
    "server/queries.js",
    "server/solana.js",
    "server/api.js",
    "server/xoauth.js",
    "src/app.js",
]

def die(msg):
    print(f"[PATCH ERROR] {msg}", file=sys.stderr)
    sys.exit(1)

def read(rel):
    p = ROOT / rel
    if not p.exists():
        die(f"Missing required file: {rel}")
    return p.read_text(encoding="utf-8")

def write(rel, text):
    p = ROOT / rel
    p.write_text(text, encoding="utf-8")

def replace_once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        die(f"{label}: expected exactly 1 match, found {count}. Project version differs; no partial patch was intended.")
    return text.replace(old, new, 1)

def backup():
    for rel in FILES:
        src = ROOT / rel
        dst = BACKUP / f"{rel}.before"
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)

def patch_db():
    rel = "server/db.js"
    s = read(rel)

    s = replace_once(s,
"""      opted_out INTEGER NOT NULL DEFAULT 0,
      opt_out_at TEXT,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,""",
"""      opted_out INTEGER NOT NULL DEFAULT 0,
      opt_out_at TEXT,
      reactivated_at TEXT,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,""",
"db recipients schema")

    s = replace_once(s,
"""      permanent INTEGER NOT NULL DEFAULT 0,
      hidden INTEGER NOT NULL DEFAULT 0,
      fee_config_address TEXT,""",
"""      permanent INTEGER NOT NULL DEFAULT 0,
      hidden INTEGER NOT NULL DEFAULT 0,
      opt_out_hidden INTEGER NOT NULL DEFAULT 0,
      fee_config_address TEXT,""",
"db tokens schema")

    s = replace_once(s,
"""      gross_unclaimed_usd REAL,
      recipient_unclaimed_usd REAL,
      protocol_unclaimed_usd REAL,
      active INTEGER NOT NULL DEFAULT 1,""",
"""      gross_unclaimed_usd REAL,
      recipient_unclaimed_usd REAL,
      protocol_unclaimed_usd REAL,
      opt_out_reserved_lamports INTEGER NOT NULL DEFAULT 0,
      active INTEGER NOT NULL DEFAULT 1,""",
"db chain schema")

    s = replace_once(s,
"""  if(!recipientColumns.has('banner_url')) db.exec('ALTER TABLE recipients ADD COLUMN banner_url TEXT');
  if(!recipientColumns.has('verified')) db.exec('ALTER TABLE recipients ADD COLUMN verified INTEGER NOT NULL DEFAULT 0');
  if(!recipientColumns.has('verified_type')) db.exec('ALTER TABLE recipients ADD COLUMN verified_type TEXT');
}""",
"""  if(!recipientColumns.has('banner_url')) db.exec('ALTER TABLE recipients ADD COLUMN banner_url TEXT');
  if(!recipientColumns.has('verified')) db.exec('ALTER TABLE recipients ADD COLUMN verified INTEGER NOT NULL DEFAULT 0');
  if(!recipientColumns.has('verified_type')) db.exec('ALTER TABLE recipients ADD COLUMN verified_type TEXT');
  if(!recipientColumns.has('reactivated_at')) db.exec('ALTER TABLE recipients ADD COLUMN reactivated_at TEXT');

  /* optout-reactivation-v1 */
  const tokenColumns=new Set(
    db.prepare('PRAGMA table_info(tokens)').all().map(row=>String(row.name||''))
  );
  if(!tokenColumns.has('opt_out_hidden')) db.exec('ALTER TABLE tokens ADD COLUMN opt_out_hidden INTEGER NOT NULL DEFAULT 0');

  const chainStateColumns=new Set(
    db.prepare('PRAGMA table_info(token_chain_state)').all().map(row=>String(row.name||''))
  );
  if(!chainStateColumns.has('opt_out_reserved_lamports')) db.exec('ALTER TABLE token_chain_state ADD COLUMN opt_out_reserved_lamports INTEGER NOT NULL DEFAULT 0');

  // Convert legacy opt-outs from the old shared `hidden` flag to a dedicated reversible flag.
  db.exec(`UPDATE tokens
    SET opt_out_hidden=1
    WHERE recipient_handle IN (SELECT handle FROM recipients WHERE opted_out=1)`);
  db.exec(`UPDATE tokens
    SET hidden=0
    WHERE opt_out_hidden=1
      AND hidden=1
      AND EXISTS (SELECT 1 FROM token_chain_state s WHERE s.mint=tokens.mint AND s.active=1)`);
}""",
"db migrations")

    old = """export function upsertToken(token) {
  const handle = upsertRecipient(token.recipient_handle, token.recipient_display_name || token.recipient_handle);
  db.prepare(`INSERT INTO tokens(
    mint,venue,name,symbol,image_url,description,recipient_handle,recipient_source,market_cap_usd,
    fee_share_bps,permanent,hidden,fee_config_address,created_at,metadata_json
  ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
  ON CONFLICT(mint) DO UPDATE SET
    venue=excluded.venue,name=excluded.name,symbol=excluded.symbol,image_url=excluded.image_url,
    description=excluded.description,recipient_handle=excluded.recipient_handle,recipient_source=excluded.recipient_source,
    market_cap_usd=excluded.market_cap_usd,fee_share_bps=excluded.fee_share_bps,permanent=excluded.permanent,
    hidden=excluded.hidden,fee_config_address=excluded.fee_config_address,created_at=COALESCE(excluded.created_at,tokens.created_at),
    metadata_json=excluded.metadata_json,updated_at=CURRENT_TIMESTAMP`).run(
      token.mint, token.venue || 'pump', token.name || 'Unknown token', token.symbol || 'TOKEN', token.image_url || '',
      token.description || '', handle, token.recipient_source || 'description', Number(token.market_cap_usd || 0),
      Number(token.fee_share_bps || 0), token.permanent ? 1 : 0, token.hidden ? 1 : 0, token.fee_config_address || '',
      token.created_at || null, JSON.stringify(token.metadata || {})
    );
}"""
    new = """export function upsertToken(token) {
  const handle = upsertRecipient(token.recipient_handle, token.recipient_display_name || token.recipient_handle);
  const optedOut=Number(db.prepare('SELECT opted_out FROM recipients WHERE handle=? COLLATE NOCASE').get(handle)?.opted_out||0)===1;
  db.prepare(`INSERT INTO tokens(
    mint,venue,name,symbol,image_url,description,recipient_handle,recipient_source,market_cap_usd,
    fee_share_bps,permanent,hidden,opt_out_hidden,fee_config_address,created_at,metadata_json
  ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
  ON CONFLICT(mint) DO UPDATE SET
    venue=excluded.venue,name=excluded.name,symbol=excluded.symbol,image_url=excluded.image_url,
    description=excluded.description,recipient_handle=excluded.recipient_handle,recipient_source=excluded.recipient_source,
    market_cap_usd=excluded.market_cap_usd,fee_share_bps=excluded.fee_share_bps,permanent=excluded.permanent,
    hidden=excluded.hidden,opt_out_hidden=excluded.opt_out_hidden,fee_config_address=excluded.fee_config_address,created_at=COALESCE(excluded.created_at,tokens.created_at),
    metadata_json=excluded.metadata_json,updated_at=CURRENT_TIMESTAMP`).run(
      token.mint, token.venue || 'pump', token.name || 'Unknown token', token.symbol || 'TOKEN', token.image_url || '',
      token.description || '', handle, token.recipient_source || 'description', Number(token.market_cap_usd || 0),
      Number(token.fee_share_bps || 0), token.permanent ? 1 : 0, token.hidden ? 1 : 0, optedOut ? 1 : 0, token.fee_config_address || '',
      token.created_at || null, JSON.stringify(token.metadata || {})
    );
}"""
    s = replace_once(s, old, new, "db upsertToken")

    old = """export function upsertTokenChainState(state) {
  db.prepare(`INSERT INTO token_chain_state(
    mint,sharing_config_address,verified_slot,admin_revoked,sole_treasury,fee_share_bps,
    distributable_lamports,minimum_required_lamports,can_distribute,is_graduated,sol_usd,
    gross_unclaimed_usd,recipient_unclaimed_usd,protocol_unclaimed_usd,active,
    shareholders_json,last_error,indexed_at
  ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)
  ON CONFLICT(mint) DO UPDATE SET
    sharing_config_address=excluded.sharing_config_address,verified_slot=excluded.verified_slot,
    admin_revoked=excluded.admin_revoked,sole_treasury=excluded.sole_treasury,
    fee_share_bps=excluded.fee_share_bps,distributable_lamports=excluded.distributable_lamports,
    minimum_required_lamports=excluded.minimum_required_lamports,can_distribute=excluded.can_distribute,
    is_graduated=excluded.is_graduated,sol_usd=excluded.sol_usd,
    gross_unclaimed_usd=excluded.gross_unclaimed_usd,
    recipient_unclaimed_usd=excluded.recipient_unclaimed_usd,
    protocol_unclaimed_usd=excluded.protocol_unclaimed_usd,active=excluded.active,
    shareholders_json=excluded.shareholders_json,last_error=excluded.last_error,
    indexed_at=CURRENT_TIMESTAMP`).run(
      state.mint, state.sharing_config_address, state.verified_slot ?? null,
      state.admin_revoked ? 1 : 0, state.sole_treasury ? 1 : 0, Number(state.fee_share_bps || 0),
      Number(state.distributable_lamports || 0), Number(state.minimum_required_lamports || 0),
      state.can_distribute ? 1 : 0, state.is_graduated ? 1 : 0,
      state.sol_usd == null ? null : Number(state.sol_usd),
      state.gross_unclaimed_usd == null ? null : Number(state.gross_unclaimed_usd),
      state.recipient_unclaimed_usd == null ? null : Number(state.recipient_unclaimed_usd),
      state.protocol_unclaimed_usd == null ? null : Number(state.protocol_unclaimed_usd),
      state.active === false ? 0 : 1, JSON.stringify(state.shareholders || []),
      state.last_error || null
    );
}"""
    new = """export function upsertTokenChainState(state) {
  db.prepare(`INSERT INTO token_chain_state(
    mint,sharing_config_address,verified_slot,admin_revoked,sole_treasury,fee_share_bps,
    distributable_lamports,minimum_required_lamports,can_distribute,is_graduated,sol_usd,
    gross_unclaimed_usd,recipient_unclaimed_usd,protocol_unclaimed_usd,opt_out_reserved_lamports,active,
    shareholders_json,last_error,indexed_at
  ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP)
  ON CONFLICT(mint) DO UPDATE SET
    sharing_config_address=excluded.sharing_config_address,verified_slot=excluded.verified_slot,
    admin_revoked=excluded.admin_revoked,sole_treasury=excluded.sole_treasury,
    fee_share_bps=excluded.fee_share_bps,distributable_lamports=excluded.distributable_lamports,
    minimum_required_lamports=excluded.minimum_required_lamports,can_distribute=excluded.can_distribute,
    is_graduated=excluded.is_graduated,sol_usd=excluded.sol_usd,
    gross_unclaimed_usd=excluded.gross_unclaimed_usd,
    recipient_unclaimed_usd=excluded.recipient_unclaimed_usd,
    protocol_unclaimed_usd=excluded.protocol_unclaimed_usd,
    opt_out_reserved_lamports=excluded.opt_out_reserved_lamports,active=excluded.active,
    shareholders_json=excluded.shareholders_json,last_error=excluded.last_error,
    indexed_at=CURRENT_TIMESTAMP`).run(
      state.mint, state.sharing_config_address, state.verified_slot ?? null,
      state.admin_revoked ? 1 : 0, state.sole_treasury ? 1 : 0, Number(state.fee_share_bps || 0),
      Number(state.distributable_lamports || 0), Number(state.minimum_required_lamports || 0),
      state.can_distribute ? 1 : 0, state.is_graduated ? 1 : 0,
      state.sol_usd == null ? null : Number(state.sol_usd),
      state.gross_unclaimed_usd == null ? null : Number(state.gross_unclaimed_usd),
      state.recipient_unclaimed_usd == null ? null : Number(state.recipient_unclaimed_usd),
      state.protocol_unclaimed_usd == null ? null : Number(state.protocol_unclaimed_usd),
      Number(state.opt_out_reserved_lamports || 0),
      state.active === false ? 0 : 1, JSON.stringify(state.shareholders || []),
      state.last_error || null
    );
}"""
    s = replace_once(s, old, new, "db upsertTokenChainState")

    old = """export function recordClaim({ mint, txSignature, grossNative, nativeUsdPrice, raw = null }) {
  const token = db.prepare(`SELECT t.*, r.opted_out FROM tokens t JOIN recipients r ON r.handle=t.recipient_handle WHERE mint=?`).get(mint);
  if (!token) throw new Error(`Unknown token ${mint}`);
  if (txSignature) {
    const existing = db.prepare('SELECT * FROM claims WHERE tx_signature=?').get(txSignature);
    if (existing) return existing;
  }
  const grossUsd = grossNative * nativeUsdPrice;
  const recipientUsd = token.opted_out ? 0 : grossUsd * config.recipientShareBps / 10000;
  const protocolUsd = grossUsd - recipientUsd;
  const id = randomUUID();
  const tx = db.prepare(`INSERT INTO claims(id,mint,tx_signature,gross_native,native_usd_price,gross_usd,recipient_usd,protocol_usd,confirmed_at,raw_json)
    VALUES(?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP,?)`);
  db.exec('BEGIN IMMEDIATE');
  try {
    tx.run(id,mint,txSignature || null,grossNative,nativeUsdPrice,grossUsd,recipientUsd,protocolUsd,JSON.stringify(raw || {}));
    db.prepare(`INSERT INTO buybacks(id,claim_id,source,amount_usd) VALUES(?,?,?,?)`).run(randomUUID(), id, token.opted_out ? 'opted_out_recipient' : 'protocol_cut', protocolUsd);
    db.exec('COMMIT');
  } catch (e) { db.exec('ROLLBACK'); throw e; }
  return db.prepare('SELECT * FROM claims WHERE id=?').get(id);
}"""
    new = """export function recordClaim({ mint, txSignature, grossNative, nativeUsdPrice, raw = null }) {
  const token = db.prepare(`SELECT t.*, r.opted_out FROM tokens t JOIN recipients r ON r.handle=t.recipient_handle WHERE mint=?`).get(mint);
  if (!token) throw new Error(`Unknown token ${mint}`);
  if (txSignature) {
    const existing = db.prepare('SELECT * FROM claims WHERE tx_signature=?').get(txSignature);
    if (existing) return existing;
  }
  const grossUsd = grossNative * nativeUsdPrice;
  const chainState=db.prepare('SELECT opt_out_reserved_lamports FROM token_chain_state WHERE mint=?').get(mint);
  const grossLamports=Math.max(0,Math.round(Number(grossNative||0)*1e9));
  const reservedLamports=Math.min(grossLamports,Math.max(0,Number(chainState?.opt_out_reserved_lamports||0)));
  const reservedUsd=(reservedLamports/1e9)*nativeUsdPrice;
  const eligibleUsd=Math.max(0,grossUsd-reservedUsd);
  const recipientUsd = token.opted_out ? 0 : eligibleUsd * config.recipientShareBps / 10000;
  const protocolUsd = grossUsd - recipientUsd;
  const buybackSource=token.opted_out
    ? 'opted_out_recipient'
    : reservedLamports>0
      ? 'opt_out_reserved_plus_protocol_cut'
      : 'protocol_cut';
  const id = randomUUID();
  const tx = db.prepare(`INSERT INTO claims(id,mint,tx_signature,gross_native,native_usd_price,gross_usd,recipient_usd,protocol_usd,confirmed_at,raw_json)
    VALUES(?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP,?)`);
  db.exec('BEGIN IMMEDIATE');
  try {
    tx.run(id,mint,txSignature || null,grossNative,nativeUsdPrice,grossUsd,recipientUsd,protocolUsd,JSON.stringify(raw || {}));
    db.prepare(`INSERT INTO buybacks(id,claim_id,source,amount_usd) VALUES(?,?,?,?)`).run(randomUUID(), id, buybackSource, protocolUsd);
    db.exec('COMMIT');
  } catch (e) { db.exec('ROLLBACK'); throw e; }
  return db.prepare('SELECT * FROM claims WHERE id=?').get(id);
}"""
    s = replace_once(s, old, new, "db recordClaim")

    s = replace_once(s,
"""        COALESCE((SELECT SUM(pi.amount_usd) FROM payout_items pi JOIN payouts p ON p.id=pi.payout_id WHERE pi.mint=t.mint AND p.status IN ('sent','claimed')),0)
      ) AS owed_usd,""",
"""        COALESCE((SELECT SUM(pi.amount_usd) FROM payout_items pi JOIN payouts p ON p.id=pi.payout_id WHERE pi.mint=t.mint AND p.status IN ('sent','claimed','diverted')),0)
      ) AS owed_usd,""",
"db owed diversion subtraction")

    old = """export function allocatePayoutItems(payoutId, handle, amountUsd) {
  let remaining = amountUsd;
  const rows = tokenFinancialsWhere(`t.recipient_handle=? COLLATE NOCASE AND t.hidden=0`, [handle])
    .filter(x => x.owed_usd > 0).sort((a,b) => String(a.discovered_at).localeCompare(String(b.discovered_at)));
  for (const row of rows) {
    if (remaining <= 0.000001) break;
    const take = Math.min(remaining, row.owed_usd);
    db.prepare(`INSERT INTO payout_items(payout_id,mint,amount_usd) VALUES(?,?,?)
      ON CONFLICT(payout_id,mint) DO UPDATE SET amount_usd=amount_usd+excluded.amount_usd`).run(payoutId,row.mint,take);
    remaining -= take;
  }
  return Math.max(0, remaining);
}"""
    new = """export function allocatePayoutItems(payoutId, handle, amountUsd, {includeHidden=false,claimsOnly=false}={}) {
  let remaining = amountUsd;
  const visibility=includeHidden ? '' : ' AND t.hidden=0 AND COALESCE(t.opt_out_hidden,0)=0';
  const rows = claimsOnly
    ? db.prepare(`
        SELECT t.mint,t.discovered_at,
          MAX(0,
            COALESCE((SELECT SUM(c.recipient_usd) FROM claims c WHERE c.mint=t.mint AND c.status='confirmed'),0) -
            COALESCE((SELECT SUM(pi.amount_usd) FROM payout_items pi JOIN payouts p ON p.id=pi.payout_id
              WHERE pi.mint=t.mint AND p.status IN ('sent','claimed','diverted')),0)
          ) AS owed_usd
        FROM tokens t
        WHERE t.recipient_handle=? COLLATE NOCASE${visibility}
      `).all(handle)
    : tokenFinancialsWhere(`t.recipient_handle=? COLLATE NOCASE${visibility}`, [handle]);
  rows.filter(x => x.owed_usd > 0)
    .sort((a,b) => String(a.discovered_at).localeCompare(String(b.discovered_at)))
    .forEach(row => {
      if (remaining <= 0.000001) return;
      const take = Math.min(remaining, Number(row.owed_usd||0));
      db.prepare(`INSERT INTO payout_items(payout_id,mint,amount_usd) VALUES(?,?,?)
        ON CONFLICT(payout_id,mint) DO UPDATE SET amount_usd=amount_usd+excluded.amount_usd`).run(payoutId,row.mint,take);
      remaining -= take;
    });
  return Math.max(0, remaining);
}"""
    s = replace_once(s, old, new, "db allocatePayoutItems")

    write(rel, s)

def patch_payouts():
    rel="server/payouts.js"
    s=read(rel)

    s=replace_once(s,
"""function recipientBalance(handle){
  const earned=Number(db.prepare(`SELECT COALESCE(SUM(c.recipient_usd),0) v FROM claims c JOIN tokens t ON t.mint=c.mint WHERE t.recipient_handle=? COLLATE NOCASE AND c.status='confirmed'`).get(handle).v);
  const allocated=Number(db.prepare(`SELECT COALESCE(SUM(p.amount_usd),0) v FROM payouts p WHERE p.recipient_handle=? COLLATE NOCASE AND p.status IN ('queued','sent','claimed')`).get(handle).v);
  const sent=Number(db.prepare(`SELECT COALESCE(SUM(p.amount_usd),0) v FROM payouts p WHERE p.recipient_handle=? COLLATE NOCASE AND p.status IN ('sent','claimed')`).get(handle).v);
  return {earned,owed:Math.max(0,earned-allocated),sent};
}
async function sendProvider(payout){""",
"""function recipientBalance(handle){
  const earned=Number(db.prepare(`SELECT COALESCE(SUM(c.recipient_usd),0) v FROM claims c JOIN tokens t ON t.mint=c.mint WHERE t.recipient_handle=? COLLATE NOCASE AND c.status='confirmed'`).get(handle).v);
  const allocated=Number(db.prepare(`SELECT COALESCE(SUM(p.amount_usd),0) v FROM payouts p WHERE p.recipient_handle=? COLLATE NOCASE AND p.status IN ('queued','sent','claimed','diverted')`).get(handle).v);
  const sent=Number(db.prepare(`SELECT COALESCE(SUM(p.amount_usd),0) v FROM payouts p WHERE p.recipient_handle=? COLLATE NOCASE AND p.status IN ('sent','claimed')`).get(handle).v);
  return {earned,owed:Math.max(0,earned-allocated),sent};
}

function cancelQueuedPayouts(handle){
  const out=db.prepare(`UPDATE payouts
    SET status='cancelled',updated_at=CURRENT_TIMESTAMP
    WHERE recipient_handle=? COLLATE NOCASE AND status='queued'`).run(handle);
  return Number(out?.changes||0);
}

function createDiversion(handle,amountUsd,{recordBuyback=true}={}){
  const amount=Math.max(0,Number(amountUsd||0));
  if(amount<=0.000001) return null;
  const id=randomUUID();
  db.prepare(`INSERT INTO payouts(id,recipient_handle,amount_usd,status,provider,raw_json)
    VALUES(?,?,?,'diverted','protocol_opt_out',?)`)
    .run(id,handle,amount,JSON.stringify({reason:'recipient_opt_out'}));
  const remaining=allocatePayoutItems(id,handle,amount,{includeHidden:true,claimsOnly:true});
  if(remaining>0.0001) throw new Error(`Unable to allocate ${remaining.toFixed(6)} USD of opt-out diversion for @${handle}`);
  if(recordBuyback){
    db.prepare(`INSERT INTO buybacks(id,source,amount_usd,status,raw_json)
      VALUES(?,?,?,'pending',?)`)
      .run(randomUUID(),'opt_out_unpaid_balance',amount,JSON.stringify({recipient_handle:handle,payout_id:id}));
  }
  return {id,amountUsd:amount};
}

async function sendProvider(payout){""",
"payouts helpers")

    s=replace_once(s,
"""  for(const r of recipients){
    const bal=recipientBalance(r.handle); const milestone=nextMilestone(bal.sent);""",
"""  for(const r of recipients){
    const latest=db.prepare('SELECT opted_out FROM recipients WHERE handle=? COLLATE NOCASE').get(r.handle);
    if(latest?.opted_out) continue;
    const bal=recipientBalance(r.handle); const milestone=nextMilestone(bal.sent);""",
"payout worker recheck")

    old = """export function optOutHandle(handle){
  const h=String(handle).replace(/^@/,''); const r=db.prepare('SELECT * FROM recipients WHERE handle=? COLLATE NOCASE').get(h); if(!r)throw new Error('Recipient not found');
  db.exec('BEGIN IMMEDIATE');
  try{
    const bal=recipientBalance(h);
    db.prepare(`UPDATE recipients SET opted_out=1,opt_out_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP WHERE handle=? COLLATE NOCASE`).run(h);
    db.prepare(`UPDATE tokens SET hidden=1,updated_at=CURRENT_TIMESTAMP WHERE recipient_handle=? COLLATE NOCASE`).run(h);
    if(bal.owed>0) db.prepare(`INSERT INTO buybacks(id,source,amount_usd,status) VALUES(?,?,?,'pending')`).run(randomUUID(),'opt_out_unpaid_balance',bal.owed);
    db.exec('COMMIT'); return {handle:h,optedOut:true,divertedUsd:bal.owed};
  }catch(e){db.exec('ROLLBACK');throw e;}
}"""
    new = """export function optOutHandle(handle){
  const h=String(handle||'').replace(/^@/,'').trim();
  if(!h) throw new Error('Recipient handle required');
  db.prepare(`INSERT INTO recipients(handle,display_name) VALUES(?,?)
    ON CONFLICT(handle) DO NOTHING`).run(h,h);
  const current=db.prepare('SELECT * FROM recipients WHERE handle=? COLLATE NOCASE').get(h);
  if(current?.opted_out) return {handle:h,optedOut:true,alreadyOptedOut:true,divertedUsd:0,cancelledQueued:0};

  db.exec('BEGIN IMMEDIATE');
  try{
    const cancelledQueued=cancelQueuedPayouts(h);
    const bal=recipientBalance(h);
    const diversion=createDiversion(h,bal.owed,{recordBuyback:true});
    db.prepare(`UPDATE recipients
      SET opted_out=1,opt_out_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP
      WHERE handle=? COLLATE NOCASE`).run(h);
    db.prepare(`UPDATE tokens
      SET opt_out_hidden=1,updated_at=CURRENT_TIMESTAMP
      WHERE recipient_handle=? COLLATE NOCASE`).run(h);
    db.prepare(`UPDATE token_chain_state
      SET opt_out_reserved_lamports=distributable_lamports,
          recipient_unclaimed_usd=0,
          protocol_unclaimed_usd=COALESCE(gross_unclaimed_usd,0),
          indexed_at=CURRENT_TIMESTAMP
      WHERE mint IN (SELECT mint FROM tokens WHERE recipient_handle=? COLLATE NOCASE)`).run(h);
    const reservedLamports=Number(db.prepare(`SELECT COALESCE(SUM(s.opt_out_reserved_lamports),0) v
      FROM token_chain_state s JOIN tokens t ON t.mint=s.mint
      WHERE t.recipient_handle=? COLLATE NOCASE AND s.active=1`).get(h)?.v||0);
    db.exec('COMMIT');
    return {handle:h,optedOut:true,divertedUsd:diversion?.amountUsd||0,cancelledQueued,reservedLamports};
  }catch(e){db.exec('ROLLBACK');throw e;}
}

export function reactivateHandle(handle){
  const h=String(handle||'').replace(/^@/,'').trim();
  if(!h) throw new Error('Recipient handle required');
  const current=db.prepare('SELECT * FROM recipients WHERE handle=? COLLATE NOCASE').get(h);
  if(!current) throw new Error('Recipient not found');
  if(!current.opted_out) return {handle:h,optedOut:false,active:true,alreadyActive:true,legacyDivertedUsd:0,cancelledQueued:0};

  db.exec('BEGIN IMMEDIATE');
  try{
    const cancelledQueued=cancelQueuedPayouts(h);

    // Legacy versions could leave queued payouts and unpaid claimed balance behind.
    // Permanently allocate that balance to protocol accounting before reactivation.
    const legacyBal=recipientBalance(h);
    const legacyDiversion=createDiversion(h,legacyBal.owed,{recordBuyback:false});

    // Freeze every currently-unclaimed lamport that accrued before reactivation.
    // New lamports after reactivation can resume the normal recipient/protocol split.
    db.prepare(`UPDATE token_chain_state
      SET opt_out_reserved_lamports=MAX(COALESCE(opt_out_reserved_lamports,0),distributable_lamports),
          recipient_unclaimed_usd=0,
          protocol_unclaimed_usd=COALESCE(gross_unclaimed_usd,0),
          indexed_at=CURRENT_TIMESTAMP
      WHERE mint IN (SELECT mint FROM tokens WHERE recipient_handle=? COLLATE NOCASE)`).run(h);

    db.prepare(`UPDATE recipients
      SET opted_out=0,reactivated_at=CURRENT_TIMESTAMP,updated_at=CURRENT_TIMESTAMP
      WHERE handle=? COLLATE NOCASE`).run(h);
    db.prepare(`UPDATE tokens
      SET opt_out_hidden=0,updated_at=CURRENT_TIMESTAMP
      WHERE recipient_handle=? COLLATE NOCASE`).run(h);
    db.exec('COMMIT');
    return {handle:h,optedOut:false,active:true,legacyDivertedUsd:legacyDiversion?.amountUsd||0,cancelledQueued};
  }catch(e){db.exec('ROLLBACK');throw e;}
}"""
    s=replace_once(s, old, new, "payout optout/reactivate")
    write(rel,s)

def patch_queries():
    rel="server/queries.js"
    s=read(rel)
    s=replace_once(s,
"  const clauses=['t.hidden=0']; const params=[];",
"  const clauses=['t.hidden=0','COALESCE(t.opt_out_hidden,0)=0']; const params=[];",
"queries list token visibility")

    s=replace_once(s,
"export function getToken(mint){ const row=tokenFinancialsWhere('t.mint=? AND t.hidden=0',[mint])[0]; if(!row)return null; const token=mapToken(row); token.claims=db.prepare('SELECT * FROM claims WHERE mint=? ORDER BY created_at DESC LIMIT 100').all(mint); token.payouts=db.prepare(`SELECT p.*,pi.amount_usd item_amount_usd,r.display_name,r.avatar_url,r.verified,r.verified_type FROM payout_items pi JOIN payouts p ON p.id=pi.payout_id LEFT JOIN recipients r ON r.handle=p.recipient_handle WHERE pi.mint=? ORDER BY p.created_at DESC`).all(mint); token.chain=db.prepare(`SELECT sharing_config_address,verified_slot,admin_revoked,sole_treasury,fee_share_bps,distributable_lamports,minimum_required_lamports,can_distribute,is_graduated,sol_usd,gross_unclaimed_usd,recipient_unclaimed_usd,protocol_unclaimed_usd,indexed_at FROM token_chain_state WHERE mint=? AND active=1`).get(mint)||null; return token; }",
"export function getToken(mint){ const row=tokenFinancialsWhere('t.mint=? AND t.hidden=0 AND COALESCE(t.opt_out_hidden,0)=0',[mint])[0]; if(!row)return null; const token=mapToken(row); token.claims=db.prepare('SELECT * FROM claims WHERE mint=? ORDER BY created_at DESC LIMIT 100').all(mint); token.payouts=db.prepare(`SELECT p.*,pi.amount_usd item_amount_usd,r.display_name,r.avatar_url,r.verified,r.verified_type FROM payout_items pi JOIN payouts p ON p.id=pi.payout_id LEFT JOIN recipients r ON r.handle=p.recipient_handle WHERE pi.mint=? AND p.status NOT IN ('diverted','cancelled') ORDER BY p.created_at DESC`).all(mint); token.chain=db.prepare(`SELECT sharing_config_address,verified_slot,admin_revoked,sole_treasury,fee_share_bps,distributable_lamports,minimum_required_lamports,can_distribute,is_graduated,sol_usd,gross_unclaimed_usd,recipient_unclaimed_usd,protocol_unclaimed_usd,opt_out_reserved_lamports,indexed_at FROM token_chain_state WHERE mint=? AND active=1`).get(mint)||null; return token; }",
"queries getToken")

    s=replace_once(s,
"export function listPayments(limit=50){ return db.prepare(`SELECT p.*,r.display_name,r.avatar_url,r.verified,r.verified_type, GROUP_CONCAT(pi.mint) mints FROM payouts p LEFT JOIN recipients r ON r.handle=p.recipient_handle LEFT JOIN payout_items pi ON pi.payout_id=p.id GROUP BY p.id ORDER BY p.created_at DESC LIMIT ?`).all(Number(limit)); }",
"export function listPayments(limit=50){ return db.prepare(`SELECT p.*,r.display_name,r.avatar_url,r.verified,r.verified_type, GROUP_CONCAT(pi.mint) mints FROM payouts p LEFT JOIN recipients r ON r.handle=p.recipient_handle LEFT JOIN payout_items pi ON pi.payout_id=p.id WHERE COALESCE(r.opted_out,0)=0 AND p.status NOT IN ('diverted','cancelled') GROUP BY p.id ORDER BY p.created_at DESC LIMIT ?`).all(Number(limit)); }",
"queries listPayments")

    s=replace_once(s,
"""  const totalOwed=Number(db.prepare(`SELECT COALESCE(SUM(recipient_usd),0) v FROM claims WHERE status='confirmed'`).get().v)+indexedOwed-Number(db.prepare(`SELECT COALESCE(SUM(pi.amount_usd),0) v FROM payout_items pi JOIN payouts p ON p.id=pi.payout_id WHERE p.status IN ('sent','claimed')`).get().v);""",
"""  const totalOwed=Number(db.prepare(`SELECT COALESCE(SUM(recipient_usd),0) v FROM claims WHERE status='confirmed'`).get().v)+indexedOwed-Number(db.prepare(`SELECT COALESCE(SUM(pi.amount_usd),0) v FROM payout_items pi JOIN payouts p ON p.id=pi.payout_id WHERE p.status IN ('sent','claimed','diverted')`).get().v);""",
"queries totalOwed")

    s=replace_once(s,
"""  const topPaid=db.prepare(`SELECT r.handle,r.display_name,r.avatar_url,r.verified,r.verified_type,COALESCE(SUM(p.amount_usd),0) received FROM recipients r JOIN payouts p ON p.recipient_handle=r.handle WHERE p.status IN ('sent','claimed') GROUP BY r.handle ORDER BY received DESC LIMIT 10`).all();""",
"""  const topPaid=db.prepare(`SELECT r.handle,r.display_name,r.avatar_url,r.verified,r.verified_type,COALESCE(SUM(p.amount_usd),0) received FROM recipients r JOIN payouts p ON p.recipient_handle=r.handle WHERE r.opted_out=0 AND p.status IN ('sent','claimed') GROUP BY r.handle ORDER BY received DESC LIMIT 10`).all();""",
"queries topPaid")

    old="""export function profile(handle){
  const recipient=db.prepare('SELECT * FROM recipients WHERE handle=? COLLATE NOCASE').get(handle); if(!recipient)return null;
  const tokens=listTokens({limit:500}).filter(t=>t.recipient_handle.toLowerCase()===String(handle).replace(/^@/,'').toLowerCase());
  const payments=db.prepare(`SELECT * FROM payouts WHERE recipient_handle=? COLLATE NOCASE ORDER BY created_at DESC LIMIT 100`).all(handle);
  return {recipient,tokens,payments,received:payments.filter(p=>['sent','claimed'].includes(p.status)).reduce((a,p)=>a+Number(p.amount_usd),0)};
}"""
    new="""export function profile(handle){
  const recipient=db.prepare('SELECT * FROM recipients WHERE handle=? COLLATE NOCASE').get(handle); if(!recipient)return null;
  if(recipient.opted_out) return {recipient,tokens:[],payments:[],received:0};
  const tokens=listTokens({limit:500}).filter(t=>t.recipient_handle.toLowerCase()===String(handle).replace(/^@/,'').toLowerCase());
  const payments=db.prepare(`SELECT * FROM payouts WHERE recipient_handle=? COLLATE NOCASE AND status NOT IN ('diverted','cancelled') ORDER BY created_at DESC LIMIT 100`).all(handle);
  return {recipient,tokens,payments,received:payments.filter(p=>['sent','claimed'].includes(p.status)).reduce((a,p)=>a+Number(p.amount_usd),0)};
}"""
    s=replace_once(s,old,new,"queries profile")

    s=replace_once(s,
"""export function homeData(){ const tokens=listTokens({limit:40}); return {tokens, trending:tokens.slice(0,10), payments:listPayments(12), money:moneySummary(), profiles:db.prepare(`SELECT r.handle,r.display_name,r.avatar_url,r.banner_url,r.verified,r.verified_type,COUNT(DISTINCT t.mint) token_count,COALESCE(SUM(p.amount_usd),0) received FROM recipients r LEFT JOIN tokens t ON t.recipient_handle=r.handle AND t.hidden=0 LEFT JOIN payouts p ON p.recipient_handle=r.handle AND p.status IN ('sent','claimed') WHERE r.opted_out=0 GROUP BY r.handle ORDER BY received DESC LIMIT 12`).all()}; }""",
"""export function homeData(){ const tokens=listTokens({limit:40}); return {tokens, trending:tokens.slice(0,10), payments:listPayments(12), money:moneySummary(), profiles:db.prepare(`SELECT r.handle,r.display_name,r.avatar_url,r.banner_url,r.verified,r.verified_type,COUNT(DISTINCT t.mint) token_count,COALESCE(SUM(p.amount_usd),0) received FROM recipients r LEFT JOIN tokens t ON t.recipient_handle=r.handle AND t.hidden=0 AND COALESCE(t.opt_out_hidden,0)=0 LEFT JOIN payouts p ON p.recipient_handle=r.handle AND p.status IN ('sent','claimed') WHERE r.opted_out=0 GROUP BY r.handle ORDER BY received DESC LIMIT 12`).all()}; }""",
"queries home profiles")
    write(rel,s)

def patch_solana():
    rel="server/solana.js"
    s=read(rel)

    old="""  const grossUnclaimedUsd=(distributableLamports/1e9)*solPrice;
  upsertToken({
    mint,venue:'pump',name:name||existing.name,symbol:symbol||existing.symbol,image_url:meta.image_uri||meta.image||meta.image_url||meta.metadata?.image_uri||meta.metadata?.image||meta.metadata?.image_url||meta.coin_metadata?.image_uri||meta.coin_metadata?.image||meta.coin_metadata?.image_url||existing?.image_url||'',
    description:description||existing?.description||'',recipient_handle:handle,recipient_source:recipientSource,
    market_cap_usd:Number.isFinite(marketCap)?marketCap:Number(existing.market_cap_usd),
    fee_share_bps:10000,permanent:true,hidden:false,fee_config_address:cfg,
    created_at:meta.created_timestamp?new Date(Number(meta.created_timestamp)<1e12?Number(meta.created_timestamp)*1000:Number(meta.created_timestamp)).toISOString():existing?.created_at||null,metadata:meta
  });
  upsertTokenChainState({
    mint,sharing_config_address:cfg,verified_slot:slot,admin_revoked:true,sole_treasury:true,fee_share_bps:10000,
    distributable_lamports:distributableLamports,minimum_required_lamports:minimumLamports,
    can_distribute:!!minimum.canDistribute,is_graduated:!!minimum.isGraduated,sol_usd:solPrice,
    gross_unclaimed_usd:grossUnclaimedUsd,
    recipient_unclaimed_usd:grossUnclaimedUsd*config.recipientShareBps/10000,
    protocol_unclaimed_usd:grossUnclaimedUsd*config.protocolShareBps/10000,
    shareholders,active:true
  });"""
    new="""  const grossUnclaimedUsd=(distributableLamports/1e9)*solPrice;
  upsertToken({
    mint,venue:'pump',name:name||existing.name,symbol:symbol||existing.symbol,image_url:meta.image_uri||meta.image||meta.image_url||meta.metadata?.image_uri||meta.metadata?.image||meta.metadata?.image_url||meta.coin_metadata?.image_uri||meta.coin_metadata?.image||meta.coin_metadata?.image_url||existing?.image_url||'',
    description:description||existing?.description||'',recipient_handle:handle,recipient_source:recipientSource,
    market_cap_usd:Number.isFinite(marketCap)?marketCap:Number(existing.market_cap_usd),
    fee_share_bps:10000,permanent:true,hidden:false,fee_config_address:cfg,
    created_at:meta.created_timestamp?new Date(Number(meta.created_timestamp)<1e12?Number(meta.created_timestamp)*1000:Number(meta.created_timestamp)).toISOString():existing?.created_at||null,metadata:meta
  });

  const recipientState=db.prepare('SELECT opted_out FROM recipients WHERE handle=? COLLATE NOCASE').get(handle);
  const previousState=db.prepare('SELECT opt_out_reserved_lamports FROM token_chain_state WHERE mint=?').get(mint);
  const optedOut=Boolean(recipientState?.opted_out);
  const priorReserved=Math.max(0,Number(previousState?.opt_out_reserved_lamports||0));
  const reservedLamports=optedOut
    ? distributableLamports
    : Math.min(distributableLamports,priorReserved);
  const eligibleLamports=Math.max(0,distributableLamports-reservedLamports);
  const reservedUsd=(reservedLamports/1e9)*solPrice;
  const eligibleUsd=(eligibleLamports/1e9)*solPrice;
  const recipientUnclaimedUsd=optedOut ? 0 : eligibleUsd*config.recipientShareBps/10000;
  const protocolUnclaimedUsd=optedOut
    ? grossUnclaimedUsd
    : reservedUsd + eligibleUsd*config.protocolShareBps/10000;

  upsertTokenChainState({
    mint,sharing_config_address:cfg,verified_slot:slot,admin_revoked:true,sole_treasury:true,fee_share_bps:10000,
    distributable_lamports:distributableLamports,minimum_required_lamports:minimumLamports,
    can_distribute:!!minimum.canDistribute,is_graduated:!!minimum.isGraduated,sol_usd:solPrice,
    gross_unclaimed_usd:grossUnclaimedUsd,
    recipient_unclaimed_usd:recipientUnclaimedUsd,
    protocol_unclaimed_usd:protocolUnclaimedUsd,
    opt_out_reserved_lamports:reservedLamports,
    shareholders,active:true
  });"""
    s=replace_once(s,old,new,"solana optout reservation")

    s=replace_once(s,
"""  db.prepare(`UPDATE token_chain_state SET distributable_lamports=0,gross_unclaimed_usd=0,recipient_unclaimed_usd=0,protocol_unclaimed_usd=0,can_distribute=0,indexed_at=CURRENT_TIMESTAMP WHERE mint=?`).run(mint);""",
"""  db.prepare(`UPDATE token_chain_state SET distributable_lamports=0,gross_unclaimed_usd=0,recipient_unclaimed_usd=0,protocol_unclaimed_usd=0,opt_out_reserved_lamports=0,can_distribute=0,indexed_at=CURRENT_TIMESTAMP WHERE mint=?`).run(mint);""",
"solana clear reservation after claim")
    write(rel,s)

def patch_api():
    rel="server/api.js"
    s=read(rel)
    s=replace_once(s,
"import { confirmPayout, optOutHandle } from './payouts.js';",
"import { confirmPayout, optOutHandle, reactivateHandle } from './payouts.js';",
"api payouts import")

    old="""      const user=await finishXOAuth({code:url.searchParams.get('code'),state:url.searchParams.get('state')});
      if(!user?.username)throw Object.assign(new Error('X did not return a username'),{statusCode:502});
      const token=createXSession(user);"""
    new="""      const user=await finishXOAuth({code:url.searchParams.get('code'),state:url.searchParams.get('state')});
      if(!user?.username)throw Object.assign(new Error('X did not return a username'),{statusCode:502});
      cacheXIdentityUser(user);
      const token=createXSession(user);"""
    s=replace_once(s,old,new,"api cache oauth identity")

    old="""    if(req.method==='GET'&&url.pathname==='/api/auth/x/session'){
      const user=xSessionUser(req);
      return json(res,200,{authenticated:Boolean(user),user:user?{
        id:user.id,username:user.username,name:user.name,profile_image_url:user.profile_image_url
      }:null});
    }"""
    new="""    if(req.method==='GET'&&url.pathname==='/api/auth/x/session'){
      const user=xSessionUser(req);
      const recipient=user
        ? db.prepare('SELECT opted_out,opt_out_at,reactivated_at FROM recipients WHERE handle=? COLLATE NOCASE').get(user.username)
        : null;
      return json(res,200,{authenticated:Boolean(user),user:user?{
        id:user.id,username:user.username,name:user.name,profile_image_url:user.profile_image_url,
        opted_out:Boolean(recipient?.opted_out),
        opt_out_at:recipient?.opt_out_at||null,
        reactivated_at:recipient?.reactivated_at||null
      }:null});
    }"""
    s=replace_once(s,old,new,"api session status")

    old="""    if(req.method==='POST'&&url.pathname==='/api/auth/x/opt-out'){
      const user=xSessionUser(req);
      if(!user)throw Object.assign(new Error('Sign in with X first'),{statusCode:401});
      const result=optOutHandle(user.username);
      res.setHeader('set-cookie',xSessionCookie(req,'',0));
      return json(res,200,{ok:true,handle:result.handle});
    }
    if(req.method==='POST'&&url.pathname==='/api/auth/x/logout'){"""
    new="""    if(req.method==='POST'&&url.pathname==='/api/auth/x/opt-out'){
      const user=xSessionUser(req);
      if(!user)throw Object.assign(new Error('Sign in with X first'),{statusCode:401});
      const result=optOutHandle(user.username);
      res.setHeader('set-cookie',xSessionCookie(req,'',0));
      return json(res,200,{ok:true,...result});
    }
    if(req.method==='POST'&&url.pathname==='/api/auth/x/reactivate'){
      const user=xSessionUser(req);
      if(!user)throw Object.assign(new Error('Sign in with X first'),{statusCode:401});
      const result=reactivateHandle(user.username);
      res.setHeader('set-cookie',xSessionCookie(req,'',0));
      return json(res,200,{ok:true,...result});
    }
    if(req.method==='POST'&&url.pathname==='/api/auth/x/logout'){"""
    s=replace_once(s,old,new,"api reactivate route")

    s=replace_once(s,
"""    if(req.method==='POST'&&url.pathname==='/api/admin/opt-out'){ requireAdmin(req); const b=await body(req); return json(res,200,optOutHandle(b.handle)); }""",
"""    if(req.method==='POST'&&url.pathname==='/api/admin/opt-out'){ requireAdmin(req); const b=await body(req); return json(res,200,optOutHandle(b.handle)); }
    if(req.method==='POST'&&url.pathname==='/api/admin/reactivate'){ requireAdmin(req); const b=await body(req); return json(res,200,reactivateHandle(b.handle)); }""",
"api admin reactivate")
    write(rel,s)

def patch_xoauth():
    rel="server/xoauth.js"
    s=read(rel)
    s=replace_once(s,
"""    'https://api.x.com/2/users/me?user.fields=name,username,profile_image_url',""",
"""    'https://api.x.com/2/users/me?user.fields=name,username,profile_image_url,verified,verified_type',""",
"xoauth identity fields")
    write(rel,s)

def patch_app():
    rel="src/app.js"
    s=read(rel)

    old = """async function optOutPage(){
  const raw=(location.hash||'').split('?')[1]||'';
  const qs=new URLSearchParams(raw);
  const done=qs.get('done')||'';
  const oauthError=qs.get('oauth_error')||'';

  let auth={authenticated:false,user:null};
  let oauthStatus={configured:false,callbackUrl:'',hasClientSecret:false,hasSessionSecret:false};
  if(!done){
    try{auth=await api('/api/auth/x/session');}catch{}
    try{oauthStatus=await api('/api/auth/x/status');}catch{}
  }
  const user=auth?.authenticated?auth.user:null;

  return `<main class="optout-page-v1">
    <section class="wrap optout-hero">
      <h1>Opt out of ${esc(state.brand.name)}</h1>
      <p>Sign in with X to stop payments to your account and keep tokens that name you off this site.</p>
    </section>

    <section class="wrap optout-card">
      <p class="eyebrow">Opt out</p>
      <h2>Turn off everything tied to your handle</h2>
      <p class="optout-lead">${esc(state.brand.name)} pays creator-fee distributions to the X account a token names. If that is you and you do not want it, opting out disables the recipient flow for your handle.</p>

      <div class="optout-effects">
        <div><b>1</b><section><h3>Payments stop</h3><p>We will not send future X Money-style payouts to your account.</p></section></div>
        <div><b>2</b><section><h3>Tokens naming you are hidden</h3><p>They are removed from Explore, Payments, search and your public profile views.</p></section></div>
        <div><b>3</b><section><h3>Unpaid fees move to protocol accounting</h3><p>Future unpaid recipient accounting can be diverted to the protocol allocation and pending $PAID buyback ledger.</p></section></div>
        <div><b>4</b><section><h3>Launches here cannot pick you</h3><p>The launch flow rejects a recipient handle that has opted out.</p></section></div>
      </div>

      <div class="optout-limit">
        <h3>What we cannot stop</h3>
        <p>Anyone can still create a token on third-party launch venues using your handle or name. We do not control those venues. We can stop listing it here and stop paying your handle from it.</p>
      </div>

      <p class="optout-auth-note">Signing in verifies that the request comes from the X account owner. Opt-out happens only after a separate confirmation.</p>
    </section>

    <section class="wrap optout-status-card">
      ${done ? `
        <div class="optout-success">
          <div class="optout-success-icon">✓</div>
          <div>
            <span>Opted out</span>
            <h2>@${esc(done)}</h2>
            <p>Payments and launch selection for this handle are now disabled by the backend.</p>
          </div>
        </div>
        <div class="optout-check-grid">
          <div><span>Your X account</span><b>@${esc(done)}</b></div>
          <div><span>X Money payments</span><b>Stopped</b></div>
          <div><span>Tokens shown here</span><b>Hidden</b></div>
          <div><span>Selectable at launch</span><b>No</b></div>
        </div>
      ` : user ? `
        <div class="optout-checking optout-authenticated">
          <span>Signed in</span>
          <h2>${esc(user.name||user.username)}</h2>
          <p class="optout-auth-handle">@${esc(user.username)}</p>
          <div class="optout-check-grid">
            <div><span>X account</span><b>Verified</b></div>
            <div><span>X Money payments</span><b>Ready to stop</b></div>
            <div><span>Tokens shown here</span><b>Ready to hide</b></div>
            <div><span>Unpaid fees</span><b>Confirm required</b></div>
          </div>
        </div>

        <div class="optout-auth-actions">
          <button class="btn-light full center-button optout-x-button" type="button" data-action="confirm-opt-out">Confirm opt out</button>
          <button class="optout-secondary-button" type="button" data-action="x-logout">Sign out</button>
        </div>
      ` : `
        <div class="optout-checking">
          <span>Checking</span>
          <h2>Your X account</h2>
          <div class="optout-check-grid">
            <div><span>X Money payments</span><b>—</b></div>
            <div><span>Tokens shown here</span><b>—</b></div>
            <div><span>Selectable at launch</span><b>—</b></div>
            <div><span>Unpaid fees</span><b>—</b></div>
          </div>
        </div>

        <a class="btn-light full center-button optout-x-button" href="/api/auth/x/start">Sign in with X</a>
        ${oauthError?`<div class="status-box optout-env-note optout-oauth-error">${esc(oauthError)}</div>`:''}
        ${!oauthStatus.configured?`<div class="status-box optout-env-note">X OAuth needs an X Developer App client ID before sign-in can start.</div>`:''}
      `}

      <div class="optout-progress">
        <div class="${done||user?'done':'active'}"><b>1</b><span>Sign in with X</span></div>
        <div class="${done?'done':user?'active':''}"><b>2</b><span>Confirm</span></div>
        <div class="${done?'done':''}"><b>3</b><span>Opted out</span></div>
      </div>
    </section>

    ${moneyFooter()}
  </main>`;
}"""

    new = """async function optOutPage(){
  const raw=(location.hash||'').split('?')[1]||'';
  const qs=new URLSearchParams(raw);
  const done=qs.get('done')||'';
  const reactivated=qs.get('reactivated')||'';
  const oauthError=qs.get('oauth_error')||'';

  let auth={authenticated:false,user:null};
  let oauthStatus={configured:false,callbackUrl:'',hasClientSecret:false,hasSessionSecret:false};
  if(!done&&!reactivated){
    try{auth=await api('/api/auth/x/session');}catch{}
    try{oauthStatus=await api('/api/auth/x/status');}catch{}
  }
  const user=auth?.authenticated?auth.user:null;
  const isOptedOut=Boolean(user?.opted_out);
  const finished=Boolean(done||reactivated);
  const targetLabel=reactivated||isOptedOut?'Active':'Opted out';

  return `<main class="optout-page-v1">
    <section class="wrap optout-hero">
      <h1>Manage ${esc(state.brand.name)} status</h1>
      <p>Sign in with X to stop recipient payments and visibility, or reactivate the same handle later.</p>
    </section>

    <section class="wrap optout-card">
      <p class="eyebrow">Recipient control</p>
      <h2>Turn off everything tied to your handle</h2>
      <p class="optout-lead">${esc(state.brand.name)} pays creator-fee distributions to the X account a token names. The verified X owner can opt out and can later reactivate the handle.</p>

      <div class="optout-effects">
        <div><b>1</b><section><h3>Payments stop</h3><p>We will not create future recipient payouts while your handle is opted out.</p></section></div>
        <div><b>2</b><section><h3>Tokens naming you are hidden</h3><p>They are removed from Explore, Payments, search and your public profile views.</p></section></div>
        <div><b>3</b><section><h3>Unpaid fees move to protocol accounting</h3><p>Already-unpaid recipient balance and fees accrued while opted out stay protocol-side and are not restored by reactivation.</p></section></div>
        <div><b>4</b><section><h3>Launches here cannot pick you</h3><p>The launch flow rejects a recipient handle while it is opted out.</p></section></div>
      </div>

      <div class="optout-limit">
        <h3>What we cannot stop</h3>
        <p>Anyone can still create a token on third-party launch venues using your handle or name. We do not control those venues. We can stop listing it here and stop paying your handle from it.</p>
        <h3>Reactivation</h3>
        <p>Sign in again with the same X account and choose Reactivate. Visibility, launch selection and future recipient accounting resume from that point forward; previously diverted amounts remain protocol-side.</p>
      </div>

      <p class="optout-auth-note">Signing in verifies that the request comes from the X account owner. Both opt-out and reactivation require a separate confirmation.</p>
    </section>

    <section class="wrap optout-status-card">
      ${done ? `
        <div class="optout-success">
          <div class="optout-success-icon">✓</div>
          <div>
            <span>Opted out</span>
            <h2>@${esc(done)}</h2>
            <p>Future recipient payouts, public listings and launch selection are disabled for this handle.</p>
          </div>
        </div>
        <div class="optout-check-grid">
          <div><span>Your X account</span><b>@${esc(done)}</b></div>
          <div><span>X Money payments</span><b>Stopped</b></div>
          <div><span>Tokens shown here</span><b>Hidden</b></div>
          <div><span>Selectable at launch</span><b>No</b></div>
        </div>
      ` : reactivated ? `
        <div class="optout-success">
          <div class="optout-success-icon">✓</div>
          <div>
            <span>Active again</span>
            <h2>@${esc(reactivated)}</h2>
            <p>Future recipient accounting, eligible token visibility and launch selection are active again.</p>
          </div>
        </div>
        <div class="optout-check-grid">
          <div><span>Your X account</span><b>@${esc(reactivated)}</b></div>
          <div><span>Future payments</span><b>Enabled</b></div>
          <div><span>Eligible tokens</span><b>Visible</b></div>
          <div><span>Past diverted fees</span><b>Not restored</b></div>
        </div>
      ` : user ? `
        <div class="optout-checking optout-authenticated">
          <span>${isOptedOut?'Signed in · opted out':'Signed in · active'}</span>
          <h2>${esc(user.name||user.username)}</h2>
          <p class="optout-auth-handle">@${esc(user.username)}</p>
          <div class="optout-check-grid">
            <div><span>X account</span><b>Verified</b></div>
            <div><span>X Money payments</span><b>${isOptedOut?'Stopped':'Ready to stop'}</b></div>
            <div><span>Tokens shown here</span><b>${isOptedOut?'Hidden':'Ready to hide'}</b></div>
            <div><span>${isOptedOut?'Reactivation':'Unpaid fees'}</span><b>Confirm required</b></div>
          </div>
        </div>

        <div class="optout-auth-actions">
          <button class="btn-light full center-button optout-x-button" type="button" data-action="${isOptedOut?'confirm-reactivate':'confirm-opt-out'}">${isOptedOut?'Reactivate':'Confirm opt out'}</button>
          <button class="optout-secondary-button" type="button" data-action="x-logout">Sign out</button>
        </div>
      ` : `
        <div class="optout-checking">
          <span>Checking</span>
          <h2>Your X account</h2>
          <div class="optout-check-grid">
            <div><span>X Money payments</span><b>—</b></div>
            <div><span>Tokens shown here</span><b>—</b></div>
            <div><span>Selectable at launch</span><b>—</b></div>
            <div><span>Unpaid fees</span><b>—</b></div>
          </div>
        </div>

        <a class="btn-light full center-button optout-x-button" href="/api/auth/x/start">Sign in with X</a>
        ${oauthError?`<div class="status-box optout-env-note optout-oauth-error">${esc(oauthError)}</div>`:''}
        ${!oauthStatus.configured?`<div class="status-box optout-env-note">X OAuth needs an X Developer App client ID before sign-in can start.</div>`:''}
      `}

      <div class="optout-progress">
        <div class="${finished||user?'done':'active'}"><b>1</b><span>Sign in with X</span></div>
        <div class="${finished?'done':user?'active':''}"><b>2</b><span>Confirm</span></div>
        <div class="${finished?'done':''}"><b>3</b><span>${targetLabel}</span></div>
      </div>
    </section>

    ${moneyFooter()}
  </main>`;
}"""
    s=replace_once(s,old,new,"app optout page")

    old_line="""    const a=e.target.closest('[data-action]');if(a){const action=a.dataset.action;if(action==='confirm-opt-out'){e.preventDefault();a.disabled=true;a.textContent='Confirming…';const result=await api('/api/auth/x/opt-out',{method:'POST',body:'{}'});location.hash=`#/opt-out?done=${encodeURIComponent(result.handle)}`;return;}if(action==='x-logout'){e.preventDefault();await api('/api/auth/x/logout',{method:'POST',body:'{}'});location.hash='#/opt-out';await render();return;}if(action==='menu')document.querySelector('#mobileMenu')?.classList.toggle('hidden');if(action==='go-launch')location.hash='#/launch';if(action==='reload'){state.home=null;render();}if(action==='connect-wallet'){const pub=await connectWallet();if(pub)setLaunchStatus(`Wallet connected: ${pub}`,true);}if(action==='launch-token')await launchTokenOnPump();if(action==='route-fees')await routeFees();if(action==='verify-mint'){const mint=(document.querySelector('#launchMintSuccess')?.value||document.querySelector('#launchMint')?.value||'').trim();if(!mint)throw new Error('Paste the mint first');const out=await api('/api/tokens/register',{method:'POST',body:JSON.stringify({mint,recipient_handle:currentLaunch?.handle||''})});setLaunchStatus(out.ok?`Registered for @${out.recipient}`:`Not ready: ${out.reason}`,out.ok);}if(action==='copy-fee-address'){const value=String(a.dataset.copyValue||'').trim();if(value&&navigator.clipboard?.writeText){await navigator.clipboard.writeText(value);a.textContent='✓';setTimeout(()=>{a.textContent='⌑';},900);}}}"""
    new_line="""    const a=e.target.closest('[data-action]');if(a){const action=a.dataset.action;if(action==='confirm-opt-out'){e.preventDefault();a.disabled=true;a.textContent='Confirming…';const result=await api('/api/auth/x/opt-out',{method:'POST',body:'{}'});location.hash=`#/opt-out?done=${encodeURIComponent(result.handle)}`;return;}if(action==='confirm-reactivate'){e.preventDefault();a.disabled=true;a.textContent='Reactivating…';const result=await api('/api/auth/x/reactivate',{method:'POST',body:'{}'});location.hash=`#/opt-out?reactivated=${encodeURIComponent(result.handle)}`;return;}if(action==='x-logout'){e.preventDefault();await api('/api/auth/x/logout',{method:'POST',body:'{}'});location.hash='#/opt-out';await render();return;}if(action==='menu')document.querySelector('#mobileMenu')?.classList.toggle('hidden');if(action==='go-launch')location.hash='#/launch';if(action==='reload'){state.home=null;render();}if(action==='connect-wallet'){const pub=await connectWallet();if(pub)setLaunchStatus(`Wallet connected: ${pub}`,true);}if(action==='launch-token')await launchTokenOnPump();if(action==='route-fees')await routeFees();if(action==='verify-mint'){const mint=(document.querySelector('#launchMintSuccess')?.value||document.querySelector('#launchMint')?.value||'').trim();if(!mint)throw new Error('Paste the mint first');const out=await api('/api/tokens/register',{method:'POST',body:JSON.stringify({mint,recipient_handle:currentLaunch?.handle||''})});setLaunchStatus(out.ok?`Registered for @${out.recipient}`:`Not ready: ${out.reason}`,out.ok);}if(action==='copy-fee-address'){const value=String(a.dataset.copyValue||'').trim();if(value&&navigator.clipboard?.writeText){await navigator.clipboard.writeText(value);a.textContent='✓';setTimeout(()=>{a.textContent='⌑';},900);}}}"""
    s=replace_once(s,old_line,new_line,"app action handler")

    s=replace_once(s,
"""        <p>The project includes an X OAuth opt-out flow. Once a handle is verified and opted out, future payout eligibility can be blocked and the related token visibility/accounting rules can be applied consistently by the backend.</p>""",
"""        <p>The project includes an X OAuth opt-out and reactivation flow. Once a handle is verified and opted out, future payout eligibility is blocked, related tokens are hidden and unpaid recipient accounting is diverted. The same X owner can later reactivate future eligibility; amounts already diverted while opted out are not restored.</p>""",
"app docs stopping payments")

    s=replace_once(s,
"""        <p>An X account owner can use the opt-out flow to stop future recipient payouts and hide associated listings in this product. Opting out does not prevent third parties from creating or trading tokens elsewhere.</p>""",
"""        <p>An X account owner can use the opt-out flow to stop future recipient payouts and hide associated listings in this product. The same owner can later reactivate future eligibility by signing in again with X. Reactivation does not reverse amounts already diverted while opted out. Opting out does not prevent third parties from creating or trading tokens elsewhere.</p>""",
"app legal optout")

    write(rel,s)

def verify_markers():
    checks={
        "server/db.js":["optout-reactivation-v1","opt_out_hidden","opt_out_reserved_lamports"],
        "server/payouts.js":["reactivateHandle","protocol_opt_out","cancelQueuedPayouts"],
        "server/queries.js":["COALESCE(t.opt_out_hidden,0)=0","'diverted'"],
        "server/solana.js":["opt_out_reserved_lamports","eligibleLamports"],
        "server/api.js":["/api/auth/x/reactivate","reactivateHandle","opted_out:Boolean"],
        "server/xoauth.js":["verified,verified_type"],
        "src/app.js":["confirm-reactivate","reactivated","Past diverted fees"],
    }
    for rel,needles in checks.items():
        t=read(rel)
        for n in needles:
            if n not in t:
                die(f"Verification failed: {n!r} missing from {rel}")

def run(cmd, allow_fail=False):
    print("+", " ".join(cmd))
    p=subprocess.run(cmd, cwd=ROOT)
    if p.returncode and not allow_fail:
        die(f"Command failed ({p.returncode}): {' '.join(cmd)}")
    return p.returncode

def main():
    for rel in FILES:
        if not (ROOT/rel).exists():
            die(f"Run this from the existing Pump-Fee-Routing Replit workspace; {rel} is missing.")

    # Idempotent all-installed check.
    if all(marker in read(rel) for rel,marker in [
        ("server/db.js","optout-reactivation-v1"),
        ("server/payouts.js","export function reactivateHandle"),
        ("server/api.js","/api/auth/x/reactivate"),
        ("src/app.js","confirm-reactivate"),
    ]):
        print("Opt-out/reactivation v1 is already installed.")
        verify_markers()
    else:
        backup()
        patch_db()
        patch_payouts()
        patch_queries()
        patch_solana()
        patch_api()
        patch_xoauth()
        patch_app()
        verify_markers()

    for rel in FILES:
        run(["node","--check",rel])
    run(["npm","run","check"])
    run(["git","diff","--check"])

    print("\nPatch checks passed.")
    print("No server restart was performed.")

    # Commit and push, but never fail the patch if git identity/credentials are unavailable.
    run(["git","add",*FILES])
    diff_rc=subprocess.run(["git","diff","--cached","--quiet"],cwd=ROOT).returncode
    if diff_rc==0:
        print("No new git changes to commit.")
        return

    commit = subprocess.run(
        ["git","commit","-m","Fix reversible X opt-out and reactivation"],
        cwd=ROOT
    )
    if commit.returncode!=0:
        print("\nPatch is installed and verified, but git commit failed. Commit manually if needed.")
        return

    push = subprocess.run(["git","push","origin","HEAD"],cwd=ROOT)
    if push.returncode!=0:
        print("\nPatch is committed locally, but git push failed. Run: git push origin HEAD")
    else:
        print("\nPatch committed and pushed successfully.")

if __name__=="__main__":
    main()
