#!/usr/bin/env bash
set -euo pipefail

echo "Installing opt-out/reactivation v1..."
python3 "$(dirname "$0")/apply_patch.py"
echo
echo "Done. Restart the app manually from the Replit console when you are ready."
