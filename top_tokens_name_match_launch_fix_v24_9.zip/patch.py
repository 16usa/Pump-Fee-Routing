from pathlib import Path

path = Path('src/styles.css')
css = path.read_text()

marker = '/* top-tokens-name-match-launch-fix-v24-9 */'
if marker not in css:
    css += r'''

/* top-tokens-name-match-launch-fix-v24-9
   Top Tokens recipient chip: increase only the GG name so it visually
   matches the Launch block, while keeping the verified badge as-is. */
.home-top-token-recipient b{
  font-size: 18px;
  line-height: 1;
  font-weight: 700;
}

@media (max-width: 640px){
  .home-top-token-recipient b{
    font-size: 18px;
  }
}
'''
    path.write_text(css)
    print('src/styles.css: Top Tokens name enlarged to match Launch better')
else:
    print('src/styles.css: patch already installed')

print('PASS: CSS patch prepared')
