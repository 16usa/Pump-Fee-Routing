Top Tokens Name Match Launch Fix v24.9

Changes only the recipient chip inside Top Tokens cards:
- increases only the name text (GG) so it matches the Launch block better;
- keeps the verified badge sizing from the previous patch;
- keeps the current chip/avatar layout otherwise;
- no automatic server restart.

Install in the existing Replit Shell:

rm -rf /tmp/top_tokens_name_match_launch_fix_v24_9 && mkdir -p /tmp/top_tokens_name_match_launch_fix_v24_9 && unzip -o top_tokens_name_match_launch_fix_v24_9.zip -d /tmp/top_tokens_name_match_launch_fix_v24_9 && bash /tmp/top_tokens_name_match_launch_fix_v24_9/install.sh
