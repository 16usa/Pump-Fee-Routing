Hero X Logo Mark v24.52

Checked against current GitHub main before building.

Change:
- replaces only the text letter X in the Home hero heading with the actual X logo mark
- logo color follows the heading with currentColor
- logo scales to roughly the same visual size as one capital X glyph
- keeps the existing heading font size, line break, buttons, and layout unchanged
- uses inline SVG, so there is no external image dependency

No automatic server restart.
