#!/usr/bin/env bash
set -euo pipefail

PATCH_NAME="hero_x_logo_mark_v24_52"
APP="src/app.js"
CSS="src/styles.css"

if [ ! -f "$APP" ] || [ ! -f "$CSS" ]; then
  echo "ERROR: src/app.js or src/styles.css missing"
  echo "Run this from the existing Replit project root."
  exit 1
fi

echo "==> Installing ${PATCH_NAME}"
mkdir -p ".patch-backups/${PATCH_NAME}"
cp "$APP" ".patch-backups/${PATCH_NAME}/app.js.before"
cp "$CSS" ".patch-backups/${PATCH_NAME}/styles.css.before"

python3 "$(dirname "$0")/patch.py"

echo "==> Verifying patch"
grep -q 'class="hero-x-logo"' "$APP"
grep -q 'hero-x-logo-mark-v24-52' "$CSS"
grep -q 'fill:currentColor' "$CSS"

echo "==> Running project check"
npm run check

echo "==> Git diff"
git diff --stat -- "$APP" "$CSS"

git add "$APP" "$CSS"
if git diff --cached --quiet; then
  echo "==> No new changes to commit."
else
  git commit -m "Use X logo mark in home hero"
  git push origin main
fi

echo
echo "PASS: ${PATCH_NAME} installed."
echo "No server restart was performed."
