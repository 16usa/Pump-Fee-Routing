from pathlib import Path

app_path = Path("src/app.js")
css_path = Path("src/styles.css")

for p in (app_path, css_path):
    if not p.exists():
        raise SystemExit(f"ERROR: {p} not found. Run from the existing Replit project root.")

app = app_path.read_text()
css = css_path.read_text()
marker = "/* hero-x-logo-mark-v24-52 */"

old = '<h1>Route token fees<br>through X Money</h1>'
new = '''<h1>Route token fees<br>through <span class="hero-x-logo" aria-label="X"><svg viewBox="0 0 1200 1227" aria-hidden="true" focusable="false"><path fill="currentColor" d="M714.163 519.284L1160.89 0H1055.06L667.137 450.887L357.328 0H0L468.492 681.821L0 1226.37H105.866L515.454 750.218L842.672 1226.37H1200L714.137 519.284H714.163ZM569.137 687.828L521.697 619.934L144.011 79.6944H306.615L611.449 515.999L658.889 583.893L1055.11 1150.13H892.506L569.137 687.854V687.828Z"/></svg></span> Money</h1>'''

if old in app:
    app = app.replace(old, new, 1)
elif 'class="hero-x-logo"' not in app:
    raise SystemExit("ERROR: target Home hero heading not found in src/app.js")

if marker not in css:
    css += r'''

/* hero-x-logo-mark-v24-52
   Replace the text X in the Home hero heading with the actual X logo mark.
   The logo follows the heading color via currentColor and scales like one glyph. */
.home-reference-v1 .home-hero .hero-copy h1 .hero-x-logo{
  display:inline-flex !important;
  width:.86em !important;
  height:.86em !important;
  align-items:center !important;
  justify-content:center !important;
  color:currentColor !important;
  vertical-align:-.075em !important;
  margin:0 .015em !important;
  line-height:1 !important;
}

.home-reference-v1 .home-hero .hero-copy h1 .hero-x-logo svg{
  display:block !important;
  width:100% !important;
  height:100% !important;
  overflow:visible !important;
  fill:currentColor !important;
}

.home-reference-v1 .home-hero .hero-copy h1 .hero-x-logo path{
  fill:currentColor !important;
}
'''

app_path.write_text(app)
css_path.write_text(css)

print("PASS: Home hero text X replaced with inline X logo mark.")
print("PASS: logo uses currentColor and scales with the heading.")
