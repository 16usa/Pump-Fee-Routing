Pump Fee Routing — Launch Wallet Flow v1

Changes the normal Launch flow to:
1. Fill token information
2. Accept Terms
3. Connect wallet
4. Launch token
5. Automatically route creator fees after token creation

Removes the manual Routing setup, Creator wallet, Token mint, and manual route/verify UI from the normal Launch form.
Creator wallet is taken from the connected wallet; mint is taken from the Pump creation result.
The existing automatic second wallet approval for permanent fee routing remains intact.

Installer checks only src/app.js, runs checks, commits, and pushes origin/main.
No automatic server restart.
