#!/usr/bin/env bash
set -euo pipefail

echo "== Sitewide X Avatars v13 =="

for f in src/app.js src/styles.css server/api.js server/queries.js; do
  if [ ! -f "$f" ]; then
    echo "ERROR: $f not found. Run this from the existing Replit project workspace."
    exit 1
  fi
done

python3 <<'PY'
from pathlib import Path

app_path = Path("src/app.js")
css_path = Path("src/styles.css")
api_path = Path("server/api.js")
queries_path = Path("server/queries.js")

app = app_path.read_text()
css = css_path.read_text()
api = api_path.read_text()
queries = queries_path.read_text()

def replace_once(src, old, new, label, required=False):
    if new in src:
        print("PASS", label, "(already)")
        return src
    if old in src:
        print("PASS", label)
        return src.replace(old, new, 1)
    if required:
        raise SystemExit(f"ERROR: anchor not found: {label}")
    print("SKIP", label, "(layout/version differs)")
    return src

# ============================================================
# FRONTEND: one X avatar renderer for every real X-recipient slot
# ============================================================

avatar_anchor = """const avatar=(text,large=false,img='')=>img?`<div class="avatar ${large?'avatar-lg':''}"><img src="${esc(img)}" alt=""></div>`:`<div class="avatar ${large?'avatar-lg':''}" aria-hidden="true">${esc(initials(text))}</div>`;"""

sitewide_helper = r"""
/* sitewide-x-avatars-v13 */
const recipientAvatar=(handle,label='',large=false,direct='')=>{
  const clean=String(handle||'').replace(/^@/,'').trim();
  const title=String(label||clean||'X').trim()||'X';
  if(!clean) return avatar(title,large,direct);
  const resolved=`/api/x-avatar/${encodeURIComponent(clean)}`;
  const fallback=String(direct||'').trim();
  const retry=fallback
    ? ` data-x-avatar-direct="${esc(fallback)}" onerror="if(!this.dataset.xAvatarRetried){this.dataset.xAvatarRetried='1';this.src=this.dataset.xAvatarDirect;return}this.style.display='none';this.nextElementSibling.style.display='grid'"`
    : ` onerror="this.style.display='none';this.nextElementSibling.style.display='grid'"`;
  return `<div class="avatar ${large?'avatar-lg':''} x-recipient-avatar"><img src="${esc(resolved)}" alt="" loading="lazy" decoding="async"${retry}><span class="x-recipient-avatar-fallback" style="display:none">${esc(initials(title))}</span></div>`;
};
"""

if "sitewide-x-avatars-v13" not in app and "x-recipient-avatar-v12" not in app:
    if avatar_anchor not in app:
        raise SystemExit("ERROR: base avatar helper anchor not found")
    app = app.replace(avatar_anchor, avatar_anchor + sitewide_helper, 1)
    print("PASS sitewide recipientAvatar helper added")
elif "x-recipient-avatar-v12" in app:
    print("PASS recipientAvatar helper preserved from v12")
else:
    print("PASS sitewide recipientAvatar helper already present")

# If v12 is installed, rename marker so checks reflect the new patch.
app = app.replace("/* x-recipient-avatar-v12 */", "/* sitewide-x-avatars-v13 */")

# 1) Home Explore recipient pill
app = replace_once(
    app,
    """return `<div class="home-explore-v8-recipient"><i>$</i>${avatar(label, false, avatarUrl)}<b>${esc(label)}</b></div>`;""",
    """return `<div class="home-explore-v8-recipient"><i>$</i>${recipientAvatar(handle,label,false,avatarUrl)}<b>${esc(label)}</b></div>`;""",
    "Home Explore recipient avatar",
    required=True
)

# 2) Home launch/profile strip
app = replace_once(
    app,
    """return `<span class="${i===0?'active':''}">${avatar(n,false,p.avatar_url||'')}<b>${esc(n)}</b><small>@${esc(p.handle||'')}</small></span>`;""",
    """return `<span class="${i===0?'active':''}">${recipientAvatar(p.handle,n,false,p.avatar_url||'')}<b>${esc(n)}</b><small>@${esc(p.handle||'')}</small></span>`;""",
    "Home Launch profile-strip avatars"
)

# Keep the empty fallback generic; only a real profile should query X.
app = replace_once(
    app,
    """          <div>${avatar(leadName,true,leadProfile?.avatar_url||'')}</div>""",
    """          <div>${leadProfile?recipientAvatar(leadHandle,leadName,true,leadProfile?.avatar_url||''):avatar(leadName,true,'')}</div>""",
    "Home Launch active recipient avatar"
)

# 3) Top Tokens recipient avatar
app = replace_once(
    app,
    """        ${avatar(handle||t.symbol)}
        <span>${handle?`@${esc(handle)}`:'Recipient'}</span>""",
    """        ${handle?recipientAvatar(handle,handle,false,''):avatar(t.symbol||'T')}
        <span>${handle?`@${esc(handle)}`:'Recipient'}</span>""",
    "Top Tokens recipient avatar"
)

# 4) Top X Profiles
app = replace_once(
    app,
    """      <div class="home-profile-avatar">${avatar(name,true,p.avatar_url)}</div>""",
    """      <div class="home-profile-avatar">${recipientAvatar(p.handle,name,true,p.avatar_url||'')}</div>""",
    "Top X Profiles avatar"
)

# 5) Home Recent Payments recipient side
app = replace_once(
    app,
    """        ${avatar(to,true,p.avatar_url||'')}
        <i class="home-payment-x">X</i>""",
    """        ${recipientAvatar(p.recipient_handle||p.to||'',to,true,p.avatar_url||'')}
        <i class="home-payment-x">X</i>""",
    "Recent Payments recipient avatar"
)

# 6) Home Most Payments recipient side
app = replace_once(
    app,
    """        ${avatar(name,true,x.avatar_url||'')}
        <i class="home-most-x">X</i>""",
    """        ${recipientAvatar(handle,name,true,x.avatar_url||'')}
        <i class="home-most-x">X</i>""",
    "Most Payments recipient avatar"
)

# 7) Money page recent payments recipient
app = replace_once(
    app,
    """        ${avatar(profile?.display_name||p.display_name||handle,true,profile?.avatar_url||p.avatar_url||'')}
        <i class="x">X</i>""",
    """        ${recipientAvatar(handle,profile?.display_name||p.display_name||handle,true,profile?.avatar_url||p.avatar_url||'')}
        <i class="x">X</i>""",
    "Money recent recipient avatar"
)

# 8) Money top-token route recipient
app = replace_once(
    app,
    """      <div class="money-payment-avatar">${avatar(profile?.display_name||handle||'X',true,profile?.avatar_url||'')}<i class="x">X</i></div>""",
    """      <div class="money-payment-avatar">${recipientAvatar(handle,profile?.display_name||handle||'X',true,profile?.avatar_url||'')}<i class="x">X</i></div>""",
    "Money top-token recipient avatar"
)

# 9) Token detail recipient
app = replace_once(
    app,
    """          ${avatar(recipient.display_name||t.recipient_handle||'X',true,recipient.avatar_url||'')}""",
    """          ${recipientAvatar(t.recipient_handle||'',recipient.display_name||t.recipient_handle||'X',true,recipient.avatar_url||'')}""",
    "Token detail recipient avatar"
)

# 10) X profile page hero
app = replace_once(
    app,
    """        ${avatar(display,true,r.avatar_url||'')}""",
    """        ${recipientAvatar(cleanHandle,display,true,r.avatar_url||'')}""",
    "X profile page avatar"
)

# 11) Launch X search result: proxy first, direct X image fallback.
old = """  if(profile.profileImageUrl){
    const img=document.createElement('img');
    img.src=profile.profileImageUrl;
    img.alt='';
    img.referrerPolicy='no-referrer';
    avatar.appendChild(img);
  }else{
    avatar.textContent=(profile.name||profile.username||'X').trim().charAt(0).toUpperCase()||'X';
  }"""
new = """  if(profile.username||profile.profileImageUrl){
    const img=document.createElement('img');
    img.src=profile.username?`/api/x-avatar/${encodeURIComponent(profile.username)}`:profile.profileImageUrl;
    img.alt='';
    img.referrerPolicy='no-referrer';
    if(profile.profileImageUrl){
      img.dataset.directAvatar=profile.profileImageUrl;
      img.onerror=()=>{
        if(img.dataset.retried)return;
        img.dataset.retried='1';
        img.src=img.dataset.directAvatar;
      };
    }
    avatar.appendChild(img);
  }else{
    avatar.textContent=(profile.name||profile.username||'X').trim().charAt(0).toUpperCase()||'X';
  }"""
if old in app:
    app = app.replace(old,new,1)
    print("PASS Launch X lookup avatar")
elif new in app:
    print("PASS Launch X lookup avatar (already)")
else:
    print("SKIP Launch X lookup avatar (version differs)")

# 12) Launch preview avatar: same idea. There is a second identical block.
old2 = """  if(profile.profileImageUrl){
    const img=document.createElement('img');
    img.src=profile.profileImageUrl;
    img.alt='';
    img.referrerPolicy='no-referrer';
    avatar.appendChild(img);
  }else{
    avatar.textContent=(profile.name||profile.username||'X').trim().charAt(0).toUpperCase()||'X';
  }"""
new2 = """  if(profile.username||profile.profileImageUrl){
    const img=document.createElement('img');
    img.src=profile.username?`/api/x-avatar/${encodeURIComponent(profile.username)}`:profile.profileImageUrl;
    img.alt='';
    img.referrerPolicy='no-referrer';
    if(profile.profileImageUrl){
      img.dataset.directAvatar=profile.profileImageUrl;
      img.onerror=()=>{
        if(img.dataset.retried)return;
        img.dataset.retried='1';
        img.src=img.dataset.directAvatar;
      };
    }
    avatar.appendChild(img);
  }else{
    avatar.textContent=(profile.name||profile.username||'X').trim().charAt(0).toUpperCase()||'X';
  }"""
if old2 in app:
    app = app.replace(old2,new2,1)
    print("PASS Launch preview recipient avatar")
elif new2 in app:
    print("PASS Launch preview recipient avatar (already)")
else:
    print("SKIP Launch preview recipient avatar (version differs)")

# 13) Launch rotating demo recipient avatar
old_demo = """  if(profile.avatarUrl){
    return `<span class="launch-demo-avatar ${extraClass}"><img src="${launchDemoEscapeHtml(profile.avatarUrl)}" alt="" referrerpolicy="no-referrer"></span>`;
  }
  return `<span class="launch-demo-avatar ${extraClass}">${launchDemoEscapeHtml(profile.initial||'')}</span>`;"""
new_demo = """  if(profile.username||profile.avatarUrl){
    const primary=profile.username?`/api/x-avatar/${encodeURIComponent(profile.username)}`:profile.avatarUrl;
    const retry=profile.avatarUrl?` data-direct-avatar="${launchDemoEscapeHtml(profile.avatarUrl)}" onerror="if(!this.dataset.retried){this.dataset.retried='1';this.src=this.dataset.directAvatar}"`:'';
    return `<span class="launch-demo-avatar ${extraClass}"><img src="${launchDemoEscapeHtml(primary)}" alt="" referrerpolicy="no-referrer"${retry}></span>`;
  }
  return `<span class="launch-demo-avatar ${extraClass}">${launchDemoEscapeHtml(profile.initial||'')}</span>`;"""
app = replace_once(app, old_demo, new_demo, "Launch rotating-demo recipient avatar")

app_path.write_text(app)

# ============================================================
# CSS: robust image/fallback layout in every avatar size/slot
# ============================================================
css_marker = "/* sitewide-x-avatars-v13 */"
css_block = r"""
/* sitewide-x-avatars-v13 */
.x-recipient-avatar{
  position:relative;
  overflow:hidden;
}
.x-recipient-avatar>img{
  position:absolute;
  inset:0;
  width:100%;
  height:100%;
  object-fit:cover;
  border-radius:inherit;
}
.x-recipient-avatar-fallback{
  position:absolute;
  inset:0;
  width:100%;
  height:100%;
  place-items:center;
  border-radius:inherit;
  background:radial-gradient(circle at 35% 25%,#555,#1b1b1b 58%,#0b0b0b);
  color:#fff;
}
"""
if css_marker not in css:
    css += "\n" + css_block + "\n"
    print("PASS X avatar CSS added")
else:
    print("PASS X avatar CSS already present")
css_path.write_text(css)

# ============================================================
# QUERIES: expose avatar_url everywhere profile summary data is used
# ============================================================
queries = replace_once(
    queries,
    """profiles:db.prepare(`SELECT r.handle,r.display_name,COUNT(DISTINCT t.mint) token_count,COALESCE(SUM(p.amount_usd),0) received FROM recipients r""",
    """profiles:db.prepare(`SELECT r.handle,r.display_name,r.avatar_url,COUNT(DISTINCT t.mint) token_count,COALESCE(SUM(p.amount_usd),0) received FROM recipients r""",
    "homeData returns avatar_url",
    required=True
)

queries = replace_once(
    queries,
    """const topPaid=db.prepare(`SELECT r.handle,r.display_name,COALESCE(SUM(p.amount_usd),0) received FROM recipients r""",
    """const topPaid=db.prepare(`SELECT r.handle,r.display_name,r.avatar_url,COALESCE(SUM(p.amount_usd),0) received FROM recipients r""",
    "moneySummary topPaid returns avatar_url"
)

queries_path.write_text(queries)

# ============================================================
# BACKEND: resolve/cache/proxy X avatars for all site pages
# ============================================================
api = api.replace("/* x-recipient-avatar-v12 */", "/* sitewide-x-avatars-v13 */")

handle_anchor = "export async function handleApi(req,res,url){"
if "sitewide-x-avatars-v13" not in api:
    idx = api.find(handle_anchor)
    if idx < 0:
        raise SystemExit("ERROR: handleApi anchor not found")

    helper = r"""
/* sitewide-x-avatars-v13 */
function largerXAvatar(url){
  return String(url||'').replace(/_normal(\.[a-z0-9]+)(\?.*)?$/i,'_400x400$1$2');
}

async function resolveXAvatar(handle){
  const username=String(handle||'').replace(/^@/,'').trim();
  if(!/^[A-Za-z0-9_]{1,15}$/.test(username)) return null;

  const existing=db.prepare(
    'SELECT handle,display_name,avatar_url,x_user_id FROM recipients WHERE handle=? COLLATE NOCASE'
  ).get(username);

  if(existing?.avatar_url) return String(existing.avatar_url);
  if(!config.xBearerToken) return null;

  try{
    const fields='id,name,username,profile_image_url';
    const r=await fetch(
      `https://api.x.com/2/users/by/username/${encodeURIComponent(username)}?user.fields=${encodeURIComponent(fields)}`,
      {
        headers:{authorization:`Bearer ${config.xBearerToken}`,accept:'application/json'},
        signal:AbortSignal.timeout(12000)
      }
    );
    if(!r.ok) return null;

    const payload=await r.json().catch(()=>({}));
    const u=payload?.data;
    const avatarUrl=largerXAvatar(u?.profile_image_url||'');
    if(!avatarUrl) return null;

    if(existing){
      db.prepare(`UPDATE recipients
        SET x_user_id=COALESCE(NULLIF(?,''),x_user_id),
            display_name=COALESCE(NULLIF(?,''),display_name),
            avatar_url=?,
            updated_at=CURRENT_TIMESTAMP
        WHERE handle=? COLLATE NOCASE`)
        .run(
          String(u?.id||''),
          String(u?.name||u?.username||''),
          avatarUrl,
          username
        );
    }

    return avatarUrl;
  }catch{
    return null;
  }
}

async function proxyXAvatar(res,handle){
  const target=await resolveXAvatar(handle);
  if(!target) return false;

  try{
    const r=await fetch(target,{
      headers:{
        accept:'image/avif,image/webp,image/apng,image/*,*/*;q=0.8',
        'user-agent':'Mozilla/5.0'
      },
      redirect:'follow',
      signal:AbortSignal.timeout(12000)
    });
    if(!r.ok) return false;

    const type=String(r.headers.get('content-type')||'').split(';')[0].trim().toLowerCase();
    if(!type.startsWith('image/')) return false;

    const bytes=Buffer.from(await r.arrayBuffer());
    if(!bytes.length || bytes.length>3_000_000) return false;

    res.writeHead(200,{
      'content-type':type,
      'content-length':String(bytes.length),
      'cache-control':'public, max-age=3600, stale-while-revalidate=86400',
      'x-content-type-options':'nosniff'
    });
    res.end(bytes);
    return true;
  }catch{
    return false;
  }
}


"""
    api = api[:idx] + helper + api[idx:]
    print("PASS sitewide X avatar backend resolver added")
else:
    print("PASS sitewide X avatar backend resolver already present")

# If v12 was installed, it may already have resolver/route but old marker.
if "async function resolveXAvatar(handle)" not in api:
    raise SystemExit("ERROR: resolveXAvatar helper missing after patch")

# Add sitewide avatar route before /api/health if needed.
if "url.pathname.startsWith('/api/x-avatar/')" not in api:
    health_anchor = "    if(req.method==='GET'&&url.pathname==='/api/health')"
    hidx = api.find(health_anchor)
    if hidx < 0:
        raise SystemExit("ERROR: /api/health route anchor not found")
    route = r"""    if(req.method==='GET'&&url.pathname.startsWith('/api/x-avatar/')){
      const handle=decodeURIComponent(url.pathname.slice('/api/x-avatar/'.length)).replace(/^@/,'').trim();
      if(!/^[A-Za-z0-9_]{1,15}$/.test(handle)) return json(res,400,{error:'Invalid X username'});
      const sent=await proxyXAvatar(res,handle);
      if(sent) return;
      return json(res,404,{error:'X avatar not found'});
    }
"""
    api = api[:hidx] + route + api[hidx:]
    print("PASS /api/x-avatar route added")
else:
    print("PASS /api/x-avatar route already present")

# Cache X lookup results when that recipient already exists.
cache_marker = "/* cache-x-profile-avatar-v13 */"
if cache_marker not in api:
    anchor = "      const u=payload.data;\n      return json(res,200,{"
    if anchor in api:
        injected = """      const u=payload.data;
      /* cache-x-profile-avatar-v13 */
      const cachedAvatar=largerXAvatar(u.profile_image_url||'');
      if(cachedAvatar){
        db.prepare(`UPDATE recipients
          SET x_user_id=COALESCE(NULLIF(?,''),x_user_id),
              display_name=COALESCE(NULLIF(?,''),display_name),
              avatar_url=?,
              updated_at=CURRENT_TIMESTAMP
          WHERE handle=? COLLATE NOCASE`)
          .run(String(u.id||''),String(u.name||u.username||''),cachedAvatar,username);
      }
      return json(res,200,{"""
        api = api.replace(anchor, injected, 1)
        print("PASS X lookup now refreshes cached recipient avatar")
    else:
        print("SKIP X lookup cache hook (version differs)")
else:
    print("PASS X lookup cache hook already present")

api_path.write_text(api)

# ============================================================
# STATIC VERIFICATION
# ============================================================
app2 = app_path.read_text()
css2 = css_path.read_text()
api2 = api_path.read_text()
queries2 = queries_path.read_text()

required_checks = {
    "sitewide avatar helper": "sitewide-x-avatars-v13" in app2,
    "Explore recipient uses real X avatar": "recipientAvatar(handle,label,false,avatarUrl)" in app2,
    "Top Token recipient uses X avatar": "recipientAvatar(handle,handle,false,'')" in app2,
    "Top X Profiles use X avatar": "recipientAvatar(p.handle,name,true,p.avatar_url||'')" in app2,
    "Recent Payments uses X avatar": "recipientAvatar(p.recipient_handle||p.to||'',to,true,p.avatar_url||'')" in app2,
    "Money recipient uses X avatar": "recipientAvatar(handle,profile?.display_name||p.display_name||handle" in app2,
    "Token detail uses X avatar": "recipientAvatar(t.recipient_handle||'',recipient.display_name" in app2,
    "Profile hero uses X avatar": "recipientAvatar(cleanHandle,display,true,r.avatar_url||'')" in app2,
    "homeData exposes avatar_url": "SELECT r.handle,r.display_name,r.avatar_url" in queries2,
    "avatar API route exists": "/api/x-avatar/" in api2,
    "avatar resolver exists": "async function resolveXAvatar(handle)" in api2,
    "avatar CSS exists": "x-recipient-avatar-fallback" in css2,
}

for label, ok in required_checks.items():
    if not ok:
        raise SystemExit(f"ERROR: verification failed: {label}")
    print("PASS", label)

print("PASS sitewide X-avatar static verification")
PY

echo
echo "== Existing project checks =="
npm run check

echo
echo "== Changed files =="
git diff --stat

git add src/app.js src/styles.css server/api.js server/queries.js

if git diff --cached --quiet; then
  echo "No new changes to commit (patch may already be installed)."
else
  git commit -m "Show real X avatars sitewide"
  git push
fi

echo
echo "DONE: Sitewide X Avatars v13 installed, checked, committed, and pushed."
echo "No server restart was performed."
echo "Restart Run/Console manually once, then reload the site."
