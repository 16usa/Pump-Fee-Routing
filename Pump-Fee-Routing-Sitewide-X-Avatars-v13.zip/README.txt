Pump Fee Routing — Sitewide X Avatars v13

This supersedes the earlier one-page avatar fix.

It fixes REAL X profile avatars everywhere an X-recipient/profile avatar already belongs in the UI:
- Home Explore recipient pill
- Home Launch preview/profile strip
- Top Tokens recipient badge
- Top X Profiles
- Recent Payments
- Most Payments
- Money page recipient routes
- Token detail recipient
- X profile page
- Launch X lookup / Launch preview
- Launch rotating payment demo

It does NOT replace token artwork with X avatars. Token image slots continue using token images.

Backend behavior:
1. Use recipients.avatar_url when already stored.
2. If missing, resolve the X profile through the configured X API.
3. Cache the real avatar/name for existing recipients.
4. Proxy the avatar through /api/x-avatar/:handle so Safari gets a reliable same-origin image.
5. Use a letter only if no real avatar can be resolved.

The patch also adds avatar_url to Home/Money summary queries, which was one of the reasons initials appeared after launch.

INSTALL IN THE EXISTING REPLIT SHELL:

rm -rf /tmp/sitewide-x-avatars-v13
mkdir -p /tmp/sitewide-x-avatars-v13
unzip -o Pump-Fee-Routing-Sitewide-X-Avatars-v13.zip -d /tmp/sitewide-x-avatars-v13
bash /tmp/sitewide-x-avatars-v13/install.sh

No workspace creation and no automatic server restart.
The installer runs checks, commits, and pushes.
Restart Run/Console manually once after installation.
