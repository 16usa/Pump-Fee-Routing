Pump Fee Routing — Launch Image Preview v1.2

Use this INSTEAD of the previous repair patch.
It safely handles both states:
- previous v1 preview changes already exist locally after the failed installer, or
- they do not exist yet.

Adds both:
1. small selected-image thumbnail inside the Token image control with 'Change image'
2. large image in the existing token Preview card

Existing Launch layout is otherwise unchanged.
Runs checks, commits, pushes origin/main. No automatic restart.
