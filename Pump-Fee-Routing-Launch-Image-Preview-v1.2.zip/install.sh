#!/usr/bin/env bash
set -euo pipefail

for f in src/app.js src/styles.css; do
  [ -f "$f" ] || { echo "Missing $f. Run this from the Pump-Fee-Routing project root."; exit 1; }
done

# Accept only the expected dirty files from the previously failed image-preview installer.
changed="$(git diff --name-only; git diff --cached --name-only)"
unexpected="$(printf '%s
' "$changed" | sed '/^$/d' | sort -u | grep -vE '^(src/app\.js|src/styles\.css)$' || true)"
if [ -n "$unexpected" ]; then
  echo "STOP: unrelated tracked changes are present:"
  echo "$unexpected"
  exit 2
fi

python3 - <<'PY'

from pathlib import Path
import base64

def dec(s): return base64.b64decode(s).decode()

app_path=Path('src/app.js')
css_path=Path('src/styles.css')
app=app_path.read_text()
css=css_path.read_text()

# If the failed v1 installer already applied the base preview locally, keep it.
# If not, apply the base preview now.
if 'function updateLaunchImagePreview(input)' not in app:
    anchor='function updateLaunchPreview(){'
    if anchor not in app:
        raise SystemExit('updateLaunchPreview anchor not found')
    app=app.replace(anchor,dec('bGV0IGxhdW5jaFByZXZpZXdJbWFnZVVybD0nJzsKCmZ1bmN0aW9uIHVwZGF0ZUxhdW5jaEltYWdlUHJldmlldyhpbnB1dCl7CiAgY29uc3QgZmlsZT1pbnB1dD8uZmlsZXM/LlswXXx8bnVsbDsKICBjb25zdCBzaGVsbD1pbnB1dD8uY2xvc2VzdCgnLmxhdW5jaC1maWxlLXNoZWxsJyk7CiAgY29uc3QgbGFiZWw9c2hlbGw/LnF1ZXJ5U2VsZWN0b3IoJ3NwYW4nKTsKICBjb25zdCBwcmV2aWV3PWRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJyNsYXVuY2hQcmV2aWV3SW1hZ2UnKTsKCiAgaWYobGF1bmNoUHJldmlld0ltYWdlVXJsKXsKICAgIFVSTC5yZXZva2VPYmplY3RVUkwobGF1bmNoUHJldmlld0ltYWdlVXJsKTsKICAgIGxhdW5jaFByZXZpZXdJbWFnZVVybD0nJzsKICB9CgogIGlmKCFmaWxlKXsKICAgIGlmKGxhYmVsKWxhYmVsLnRleHRDb250ZW50PSdDaG9vc2UgaW1hZ2UnOwogICAgaWYocHJldmlldyl7CiAgICAgIHByZXZpZXcucmVwbGFjZUNoaWxkcmVuKGRvY3VtZW50LmNyZWF0ZVRleHROb2RlKCdQJykpOwogICAgICBwcmV2aWV3LmNsYXNzTGlzdC5yZW1vdmUoJ2hhcy1pbWFnZScpOwogICAgfQogICAgcmV0dXJuOwogIH0KCiAgaWYoZmlsZS5zaXplPjVfMDAwXzAwMCl7CiAgICBpbnB1dC52YWx1ZT0nJzsKICAgIGlmKGxhYmVsKWxhYmVsLnRleHRDb250ZW50PSdDaG9vc2UgaW1hZ2UnOwogICAgaWYocHJldmlldyl7CiAgICAgIHByZXZpZXcucmVwbGFjZUNoaWxkcmVuKGRvY3VtZW50LmNyZWF0ZVRleHROb2RlKCdQJykpOwogICAgICBwcmV2aWV3LmNsYXNzTGlzdC5yZW1vdmUoJ2hhcy1pbWFnZScpOwogICAgfQogICAgc2V0TGF1bmNoU3RhdHVzKCdUb2tlbiBpbWFnZSBtdXN0IGJlIDUgTUIgb3Igc21hbGxlcicpOwogICAgcmV0dXJuOwogIH0KCiAgaWYoIS9eaW1hZ2VcLyhwbmd8anBlZ3xnaWZ8d2VicCkkL2kudGVzdChmaWxlLnR5cGV8fCcnKSl7CiAgICBpbnB1dC52YWx1ZT0nJzsKICAgIGlmKGxhYmVsKWxhYmVsLnRleHRDb250ZW50PSdDaG9vc2UgaW1hZ2UnOwogICAgaWYocHJldmlldyl7CiAgICAgIHByZXZpZXcucmVwbGFjZUNoaWxkcmVuKGRvY3VtZW50LmNyZWF0ZVRleHROb2RlKCdQJykpOwogICAgICBwcmV2aWV3LmNsYXNzTGlzdC5yZW1vdmUoJ2hhcy1pbWFnZScpOwogICAgfQogICAgc2V0TGF1bmNoU3RhdHVzKCdVc2UgUE5HLCBKUEcsIEdJRiwgb3IgV0VCUCcpOwogICAgcmV0dXJuOwogIH0KCiAgbGF1bmNoUHJldmlld0ltYWdlVXJsPVVSTC5jcmVhdGVPYmplY3RVUkwoZmlsZSk7CiAgaWYobGFiZWwpbGFiZWwudGV4dENvbnRlbnQ9ZmlsZS5uYW1lfHwnSW1hZ2Ugc2VsZWN0ZWQnOwogIGlmKHByZXZpZXcpewogICAgY29uc3QgaW1nPWRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2ltZycpOwogICAgaW1nLnNyYz1sYXVuY2hQcmV2aWV3SW1hZ2VVcmw7CiAgICBpbWcuYWx0PSdUb2tlbiBpbWFnZSBwcmV2aWV3JzsKICAgIHByZXZpZXcucmVwbGFjZUNoaWxkcmVuKGltZyk7CiAgICBwcmV2aWV3LmNsYXNzTGlzdC5hZGQoJ2hhcy1pbWFnZScpOwogIH0KfQoK')+anchor,1)

if 'id="launchPreviewImage"' not in app:
    old=dec('PGRpdiBjbGFzcz0ibGF1bmNoLXByZXZpZXctaW1hZ2UiPlA8L2Rpdj4=')
    if old not in app:
        raise SystemExit('Launch preview image anchor not found')
    app=app.replace(old,dec('PGRpdiBjbGFzcz0ibGF1bmNoLXByZXZpZXctaW1hZ2UiIGlkPSJsYXVuY2hQcmV2aWV3SW1hZ2UiPlA8L2Rpdj4='),1)

if "if(e.target.id==='launchImage')updateLaunchImagePreview(e.target);" not in app:
    anchor="app.addEventListener('submit',async e=>{if(e.target.id==='launchForm'){"
    if anchor not in app:
        raise SystemExit('submit listener anchor not found')
    app=app.replace(anchor,dec('YXBwLmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsZT0+ewogIGlmKGUudGFyZ2V0LmlkPT09J2xhdW5jaEltYWdlJyl1cGRhdGVMYXVuY2hJbWFnZVByZXZpZXcoZS50YXJnZXQpOwp9KTsK')+anchor,1)

if '/* launch-image-preview-v1 */' not in css:
    css += dec('Ci8qIGxhdW5jaC1pbWFnZS1wcmV2aWV3LXYxICovCi5sYXVuY2gtcHJldmlldy1pbWFnZS5oYXMtaW1hZ2V7CiAgcGFkZGluZzowOwogIGJhY2tncm91bmQ6IzA4MDgwODsKfQoubGF1bmNoLXByZXZpZXctaW1hZ2UuaGFzLWltYWdlIGltZ3sKICB3aWR0aDoxMDAlOwogIGhlaWdodDoxMDAlOwogIGRpc3BsYXk6YmxvY2s7CiAgb2JqZWN0LWZpdDpjb3ZlcjsKfQo=')

# Add the small selected-image preview shown inside the Token image control.
if 'function updateLaunchMiniImage(input)' not in app:
    anchor='function updateLaunchPreview(){'
    idx=app.find(anchor)
    if idx<0:
        raise SystemExit('mini-preview insertion anchor not found')
    app=app[:idx]+dec('CmZ1bmN0aW9uIHVwZGF0ZUxhdW5jaE1pbmlJbWFnZShpbnB1dCl7CiAgY29uc3Qgc2hlbGw9aW5wdXQ/LmNsb3Nlc3QoJy5sYXVuY2gtZmlsZS1zaGVsbCcpOwogIGlmKCFzaGVsbClyZXR1cm47CgogIGxldCBtaW5pPXNoZWxsLnF1ZXJ5U2VsZWN0b3IoJy5sYXVuY2gtZmlsZS1taW5pJyk7CiAgaWYoIW1pbmkpewogICAgbWluaT1kb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTsKICAgIG1pbmkuY2xhc3NOYW1lPSdsYXVuY2gtZmlsZS1taW5pJzsKCiAgICBjb25zdCBpbWc9ZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaW1nJyk7CiAgICBpbWcuYWx0PSdTZWxlY3RlZCB0b2tlbiBpbWFnZSc7CgogICAgY29uc3QgdGV4dD1kb2N1bWVudC5jcmVhdGVFbGVtZW50KCdzcGFuJyk7CiAgICB0ZXh0LnRleHRDb250ZW50PSdDaGFuZ2UgaW1hZ2UnOwoKICAgIG1pbmkuYXBwZW5kKGltZyx0ZXh0KTsKICAgIHNoZWxsLmFwcGVuZENoaWxkKG1pbmkpOwogIH0KCiAgY29uc3QgZmlsZT1pbnB1dD8uZmlsZXM/LlswXXx8bnVsbDsKICBpZighZmlsZSl7CiAgICBzaGVsbC5jbGFzc0xpc3QucmVtb3ZlKCdoYXMtc2VsZWN0ZWQtaW1hZ2UnKTsKICAgIG1pbmkuaGlkZGVuPXRydWU7CiAgICByZXR1cm47CiAgfQoKICBjb25zdCBpbWc9bWluaS5xdWVyeVNlbGVjdG9yKCdpbWcnKTsKICBpZihpbWcgJiYgbGF1bmNoUHJldmlld0ltYWdlVXJsKWltZy5zcmM9bGF1bmNoUHJldmlld0ltYWdlVXJsOwogIG1pbmkuaGlkZGVuPWZhbHNlOwogIHNoZWxsLmNsYXNzTGlzdC5hZGQoJ2hhcy1zZWxlY3RlZC1pbWFnZScpOwp9Cg==')+app[idx:]

if "setTimeout(()=>updateLaunchMiniImage(e.target),0)" not in app:
    anchor="app.addEventListener('submit',async e=>{if(e.target.id==='launchForm'){"
    if anchor not in app:
        raise SystemExit('mini change listener anchor not found')
    app=app.replace(anchor,dec('YXBwLmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsZT0+ewogIGlmKGUudGFyZ2V0LmlkPT09J2xhdW5jaEltYWdlJylzZXRUaW1lb3V0KCgpPT51cGRhdGVMYXVuY2hNaW5pSW1hZ2UoZS50YXJnZXQpLDApOwp9KTsK')+anchor,1)

if '/* launch-image-preview-v1.2 */' not in css:
    css += dec('Ci8qIGxhdW5jaC1pbWFnZS1wcmV2aWV3LXYxLjIgKi8KLmxhdW5jaC1maWxlLXNoZWxsLmhhcy1zZWxlY3RlZC1pbWFnZXsKICBwbGFjZS1pdGVtczpzdHJldGNoOwp9Ci5sYXVuY2gtZmlsZS1zaGVsbC5oYXMtc2VsZWN0ZWQtaW1hZ2U+c3BhbnsKICBkaXNwbGF5Om5vbmU7Cn0KLmxhdW5jaC1maWxlLW1pbmlbaGlkZGVuXXsKICBkaXNwbGF5Om5vbmU7Cn0KLmxhdW5jaC1maWxlLW1pbml7CiAgbWluLWhlaWdodDo3NHB4OwogIGRpc3BsYXk6ZmxleDsKICBhbGlnbi1pdGVtczpjZW50ZXI7CiAgZ2FwOjE0cHg7CiAgcGFkZGluZzoxMHB4IDE0cHg7CiAgcG9pbnRlci1ldmVudHM6bm9uZTsKfQoubGF1bmNoLWZpbGUtbWluaSBpbWd7CiAgd2lkdGg6NTZweDsKICBoZWlnaHQ6NTZweDsKICBmbGV4OjAgMCA1NnB4OwogIGRpc3BsYXk6YmxvY2s7CiAgYm9yZGVyLXJhZGl1czoxMnB4OwogIG9iamVjdC1maXQ6Y292ZXI7CiAgYmFja2dyb3VuZDojMTUxNTE1Owp9Ci5sYXVuY2gtZmlsZS1taW5pIHNwYW57CiAgY29sb3I6I2RlZGVkZTsKICBmb250LXNpemU6MTJweDsKICBmb250LXdlaWdodDo1MDA7Cn0K')

app_path.write_text(app)
css_path.write_text(css)
print('Launch Image Preview v1.2 installed.')

PY

node --check src/app.js
npm run check

node <<'NODE'
const fs=require('fs');
const app=fs.readFileSync('src/app.js','utf8');
const css=fs.readFileSync('src/styles.css','utf8');

const checks=[
  ['base image preview handler', app.includes('function updateLaunchImagePreview(input)')],
  ['large Preview image target', app.includes('id="launchPreviewImage"')],
  ['small image preview handler', app.includes('function updateLaunchMiniImage(input)')],
  ['small image Change image label', app.includes("text.textContent='Change image'")],
  ['image selection listener', app.includes("e.target.id==='launchImage'")],
  ['mini preview CSS', css.includes('.launch-file-mini img')],
  ['large preview CSS', css.includes('.launch-preview-image.has-image img')],
];

let bad=0;
for(const [name,ok] of checks){
  console.log(`${ok?'PASS':'FAIL'} ${name}`);
  if(!ok)bad++;
}
if(bad)process.exit(1);
NODE

git add src/app.js src/styles.css

if git diff --cached --quiet; then
  echo "No staged changes; nothing to commit."
else
  git commit -m "Add Launch image previews"
fi

git push origin main

echo
echo "DONE: Launch image preview v1.2 checked, committed, and pushed to GitHub."
echo "No server restart was performed."
echo "Restart Console/Run manually once, then choose the image again."
