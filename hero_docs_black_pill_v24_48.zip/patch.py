from pathlib import Path

css_path = Path("src/styles.css")
app_path = Path("src/app.js")

for p in (css_path, app_path):
    if not p.exists():
        raise SystemExit(f"ERROR: {p} not found. Run this from the existing Replit project root.")

css = css_path.read_text()
app = app_path.read_text()

marker = "/* hero-docs-black-pill-v24-48 */"

old = '<a class="text-link" href="#/docs">Read the docs <span>→</span></a>'
new = '<a class="text-link" href="#/docs">Read the docs</a>'

if old in app:
    app = app.replace(old, new, 1)
elif new not in app:
    raise SystemExit("ERROR: Home hero Read the docs link markup not found in src/app.js")

if marker not in css:
    css += r'''

/* hero-docs-black-pill-v24-48
   Turn Read the docs into a black pill button matching the Launch CTA shape.
   No arrow. White text. Thin site-standard outline. */
.home-reference-v1 .home-hero .text-link{
  display:inline-flex !important;
  align-items:center !important;
  justify-content:center !important;
  box-sizing:border-box !important;
  padding:10px 16px !important;
  border:1px solid var(--line,#272727) !important;
  border-radius:999px !important;
  background:#0A0A0A !important;
  color:#fff !important;
  font-size:13px !important;
  line-height:normal !important;
  font-weight:700 !important;
  letter-spacing:0 !important;
  white-space:nowrap !important;
  text-decoration:none !important;
}

.home-reference-v1 .home-hero .text-link > span{
  display:none !important;
}

@media(max-width:640px){
  .home-reference-v1 .home-hero .text-link{
    padding:9px 15px !important;
    font-size:10px !important;
  }
}
'''

css_path.write_text(css)
app_path.write_text(app)

print("PASS: Read the docs arrow removed from markup.")
print("PASS: Read the docs is now a black outlined pill with white text.")
