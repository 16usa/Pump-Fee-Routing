#!/usr/bin/env bash
set -euo pipefail

PATCH_NAME="hero_docs_black_pill_v24_48"
CSS="src/styles.css"
APP="src/app.js"

if [ ! -f "$CSS" ] || [ ! -f "$APP" ]; then
  echo "ERROR: src/styles.css or src/app.js missing"
  echo "Run this from the existing Replit project root."
  exit 1
fi

echo "==> Installing ${PATCH_NAME}"
mkdir -p ".patch-backups/${PATCH_NAME}"
cp "$CSS" ".patch-backups/${PATCH_NAME}/styles.css.before"
cp "$APP" ".patch-backups/${PATCH_NAME}/app.js.before"

python3 "$(dirname "$0")/patch.py"

echo "==> Verifying patch"
grep -q 'hero-docs-black-pill-v24-48' "$CSS"
grep -q '<a class="text-link" href="#/docs">Read the docs</a>' "$APP"
if grep -q '<a class="text-link" href="#/docs">Read the docs <span>→</span></a>' "$APP"; then
  echo "ERROR: legacy arrow markup is still present"
  exit 1
fi

echo "==> Running project check"
npm run check

echo "==> Git diff"
git diff --stat -- "$CSS" "$APP"

git add "$CSS" "$APP"
if git diff --cached --quiet; then
  echo "==> No new changes to commit."
else
  git commit -m "Style docs CTA as black outlined pill"
  git push origin main
fi

echo
echo "PASS: ${PATCH_NAME} installed."
echo "No server restart was performed."
