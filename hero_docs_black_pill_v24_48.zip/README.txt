Hero Docs Black Pill v24.48

Checked against current GitHub main.

Changes:
- removes the arrow from "Read the docs" in src/app.js
- turns "Read the docs" into a pill button like "Launch a token"
- black background: #0A0A0A
- white text: #fff
- thin outline: var(--line), fallback #272727
- keeps the white Launch button unchanged
- no server restart
