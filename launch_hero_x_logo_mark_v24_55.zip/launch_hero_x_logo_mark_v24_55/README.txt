Launch Hero X Logo Mark v24.55

Checked against the current flow used in your other X-logo patches.

Change:
- replaces only the text letter X in the Launch page hero heading
- uses the same inline X logo approach as the Home hero
- keeps the heading layout, line break, and wording unchanged
- logo color follows the heading via currentColor
- includes baseline alignment so it sits like a capital letter

No automatic server restart.

Install from the existing Replit Shell:

rm -rf /tmp/launch_hero_x_logo_mark_v24_55 && mkdir -p /tmp/launch_hero_x_logo_mark_v24_55 && unzip -o launch_hero_x_logo_mark_v24_55.zip -d /tmp/launch_hero_x_logo_mark_v24_55 && bash /tmp/launch_hero_x_logo_mark_v24_55/install.sh
