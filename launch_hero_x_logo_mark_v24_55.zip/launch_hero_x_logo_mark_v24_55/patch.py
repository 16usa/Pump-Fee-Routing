from pathlib import Path
import re

app_path = Path('src/app.js')
css_path = Path('src/styles.css')
for p in (app_path, css_path):
    if not p.exists():
        raise SystemExit(f'ERROR: {p} not found. Run this from the existing Replit project root.')

app = app_path.read_text()
css = css_path.read_text()
marker = '/* launch-hero-x-logo-mark-v24-55 */'

svg = '<span class="launch-hero-x-logo" aria-label="X"><svg viewBox="0 0 1200 1227" aria-hidden="true" focusable="false"><path fill="currentColor" d="M714.163 519.284L1160.89 0H1055.06L667.137 450.887L357.328 0H0L468.492 681.821L0 1226.37H105.866L515.454 750.218L842.672 1226.37H1200L714.137 519.284H714.163ZM569.137 687.828L521.697 619.934L144.011 79.6944H306.615L611.449 515.999L658.889 583.893L1055.11 1150.13H892.506L569.137 687.854V687.828Z"/></svg></span>'

# Replace only the X in the launch-page hero heading.
pattern = re.compile(r'(<h1>Launch and direct fees(?:<br\s*/?>|\\n|\s*<br\s*/?>\s*)through\s+)(X)(\s+Money</h1>)')
if 'class="launch-hero-x-logo"' not in app:
    app2, n = pattern.subn(r'\1' + svg + r'\3', app, count=1)
    if n != 1:
        # Try a slightly more permissive variant for spacing/newlines.
        pattern2 = re.compile(r'(<h1>Launch and direct fees.*?through\s+)(X)(\s+Money</h1>)', re.S)
        app2, n = pattern2.subn(r'\1' + svg + r'\3', app, count=1)
    if n != 1:
        raise SystemExit('ERROR: target Launch page heading not found in src/app.js')
    app = app2

if marker not in css:
    css += r'''

/* launch-hero-x-logo-mark-v24-55
   Replace the text letter X in the Launch page hero heading with the actual X logo mark.
   The logo follows the heading color via currentColor and is aligned like one capital glyph. */
.launch-hero-x-logo{
  display:inline-flex !important;
  width:.84em !important;
  height:.84em !important;
  align-items:center !important;
  justify-content:center !important;
  color:currentColor !important;
  vertical-align:-.035em !important;
  margin:0 .01em !important;
  line-height:1 !important;
}

.launch-hero-x-logo svg{
  display:block !important;
  width:100% !important;
  height:100% !important;
  overflow:visible !important;
  fill:currentColor !important;
}

.launch-hero-x-logo path{
  fill:currentColor !important;
}
'''

app_path.write_text(app)
css_path.write_text(css)
print('PASS: Launch page hero text X replaced with inline X logo mark.')
print('PASS: Launch page X logo uses currentColor and matches the hero heading scale.')
