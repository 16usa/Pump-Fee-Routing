#!/usr/bin/env bash
set -euo pipefail

for f in src/app.js src/styles.css; do
  [ -f "$f" ] || { echo "Missing $f"; exit 1; }
done

cp src/app.js /tmp/Pump-Fee-Routing-app-before-home-explore-v7.js
cp src/styles.css /tmp/Pump-Fee-Routing-styles-before-home-explore-v7.css

restore() {
  cp /tmp/Pump-Fee-Routing-app-before-home-explore-v7.js src/app.js
  cp /tmp/Pump-Fee-Routing-styles-before-home-explore-v7.css src/styles.css
}

python3 - <<'PY'
from pathlib import Path

app_path = Path('src/app.js')
styles_path = Path('src/styles.css')

new_block = r'''
      <a class="home-preview-card home-ref-card home-ref-explore-card home-explore-reference-v7" href="#/explore">
        <div class="home-explore-v7-head">
          <strong>Explore</strong>
          <span>Open →</span>
        </div>
        ${(() => {
          const withVisual = tokens.filter(t => String(t?.mint || t?.contract || t?.image_url || '').trim());
          const primary = withVisual[0] || tokens[0] || null;
          const secondary = withVisual.find(t => t !== primary) || withVisual[0] || primary;

          const findProfile = (token) => {
            const handle = String(token?.profile || token?.recipient_handle || token?.recipient_handles || '').replace(/^@/, '').trim().toLowerCase();
            if (!handle) return null;
            return profiles.find(p => String(p?.handle || '').replace(/^@/, '').trim().toLowerCase() === handle) || null;
          };

          const renderTokenArt = (token, className) => {
            const initial = esc(initials(token?.symbol || token?.name || 'P'));
            if (!token) return `<span class="home-explore-v7-fallback ${className}">${initial}</span>`;
            const mint = String(token.mint || token.contract || '').trim();
            const direct = String(token.image_url || '').trim();
            const fallbackAction = direct
              ? `this.onerror=function(){this.style.display='none';this.nextElementSibling.style.display='grid'};this.src='${esc(direct)}'`
              : `this.style.display='none';this.nextElementSibling.style.display='grid'`;
            if (mint) {
              return `<img class="home-explore-v7-art ${className}" src="/api/token-image/${encodeURIComponent(mint)}" alt="" loading="eager" decoding="async" onerror="${fallbackAction}"><span class="home-explore-v7-fallback ${className}" style="display:none">${initial}</span>`;
            }
            if (direct) {
              return `<img class="home-explore-v7-art ${className}" src="${esc(direct)}" alt="" loading="eager" decoding="async" onerror="this.style.display='none';this.nextElementSibling.style.display='grid'"><span class="home-explore-v7-fallback ${className}" style="display:none">${initial}</span>`;
            }
            return `<span class="home-explore-v7-fallback ${className}">${initial}</span>`;
          };

          const renderRecipient = (token) => {
            const profile = findProfile(token);
            const handle = String(token?.profile || token?.recipient_handle || token?.recipient_handles || '').replace(/^@/, '').trim();
            const label = profile?.display_name || handle || 'Recipient';
            const avatarUrl = String(profile?.avatar_url || '').trim();
            return `<div class="home-explore-v7-recipient"><i>$</i>${avatar(label, false, avatarUrl)}<b>${esc(label)}</b></div>`;
          };

          const renderPrimary = (token) => {
            if (!token) {
              return `<div class="home-explore-v7-primary-card is-empty"><div class="home-explore-v7-media">${renderTokenArt(null, 'primary')}</div></div>`;
            }
            return `<div class="home-explore-v7-primary-card">
              <div class="home-explore-v7-media">
                ${renderTokenArt(token, 'primary')}
                <div class="home-explore-v7-venue">${platformBadge(token.platform || 'Pump')}</div>
                ${renderRecipient(token)}
                <div class="home-explore-v7-copy">
                  <div class="home-explore-v7-title"><strong>${esc(token.name || 'Token')}</strong><span>${esc(token.symbol || '')}</span></div>
                  <div class="home-explore-v7-stats"><span>${fmtMc(token.mc ?? token.market_cap_usd)} MC</span><b>${fmtMoney(token.sent || 0)}</b></div>
                </div>
              </div>
            </div>`;
          };

          const renderSecondary = (token) => {
            return `<div class="home-explore-v7-secondary-card${token ? '' : ' is-empty'}">
              <div class="home-explore-v7-media">${renderTokenArt(token, 'secondary')}</div>
              <div class="home-explore-v7-secondary-shade" aria-hidden="true"></div>
            </div>`;
          };

          return `<div class="home-explore-v7-stage">
            <div class="home-explore-v7-primary-slot">${renderPrimary(primary)}</div>
            <div class="home-explore-v7-secondary-slot">${renderSecondary(secondary)}</div>
          </div>`;
        })()}
      </a>
'''

css_patch = r'''
/* home-explore-layout-v7 */
.home-reference-v2-previews .home-preview-card.home-ref-explore-card.home-explore-reference-v7{
  position:relative;
  display:block;
  min-height:0;
  height:390px;
  padding:0;
  overflow:hidden;
  border:1px solid #303030;
  border-radius:20px;
  background:#171717;
  color:#fff;
  text-decoration:none;
  box-shadow:none;
  isolation:isolate;
}
.home-explore-reference-v7,.home-explore-reference-v7 *{animation:none!important;transition:none!important}
.home-explore-v7-head{
  position:absolute;
  left:20px;
  right:20px;
  top:16px;
  height:22px;
  z-index:20;
  display:flex;
  align-items:center;
  justify-content:space-between;
  pointer-events:none;
}
.home-explore-v7-head strong{
  color:#f0f0f0;
  font-size:14px;
  line-height:1;
  font-weight:650;
  letter-spacing:.01em;
}
.home-explore-v7-head span{
  color:#777;
  font-size:12px;
  line-height:1;
  font-weight:450;
  white-space:nowrap;
}
.home-explore-v7-stage{
  position:absolute;
  left:0;
  right:0;
  top:52px;
  bottom:0;
  overflow:hidden;
  background:#171717;
}
.home-explore-v7-primary-slot{
  position:absolute;
  left:0;
  top:0;
  bottom:0;
  width:56.6%;
  z-index:2;
}
.home-explore-v7-secondary-slot{
  position:absolute;
  right:0;
  bottom:0;
  width:43.0%;
  height:69%;
  z-index:3;
}
.home-explore-v7-primary-card,
.home-explore-v7-secondary-card{
  position:absolute;
  inset:0;
  overflow:hidden;
  background:#0c0c0c;
  border:1px solid #2b2b2b;
  box-shadow:0 8px 22px rgba(0,0,0,.24);
}
.home-explore-v7-primary-card{border-radius:0 16px 0 0;border-left:0;border-bottom:0}
.home-explore-v7-secondary-card{border-radius:16px 0 0 0;border-right:0;border-bottom:0}
.home-explore-v7-media{position:relative;width:100%;height:100%;overflow:hidden;background:#0a0a0a}
.home-explore-v7-art,.home-explore-v7-fallback{position:absolute;inset:0;width:100%;height:100%}
.home-explore-v7-art{display:block;object-fit:cover;object-position:center;transform:none!important;filter:saturate(.96) contrast(1.02)}
.home-explore-v7-fallback{display:grid;place-items:center;background:radial-gradient(circle at 50% 40%,rgba(255,255,255,.095),rgba(255,255,255,.025) 28%,transparent 56%),linear-gradient(160deg,#202020 0%,#111 62%,#090909 100%);color:#858585;font-size:60px;font-weight:730}
.home-explore-v7-venue{position:absolute;right:14px;top:14px;z-index:4;display:flex;align-items:center;min-height:23px;padding:3px 8px;border:1px solid rgba(255,255,255,.14);border-radius:999px;background:rgba(8,8,8,.78);color:#b9b9b9;font-size:10px;backdrop-filter:blur(7px);-webkit-backdrop-filter:blur(7px)}
.home-explore-v7-recipient{position:absolute;left:14px;bottom:76px;z-index:5;max-width:82%;min-height:34px;display:flex;align-items:center;gap:7px;padding:5px 12px 5px 7px;overflow:hidden;border:1px solid rgba(255,255,255,.16);border-radius:999px;background:rgba(4,4,4,.93);box-shadow:0 4px 16px rgba(0,0,0,.28);white-space:nowrap}
.home-explore-v7-recipient>i{width:22px;height:22px;flex:0 0 22px;display:grid;place-items:center;border-radius:50%;background:#171717;color:#d8d8d8;font-size:11px;font-style:normal;font-weight:750}
.home-explore-v7-recipient .avatar{width:23px;height:23px;flex:0 0 23px;margin-left:-11px;border:1px solid #292929;font-size:8px}
.home-explore-v7-recipient>b{min-width:0;overflow:hidden;text-overflow:ellipsis;color:#f1f1f1;font-size:11px;font-weight:650}
.home-explore-v7-copy{position:absolute;left:0;right:0;bottom:0;z-index:4;display:grid;gap:5px;padding:24px 16px 15px;background:linear-gradient(180deg,rgba(8,8,8,0) 0%,rgba(8,8,8,.48) 28%,rgba(8,8,8,.94) 66%,rgba(8,8,8,.985) 100%)}
.home-explore-v7-title{display:flex;align-items:baseline;gap:8px;min-width:0}.home-explore-v7-title strong{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#f1f1f1;font-size:13px;font-weight:650}.home-explore-v7-title span{flex:0 0 auto;color:#6f6f6f;font-size:9px}
.home-explore-v7-stats{display:flex;align-items:baseline;justify-content:space-between;gap:10px;color:#666;font-size:9px}.home-explore-v7-stats b{color:#e5e5e5;font-size:13px;font-weight:650}
.home-explore-v7-secondary-shade{position:absolute;inset:0;z-index:2;background:linear-gradient(180deg,rgba(0,0,0,.02) 0%,rgba(0,0,0,.04) 54%,rgba(0,0,0,.20) 78%,rgba(0,0,0,.50) 100%);pointer-events:none}

@media (max-width:640px){
  .home-reference-v2-previews .home-preview-card.home-ref-explore-card.home-explore-reference-v7{height:350px;border-radius:16px}
  .home-explore-v7-head{left:14px;right:14px;top:13px;height:20px}
  .home-explore-v7-head strong{font-size:13px}
  .home-explore-v7-head span{font-size:11px}
  .home-explore-v7-stage{top:45px}
  .home-explore-v7-primary-slot{width:57.2%}
  .home-explore-v7-secondary-slot{width:42.4%;height:68%}
  .home-explore-v7-primary-card{border-radius:0 13px 0 0}
  .home-explore-v7-secondary-card{border-radius:13px 0 0 0}
  .home-explore-v7-venue{right:10px;top:10px;min-height:20px;padding:3px 7px;font-size:8px}
  .home-explore-v7-recipient{left:9px;bottom:62px;min-height:29px;gap:5px;padding:4px 9px 4px 5px}
  .home-explore-v7-recipient>i{width:19px;height:19px;flex-basis:19px;font-size:9px}
  .home-explore-v7-recipient .avatar{width:19px;height:19px;flex-basis:19px;margin-left:-9px;font-size:7px}
  .home-explore-v7-recipient>b{font-size:9px}
  .home-explore-v7-copy{padding:20px 11px 11px;gap:4px}
  .home-explore-v7-title strong{font-size:10px}
  .home-explore-v7-title span{font-size:7px}
  .home-explore-v7-stats{font-size:7px}
  .home-explore-v7-stats b{font-size:10px}
}
'''

app = app_path.read_text()
markers = [
  '      <a class="home-preview-card home-ref-card home-ref-explore-card home-explore-reference-v7" href="#/explore">',
  '      <a class="home-preview-card home-ref-card home-ref-explore-card home-explore-reference-v6" href="#/explore">',
  '      <a class="home-preview-card home-ref-card home-ref-explore-card home-explore-reference-v5" href="#/explore">',
  '      <a class="home-preview-card home-ref-card home-ref-explore-card home-explore-modules-v4" href="#/explore">',
  '      <a class="home-preview-card home-ref-card home-ref-explore-card home-explore-reference-v3" href="#/explore">',
  '      <a class="home-preview-card home-ref-card home-ref-explore-card home-explore-reference-v2" href="#/explore">',
  '      <a class="home-preview-card home-ref-card home-ref-explore-card" href="#/explore">'
]
start = -1
for marker in markers:
    start = app.find(marker)
    if start >= 0:
        break
if start < 0:
    raise SystemExit('Could not locate Home Explore preview block.')
end_marker = '      <a class="home-preview-card home-ref-card home-v2-payments-card" href="#/money">'
end = app.find(end_marker, start)
if end < 0:
    raise SystemExit('Could not locate Payments block after Explore.')
app = app[:start] + new_block + app[end:]
app_path.write_text(app)

css = styles_path.read_text()
markers = [
  '/* home-explore-layout-v7 */',
  '/* home-explore-reference-match-v6 */',
  '/* home-explore-reference-match-v5 */',
  '/* home-explore-modules-v4 */',
  '/* home-explore-reference-match-v3 */',
  '/* home-explore-reference-match-v2 */',
  '/* home-explore-static-reference-v1 */'
]
cut = None
for marker in markers:
    p = css.find(marker)
    if p >= 0 and (cut is None or p < cut):
        cut = p
if cut is not None:
    css = css[:cut].rstrip() + '\n'
css += '\n\n' + css_patch + '\n'
styles_path.write_text(css)
print('Home Explore Layout v7 installed.')
PY

if ! node --check src/app.js; then
  restore
  echo "src/app.js syntax failed; restored originals."
  exit 2
fi

if ! npm run check; then
  restore
  echo "Project check failed; restored originals."
  exit 3
fi

node <<'NODE'
const fs=require('fs');
const app=fs.readFileSync('src/app.js','utf8');
const css=fs.readFileSync('src/styles.css','utf8');
const s=app.indexOf('home-explore-reference-v7');
const e=app.indexOf('home-v2-payments-card',s);
const block=app.slice(s,e);
const checks=[
 ['v7 block',s>=0],
 ['compact Explore/Open header',block.includes('home-explore-v7-head')&&block.includes('<strong>Explore</strong>')&&block.includes('<span>Open →</span>')],
 ['left flush slot',css.includes('left:0;\n  top:0;\n  bottom:0;\n  width:56.6%')],
 ['right flush slot',css.includes('right:0;\n  bottom:0;\n  width:43.0%')],
 ['larger cards',css.includes('height:390px')],
 ['static cards',css.includes('animation:none!important;transition:none!important')],
 ['Payments preserved',e>=0],
 ['wallet code preserved',app.includes('function connectWallet')],
 ['v7 css marker',css.includes('home-explore-layout-v7')]
];
let bad=0;
for(const [name,ok] of checks){console.log((ok?'PASS':'FAIL')+' '+name); if(!ok) bad++;}
if(bad) process.exit(1);
NODE

git add src/app.js src/styles.css
if git diff --cached --quiet; then
  echo "No new changes to commit."
else
  git commit -m "Tighten Home Explore preview layout"
  git push origin main
fi

echo
echo "DONE: Home Explore Layout v7 installed, checked, committed, and pushed."
echo "Only Home Explore layout was changed."
echo "No server restart was performed."
echo "Restart Console/Run manually once, then reload Home."
