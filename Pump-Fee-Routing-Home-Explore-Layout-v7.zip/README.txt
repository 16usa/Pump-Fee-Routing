Pump Fee Routing — Home Explore Layout v7

Changes only the Home > Explore preview block.

What changes:
- Restores the Explore / Open header to the same compact header pattern as the lower Home modules.
- Left preview card touches the content area on TOP + LEFT + BOTTOM (no outer gap on those sides).
- Right preview card touches RIGHT + BOTTOM (no outer gap on those sides).
- Cards are larger and the gap between them is reduced.
- Keeps both cards static (no motion).
- Preserves token/profile data and token image resolving.
- Does not change Payments, Analytics, Launch, Docs or wallet/launch logic.
- Does not restart the server automatically.

Install from the existing Replit workspace Shell:
rm -rf /tmp/home-explore-v7
mkdir -p /tmp/home-explore-v7
unzip -o Pump-Fee-Routing-Home-Explore-Layout-v7.zip -d /tmp/home-explore-v7
bash /tmp/home-explore-v7/install.sh

After install, restart Console/Run manually once and reload Home.
