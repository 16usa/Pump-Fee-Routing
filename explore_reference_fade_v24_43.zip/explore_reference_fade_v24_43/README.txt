Patch: explore_reference_fade_v24_43

What it does:
- removes the previous full-block Explore blur behavior
- applies the visual treatment only inside the projected preview content
- keeps Explore / Open text crisp above the treatment
- creates a lower progressive blur/fade with subtle side shading, closer to the UsePaid reference

Install from your existing Replit project root:
rm -rf /tmp/explore_reference_fade_v24_43 && mkdir -p /tmp/explore_reference_fade_v24_43 && unzip -o explore_reference_fade_v24_43.zip -d /tmp/explore_reference_fade_v24_43 && bash /tmp/explore_reference_fade_v24_43/install.sh
