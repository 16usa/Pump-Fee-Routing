#!/usr/bin/env bash
set -euo pipefail

PATCH_NAME="explore_reference_fade_v24_43"
CSS="src/styles.css"

if [ ! -f "$CSS" ]; then
  echo "ERROR: missing src/styles.css"
  echo "Run this from the existing Replit project root."
  exit 1
fi

echo "==> Installing ${PATCH_NAME}"
mkdir -p ".patch-backups/${PATCH_NAME}"
cp "$CSS" ".patch-backups/${PATCH_NAME}/styles.css.before"

python3 "$(dirname "$0")/patch.py"

echo "==> Verifying patch markers"
grep -q 'explore-reference-fade-v24-43' "$CSS"
grep -q '.home-explore-v8-primary-slot::after' "$CSS"
grep -q '.home-explore-v8-secondary-slot::after' "$CSS"

echo "==> Running project check"
npm run check

echo "==> Diff summary"
git diff --stat -- src/styles.css

git add src/styles.css
if git diff --cached --quiet; then
  echo "==> No new changes to commit."
else
  git commit -m "Match Explore preview fade to reference"
  git push origin main
fi

echo
echo "PASS: ${PATCH_NAME} installed."
echo "No server restart was performed."
