#!/usr/bin/env bash
set -euo pipefail

for f in src/app.js src/styles.css; do
  [ -f "$f" ] || {
    echo "Missing $f. Run this from the Pump-Fee-Routing project root."
    exit 1
  }
done

if [ -n "$(git status --porcelain -- src/app.js src/styles.css public/assets 2>/dev/null || true)" ]; then
  echo "STOP: tracked Launch files/assets have uncommitted changes."
  git status --short -- src/app.js src/styles.css public/assets 2>/dev/null || true
  exit 2
fi

python3 - <<'PY'
from pathlib import Path
import base64

app_path=Path("src/app.js")
css_path=Path("src/styles.css")
app=app_path.read_text()
css=css_path.read_text()

marker="launch-walletless-reference-image-v1"
if marker in app or marker in css:
    raise SystemExit("Walletless Reference Image v1 is already installed.")

old=base64.b64decode("PGRpdiBjbGFzcz0ibGF1bmNoLXdhbGxldGxlc3MtcHVtcC11aSI+CiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPSJsYXVuY2gtd2FsbGV0bGVzcy1wdW1wLWhlYWQiPjxzcGFuPlNoYXJlIGNyZWF0b3IgcmV3YXJkczwvc3Bhbj48Yj7DlzwvYj48L2Rpdj4KICAgICAgICAgICAgICAgIDxzbWFsbD5DcmVhdG9ycyBjYW4gcGVyY2VudGFnZSByZXdhcmRzIG9uIGFsbCB0cmFuc2FjdGlvbiBmZWVzLiBZb3UgbWF5IGludml0ZSB3YWxsZXRzIG9yIGNoYXJpdGllcyB0byByZWNlaXZlIGEgcG9ydGlvbiBvZiBpdC48L3NtYWxsPgogICAgICAgICAgICAgICAgPGRpdiBjbGFzcz0ibGF1bmNoLXdhbGxldGxlc3MtYWxsb2NhdGlvbiI+PHNwYW4+QWxsb2NhdGVkPC9zcGFuPjxzdHJvbmc+MTAwJTwvc3Ryb25nPjwvZGl2PgogICAgICAgICAgICAgICAgPGRpdiBjbGFzcz0ibGF1bmNoLXdhbGxldGxlc3MtcHVtcC1yb3ciPjxpPuKXjzwvaT48c3Bhbj4ke2JyYW5kTmFtZX08L3NwYW4+PGI+MTAwJTwvYj48L2Rpdj4KICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT0iYnV0dG9uIiBkaXNhYmxlZD5BZGQgbW9yZSByZWNpcGllbnRzPC9idXR0b24+CiAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9ImJ1dHRvbiIgZGlzYWJsZWQ+RG9uZTwvYnV0dG9uPgogICAgICAgICAgICAgIDwvZGl2Pg==").decode()
new=base64.b64decode("PGltZwogICAgICAgICAgICAgICAgY2xhc3M9ImxhdW5jaC13YWxsZXRsZXNzLXB1bXAtcmVmZXJlbmNlIgogICAgICAgICAgICAgICAgc3JjPSIvYXNzZXRzL3dhbGxldGxlc3Mtc2hhcmUtY3JlYXRvci1yZXdhcmRzLndlYnAiCiAgICAgICAgICAgICAgICBhbHQ9IlB1bXAgU2hhcmUgY3JlYXRvciByZXdhcmRzIHNldHVwIHNob3dpbmcgb25lIHJlY2lwaWVudCB3aXRoIDEwMCBwZXJjZW50IGFsbG9jYXRpb24iCiAgICAgICAgICAgICAgICBsb2FkaW5nPSJsYXp5IgogICAgICAgICAgICAgICAgZGVjb2Rpbmc9ImFzeW5jIgogICAgICAgICAgICAgID4=").decode()

if old not in app:
    raise SystemExit("Walletless mock Share creator rewards block was not found.")

app=app.replace(old,new,1)
app += "\n/* "+marker+" */\n"
css += base64.b64decode("Ci8qIGxhdW5jaC13YWxsZXRsZXNzLXJlZmVyZW5jZS1pbWFnZS12MSAqLwoubGF1bmNoLXdhbGxldGxlc3MtcHVtcC1yZWZlcmVuY2V7CiAgd2lkdGg6MTAwJTsKICBoZWlnaHQ6YXV0bzsKICBkaXNwbGF5OmJsb2NrOwogIG1hcmdpbi10b3A6MTJweDsKICBib3JkZXItcmFkaXVzOjExcHg7CiAgb2JqZWN0LWZpdDpjb250YWluOwogIGJhY2tncm91bmQ6IzBjMGMwYzsKfQo=").decode()

app_path.write_text(app)
css_path.write_text(css)
print("Walletless reference image markup installed.")
PY

mkdir -p public/assets
cp "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/assets/walletless-share-creator-rewards.webp" \
   public/assets/walletless-share-creator-rewards.webp

test -s public/assets/walletless-share-creator-rewards.webp

node --check src/app.js
npm run check

node <<'NODE'
const fs=require('fs');
const app=fs.readFileSync('src/app.js','utf8');
const css=fs.readFileSync('src/styles.css','utf8');

const checks=[
  ['Walletless reference image markup', app.includes('class="launch-walletless-pump-reference"')],
  ['correct public asset path', app.includes('src="/assets/walletless-share-creator-rewards.webp"')],
  ['old hand-built mock removed from markup', !app.includes('<div class="launch-walletless-pump-ui">')],
  ['Launch on Pump card preserved', app.includes('<h3>Launch on Pump</h3>')],
  ['reference caption preserved', app.includes('Add our treasury as the only recipient, at 100%, before you create the coin.')],
  ['Walletless mode preserved', app.includes('data-launch-panel="walletless"')],
  ['reference image CSS', css.includes('.launch-walletless-pump-reference{')],
  ['patch marker', app.includes('launch-walletless-reference-image-v1')]
];

let bad=0;
for(const [name,ok] of checks){
  console.log((ok?'PASS':'FAIL')+' '+name);
  if(!ok)bad++;
}
if(bad)process.exit(1);
NODE

git add src/app.js src/styles.css public/assets/walletless-share-creator-rewards.webp

if git diff --cached --quiet; then
  echo "No staged changes; nothing to commit."
else
  git commit -m "Use reference image in Walletless Pump guide"
fi

git push origin main

echo
echo "DONE: Walletless Reference Image v1 checked, committed, and pushed to GitHub."
echo "The hand-built Share creator rewards mock was replaced by the supplied reference image."
echo "Only the Walletless Launch on Pump guide was changed."
echo "No server restart was performed."
echo "Restart Console/Run manually once to load the update."
