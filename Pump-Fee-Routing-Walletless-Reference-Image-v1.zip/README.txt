Pump Fee Routing — Walletless Reference Image v1

Changes only the Walletless tab's "Launch on Pump" guide.

What it does:
- Removes the hand-built imitation of Pump's "Share creator rewards" window.
- Inserts the supplied reference image directly inside the "Launch on Pump" card.
- Keeps the title, subtitle, explanatory caption, animated payout block, and the rest of Walletless unchanged.
- Adds the image as: public/assets/walletless-share-creator-rewards.webp
- Keeps the image responsive on mobile.
- Installer validates, commits, and pushes origin/main.
- No automatic server restart.
