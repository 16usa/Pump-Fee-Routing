#!/usr/bin/env bash
set -euo pipefail

echo "== Explore Blur / Vignette Match v15.4 =="

for f in src/styles.css src/app.js; do
  if [ ! -f "$f" ]; then
    echo "ERROR: $f not found. Run this from the existing Replit project workspace."
    exit 1
  fi
done

python3 <<'PYCODE'
from pathlib import Path
import re

css_path = Path('src/styles.css')
app_path = Path('src/app.js')
css = css_path.read_text()
app = app_path.read_text()

# Guard: expect Explore module patches to already exist
if 'home-explore-reference-v8' not in css or 'data-explore-card-info="v15"' not in app:
    raise SystemExit('ERROR: required Explore reference/card patches are missing. Install the previous Explore patches first.')

marker = '/* explore-vignette-match-v15-4 */'
start = css.find(marker)
if start != -1:
    end = css.find('/* end explore-vignette-match-v15-4 */', start)
    if end != -1:
        end += len('/* end explore-vignette-match-v15-4 */')
        css = css[:start] + css[end:]

patch = r'''
/* explore-vignette-match-v15-4 */

/* Make the image treatment match the reference more closely:
   - soft fog around all edges
   - stronger bottom fade where text sits
   - slight softness on sides/top
   - same feel on both primary and secondary explore media */
.home-explore-reference-v8 .home-explore-v8-primary-card > .home-explore-v8-media,
.home-explore-reference-v8 .home-explore-v8-secondary-card > .home-explore-v8-secondary-media{
  position: relative;
  overflow: hidden;
  isolation: isolate;
}

.home-explore-reference-v8 .home-explore-v8-primary-card > .home-explore-v8-media::before,
.home-explore-reference-v8 .home-explore-v8-secondary-card > .home-explore-v8-secondary-media::before{
  content: "";
  position: absolute;
  inset: 0;
  z-index: 1;
  pointer-events: none;
  border-radius: inherit;
  background:
    radial-gradient(120% 82% at 50% 44%, rgba(0,0,0,0) 44%, rgba(0,0,0,0.06) 60%, rgba(0,0,0,0.14) 76%, rgba(0,0,0,0.24) 100%),
    linear-gradient(180deg, rgba(0,0,0,0.18) 0%, rgba(0,0,0,0.06) 20%, rgba(0,0,0,0.02) 42%, rgba(0,0,0,0.10) 58%, rgba(0,0,0,0.36) 78%, rgba(0,0,0,0.70) 100%),
    linear-gradient(90deg, rgba(0,0,0,0.22) 0%, rgba(0,0,0,0.06) 12%, rgba(0,0,0,0.00) 26%, rgba(0,0,0,0.00) 74%, rgba(0,0,0,0.06) 88%, rgba(0,0,0,0.22) 100%);
  box-shadow:
    inset 0 -132px 110px -72px rgba(0,0,0,0.80),
    inset 0 -64px 54px -36px rgba(0,0,0,0.42),
    inset 0 26px 36px -28px rgba(0,0,0,0.18),
    inset 22px 0 28px -22px rgba(0,0,0,0.22),
    inset -22px 0 28px -22px rgba(0,0,0,0.22);
}

/* extra bottom haze like the reference */
.home-explore-reference-v8 .home-explore-v8-primary-card > .home-explore-v8-media::after,
.home-explore-reference-v8 .home-explore-v8-secondary-card > .home-explore-v8-secondary-media::after{
  content: "";
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
  height: 42%;
  z-index: 2;
  pointer-events: none;
  border-radius: 0 0 inherit inherit;
  background:
    linear-gradient(180deg,
      rgba(0,0,0,0.00) 0%,
      rgba(0,0,0,0.08) 18%,
      rgba(0,0,0,0.18) 38%,
      rgba(0,0,0,0.36) 62%,
      rgba(0,0,0,0.58) 82%,
      rgba(0,0,0,0.76) 100%);
  filter: blur(10px);
  transform: translateY(8px);
}

/* Keep important overlays above the blur */
.home-explore-reference-v8 .home-explore-v8-primary-card .home-top-token-age,
.home-explore-reference-v8 .home-explore-v8-primary-card .home-explore-v8-recipient,
.home-explore-reference-v8 .home-explore-v8-primary-card .home-explore-v8-body,
.home-explore-reference-v8 .home-explore-v8-secondary-card .home-explore-v8-open,
.home-explore-reference-v8 .home-explore-v8-secondary-card .home-top-token-age{
  position: relative;
  z-index: 4;
}

/* Slightly blur the actual image underneath to remove the harsh look */
.home-explore-reference-v8 .home-explore-v8-primary-card > .home-explore-v8-media img,
.home-explore-reference-v8 .home-explore-v8-secondary-card > .home-explore-v8-secondary-media img{
  filter: saturate(0.98) contrast(0.96);
}

/* Mobile tuning */
@media (max-width: 640px){
  .home-explore-reference-v8 .home-explore-v8-primary-card > .home-explore-v8-media::before,
  .home-explore-reference-v8 .home-explore-v8-secondary-card > .home-explore-v8-secondary-media::before{
    box-shadow:
      inset 0 -118px 96px -68px rgba(0,0,0,0.82),
      inset 0 -54px 46px -32px rgba(0,0,0,0.46),
      inset 0 18px 28px -22px rgba(0,0,0,0.18),
      inset 16px 0 22px -16px rgba(0,0,0,0.20),
      inset -16px 0 22px -16px rgba(0,0,0,0.20);
  }

  .home-explore-reference-v8 .home-explore-v8-primary-card > .home-explore-v8-media::after,
  .home-explore-reference-v8 .home-explore-v8-secondary-card > .home-explore-v8-secondary-media::after{
    height: 46%;
    filter: blur(12px);
    transform: translateY(10px);
  }
}
/* end explore-vignette-match-v15-4 */
'''

css = css.rstrip() + '\n\n' + patch + '\n'
css_path.write_text(css)

# Verify
new_css = css_path.read_text()
checks = {
    'marker': marker in new_css,
    'primary media blur block': '.home-explore-v8-primary-card > .home-explore-v8-media::before' in new_css,
    'secondary media blur block': '.home-explore-v8-secondary-card > .home-explore-v8-secondary-media::before' in new_css,
    'bottom haze': '.home-explore-v8-primary-card > .home-explore-v8-media::after' in new_css,
}
for label, ok in checks.items():
    if not ok:
        raise SystemExit(f'ERROR: verification failed: {label}')
    print('PASS', label)
PYCODE

echo
npm run check || true

echo
if git status --short src/styles.css >/dev/null 2>&1; then
  git add src/styles.css || true
  if ! git diff --cached --quiet 2>/dev/null; then
    git commit -m "Match Explore image blur to reference" || true
    git push || true
  fi
fi

echo
 echo "DONE: Explore Blur / Vignette Match v15.4 installed."
 echo "No server restart was performed. Restart manually from Replit console and reload the page."
