Pump Fee Routing — Explore Blur / Vignette Match v15.4

What this patch changes:
- Reworks the Explore-card image blur / darkening to match the reference more closely.
- Adds soft fog around all edges.
- Adds stronger bottom fade behind the text zone.
- Applies the same treatment to the right small Explore media tile.
- No automatic restart.

Install in Replit Shell:
rm -rf /tmp/explore-vignette-v15-4
mkdir -p /tmp/explore-vignette-v15-4
unzip -o Pump-Fee-Routing-Explore-Blur-Match-v15-4.zip -d /tmp/explore-vignette-v15-4
bash /tmp/explore-vignette-v15-4/install.sh
