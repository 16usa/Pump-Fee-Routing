#!/usr/bin/env bash
set -euo pipefail

PATCH_NAME="hero_cta_match_subtitle_size_v24_51"
CSS="src/styles.css"

if [ ! -f "$CSS" ]; then
  echo "ERROR: missing src/styles.css"
  echo "Run this from the existing Replit project root."
  exit 1
fi

echo "==> Installing ${PATCH_NAME}"
mkdir -p ".patch-backups/${PATCH_NAME}"
cp "$CSS" ".patch-backups/${PATCH_NAME}/styles.css.before"

python3 "$(dirname "$0")/patch.py"

echo "==> Verifying final CTA sizes"
grep -q 'hero-cta-match-subtitle-size-v24-51' "$CSS"
grep -q 'font-size:15px !important' "$CSS"
grep -q 'font-size:12px !important' "$CSS"

echo "==> Running project check"
npm run check

echo "==> Git diff"
git diff --stat -- "$CSS"

git add "$CSS"
if git diff --cached --quiet; then
  echo "==> No new changes to commit."
else
  git commit -m "Match hero CTA text to subtitle size"
  git push origin main
fi

echo
echo "PASS: ${PATCH_NAME} installed."
echo "No server restart was performed."
