from pathlib import Path

css_path = Path("src/styles.css")
if not css_path.exists():
    raise SystemExit("ERROR: src/styles.css not found. Run this from the existing Replit project root.")

css = css_path.read_text()
marker = "/* hero-cta-match-subtitle-size-v24-51 */"

required = [
    "home-hero-subtitle-match-launch-v24-27",
    "hero-cta-typography-unify-v24-50",
    ".home-reference-v1 .home-hero .hero-copy>p",
    ".home-reference-v1 .home-hero .btn-light",
    ".home-reference-v1 .home-hero .text-link",
]
missing = [s for s in required if s not in css]
if missing:
    raise SystemExit("ERROR: required current hero styles not found: " + ", ".join(missing))

if marker not in css:
    css += r'''

/* hero-cta-match-subtitle-size-v24-51
   Final source of truth: both hero CTA labels use the SAME font-size
   as the subtitle directly above them. */
.home-reference-v1 .home-hero .btn-light,
.home-reference-v1 .home-hero .text-link{
  font-size:15px !important;
}

@media(max-width:760px){
  .home-reference-v1 .home-hero .btn-light,
  .home-reference-v1 .home-hero .text-link{
    font-size:12px !important;
  }
}
'''
    css_path.write_text(css)
    print("PASS: both hero CTA labels now match the subtitle size.")
    print("PASS: desktop = 15px, <=760px = 12px.")
else:
    print("No changes needed; v24.51 already installed.")
