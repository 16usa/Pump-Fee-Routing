Pump Fee Routing — Launch Image Preview v1

Fixes the existing Launch image selector without changing the page design.
After choosing an image:
- the selected filename replaces 'Choose image'
- the token Preview card immediately displays the selected image
- PNG/JPG/GIF/WEBP and 5 MB limit are validated immediately

The selected File stays in the existing file input and is still used by the real Pump launch metadata upload.
Installer runs checks, commits, and pushes origin/main. No automatic server restart.
