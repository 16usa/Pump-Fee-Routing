#!/usr/bin/env bash
set -euo pipefail

for f in src/app.js src/styles.css; do
  [ -f "$f" ] || { echo "Missing $f. Run this from the Pump-Fee-Routing project root."; exit 1; }
done

if [ -n "$(git status --porcelain -- src/app.js src/styles.css)" ]; then
  echo "STOP: launch UI files have uncommitted changes."
  git status --short -- src/app.js src/styles.css
  exit 2
fi

python3 - <<'PY'

from pathlib import Path
import base64

def dec(s): return base64.b64decode(s).decode()

app_path=Path('src/app.js')
css_path=Path('src/styles.css')
app=app_path.read_text()
css=css_path.read_text()

if '/* launch-image-preview-v1' in css:
    raise SystemExit('Launch image preview v1 is already installed.')

anchor=dec('ZnVuY3Rpb24gdXBkYXRlTGF1bmNoUHJldmlldygpew==')
if anchor not in app:
    raise SystemExit('updateLaunchPreview anchor not found')
app=app.replace(anchor,dec('bGV0IGxhdW5jaFByZXZpZXdJbWFnZVVybD0nJzsKCmZ1bmN0aW9uIHVwZGF0ZUxhdW5jaEltYWdlUHJldmlldyhpbnB1dCl7CiAgY29uc3QgZmlsZT1pbnB1dD8uZmlsZXM/LlswXXx8bnVsbDsKICBjb25zdCBzaGVsbD1pbnB1dD8uY2xvc2VzdCgnLmxhdW5jaC1maWxlLXNoZWxsJyk7CiAgY29uc3QgbGFiZWw9c2hlbGw/LnF1ZXJ5U2VsZWN0b3IoJ3NwYW4nKTsKICBjb25zdCBwcmV2aWV3PWRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJyNsYXVuY2hQcmV2aWV3SW1hZ2UnKTsKCiAgaWYobGF1bmNoUHJldmlld0ltYWdlVXJsKXsKICAgIFVSTC5yZXZva2VPYmplY3RVUkwobGF1bmNoUHJldmlld0ltYWdlVXJsKTsKICAgIGxhdW5jaFByZXZpZXdJbWFnZVVybD0nJzsKICB9CgogIGlmKCFmaWxlKXsKICAgIGlmKGxhYmVsKWxhYmVsLnRleHRDb250ZW50PSdDaG9vc2UgaW1hZ2UnOwogICAgaWYocHJldmlldyl7CiAgICAgIHByZXZpZXcucmVwbGFjZUNoaWxkcmVuKGRvY3VtZW50LmNyZWF0ZVRleHROb2RlKCdQJykpOwogICAgICBwcmV2aWV3LmNsYXNzTGlzdC5yZW1vdmUoJ2hhcy1pbWFnZScpOwogICAgfQogICAgcmV0dXJuOwogIH0KCiAgaWYoZmlsZS5zaXplPjVfMDAwXzAwMCl7CiAgICBpbnB1dC52YWx1ZT0nJzsKICAgIGlmKGxhYmVsKWxhYmVsLnRleHRDb250ZW50PSdDaG9vc2UgaW1hZ2UnOwogICAgaWYocHJldmlldyl7CiAgICAgIHByZXZpZXcucmVwbGFjZUNoaWxkcmVuKGRvY3VtZW50LmNyZWF0ZVRleHROb2RlKCdQJykpOwogICAgICBwcmV2aWV3LmNsYXNzTGlzdC5yZW1vdmUoJ2hhcy1pbWFnZScpOwogICAgfQogICAgc2V0TGF1bmNoU3RhdHVzKCdUb2tlbiBpbWFnZSBtdXN0IGJlIDUgTUIgb3Igc21hbGxlcicpOwogICAgcmV0dXJuOwogIH0KCiAgaWYoIS9eaW1hZ2VcLyhwbmd8anBlZ3xnaWZ8d2VicCkkL2kudGVzdChmaWxlLnR5cGV8fCcnKSl7CiAgICBpbnB1dC52YWx1ZT0nJzsKICAgIGlmKGxhYmVsKWxhYmVsLnRleHRDb250ZW50PSdDaG9vc2UgaW1hZ2UnOwogICAgaWYocHJldmlldyl7CiAgICAgIHByZXZpZXcucmVwbGFjZUNoaWxkcmVuKGRvY3VtZW50LmNyZWF0ZVRleHROb2RlKCdQJykpOwogICAgICBwcmV2aWV3LmNsYXNzTGlzdC5yZW1vdmUoJ2hhcy1pbWFnZScpOwogICAgfQogICAgc2V0TGF1bmNoU3RhdHVzKCdVc2UgUE5HLCBKUEcsIEdJRiwgb3IgV0VCUCcpOwogICAgcmV0dXJuOwogIH0KCiAgbGF1bmNoUHJldmlld0ltYWdlVXJsPVVSTC5jcmVhdGVPYmplY3RVUkwoZmlsZSk7CiAgaWYobGFiZWwpbGFiZWwudGV4dENvbnRlbnQ9ZmlsZS5uYW1lfHwnSW1hZ2Ugc2VsZWN0ZWQnOwogIGlmKHByZXZpZXcpewogICAgY29uc3QgaW1nPWRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2ltZycpOwogICAgaW1nLnNyYz1sYXVuY2hQcmV2aWV3SW1hZ2VVcmw7CiAgICBpbWcuYWx0PSdUb2tlbiBpbWFnZSBwcmV2aWV3JzsKICAgIHByZXZpZXcucmVwbGFjZUNoaWxkcmVuKGltZyk7CiAgICBwcmV2aWV3LmNsYXNzTGlzdC5hZGQoJ2hhcy1pbWFnZScpOwogIH0KfQoK')+anchor,1)

old=dec('ICAgICAgICA8ZGl2IGNsYXNzPSJsYXVuY2gtcHJldmlldy1pbWFnZSI+UDwvZGl2Pg==')
new=dec('ICAgICAgICA8ZGl2IGNsYXNzPSJsYXVuY2gtcHJldmlldy1pbWFnZSIgaWQ9ImxhdW5jaFByZXZpZXdJbWFnZSI+UDwvZGl2Pg==')
if old not in app:
    raise SystemExit('Launch preview image anchor not found')
app=app.replace(old,new,1)

anchor=dec('YXBwLmFkZEV2ZW50TGlzdGVuZXIoJ3N1Ym1pdCcsYXN5bmMgZT0+e2lmKGUudGFyZ2V0LmlkPT09J2xhdW5jaEZvcm0nKXs=')
if anchor not in app:
    raise SystemExit('submit listener anchor not found')
app=app.replace(anchor,dec('YXBwLmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsZT0+ewogIGlmKGUudGFyZ2V0LmlkPT09J2xhdW5jaEltYWdlJyl1cGRhdGVMYXVuY2hJbWFnZVByZXZpZXcoZS50YXJnZXQpOwp9KTsK')+anchor,1)

css += dec('Ci8qIGxhdW5jaC1pbWFnZS1wcmV2aWV3LXYxIOKAlCBzZWxlY3RlZCB0b2tlbiBpbWFnZSBwcmV2aWV3IG9ubHk7IGxheW91dCB1bmNoYW5nZWQgKi8KLmxhdW5jaC1wcmV2aWV3LWltYWdlLmhhcy1pbWFnZXsKICBwYWRkaW5nOjA7CiAgYmFja2dyb3VuZDojMDgwODA4Owp9Ci5sYXVuY2gtcHJldmlldy1pbWFnZS5oYXMtaW1hZ2UgaW1newogIHdpZHRoOjEwMCU7CiAgaGVpZ2h0OjEwMCU7CiAgZGlzcGxheTpibG9jazsKICBvYmplY3QtZml0OmNvdmVyOwp9Cg==')

app_path.write_text(app)
css_path.write_text(css)
print('Launch image preview v1 patch installed.')

PY

node --check src/app.js
npm run check

node <<'NODE'
const fs=require('fs');
const app=fs.readFileSync('src/app.js','utf8');
const css=fs.readFileSync('src/styles.css','utf8');
const checks=[
  ['file change listener',app.includes("e.target.id==='launchImage'")],
  ['preview image target',app.includes('id="launchPreviewImage"')],
  ['object URL preview',app.includes('URL.createObjectURL(file)')],
  ['5 MB validation',app.includes('file.size>5_000_000')],
  ['image type validation',app.includes("image\\/(png|jpeg|gif|webp)")] || app.includes("image\/(png|jpeg|gif|webp)")],
  ['preview object-fit',css.includes('.launch-preview-image.has-image img')],
];
let bad=0;
for(const [name,ok] of checks){console.log(`${ok?'PASS':'FAIL'} ${name}`);if(!ok)bad++;}
if(bad)process.exit(1);
NODE

git add src/app.js src/styles.css

if git diff --cached --quiet; then
  echo "No staged changes; nothing to commit."
else
  git commit -m "Fix Launch token image preview"
fi

git push origin main

echo
echo "DONE: Launch image preview checked, committed, and pushed to GitHub."
echo "No server restart was performed."
echo "Restart Console/Run manually once, then choose the image again."
