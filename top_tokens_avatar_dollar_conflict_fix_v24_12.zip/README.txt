Top Tokens Avatar + Dollar Conflict Fix v24.12

Cause found:
The intended enlarged rules were generic:
  .home-top-token-recipient .avatar
  .home-top-token-recipient .home-top-token-money-mark

But an older MORE SPECIFIC v21 block still forced:
- avatar to 22px desktop / 19px mobile
- dollar circle to 22px desktop / 19px mobile

So v24.11 effectively set the dollar circle to the already-small constrained size,
which is why visually almost nothing changed.

This patch fixes both elements at the real v21 specificity:
- Desktop: avatar 30px + dollar circle 30px
- Mobile: avatar 28px + dollar circle 28px
- Dollar glyph scales to 15px / 14px
- Existing name and verified badge sizes are untouched
- No automatic restart

Install in the existing Replit Shell:

rm -rf /tmp/top_tokens_avatar_dollar_conflict_fix_v24_12 && mkdir -p /tmp/top_tokens_avatar_dollar_conflict_fix_v24_12 && unzip -o top_tokens_avatar_dollar_conflict_fix_v24_12.zip -d /tmp/top_tokens_avatar_dollar_conflict_fix_v24_12 && bash /tmp/top_tokens_avatar_dollar_conflict_fix_v24_12/install.sh
