Launch Preview Search Border White v24.47

Checked against current GitHub main.

Current values before patch:
- Home hero 'Launch a token' button (.btn-light): background #fff
- Launch preview search outline: #252525
- Search outline width: 3px desktop / 2.5px mobile

This patch changes ONLY the search outline color to #fff,
so it matches the hero CTA exactly.
Width, radius, background, text, and all other Launch preview styles remain unchanged.

No automatic server restart.
