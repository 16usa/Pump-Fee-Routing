from pathlib import Path

css_path = Path("src/styles.css")
if not css_path.exists():
    raise SystemExit("ERROR: src/styles.css not found. Run this from the existing Replit project root.")

css = css_path.read_text()
marker = "/* launch-preview-search-border-white-v24-47 */"

required = [
    '.home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-search',
    '.btn-light'
]
missing = [s for s in required if s not in css]
if missing:
    raise SystemExit("ERROR: required selectors not found: " + ", ".join(missing))

if marker in css:
    print("No changes needed; v24.47 already installed.")
    raise SystemExit(0)

css += r'''

/* launch-preview-search-border-white-v24-47
   Match the Launch preview search outline to the exact white used by .btn-light. */
.home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-search{
  border-color:#fff !important;
}
'''

css_path.write_text(css)
print("PASS: Launch preview search border now matches .btn-light white (#fff).")
