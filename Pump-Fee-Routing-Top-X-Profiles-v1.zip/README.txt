Pump Fee Routing — Top X Profiles v1
Scope: Home Top X Profiles section only.
Creates the large visual profile-card layout from real recipient/payout data.
No demo profiles are inserted; empty state preserves the intended geometry.
Runs npm check, commits, and pushes to origin/main. No automatic server restart.
