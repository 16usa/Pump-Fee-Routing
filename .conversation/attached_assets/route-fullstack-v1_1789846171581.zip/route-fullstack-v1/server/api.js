import { randomUUID, timingSafeEqual } from 'node:crypto';
import { config } from './config.js';
import { db, upsertToken, recordClaim } from './db.js';
import { homeData, listTokens, getToken, moneySummary, profile, listPayments } from './queries.js';
import { verifyAndRegisterMint, buildFeeRoutingTransaction, parseRecipient, fetchSolUsd } from './solana.js';
import { runDiscovery, runClaims, runPayouts } from './workers.js';
import { confirmPayout, optOutHandle } from './payouts.js';
import { sellSolUsd } from './kraken.js';
import { startXOAuth, finishXOAuth } from './xoauth.js';

function json(res,status,body){ const data=JSON.stringify(body); res.writeHead(status,{'content-type':'application/json; charset=utf-8','cache-control':'no-store'}); res.end(data); }
async function body(req){ const chunks=[]; let size=0; for await(const c of req){ size+=c.length; if(size>1_000_000)throw Object.assign(new Error('Body too large'),{statusCode:413}); chunks.push(c); } if(!chunks.length)return {}; const text=Buffer.concat(chunks).toString('utf8'); try{return JSON.parse(text);}catch{throw Object.assign(new Error('Invalid JSON'),{statusCode:400});} }
function secureEq(a,b){ const aa=Buffer.from(a||''),bb=Buffer.from(b||''); return aa.length===bb.length && aa.length>0 && timingSafeEqual(aa,bb); }
function requireAdmin(req){ const token=(req.headers.authorization||'').replace(/^Bearer\s+/i,'') || req.headers['x-admin-token']; if(!config.adminToken||!secureEq(token,config.adminToken))throw Object.assign(new Error('Unauthorized'),{statusCode:401}); }
function requireWebhook(req){ const token=req.headers['x-webhook-secret'] || (req.headers.authorization||'').replace(/^Bearer\s+/i,''); if(!config.webhookSecret||!secureEq(token,config.webhookSecret))throw Object.assign(new Error('Unauthorized'),{statusCode:401}); }

export async function handleApi(req,res,url){
  try{
    if(req.method==='GET'&&url.pathname==='/api/health') return json(res,200,{ok:true,name:config.appName,treasuryConfigured:!!config.treasuryAddress,liveChain:config.liveChainTransactions,onchainDiscovery:config.onchainDiscoveryEnabled,payoutProvider:config.payoutProvider,exchangeProvider:config.exchangeProvider});
    if(req.method==='GET'&&url.pathname==='/api/config') return json(res,200,{name:config.appName,mark:config.appMark,treasuryAddress:config.treasuryAddress,recipientShareBps:config.recipientShareBps,protocolShareBps:config.protocolShareBps,liveChain:config.liveChainTransactions,payoutProvider:config.payoutProvider});
    if(req.method==='GET'&&url.pathname==='/api/home') return json(res,200,homeData());
    if(req.method==='GET'&&url.pathname==='/api/tokens') return json(res,200,{tokens:listTokens({search:url.searchParams.get('search')||'',sort:url.searchParams.get('sort')||'sent',venue:url.searchParams.get('venue')||'',limit:url.searchParams.get('limit')||100})});
    if(req.method==='GET'&&url.pathname.startsWith('/api/tokens/')){ const row=getToken(decodeURIComponent(url.pathname.slice('/api/tokens/'.length))); return row?json(res,200,row):json(res,404,{error:'Not found'}); }
    if(req.method==='GET'&&url.pathname.startsWith('/api/profiles/')){ const row=profile(decodeURIComponent(url.pathname.slice('/api/profiles/'.length))); return row?json(res,200,row):json(res,404,{error:'Not found'}); }
    if(req.method==='GET'&&url.pathname==='/api/money') return json(res,200,moneySummary());
    if(req.method==='GET'&&url.pathname==='/api/payments') return json(res,200,{payments:listPayments(Number(url.searchParams.get('limit')||50))});
    if(req.method==='POST'&&url.pathname==='/api/tokens/register'){ const b=await body(req); const out=await verifyAndRegisterMint(b.mint,{fallbackHandle:b.recipient_handle||''}); return json(res,out.ok?200:422,out); }
    if(req.method==='POST'&&url.pathname==='/api/launch/intents'){ const b=await body(req); const handle=String(b.recipient_handle||'').replace(/^@/,'').trim(); if(!/^[A-Za-z0-9_]{1,15}$/.test(handle))throw Object.assign(new Error('Invalid X handle'),{statusCode:400}); const opted=db.prepare('SELECT opted_out FROM recipients WHERE handle=? COLLATE NOCASE').get(handle); if(opted?.opted_out)throw Object.assign(new Error('Recipient has opted out'),{statusCode:409}); const id=randomUUID(); const line=`Fees to @${handle} via ${config.appName}`; db.prepare(`INSERT INTO launch_intents(id,mint,recipient_handle,creator_pubkey,description_line,status) VALUES(?,?,?,?,?,'draft')`).run(id,b.mint||null,handle,b.creator_pubkey||null,line); return json(res,201,{id,descriptionLine:line,treasuryAddress:config.treasuryAddress,status:'draft'}); }
    if(req.method==='POST'&&url.pathname==='/api/launch/prepare-routing'){ const b=await body(req); if(!b.mint||!b.creator_pubkey)throw Object.assign(new Error('mint and creator_pubkey required'),{statusCode:400}); const tx=await buildFeeRoutingTransaction({mint:b.mint,creator:b.creator_pubkey}); return json(res,200,tx); }
    if(req.method==='POST'&&url.pathname==='/api/launch/confirm'){ const b=await body(req); if(!b.mint)throw Object.assign(new Error('mint required'),{statusCode:400}); const out=await verifyAndRegisterMint(b.mint,{fallbackHandle:b.recipient_handle||''}); if(out.ok && b.intent_id) db.prepare(`UPDATE launch_intents SET mint=?,status='registered',tx_signature=?,updated_at=CURRENT_TIMESTAMP WHERE id=?`).run(b.mint,b.tx_signature||null,b.intent_id); return json(res,out.ok?200:422,out); }
    if(req.method==='POST'&&url.pathname==='/api/webhooks/pump'){ requireWebhook(req); const b=await body(req); const key=b.id||b.signature||randomUUID(); try{db.prepare(`INSERT INTO webhook_events(id,source,event_key,payload_json) VALUES(?,?,?,?)`).run(randomUUID(),'pump',key,JSON.stringify(b));}catch{return json(res,200,{ok:true,duplicate:true});} const mints=[...(Array.isArray(b.mints)?b.mints:[]),...(b.mint?[b.mint]:[])]; const out=[]; for(const mint of [...new Set(mints)]){try{out.push(await verifyAndRegisterMint(mint,{fallbackHandle:b.recipient_handle||''}));}catch(e){out.push({ok:false,mint,error:e.message});}} return json(res,200,{ok:true,results:out}); }
    if(req.method==='POST'&&url.pathname==='/api/webhooks/payout'){ requireWebhook(req); const b=await body(req); return json(res,200,confirmPayout({id:b.id,status:b.status||'sent',provider_ref:b.provider_ref||b.reference,confirmation_url:b.public_confirmation_url})); }
    if(req.method==='GET'&&url.pathname==='/api/auth/x/start'){ const dest=startXOAuth(); res.writeHead(302,{location:dest}); return res.end(); }
    if(req.method==='GET'&&url.pathname==='/api/auth/x/callback'){ const user=await finishXOAuth({code:url.searchParams.get('code'),state:url.searchParams.get('state')}); if(!user?.username)throw new Error('X did not return a username'); const result=optOutHandle(user.username); res.writeHead(302,{location:`/#/opt-out?done=${encodeURIComponent(result.handle)}`}); return res.end(); }
    if(req.method==='POST'&&url.pathname==='/api/admin/opt-out'){ requireAdmin(req); const b=await body(req); return json(res,200,optOutHandle(b.handle)); }
    if(req.method==='POST'&&url.pathname==='/api/admin/claim-record'){ requireAdmin(req); const b=await body(req); const price=Number(b.native_usd_price||await fetchSolUsd()); return json(res,201,recordClaim({mint:b.mint,txSignature:b.tx_signature||null,grossNative:Number(b.gross_native),nativeUsdPrice:price,raw:{manual:true}})); }
    if(req.method==='POST'&&url.pathname==='/api/admin/payout-confirm'){ requireAdmin(req); const b=await body(req); return json(res,200,confirmPayout({id:b.id,status:b.status||'sent',provider_ref:b.provider_ref,confirmation_url:b.public_confirmation_url})); }
    if(req.method==='POST'&&url.pathname==='/api/admin/exchange/sell'){ requireAdmin(req); const b=await body(req); return json(res,200,await sellSolUsd({claimId:b.claim_id||null,volumeSol:Number(b.volume_sol)})); }
    if(req.method==='POST'&&url.pathname==='/api/admin/run/discovery'){ requireAdmin(req); return json(res,200,await runDiscovery()); }
    if(req.method==='POST'&&url.pathname==='/api/admin/run/claims'){ requireAdmin(req); return json(res,200,await runClaims()); }
    if(req.method==='POST'&&url.pathname==='/api/admin/run/payouts'){ requireAdmin(req); return json(res,200,await runPayouts()); }
    if(req.method==='GET'&&url.pathname==='/api/admin/status'){ requireAdmin(req); return json(res,200,{tokens:db.prepare('SELECT COUNT(*) n FROM tokens').get().n,claims:db.prepare('SELECT COUNT(*) n FROM claims').get().n,payouts:db.prepare('SELECT COUNT(*) n FROM payouts').get().n,buybacksPending:db.prepare(`SELECT COALESCE(SUM(amount_usd),0) v FROM buybacks WHERE status='pending'`).get().v,launchIntents:db.prepare('SELECT COUNT(*) n FROM launch_intents').get().n}); }
    return json(res,404,{error:'API route not found'});
  }catch(e){ console.error('[api]',e); return json(res,e.statusCode||500,{error:e.message||'Internal error'}); }
}
