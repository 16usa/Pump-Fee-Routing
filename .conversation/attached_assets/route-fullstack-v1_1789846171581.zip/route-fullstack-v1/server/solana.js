import { config } from './config.js';
import { upsertToken, recordClaim, db } from './db.js';

let sdkCache;
async function sdk() {
  if (sdkCache) return sdkCache;
  const pump = await import('@pump-fun/pump-sdk');
  const web3 = await import('@solana/web3.js');
  sdkCache={...pump,...web3}; return sdkCache;
}

function requireTreasury(){ if(!config.treasuryAddress) throw new Error('TREASURY_ADDRESS is not configured'); }
export function parseRecipient(description='', fallback='') {
  const exact = description.match(/Fees\s+to\s+@([A-Za-z0-9_]{1,15})\s+via\s+[A-Za-z0-9_\-]+/i);
  if (exact) return {handle:exact[1],source:'fees-line'};
  const first = description.match(/@([A-Za-z0-9_]{1,15})/);
  if (first) return {handle:first[1],source:'first-handle'};
  if (fallback) return {handle:String(fallback).replace(/^@/,''),source:'linked-social'};
  return null;
}
async function fetchMetadata(mint) {
  const url=config.pumpMetadataUrlTemplate.replace('{mint}',encodeURIComponent(mint));
  try { const r=await fetch(url,{headers:{accept:'application/json'}}); if(!r.ok) throw new Error(`metadata ${r.status}`); return await r.json(); } catch { return {}; }
}

export async function verifyAndRegisterMint(mint,{fallbackHandle=''}={}) {
  requireTreasury();
  const {Connection,PublicKey,OnlinePumpSdk,feeSharingConfigPda}=await sdk();
  const connection=new Connection(config.solanaRpcUrl,'confirmed');
  const online=new OnlinePumpSdk(connection);
  const pk=new PublicKey(mint);
  const sharing=await online.fetchSharingConfigNullable(pk);
  if(!sharing) return {ok:false,reason:'no-sharing-config'};
  const treasury=new PublicKey(config.treasuryAddress);
  const shareholders=(sharing.shareholders||[]).map(s=>({address:s.address.toBase58(),shareBps:Number(s.shareBps)}));
  const exact100=shareholders.length===1 && shareholders[0].address===treasury.toBase58() && shareholders[0].shareBps===10000;
  if(!exact100) return {ok:false,reason:'treasury-not-100-percent',shareholders};
  if(!sharing.adminRevoked) return {ok:false,reason:'sharing-config-not-permanent',shareholders};
  const meta=await fetchMetadata(mint);
  const description=meta.description||meta.metadata?.description||'';
  const recipient=parseRecipient(description, fallbackHandle || meta.twitter || meta.x || '');
  if(!recipient) return {ok:false,reason:'recipient-not-found'};
  const cfg=feeSharingConfigPda(pk).toBase58();
  upsertToken({
    mint,venue:'pump',name:meta.name||'Pump token',symbol:meta.symbol||'TOKEN',image_url:meta.image_uri||meta.image||meta.metadata?.image||'',
    description,recipient_handle:recipient.handle,recipient_source:recipient.source,market_cap_usd:Number(meta.usd_market_cap||meta.market_cap||0),
    fee_share_bps:10000,permanent:true,fee_config_address:cfg,created_at:meta.created_timestamp?new Date(meta.created_timestamp).toISOString():null,metadata:meta
  });
  return {ok:true,mint,recipient:recipient.handle,feeConfig:cfg};
}

export async function discoverOnChain({maxAccounts=5000}={}) {
  requireTreasury();
  const {Connection,PublicKey,PUMP_SDK,PUMP_FEE_PROGRAM_ID}=await sdk();
  const connection=new Connection(config.solanaRpcUrl,'confirmed');
  const programId=PUMP_FEE_PROGRAM_ID || new PublicKey('pfeeUxB6jkeY1Hxd7CsFCAjcbHA9rWtchMGdZ6VojVZ');
  const accounts=await connection.getProgramAccounts(programId,{commitment:'confirmed',filters:[{dataSize:1024}]});
  let checked=0,matched=0,registered=0,errors=0;
  for(const item of accounts.slice(0,maxAccounts)){
    checked++;
    try{
      const cfg=PUMP_SDK.decodeSharingConfig(item.account);
      const shareholders=(cfg.shareholders||[]).map(s=>({address:s.address.toBase58(),shareBps:Number(s.shareBps)}));
      if(cfg.adminRevoked && shareholders.length===1 && shareholders[0].address===config.treasuryAddress && shareholders[0].shareBps===10000){
        matched++;
        const res=await verifyAndRegisterMint(cfg.mint.toBase58()); if(res.ok) registered++;
      }
    }catch{ errors++; }
  }
  return {checked,matched,registered,decodeErrors:errors,totalAccounts:accounts.length};
}

function parseSecretKey(json){ const arr=JSON.parse(json); if(!Array.isArray(arr)||arr.length<32) throw new Error('CRANK_SECRET_KEY_JSON must be a JSON byte array'); return Uint8Array.from(arr); }
export async function claimMint(mint) {
  requireTreasury();
  const {Connection,PublicKey,Keypair,TransactionMessage,VersionedTransaction,OnlinePumpSdk}=await sdk();
  const connection=new Connection(config.solanaRpcUrl,'confirmed'); const online=new OnlinePumpSdk(connection); const mintPk=new PublicKey(mint);
  const min=await online.getMinimumDistributableFee(mintPk);
  const distributable=Number(min.distributableFees?.toString?.()||0);
  if(!min.canDistribute) return {ok:true,submitted:false,reason:'below-minimum',distributableLamports:distributable};
  const {instructions,isGraduated}=await online.buildDistributeCreatorFeesInstructions(mintPk);
  if(!config.liveChainTransactions) return {ok:true,submitted:false,dryRun:true,isGraduated,instructionCount:instructions.length,distributableLamports:distributable};
  if(!config.crankSecretKeyJson) throw new Error('CRANK_SECRET_KEY_JSON required when LIVE_CHAIN_TRANSACTIONS=true');
  const crank=Keypair.fromSecretKey(parseSecretKey(config.crankSecretKeyJson));
  const before=await connection.getBalance(new PublicKey(config.treasuryAddress),'confirmed');
  const latest=await connection.getLatestBlockhash('confirmed');
  const msg=new TransactionMessage({payerKey:crank.publicKey,recentBlockhash:latest.blockhash,instructions}).compileToV0Message();
  const tx=new VersionedTransaction(msg); tx.sign([crank]);
  const signature=await connection.sendTransaction(tx,{maxRetries:3,skipPreflight:false});
  await connection.confirmTransaction({signature,...latest},'confirmed');
  const parsed=await connection.getTransaction(signature,{commitment:'confirmed',maxSupportedTransactionVersion:0});
  let grossLamports=0;
  if(parsed?.transaction?.message?.staticAccountKeys){
    const idx=parsed.transaction.message.staticAccountKeys.findIndex(k=>k.toBase58()===config.treasuryAddress);
    if(idx>=0) grossLamports=(parsed.meta?.postBalances?.[idx]||0)-(parsed.meta?.preBalances?.[idx]||0);
  }
  if(grossLamports<=0){ const after=await connection.getBalance(new PublicKey(config.treasuryAddress),'confirmed'); grossLamports=Math.max(0,after-before); }
  const solPrice=await fetchSolUsd();
  const claim=recordClaim({mint,txSignature:signature,grossNative:grossLamports/1e9,nativeUsdPrice:solPrice,raw:{isGraduated,distributableLamports:distributable}});
  return {ok:true,submitted:true,signature,grossLamports,solPrice,claim};
}

export async function fetchSolUsd(){
  try{ const r=await fetch('https://api.kraken.com/0/public/Ticker?pair=SOLUSD'); const j=await r.json(); const row=Object.values(j.result||{})[0]; const p=Number(row?.c?.[0]); if(p>0)return p; }catch{}
  const v=Number(db.prepare(`SELECT value FROM indexer_state WHERE key='last_sol_usd'`).get()?.value||0); if(v>0)return v;
  throw new Error('Unable to fetch SOL/USD price');
}

export async function buildFeeRoutingTransaction({mint,creator}) {
  requireTreasury();
  const {Connection,PublicKey,TransactionMessage,VersionedTransaction,PUMP_SDK,OnlinePumpSdk,canonicalPumpPoolPda}=await sdk();
  const connection=new Connection(config.solanaRpcUrl,'confirmed'); const online=new OnlinePumpSdk(connection);
  const mintPk=new PublicKey(mint), creatorPk=new PublicKey(creator), treasury=new PublicKey(config.treasuryAddress);
  const existing=await online.fetchSharingConfigNullable(mintPk);
  if(existing?.adminRevoked) throw new Error('Sharing config is already permanent');
  const curve=await online.fetchBondingCurve(mintPk);
  const pool=curve.complete ? canonicalPumpPoolPda(mintPk) : null;
  const ixs=[];
  if(!existing) ixs.push(await PUMP_SDK.createFeeSharingConfig({creator:creatorPk,mint:mintPk,pool}));
  const current=(existing?.shareholders||[]).map(s=>s.address);
  const update = PUMP_SDK.updateFeeSharesV2
    ? await PUMP_SDK.updateFeeSharesV2({authority:creatorPk,mint:mintPk,currentShareholders:current.length?current:[creatorPk],newShareholders:[{address:treasury,shareBps:10000}],quoteMint:(await import('@solana/spl-token')).NATIVE_MINT,quoteTokenProgram:(await import('@solana/spl-token')).TOKEN_PROGRAM_ID})
    : await PUMP_SDK.updateFeeShares({authority:creatorPk,mint:mintPk,currentShareholders:current,newShareholders:[{address:treasury,shareBps:10000}]});
  ixs.push(update);
  if(!PUMP_SDK.updateFeeSharesV2 && PUMP_SDK.revokeFeeSharingAuthorityInstruction) ixs.push(await PUMP_SDK.revokeFeeSharingAuthorityInstruction({authority:creatorPk,mint:mintPk}));
  const latest=await connection.getLatestBlockhash('confirmed');
  const msg=new TransactionMessage({payerKey:creatorPk,recentBlockhash:latest.blockhash,instructions:ixs}).compileToV0Message();
  const tx=new VersionedTransaction(msg);
  return {transactionBase64:Buffer.from(tx.serialize()).toString('base64'),blockhash:latest.blockhash,lastValidBlockHeight:latest.lastValidBlockHeight,instructionCount:ixs.length};
}
