Pump-Fee-Routing — Home Reference Match v1

Matches the supplied UsePaid homepage reference while preserving PROJECT data and colors.

Changes:
- Left-aligns the mobile hero like the reference.
- Removes the extra large hero token card and ticker marquee from Home.
- Rebuilds the five preview cards: Explore, Payments, Analytics, Launch, How it works.
- Keeps Top Tokens, Top X Profiles, Recent payments, Most Payments, Off-ramp and On-ramp.
- Does not modify launch, wallet, routing, payout, claims or indexer logic.
- Validates JS and runs npm run check.
- Restores both files automatically if validation fails.
- Commits and pushes to main.
- Does not restart the server.
