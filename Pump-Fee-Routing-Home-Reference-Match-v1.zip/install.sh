#!/usr/bin/env bash
set -euo pipefail

[ -f src/app.js ] || { echo "Missing src/app.js"; exit 1; }
[ -f src/styles.css ] || { echo "Missing src/styles.css"; exit 1; }

cp src/app.js /tmp/Pump-Fee-Routing-app-before-home-reference-v1.js
cp src/styles.css /tmp/Pump-Fee-Routing-styles-before-home-reference-v1.css

restore() {
  cp /tmp/Pump-Fee-Routing-app-before-home-reference-v1.js src/app.js
  cp /tmp/Pump-Fee-Routing-styles-before-home-reference-v1.css src/styles.css
}

python3 - <<'PY'
from pathlib import Path

app=Path("src/app.js")
s=app.read_text()
marker="home-reference-match-v1"

preview_start=s.find("function homePreviewDeck(h,top){")
preview_end=s.find("\nfunction homeTopTokenCard", preview_start)
if preview_start < 0 or preview_end < 0:
    raise SystemExit("Could not locate homePreviewDeck() boundaries.")

preview='function homePreviewDeck(h,top){\n  const tokens=(top||[]).slice(0,3);\n  const t=tokens[0]||null;\n  const t2=tokens[1]||null;\n  const payments=(h.payments||[]).slice(0,2);\n  const money=h.money||{};\n  const profile=(h.profiles||[])[0]||null;\n  const total=Number(money.totalPaid||0);\n  const handle=t?.profile||t?.recipient_handle||profile?.handle||\'\';\n  const display=profile?.display_name||handle||\'Recipient\';\n\n  const tokenVisual=(x,cls=\'\')=>x?.image_url\n    ? `<img class="${cls}" src="${esc(x.image_url)}" alt="">`\n    : `<div class="home-ref-token-fallback ${cls}">${esc(initials(x?.symbol||x?.name||\'P\'))}</div>`;\n\n  const paymentRows=payments.length\n    ? payments.map((p,i)=>{\n        const amount=p.amount_usd??p.amount??0;\n        const to=p.display_name||p.recipient_handle||p.to||\'recipient\';\n        return `<div class="home-ref-pay-row">\n          <span class="home-ref-pay-coin">$</span>\n          <div><strong>${fmtMoney(amount)}</strong><small>sent to <b>${esc(to)}</b></small></div>\n          <time>${esc(ago(p.sent_at||p.created_at))}</time>\n        </div>`;\n      }).join(\'\')\n    : `<div class="home-ref-empty-route"><i></i><b>$</b><i></i><span>No payouts recorded yet.</span></div>`;\n\n  return `<section class="home-preview-shell home-ref-previews">\n    <div class="wrap home-preview-stack">\n\n      <a class="home-preview-card home-preview-token-card home-ref-card" href="#/explore">\n        <div class="home-preview-label"><b>Explore</b><span>Open →</span></div>\n        <div class="home-ref-explore-stage">\n          <div class="home-ref-explore-primary">\n            ${tokenVisual(t,\'home-ref-main-art\')}\n            <div class="home-ref-floating-badge">${platformBadge(t?.platform||\'Pump\')}</div>\n            <div class="home-ref-floating-profile">${handle?`@${esc(handle)}`:\'Recipient\'}</div>\n          </div>\n          <div class="home-ref-explore-secondary">\n            ${tokenVisual(t2,\'home-ref-side-art\')}\n            <small>${t2?esc(t2.symbol||\'\'):\'Route\'}</small>\n            <b>${t2?fmtMoney(t2.sent||0):\'100%\'}</b>\n          </div>\n        </div>\n        <div class="home-ref-explore-foot">\n          <div><small>${handle?`@${esc(handle)}`:\'Token routing\'}</small><strong>${t?esc(t.name):\'No routed token yet\'}</strong><span>${t?`${esc(t.symbol||\'\')} · ${fmtMc(t.mc??t.market_cap_usd)} MC`:\'Verified tokens appear here\'}</span></div>\n          <b>${t?fmtMoney(t.sent||0):\'$0.00\'}</b>\n        </div>\n      </a>\n\n      <a class="home-preview-card home-preview-payment-card home-ref-card" href="#/money">\n        <div class="home-preview-label"><b>Payments</b><span>Open →</span></div>\n        <div class="home-ref-payment-stage">${paymentRows}</div>\n        <div class="home-ref-card-bottom"><span>Confirmed payouts</span><b>${payments.length?fmtMoney(payments.reduce((s,p)=>s+Number(p.amount_usd??p.amount??0),0)):\'$0.00\'}</b></div>\n      </a>\n\n      <a class="home-preview-card home-preview-analytics-card home-ref-card" href="#/money">\n        <div class="home-preview-label"><b>Analytics</b><span>Open →</span></div>\n        <div class="home-ref-analytics-tabs"><b>Fees</b><span>1D</span><span>30D</span><span>All time</span></div>\n        <strong class="home-ref-analytics-total">${fmtMoney(total)}</strong>\n        <div class="home-ref-chart">${Array.from({length:28},(_,i)=>`<i style="height:${14+((i*31)%72)}%"></i>`).join(\'\')}</div>\n        <div class="home-ref-card-bottom"><span>Confirmed ledger activity</span><b>Live</b></div>\n      </a>\n\n      <a class="home-preview-card home-preview-launch-card home-ref-card" href="#/launch">\n        <div class="home-preview-label"><b>Launch</b><span>Open →</span></div>\n        <div class="home-ref-launch-label">Recipient X handle</div>\n        <div class="home-ref-launch-input">@${profile?esc(profile.handle):\'recipient\'}</div>\n        <div class="home-ref-launch-pay">\n          <div>${avatar(display,true,profile?.avatar_url||\'\')}</div>\n          <span><small>Paying out</small><b>${esc(display)}</b>${profile?.handle?`<em>@${esc(profile.handle)}</em>`:\'\'}</span>\n          <strong>${fmtMoney(payments[0]?.amount_usd??payments[0]?.amount??0)}</strong>\n        </div>\n        <div class="home-ref-launch-meta">\n          <span>Creator fees</span><b>100%</b>\n          <span>Treasury route</span><b>Permanent</b>\n        </div>\n      </a>\n\n      <a class="home-preview-card home-preview-doc-card home-ref-card" href="#/docs">\n        <div class="home-preview-label"><b>How it works</b><span>Read →</span></div>\n        <div class="home-ref-doc-head"><small>Sharing config</small><strong>Attribution is per-mint</strong></div>\n        <p class="home-ref-doc-copy">One config account per token mint. The treasury is stored in its shareholders array so every token keeps clean attribution.</p>\n        <div class="home-ref-doc-grid">\n          <span><small>Detection</small><b>On-chain</b></span>\n          <span><small>Claiming</small><b>Creator fees</b></span>\n          <span><small>Route</small><b>100%</b></span>\n          <span><small>Recipient</small><b>X handle</b></span>\n        </div>\n      </a>\n\n    </div>\n  </section>`;\n}'
s=s[:preview_start]+preview+s[preview_end:]

home_start=s.find("function homePage(){")
home_end=s.find("\nfunction exploreTrendingCard", home_start)
if home_start < 0 or home_end < 0:
    raise SystemExit("Could not locate homePage() boundaries.")

home='function homePage(){\n  const h=state.home||{tokens:[],profiles:[],payments:[],money:{}};\n  const top=h.tokens||[];\n  return `<main class="home-page home-reference-v1">\n    <section class="hero wrap home-hero">\n      <div class="hero-copy">\n        <h1>Route token fees<br>through X Money</h1>\n        <p>Point a token\'s creator fees at any X handle and we pay them out in dollars through X Money. Launch on Pump and Pons.</p>\n        <div class="hero-buttons">\n          <button class="btn-light" data-action="open-launch">Launch a token</button>\n          <a class="text-link" href="#/docs">Read the docs <span>→</span></a>\n        </div>\n      </div>\n    </section>\n\n    ${homePreviewDeck(h,top)}\n    ${homeTopTokens(top)}\n    ${homeTopProfiles(h.profiles||[])}\n    ${homeRecentPayments(h)}\n    ${homeMostPayments(h)}\n    ${homeOffRamp(h)}\n    ${homeOnRamp(h)}\n    ${footer()}\n  </main>`;\n}'
s=s[:home_start]+home+s[home_end:]
app.write_text(s)

styles=Path("src/styles.css")
css=styles.read_text()
patch='\n/* home-reference-match-v1\n   Match the supplied UsePaid home-page composition while keeping PROJECT data/colors.\n   UI only: launch, wallet, routing, payout, claims and indexer logic are untouched. */\n.home-reference-v1{\n  --home-ref-card:#171717;\n  --home-ref-border:#2a2a2a;\n  --home-ref-muted:#767676;\n}\n.home-reference-v1 .home-hero{\n  display:block;\n  width:min(100% - 32px,1080px);\n  padding:72px 0 34px;\n  text-align:left;\n}\n.home-reference-v1 .home-hero .hero-copy{\n  width:min(100%,680px);\n  max-width:none;\n  margin:0;\n}\n.home-reference-v1 .home-hero .hero-copy h1{\n  margin:0;\n  font-size:clamp(48px,6.6vw,82px);\n  line-height:.91;\n  letter-spacing:-.065em;\n  text-align:left;\n  font-weight:650;\n}\n.home-reference-v1 .home-hero .hero-copy>p{\n  max-width:650px;\n  margin:24px 0 26px;\n  color:#858585;\n  font-size:15px;\n  line-height:1.55;\n  text-align:left;\n}\n.home-reference-v1 .home-hero .hero-buttons{\n  justify-content:flex-start;\n  margin:0;\n  gap:16px;\n}\n.home-reference-v1 .home-preview-shell{padding:18px 0 38px}\n.home-reference-v1 .home-preview-stack{\n  width:min(100% - 32px,1080px);\n  display:grid;\n  grid-template-columns:repeat(2,minmax(0,1fr));\n  gap:14px;\n}\n.home-reference-v1 .home-preview-card.home-ref-card{\n  min-height:320px;\n  padding:18px;\n  color:#fff;\n  background:var(--home-ref-card);\n  border:1px solid var(--home-ref-border);\n  border-radius:20px;\n  text-decoration:none;\n  overflow:hidden;\n  box-shadow:none;\n}\n.home-reference-v1 .home-preview-label{\n  margin-bottom:16px;\n  font-size:13px;\n}\n.home-reference-v1 .home-preview-label b{font-weight:650}\n.home-reference-v1 .home-preview-label span{color:#747474;font-size:11px}\n.home-ref-explore-stage{\n  min-height:190px;\n  display:grid;\n  grid-template-columns:minmax(0,1.65fr) minmax(92px,.75fr);\n  gap:10px;\n}\n.home-ref-explore-primary,.home-ref-explore-secondary{\n  position:relative;\n  min-width:0;\n  overflow:hidden;\n  border:1px solid #292929;\n  border-radius:14px;\n  background:#080808;\n}\n.home-ref-main-art,.home-ref-side-art,.home-ref-token-fallback{\n  width:100%;height:100%;object-fit:cover;\n}\n.home-ref-token-fallback{\n  display:grid;place-items:center;\n  background:radial-gradient(circle at 50% 45%,#343434 0,#151515 48%,#090909 78%);\n  color:#777;font-size:36px;font-weight:800;\n}\n.home-ref-floating-badge{position:absolute;left:9px;bottom:9px}\n.home-ref-floating-profile{\n  position:absolute;right:9px;bottom:9px;max-width:55%;\n  padding:6px 9px;border:1px solid #333;border-radius:999px;\n  background:rgba(0,0,0,.78);color:#ddd;\n  overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:9px;\n}\n.home-ref-explore-secondary{\n  display:grid;grid-template-rows:1fr auto auto;align-items:end;\n}\n.home-ref-explore-secondary .home-ref-side-art{min-height:0}\n.home-ref-explore-secondary small{padding:7px 9px 1px;color:#717171;font-size:8px}\n.home-ref-explore-secondary>b{padding:0 9px 9px;font-size:17px}\n.home-ref-explore-foot{\n  display:flex;align-items:flex-end;justify-content:space-between;gap:14px;padding-top:13px;\n}\n.home-ref-explore-foot>div{display:grid;min-width:0}\n.home-ref-explore-foot small,.home-ref-explore-foot span{color:#707070;font-size:9px}\n.home-ref-explore-foot strong{\n  margin:2px 0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:16px;\n}\n.home-ref-explore-foot>b{font-size:22px;letter-spacing:-.04em}\n\n.home-ref-payment-stage{flex:1;display:grid;align-content:center;gap:10px}\n.home-ref-pay-row{\n  display:grid;grid-template-columns:42px minmax(0,1fr) auto;align-items:center;gap:10px;\n  padding:11px 12px;border:1px solid #2d2d2d;border-radius:13px;background:#101010;\n}\n.home-ref-pay-coin{\n  width:40px;height:40px;display:grid;place-items:center;border:1px solid #333;\n  border-radius:50%;background:#050505;font-size:18px;font-weight:800;\n}\n.home-ref-pay-row>div{display:grid;min-width:0}\n.home-ref-pay-row strong{font-size:18px;letter-spacing:-.03em}\n.home-ref-pay-row small{color:#787878;font-size:9px}\n.home-ref-pay-row small b{color:#bbb}\n.home-ref-pay-row time{color:#666;font-size:8px}\n.home-ref-empty-route{margin:auto;display:flex;align-items:center;justify-content:center;gap:8px;color:#666}\n.home-ref-empty-route i{width:36px;height:36px;border-radius:50%;border:1px solid #2a2a2a;background:#101010}\n.home-ref-empty-route>b{font-size:19px;color:#696969}\n.home-ref-empty-route>span{margin-left:8px;font-size:9px}\n.home-ref-card-bottom{\n  display:flex;align-items:center;justify-content:space-between;gap:12px;\n  padding-top:13px;margin-top:13px;border-top:1px solid #292929;color:#777;font-size:9px;\n}\n.home-ref-card-bottom b{color:#d6d6d6;font-weight:600}\n\n.home-ref-analytics-tabs{display:flex;align-items:center;gap:12px;color:#777;font-size:9px}\n.home-ref-analytics-tabs b{color:#e6e6e6;font-size:10px}\n.home-ref-analytics-total{display:block;margin:16px 0 12px;font-size:40px;line-height:1;letter-spacing:-.055em}\n.home-ref-chart{height:112px;display:flex;align-items:flex-end;gap:4px;margin-top:auto}\n.home-ref-chart i{min-width:2px;flex:1;display:block;background:#353535;border-radius:2px 2px 0 0}\n\n.home-ref-launch-label{color:#727272;font-size:9px}\n.home-ref-launch-input{\n  margin:8px 0 14px;padding:11px 14px;border:1px solid #3a3a3a;border-radius:999px;\n  background:#080808;color:#d7d7d7;font-size:11px;\n}\n.home-ref-launch-pay{\n  display:grid;grid-template-columns:42px 1fr auto;align-items:center;gap:10px;\n  padding:12px;border:1px solid #2b2b2b;border-radius:14px;background:#101010;\n}\n.home-ref-launch-pay .avatar{width:40px;height:40px}\n.home-ref-launch-pay>span{display:grid;min-width:0}\n.home-ref-launch-pay small,.home-ref-launch-pay em{color:#707070;font-size:8px;font-style:normal}\n.home-ref-launch-pay b{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:11px}\n.home-ref-launch-pay>strong{font-size:17px}\n.home-ref-launch-meta{\n  margin-top:auto;display:grid;grid-template-columns:1fr auto;gap:7px 12px;padding-top:15px;\n}\n.home-ref-launch-meta span{color:#717171;font-size:9px}\n.home-ref-launch-meta b{font-size:9px;font-weight:650}\n\n.home-ref-doc-head{display:grid;margin-top:2px}\n.home-ref-doc-head small{color:#707070;font-size:9px}\n.home-ref-doc-head strong{margin-top:3px;font-size:17px}\n.home-ref-doc-copy{margin:13px 0 16px;color:#777;font-size:10px;line-height:1.55}\n.home-ref-doc-grid{margin-top:auto;display:grid;grid-template-columns:1fr 1fr;gap:8px}\n.home-ref-doc-grid>span{\n  min-width:0;display:grid;gap:3px;padding:10px;border:1px solid #292929;border-radius:11px;background:#101010;\n}\n.home-ref-doc-grid small{color:#666;font-size:7px}\n.home-ref-doc-grid b{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:9px;font-weight:600}\n\n.home-reference-v1 .home-top-tokens,\n.home-reference-v1 .home-top-profiles,\n.home-reference-v1 .home-recent-payments,\n.home-reference-v1 .home-most-payments,\n.home-reference-v1 .home-off-ramp,\n.home-reference-v1 .home-on-ramp{width:min(100% - 32px,1080px)}\n\n@media(max-width:640px){\n  .home-reference-v1 .home-hero{\n    width:calc(100% - 32px);padding:44px 0 24px;text-align:left;\n  }\n  .home-reference-v1 .home-hero .hero-copy{width:100%;margin:0}\n  .home-reference-v1 .home-hero .hero-copy h1{\n    font-size:42px;line-height:.92;text-align:left;\n  }\n  .home-reference-v1 .home-hero .hero-copy>p{\n    max-width:none;margin:17px 0 21px;font-size:11px;line-height:1.58;text-align:left;\n  }\n  .home-reference-v1 .home-hero .hero-buttons{justify-content:flex-start;gap:17px}\n  .home-reference-v1 .home-hero .btn-light{padding:10px 16px;font-size:10px}\n  .home-reference-v1 .home-hero .text-link{font-size:9px}\n  .home-reference-v1 .home-preview-shell{padding:20px 0 28px}\n  .home-reference-v1 .home-preview-stack{\n    width:calc(100% - 32px);grid-template-columns:1fr;gap:10px;\n  }\n  .home-reference-v1 .home-preview-card.home-ref-card{\n    min-height:0;padding:12px;border-radius:14px;\n  }\n  .home-reference-v1 .home-preview-label{margin-bottom:11px;font-size:9px}\n  .home-reference-v1 .home-preview-label span{font-size:8px}\n  .home-ref-explore-stage{\n    min-height:195px;grid-template-columns:minmax(0,1.7fr) minmax(76px,.65fr);gap:7px;\n  }\n  .home-ref-explore-primary,.home-ref-explore-secondary{border-radius:10px}\n  .home-ref-floating-badge{left:6px;bottom:6px}\n  .home-ref-floating-profile{right:6px;bottom:6px;padding:4px 7px;font-size:7px}\n  .home-ref-explore-secondary small{padding:5px 6px 1px;font-size:6px}\n  .home-ref-explore-secondary>b{padding:0 6px 6px;font-size:13px}\n  .home-ref-explore-foot{padding-top:9px}\n  .home-ref-explore-foot small,.home-ref-explore-foot span{font-size:7px}\n  .home-ref-explore-foot strong{font-size:12px}\n  .home-ref-explore-foot>b{font-size:16px}\n\n  .home-ref-payment-stage{gap:7px}\n  .home-ref-pay-row{\n    grid-template-columns:32px minmax(0,1fr) auto;padding:8px 9px;gap:8px;border-radius:10px;\n  }\n  .home-ref-pay-coin{width:30px;height:30px;font-size:13px}\n  .home-ref-pay-row strong{font-size:14px}\n  .home-ref-pay-row small{font-size:7px}\n  .home-ref-pay-row time{font-size:6.5px}\n  .home-ref-card-bottom{padding-top:9px;margin-top:9px;font-size:7px}\n\n  .home-ref-analytics-tabs{gap:9px;font-size:7px}\n  .home-ref-analytics-tabs b{font-size:8px}\n  .home-ref-analytics-total{margin:11px 0 8px;font-size:31px}\n  .home-ref-chart{height:72px;gap:2px}\n\n  .home-ref-launch-label{font-size:7px}\n  .home-ref-launch-input{margin:6px 0 9px;padding:8px 10px;font-size:8px}\n  .home-ref-launch-pay{\n    grid-template-columns:32px 1fr auto;gap:7px;padding:8px;border-radius:10px;\n  }\n  .home-ref-launch-pay .avatar{width:30px;height:30px}\n  .home-ref-launch-pay small,.home-ref-launch-pay em{font-size:6px}\n  .home-ref-launch-pay b{font-size:8px}\n  .home-ref-launch-pay>strong{font-size:13px}\n  .home-ref-launch-meta{padding-top:10px;gap:5px 9px}\n  .home-ref-launch-meta span,.home-ref-launch-meta b{font-size:7px}\n\n  .home-ref-doc-head small{font-size:7px}\n  .home-ref-doc-head strong{font-size:13px}\n  .home-ref-doc-copy{margin:9px 0 11px;font-size:7px}\n  .home-ref-doc-grid{gap:6px}\n  .home-ref-doc-grid>span{padding:7px;border-radius:8px}\n  .home-ref-doc-grid small{font-size:6px}\n  .home-ref-doc-grid b{font-size:7px}\n}\n'
if marker not in css:
    css += "\n\n"+patch+"\n"
styles.write_text(css)

print("Home Reference Match v1 installed.")
PY

if ! node --check src/app.js; then
  restore
  echo "JS syntax check failed; files restored."
  exit 2
fi

if ! npm run check; then
  restore
  echo "Project check failed; files restored."
  exit 3
fi

node <<'NODE'
const fs=require('fs');
const app=fs.readFileSync('src/app.js','utf8');
const css=fs.readFileSync('src/styles.css','utf8');
const a=app.indexOf('function homePage(){');
const b=app.indexOf('function exploreTrendingCard',a);
const home=app.slice(a,b);
const checks=[
  ['home reference class',app.includes('home-page home-reference-v1')],
  ['hero card removed from home composition',!home.includes('homeHeroCard(h,top)')],
  ['marquee removed from home composition',!home.includes('home-marquee')],
  ['reference preview deck',app.includes('home-ref-explore-stage')],
  ['reference payments preview',app.includes('home-ref-payment-stage')],
  ['reference analytics preview',app.includes('home-ref-analytics-total')],
  ['reference launch preview',app.includes('home-ref-launch-pay')],
  ['reference docs preview',app.includes('home-ref-doc-grid')],
  ['reference css marker',css.includes('home-reference-match-v1')]
];
let bad=0;
for(const [name,ok] of checks){
  console.log((ok?'PASS':'FAIL')+' '+name);
  if(!ok)bad++;
}
if(bad)process.exit(1);
NODE

git add src/app.js src/styles.css
if git diff --cached --quiet; then
  echo "No new changes to commit."
else
  git commit -m "Match home page to reference layout"
  git push origin main
fi

echo
echo "DONE: Home Reference Match v1 installed, checked, committed, and pushed."
echo "Only Home UI/markup/styles were changed."
echo "Launch, wallet, routing, payout, claims, and indexer logic were not changed."
echo "No server restart was performed."
echo "Restart Console/Run manually once."
