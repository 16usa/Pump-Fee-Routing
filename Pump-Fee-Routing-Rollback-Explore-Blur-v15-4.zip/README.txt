Pump Fee Routing — Rollback Explore Blur / Vignette v15.4

This rollback removes ONLY the last v15.4 blur/vignette CSS block that broke the Explore card layout.

It keeps the previous fixes:
- image inset
- age badge
- recipient avatar
- token name/ticker
- MC / Sent layout
- previous card structure

Install in existing Replit Shell:

rm -rf /tmp/explore-vignette-rollback-v15-4
mkdir -p /tmp/explore-vignette-rollback-v15-4
unzip -o Pump-Fee-Routing-Rollback-Explore-Blur-v15-4.zip -d /tmp/explore-vignette-rollback-v15-4
bash /tmp/explore-vignette-rollback-v15-4/install.sh

No automatic server restart is performed.
