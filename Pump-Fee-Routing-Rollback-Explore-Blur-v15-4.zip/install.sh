#!/usr/bin/env bash
set -euo pipefail

echo "== Rollback Explore Blur / Vignette v15.4 =="

if [ ! -f "src/styles.css" ]; then
  echo "ERROR: src/styles.css not found. Run this from the existing Replit project workspace."
  exit 1
fi

python3 <<'PYCODE'
from pathlib import Path

p = Path("src/styles.css")
s = p.read_text()
start_marker = "/* explore-vignette-match-v15-4 */"
end_marker = "/* end explore-vignette-match-v15-4 */"

start = s.find(start_marker)
if start == -1:
    print("PASS v15.4 block is already absent — nothing to remove")
else:
    end = s.find(end_marker, start)
    if end == -1:
        raise SystemExit("ERROR: v15.4 start marker found but end marker is missing. Nothing changed.")
    end += len(end_marker)
    # remove surrounding blank lines cleanly
    left = s[:start].rstrip()
    right = s[end:].lstrip()
    s = left + "\n\n" + right if right else left + "\n"
    p.write_text(s)
    print("PASS removed Explore Blur / Vignette v15.4 block")

check = p.read_text()
if start_marker in check or end_marker in check:
    raise SystemExit("ERROR: rollback verification failed")
print("PASS rollback verification")
PYCODE

echo
echo "== Project checks =="
npm run check

echo
echo "== Git diff =="
git diff --stat

git add src/styles.css

if git diff --cached --quiet; then
  echo "No new changes to commit — v15.4 may already be rolled back."
else
  git commit -m "Rollback Explore blur vignette v15.4"
  git push
fi

echo
echo "DONE: v15.4 blur/vignette change rolled back."
echo "Earlier Explore fixes remain in place."
echo "No server restart was performed."
echo "Restart Run/Console manually once, then reload the page."
