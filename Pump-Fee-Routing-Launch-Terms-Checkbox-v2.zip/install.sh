#!/usr/bin/env bash
set -euo pipefail

[ -f src/styles.css ] || { echo "Missing src/styles.css. Run from the Pump-Fee-Routing project root."; exit 1; }

if [ -n "$(git status --porcelain -- src/styles.css)" ]; then
  echo "STOP: src/styles.css has uncommitted changes."
  git status --short -- src/styles.css
  exit 2
fi

staged_unrelated="$(git diff --cached --name-only | grep -vE '^src/styles\.css$' || true)"
if [ -n "$staged_unrelated" ]; then
  echo "STOP: unrelated staged files are present:"
  echo "$staged_unrelated"
  exit 3
fi

python3 - <<'PY'

from pathlib import Path
import base64

p=Path('src/styles.css')
css=p.read_text()

marker='/* launch-terms-checkbox-v2'
if marker in css:
    raise SystemExit('Launch Terms Checkbox v2 is already installed.')

css += base64.b64decode('Ci8qIGxhdW5jaC10ZXJtcy1jaGVja2JveC12MiDigJQgZm9yY2UgYSB0cnVlIGNvbXBhY3Qgc3F1YXJlICovCi5sYXVuY2gtdGVybXN7CiAgZ3JpZC10ZW1wbGF0ZS1jb2x1bW5zOjE2cHggMWZyIWltcG9ydGFudDsKICBjb2x1bW4tZ2FwOjhweCFpbXBvcnRhbnQ7CiAgYWxpZ24taXRlbXM6c3RhcnQhaW1wb3J0YW50Owp9Ci5sYXVuY2gtdGVybXMgaW5wdXRbdHlwZT0iY2hlY2tib3giXXsKICAtd2Via2l0LWFwcGVhcmFuY2U6bm9uZSFpbXBvcnRhbnQ7CiAgYXBwZWFyYW5jZTpub25lIWltcG9ydGFudDsKICBib3gtc2l6aW5nOmJvcmRlci1ib3ghaW1wb3J0YW50OwogIGlubGluZS1zaXplOjE2cHghaW1wb3J0YW50OwogIGJsb2NrLXNpemU6MTZweCFpbXBvcnRhbnQ7CiAgd2lkdGg6MTZweCFpbXBvcnRhbnQ7CiAgaGVpZ2h0OjE2cHghaW1wb3J0YW50OwogIG1pbi13aWR0aDoxNnB4IWltcG9ydGFudDsKICBtYXgtd2lkdGg6MTZweCFpbXBvcnRhbnQ7CiAgbWluLWhlaWdodDoxNnB4IWltcG9ydGFudDsKICBtYXgtaGVpZ2h0OjE2cHghaW1wb3J0YW50OwogIGFzcGVjdC1yYXRpbzoxLzEhaW1wb3J0YW50OwogIHBhZGRpbmc6MCFpbXBvcnRhbnQ7CiAgbWFyZ2luOjFweCAwIDAgMCFpbXBvcnRhbnQ7CiAgYm9yZGVyOjFweCBzb2xpZCAjZjJmMmYyIWltcG9ydGFudDsKICBib3JkZXItcmFkaXVzOjRweCFpbXBvcnRhbnQ7CiAgYmFja2dyb3VuZDojZjdmN2Y3IWltcG9ydGFudDsKICBkaXNwbGF5OmdyaWQhaW1wb3J0YW50OwogIHBsYWNlLWl0ZW1zOmNlbnRlciFpbXBvcnRhbnQ7CiAgYm94LXNoYWRvdzpub25lIWltcG9ydGFudDsKICBvdXRsaW5lOm5vbmUhaW1wb3J0YW50Owp9Ci5sYXVuY2gtdGVybXMgaW5wdXRbdHlwZT0iY2hlY2tib3giXTo6YWZ0ZXJ7CiAgY29udGVudDoiIjsKICBib3gtc2l6aW5nOmJvcmRlci1ib3g7CiAgd2lkdGg6NHB4OwogIGhlaWdodDo4cHg7CiAgYm9yZGVyOnNvbGlkICMxMTE7CiAgYm9yZGVyLXdpZHRoOjAgMS43cHggMS43cHggMDsKICB0cmFuc2Zvcm06dHJhbnNsYXRlWSgtMXB4KSByb3RhdGUoNDVkZWcpIHNjYWxlKDApOwogIHRyYW5zZm9ybS1vcmlnaW46Y2VudGVyOwp9Ci5sYXVuY2gtdGVybXMgaW5wdXRbdHlwZT0iY2hlY2tib3giXTpjaGVja2VkOjphZnRlcnsKICB0cmFuc2Zvcm06dHJhbnNsYXRlWSgtMXB4KSByb3RhdGUoNDVkZWcpIHNjYWxlKDEpOwp9Cg==').decode()
p.write_text(css)
print('Launch Terms Checkbox v2 installed.')

PY

npm run check

node <<'NODE'
const fs=require('fs');
const css=fs.readFileSync('src/styles.css','utf8');
const checks=[
  ['v2 marker', css.includes('launch-terms-checkbox-v2')],
  ['forced square width', css.includes('width:16px!important')],
  ['forced square height', css.includes('height:16px!important')],
  ['no inherited padding', css.includes('padding:0!important')],
  ['square aspect ratio', css.includes('aspect-ratio:1/1!important')],
  ['compact radius', css.includes('border-radius:4px!important')],
  ['tighter terms grid', css.includes('grid-template-columns:16px 1fr!important')],
  ['thin check mark', css.includes('border-width:0 1.7px 1.7px 0')],
];
let bad=0;
for(const [name,ok] of checks){
  console.log(`${ok?'PASS':'FAIL'} ${name}`);
  if(!ok) bad++;
}
if(bad) process.exit(1);
NODE

git add src/styles.css

if git diff --cached --quiet; then
  echo "No staged changes; nothing to commit."
else
  git commit -m "Refine Launch terms checkbox"
fi

git push origin main

echo
echo "DONE: Launch Terms Checkbox v2 checked, committed, and pushed to GitHub."
echo "Old ZIP files and .conversation entries were intentionally ignored."
echo "No server restart was performed."
echo "Restart Console/Run manually once to load the refined checkbox."
