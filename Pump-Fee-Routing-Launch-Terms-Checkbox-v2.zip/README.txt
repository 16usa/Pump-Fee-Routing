Pump Fee Routing — Launch Terms Checkbox v2

Refines the Terms checkbox to a true compact square.
- Forces 16x16 sizing on iPhone/Safari
- Removes inherited input padding
- Uses a 4px corner radius
- Tightens checkbox-to-text spacing
- Uses a thinner centered black check mark

Installer checks, commits, and pushes origin/main. No automatic restart.
