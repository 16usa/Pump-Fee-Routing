Pump Fee Routing — Recent payments v1
Scope: Home Recent payments section only.
Matches the reference card hierarchy: amount, recipient, token-to-X route, time, chevron and expandable details.
Uses only real ledger/token/profile data; no demo payments are inserted.
Runs npm check, commits, and pushes to origin/main. No automatic server restart.
