#!/usr/bin/env bash
set -euo pipefail

if [ ! -f src/app.js ] || [ ! -f src/styles.css ]; then
  echo "Run this from the Pump-Fee-Routing project root."
  exit 1
fi

if [ -n "$(git status --porcelain -- src/app.js src/styles.css)" ]; then
  echo "STOP: src/app.js or src/styles.css has uncommitted changes."
  git status --short -- src/app.js src/styles.css
  exit 2
fi

python3 - <<'PY'
from pathlib import Path

app_path = Path("src/app.js")
css_path = Path("src/styles.css")
app = app_path.read_text()
css = css_path.read_text()

marker = "/* home-recent-payments-v1 */"
if marker in css:
    raise SystemExit("Recent payments v1 is already installed.")

insert_before = "function homeMostPayments(h){"
idx = app.find(insert_before)
if idx < 0:
    raise SystemExit("Could not locate homeMostPayments() in src/app.js")

helper = r'''function homeRecentPaymentCard(p,i,tokens){
  const amount=p.amount_usd??p.amount??0;
  const to=p.display_name||p.recipient_handle||p.to||'recipient';
  const mints=String(p.mints||'').split(',').filter(Boolean);
  const firstMint=mints[0]||'';
  const token=(tokens||[]).find(t=>(t.mint||t.contract)===firstMint)||null;
  const confirmed=['sent','claimed'].includes(p.status);
  return `<button class="home-payment-card expandable" data-expand="home-payment-${i}">
    <div class="home-payment-top">
      <div>
        <strong>${fmtMoney(amount)}</strong>
        <span>${confirmed?'sent':'scheduled'} to <b>${esc(to)}</b>${confirmed?' <em>✓</em>':''}</span>
      </div>
      <span class="chev">⌄</span>
    </div>
    <div class="home-payment-route">
      <div class="home-payment-party home-payment-token">
        ${token?avatar(token.symbol||token.name,true,token.image_url):`<span class="home-payment-placeholder">${esc(initials(token?.symbol||firstMint||'T'))}</span>`}
        <i class="home-payment-badge">●</i>
      </div>
      <span class="home-payment-dollar">$</span>
      <div class="home-payment-party home-payment-recipient">
        ${avatar(to,true,p.avatar_url||'')}
        <i class="home-payment-x">X</i>
      </div>
      <time>${esc(ago(p.sent_at||p.created_at))}</time>
    </div>
    <div class="details hidden">
      <div><span>Status</span><b>${esc(p.status||'queued')}</b></div>
      <div><span>Provider</span><b>${esc(p.provider||'')}</b></div>
      <div><span>Reference</span><b>${esc(p.provider_ref||p.id||'')}</b></div>
      ${p.public_confirmation_url?`<div><span>Confirmation</span><b>${esc(p.public_confirmation_url)}</b></div>`:''}
    </div>
  </button>`;
}

function homeRecentPayments(h){
  const payments=(h.payments||[]).slice(0,6);
  const tokens=h.tokens||[];
  return `<section class="wrap section home-recent-payments">
    <p class="home-payment-update">Updates are delayed. Showing recent payments from the confirmed ledger.</p>
    <div class="home-recent-payments-head">
      <h2>Recent payments</h2>
      <div class="home-recent-payments-pager"><button disabled>‹</button><span>1</span><button disabled>›</button></div>
    </div>
    <div class="home-payment-list">
      ${payments.length
        ? payments.map((p,i)=>homeRecentPaymentCard(p,i,tokens)).join('')
        : `<div class="home-payment-empty">
            <div class="home-payment-empty-route"><i></i><b>$</b><i></i></div>
            <strong>No payouts recorded yet.</strong>
            <span>Confirmed payments will appear here automatically.</span>
          </div>`}
    </div>
  </section>`;
}

'''

app = app[:idx] + helper + app[idx:]

old = '''    <section class="wrap section">
      ${sectionTitle('Recent payments')}
      <div class="payment-list">${(h.payments||[]).slice(0,6).map(paymentCard).join('')||'<div class="empty">No payouts recorded yet.</div>'}</div>
    </section>'''

new = '''    ${homeRecentPayments(h)}'''

if old not in app:
    raise SystemExit("Could not locate existing Home Recent payments block.")

app = app.replace(old, new, 1)
app_path.write_text(app)

css += r'''

/* home-recent-payments-v1 */
.home-recent-payments{padding-top:42px!important}
.home-payment-update{
  max-width:520px;
  margin:0 0 15px;
  color:#6d6d6d;
  font-size:9px;
  line-height:1.45;
}
.home-recent-payments-head{
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap:12px;
  margin-bottom:14px;
}
.home-recent-payments-head h2{
  margin:0;
  font-size:18px;
  line-height:1;
  letter-spacing:-.03em;
  font-weight:650;
}
.home-recent-payments-pager{
  display:flex;
  align-items:center;
  gap:11px;
  color:#686868;
  font-size:8px;
}
.home-recent-payments-pager button{
  border:0;
  background:transparent;
  color:#666;
  padding:0;
  font-size:15px;
}
.home-payment-list{display:grid;gap:8px}
.home-payment-card{
  width:100%;
  padding:14px;
  color:#fff;
  text-align:left;
  background:#181818;
  border:1px solid #303030;
  border-radius:14px;
  cursor:pointer;
}
.home-payment-top{
  display:flex;
  justify-content:space-between;
  align-items:flex-start;
  gap:10px;
}
.home-payment-top>div{display:grid}
.home-payment-top strong{
  font-size:23px;
  line-height:1;
  letter-spacing:-.045em;
  font-weight:500;
}
.home-payment-top span:not(.chev){
  margin-top:6px;
  color:#9a9a9a;
  font-size:10px;
}
.home-payment-top span b{color:#fff;font-weight:650}
.home-payment-top em{color:#239be8;font-style:normal}
.home-payment-top .chev{
  color:#777;
  font-size:12px;
  transition:transform .2s;
}
.home-payment-card.open .chev{transform:rotate(180deg)}
.home-payment-route{
  display:grid;
  grid-template-columns:42px 20px 42px 1fr;
  align-items:center;
  gap:7px;
  margin-top:13px;
}
.home-payment-party{
  position:relative;
  width:42px;
  height:42px;
}
.home-payment-party .avatar{
  width:42px;
  height:42px;
  border:0;
  font-size:13px;
}
.home-payment-placeholder{
  width:42px;
  height:42px;
  display:grid;
  place-items:center;
  border-radius:50%;
  background:#0a0a0a;
  border:1px solid #333;
  font-size:12px;
  font-weight:800;
}
.home-payment-badge,
.home-payment-x{
  position:absolute;
  right:-2px;
  bottom:-2px;
  min-width:16px;
  height:16px;
  display:grid;
  place-items:center;
  border:2px solid #181818;
  border-radius:5px;
  background:#080808;
  font-size:7px;
  font-style:normal;
}
.home-payment-badge{color:#79ffbb}
.home-payment-x{color:#fff}
.home-payment-dollar{
  display:grid;
  place-items:center;
  color:#fff;
  font-size:21px;
  font-weight:800;
}
.home-payment-route time{
  justify-self:end;
  align-self:end;
  color:#858585;
  font-size:9px;
}
.home-payment-card .details{
  margin-top:12px;
  padding-top:10px;
  border-top:1px solid #2e2e2e;
}
.home-payment-empty{
  min-height:150px;
  display:grid;
  place-items:center;
  align-content:center;
  gap:7px;
  padding:20px;
  border:1px dashed #272727;
  border-radius:14px;
  color:#646464;
  text-align:center;
}
.home-payment-empty-route{
  display:flex;
  align-items:center;
  gap:10px;
  margin-bottom:5px;
}
.home-payment-empty-route i{
  width:34px;
  height:34px;
  display:block;
  border-radius:50%;
  background:#111;
  border:1px solid #242424;
}
.home-payment-empty-route b{font-size:18px;color:#5e5e5e}
.home-payment-empty strong{font-size:9px;color:#777}
.home-payment-empty span{font-size:7px;color:#555}

@media(max-width:640px){
  .home-recent-payments{padding-top:38px!important}
  .home-payment-update{font-size:8px;margin-bottom:13px}
  .home-recent-payments-head h2{font-size:16px}
  .home-payment-card{padding:12px;border-radius:13px}
  .home-payment-top strong{font-size:21px}
  .home-payment-top span:not(.chev){font-size:9px}
  .home-payment-route{grid-template-columns:38px 18px 38px 1fr;gap:6px;margin-top:12px}
  .home-payment-party,.home-payment-party .avatar,.home-payment-placeholder{width:38px;height:38px}
}
'''
css_path.write_text(css)

print("Recent payments v1 patch installed.")
PY

npm run check

git add src/app.js src/styles.css

if git diff --cached --quiet; then
  echo "No staged changes; nothing to commit."
else
  git commit -m "Match home recent payments"
fi

git push origin main

echo
echo "DONE: Recent payments patch checked, committed, and pushed to GitHub."
echo "No server restart was performed."
echo "Refresh the browser to see the updated Recent payments section."
