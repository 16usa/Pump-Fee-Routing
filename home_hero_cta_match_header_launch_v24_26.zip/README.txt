Home Hero CTA Match Header Launch v24.26

What this patch does:
- Makes the home hero CTA text size match the header Launch button size.
- Applies to the main CTA row:
  - Launch a token
  - Read the docs
- Keeps the arrow/icon visually matched to the text.

No automatic server restart.

Install in the existing Replit Shell:

rm -rf /tmp/home_hero_cta_match_header_launch_v24_26 && mkdir -p /tmp/home_hero_cta_match_header_launch_v24_26 && unzip -o home_hero_cta_match_header_launch_v24_26.zip -d /tmp/home_hero_cta_match_header_launch_v24_26 && bash /tmp/home_hero_cta_match_header_launch_v24_26/install.sh
