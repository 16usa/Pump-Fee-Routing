from pathlib import Path

css_path = Path('src/styles.css')
if not css_path.exists():
    raise SystemExit('ERROR: src/styles.css not found. Run from the existing Replit project root.')

css = css_path.read_text()
marker = '/* explore-project-top-token-card-v24-32'
if marker not in css:
    raise SystemExit('ERROR: v24.32 Explore projection styles not found in src/styles.css')

old_main = '''.home-explore-reference-v8 .home-explore-v8-primary-slot{
  left:2.5% !important;
  top:4% !important;
  bottom:54px !important;
  width:48% !important;
  height:auto !important;
  z-index:4 !important;
  display:flex !important;
  align-items:flex-start !important;
  justify-content:flex-start !important;
  overflow:visible !important;
}'''

new_main = '''.home-explore-reference-v8 .home-explore-v8-primary-slot{
  left:0 !important;
  top:0 !important;
  bottom:12px !important;
  width:56% !important;
  height:auto !important;
  z-index:4 !important;
  display:flex !important;
  align-items:flex-start !important;
  justify-content:flex-start !important;
  overflow:visible !important;
}'''

old_secondary = '''.home-explore-reference-v8 .home-explore-v8-secondary-slot{
  right:0 !important;
  top:14% !important;
  bottom:54px !important;
  width:33% !important;
  height:auto !important;
  z-index:3 !important;
}'''

new_secondary = '''.home-explore-reference-v8 .home-explore-v8-secondary-slot{
  right:0 !important;
  top:12% !important;
  bottom:12px !important;
  width:30% !important;
  height:auto !important;
  z-index:3 !important;
}'''

old_mobile_main = '''  .home-explore-reference-v8 .home-explore-v8-primary-slot{
    left:2.5% !important;
    top:3.5% !important;
    bottom:46px !important;
    width:48% !important;
  }'''

new_mobile_main = '''  .home-explore-reference-v8 .home-explore-v8-primary-slot{
    left:0 !important;
    top:0 !important;
    bottom:10px !important;
    width:56% !important;
  }'''

old_mobile_secondary = '''  .home-explore-reference-v8 .home-explore-v8-secondary-slot{
    top:14% !important;
    bottom:46px !important;
    width:33% !important;
  }'''

new_mobile_secondary = '''  .home-explore-reference-v8 .home-explore-v8-secondary-slot{
    top:12% !important;
    bottom:10px !important;
    width:30% !important;
  }'''

pairs = [
    (old_main, new_main, 'desktop primary slot'),
    (old_secondary, new_secondary, 'desktop secondary slot'),
    (old_mobile_main, new_mobile_main, 'mobile primary slot'),
    (old_mobile_secondary, new_mobile_secondary, 'mobile secondary slot'),
]

orig = css
for old, new, label in pairs:
    if old in css:
        css = css.replace(old, new, 1)
    elif new in css:
        pass
    else:
        raise SystemExit(f'ERROR: expected {label} block not found; no files modified.')

if css == orig:
    print('No changes needed; layout already updated.')
else:
    css_path.write_text(css)
    print('PASS: Explore primary card now fills more than half the block, flush to left/top, with reduced bottom gap.')
