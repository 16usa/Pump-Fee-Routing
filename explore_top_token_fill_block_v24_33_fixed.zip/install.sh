#!/usr/bin/env bash
set -euo pipefail

PATCH_NAME="explore_top_token_fill_block_v24_33"
CSS="src/styles.css"

if [ ! -f "$CSS" ]; then
  echo "ERROR: missing src/styles.css"
  echo "Run this from the existing Replit project root."
  exit 1
fi

echo "==> Installing ${PATCH_NAME}"
mkdir -p ".patch-backups/${PATCH_NAME}"
cp "$CSS" ".patch-backups/${PATCH_NAME}/styles.css.before"

python3 "$(dirname "$0")/patch.py"

grep -q 'left:0 !important;' "$CSS"
grep -q 'width:56% !important;' "$CSS"

git add src/styles.css
if ! git diff --cached --quiet; then
  git commit -m "Stretch Explore top token preview card"
  git push origin main
else
  echo "==> No new changes to commit."
fi

echo
echo "PASS: ${PATCH_NAME} installed."
echo "No server restart was performed."
