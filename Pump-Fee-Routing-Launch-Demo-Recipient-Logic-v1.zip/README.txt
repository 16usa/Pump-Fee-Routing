Pump Fee Routing — Launch Demo Recipient Logic v1

Changes ONLY the animated Launch notification block.

Correct behavior:
- No X recipient selected:
  - "sent to Recipient"
  - neutral empty recipient avatar
  - no fake GG
  - no verified badge
- X recipient selected:
  - uses the real selected display name
  - uses the real selected avatar
  - shows verified only when the selected profile is verified
- "Paid sent you ..." scenes stay independent from the selected X recipient
- Keeps all 10 rotating scenes: $5/$10/$20/$50/$100 x 2 states
- Token preview/card is not modified

Installer checks, commits, and pushes origin/main.
No automatic server restart.
