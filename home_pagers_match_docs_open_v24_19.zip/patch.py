from pathlib import Path

path = Path('src/styles.css')
if not path.exists():
    raise SystemExit('ERROR: src/styles.css not found. Run from the existing Replit project root.')

css = path.read_text()
marker = '/* home-pagers-match-docs-open-v24-19 */'

if marker not in css:
    css += r'''

/* home-pagers-match-docs-open-v24-19
   New reference = Docs / Open footer text.
   Footer reference is 13px desktop and 12px mobile.
   Make page number and both arrows the SAME size in all requested sections. */
.home-top-token-pager,
.home-top-profiles-pager,
.home-recent-payments-pager,
.home-most-payments-pager,
.home-off-pager,
.home-on-pager{
  font-size:13px !important;
  line-height:1 !important;
}

.home-top-token-pager button,
.home-top-profiles-pager button,
.home-recent-payments-pager button,
.home-most-payments-pager button,
.home-off-pager button,
.home-on-pager button{
  font-size:13px !important;
  line-height:1 !important;
  width:auto !important;
  height:auto !important;
}

@media(max-width:640px){
  .home-top-token-pager,
  .home-top-profiles-pager,
  .home-recent-payments-pager,
  .home-most-payments-pager,
  .home-off-pager,
  .home-on-pager{
    font-size:12px !important;
    line-height:1 !important;
  }

  .home-top-token-pager button,
  .home-top-profiles-pager button,
  .home-recent-payments-pager button,
  .home-most-payments-pager button,
  .home-off-pager button,
  .home-on-pager button{
    font-size:12px !important;
    line-height:1 !important;
    width:auto !important;
    height:auto !important;
  }
}
'''
    path.write_text(css)
    print('PASS: all requested pagers now match Docs / Open text size')
else:
    print('Patch already installed')
