Home Pagers Match Docs / Open v24.19

New typography reference:
- the bottom-card labels such as "Docs" and "Open →"

Current reference sizes found in the project:
- desktop: 13px
- mobile: 12px

This patch makes BOTH the page number and both pager arrows the same size:
- Top Tokens
- Top X Profiles
- Recent Payments
- Most Payments
- Off Ramp
- On Ramp

It is a final CSS override, so it supersedes the previous v24.16 / v24.18 pager sizing.
No automatic server restart.

Install in the existing Replit Shell:

rm -rf /tmp/home_pagers_match_docs_open_v24_19 && mkdir -p /tmp/home_pagers_match_docs_open_v24_19 && unzip -o home_pagers_match_docs_open_v24_19.zip -d /tmp/home_pagers_match_docs_open_v24_19 && bash /tmp/home_pagers_match_docs_open_v24_19/install.sh
