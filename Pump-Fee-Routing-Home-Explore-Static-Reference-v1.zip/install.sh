#!/usr/bin/env bash
set -euo pipefail

[ -f src/app.js ] || { echo "Missing src/app.js"; exit 1; }
[ -f src/styles.css ] || { echo "Missing src/styles.css"; exit 1; }

cp src/app.js /tmp/Pump-Fee-Routing-app-before-explore-static-v1.js
cp src/styles.css /tmp/Pump-Fee-Routing-styles-before-explore-static-v1.css

restore() {
  cp /tmp/Pump-Fee-Routing-app-before-explore-static-v1.js src/app.js
  cp /tmp/Pump-Fee-Routing-styles-before-explore-static-v1.css src/styles.css
}

python3 - <<'PY'
from pathlib import Path
import base64

app_path=Path("src/app.js")
s=app_path.read_text()

static_block=base64.b64decode("ICAgICAgPGEgY2xhc3M9ImhvbWUtcHJldmlldy1jYXJkIGhvbWUtcmVmLWNhcmQgaG9tZS1yZWYtZXhwbG9yZS1jYXJkIiBocmVmPSIjL2V4cGxvcmUiPgogICAgICAgIDxkaXYgY2xhc3M9ImhvbWUtcHJldmlldy1sYWJlbCI+PGI+RXhwbG9yZTwvYj48c3Bhbj5PcGVuIOKGkjwvc3Bhbj48L2Rpdj4KICAgICAgICAkeygoKT0+ewogICAgICAgICAgY29uc3QgcHJpbWFyeT10b2tlbnNbMF18fG51bGw7CiAgICAgICAgICBjb25zdCBzZWNvbmRhcnk9dG9rZW5zWzFdfHxwcmltYXJ5OwogICAgICAgICAgY29uc3QgcHJpbWFyeU5hbWU9cHJpbWFyeT8ubmFtZXx8J1dhaXRpbmcgZm9yIHRva2VuJzsKICAgICAgICAgIGNvbnN0IHByaW1hcnlTeW1ib2w9cHJpbWFyeT8uc3ltYm9sfHwnJzsKICAgICAgICAgIGNvbnN0IHByaW1hcnlIYW5kbGU9cHJpbWFyeT8ucHJvZmlsZXx8cHJpbWFyeT8ucmVjaXBpZW50X2hhbmRsZXx8Jyc7CiAgICAgICAgICBjb25zdCBzZWNvbmRhcnlOYW1lPXNlY29uZGFyeT8ubmFtZXx8cHJpbWFyeU5hbWU7CiAgICAgICAgICBjb25zdCBzZWNvbmRhcnlTeW1ib2w9c2Vjb25kYXJ5Py5zeW1ib2x8fHByaW1hcnlTeW1ib2w7CgogICAgICAgICAgY29uc3QgcHJpbWFyeU1lZGlhPXByaW1hcnk/LmltYWdlX3VybAogICAgICAgICAgICA/IGA8aW1nIGNsYXNzPSJob21lLXJlZi1tYWluLWFydCIgc3JjPSIke2VzYyhwcmltYXJ5LmltYWdlX3VybCl9IiBhbHQ9IiIgb25lcnJvcj0idGhpcy5zdHlsZS5kaXNwbGF5PSdub25lJzt0aGlzLm5leHRFbGVtZW50U2libGluZy5zdHlsZS5kaXNwbGF5PSdncmlkJyI+PHNwYW4gY2xhc3M9ImhvbWUtcmVmLXRva2VuLWZhbGxiYWNrIiBzdHlsZT0iZGlzcGxheTpub25lIj4ke2VzYyhpbml0aWFscyhwcmltYXJ5U3ltYm9sfHxwcmltYXJ5TmFtZXx8J1AnKSl9PC9zcGFuPmAKICAgICAgICAgICAgOiBgPHNwYW4gY2xhc3M9ImhvbWUtcmVmLXRva2VuLWZhbGxiYWNrIj4ke2VzYyhpbml0aWFscyhwcmltYXJ5U3ltYm9sfHxwcmltYXJ5TmFtZXx8J1AnKSl9PC9zcGFuPmA7CgogICAgICAgICAgY29uc3Qgc2Vjb25kYXJ5TWVkaWE9c2Vjb25kYXJ5Py5pbWFnZV91cmwKICAgICAgICAgICAgPyBgPGltZyBjbGFzcz0iaG9tZS1yZWYtc2lkZS1hcnQiIHNyYz0iJHtlc2Moc2Vjb25kYXJ5LmltYWdlX3VybCl9IiBhbHQ9IiIgb25lcnJvcj0idGhpcy5zdHlsZS5kaXNwbGF5PSdub25lJzt0aGlzLm5leHRFbGVtZW50U2libGluZy5zdHlsZS5kaXNwbGF5PSdncmlkJyI+PHNwYW4gY2xhc3M9ImhvbWUtcmVmLXRva2VuLWZhbGxiYWNrIiBzdHlsZT0iZGlzcGxheTpub25lIj4ke2VzYyhpbml0aWFscyhzZWNvbmRhcnlTeW1ib2x8fHNlY29uZGFyeU5hbWV8fCdQJykpfTwvc3Bhbj5gCiAgICAgICAgICAgIDogYDxzcGFuIGNsYXNzPSJob21lLXJlZi10b2tlbi1mYWxsYmFjayI+JHtlc2MoaW5pdGlhbHMoc2Vjb25kYXJ5U3ltYm9sfHxzZWNvbmRhcnlOYW1lfHwnUCcpKX08L3NwYW4+YDsKCiAgICAgICAgICByZXR1cm4gYDxkaXYgY2xhc3M9ImhvbWUtcmVmLWV4cGxvcmUtc3RhZ2UiPgogICAgICAgICAgICA8ZGl2IGNsYXNzPSJob21lLXJlZi1leHBsb3JlLXByaW1hcnkiPgogICAgICAgICAgICAgICR7cHJpbWFyeU1lZGlhfQogICAgICAgICAgICAgIDxzcGFuIGNsYXNzPSJob21lLXJlZi1mbG9hdGluZy1iYWRnZSI+JHtwbGF0Zm9ybUJhZGdlKHByaW1hcnk/LnBsYXRmb3JtfHwnUHVtcCcpfTwvc3Bhbj4KICAgICAgICAgICAgICAke3ByaW1hcnlIYW5kbGU/YDxzcGFuIGNsYXNzPSJob21lLXJlZi1mbG9hdGluZy1wcm9maWxlIj5AJHtlc2MocHJpbWFyeUhhbmRsZSl9PC9zcGFuPmA6Jyd9CiAgICAgICAgICAgIDwvZGl2PgogICAgICAgICAgICA8ZGl2IGNsYXNzPSJob21lLXJlZi1leHBsb3JlLXNlY29uZGFyeSI+CiAgICAgICAgICAgICAgJHtzZWNvbmRhcnlNZWRpYX0KICAgICAgICAgICAgICA8c21hbGw+JHtzZWNvbmRhcnk/LnBsYXRmb3JtP2VzYyhzZWNvbmRhcnkucGxhdGZvcm0pOidQdW1wJ308L3NtYWxsPgogICAgICAgICAgICAgIDxiPiR7c2Vjb25kYXJ5P2ZtdE51bShzZWNvbmRhcnkuc2VudHx8MCk6JyQwLjAwJ308L2I+CiAgICAgICAgICAgIDwvZGl2PgogICAgICAgICAgPC9kaXY+CiAgICAgICAgICA8ZGl2IGNsYXNzPSJob21lLXJlZi1leHBsb3JlLWZvb3QiPgogICAgICAgICAgICA8ZGl2PgogICAgICAgICAgICAgIDxzbWFsbD4ke3ByaW1hcnk/LnBsYXRmb3JtP2VzYyhwcmltYXJ5LnBsYXRmb3JtKTonUHVtcCd9JHtwcmltYXJ5Py5jcmVhdGVkX2F0P2AgwrcgJHtlc2MoYWdvKHByaW1hcnkuY3JlYXRlZF9hdCkpfWA6Jyd9PC9zbWFsbD4KICAgICAgICAgICAgICA8c3Ryb25nPiR7ZXNjKHByaW1hcnlOYW1lKX08L3N0cm9uZz4KICAgICAgICAgICAgICA8c3Bhbj4ke2VzYyhwcmltYXJ5U3ltYm9sKX0ke3ByaW1hcnk/YCDCtyAke2ZtdE1jKHByaW1hcnkubWM/P3ByaW1hcnkubWFya2V0X2NhcF91c2QpfSBNQ2A6Jyd9PC9zcGFuPgogICAgICAgICAgICA8L2Rpdj4KICAgICAgICAgICAgPGI+JHtwcmltYXJ5P2ZtdE1vbmV5KHByaW1hcnkuc2VudHx8MCk6JyQwLjAwJ308L2I+CiAgICAgICAgICA8L2Rpdj5gOwogICAgICAgIH0pKCl9CiAgICAgIDwvYT4KCg==").decode()
old_helper=base64.b64decode("ICBjb25zdCByYWlsVG9rZW5zPXRva2Vucy5sZW5ndGg/dG9rZW5zOltudWxsXTsKICBjb25zdCByZXBlYXRlZD1BcnJheS5mcm9tKHtsZW5ndGg6TWF0aC5tYXgoOCxyYWlsVG9rZW5zLmxlbmd0aCozKX0sKF8saSk9PnJhaWxUb2tlbnNbaSVyYWlsVG9rZW5zLmxlbmd0aF0pOwoKICBjb25zdCBleHBsb3JlTWluaT0odCxpKT0+ewogICAgY29uc3QgbmFtZT10Py5uYW1lfHwnV2FpdGluZyBmb3IgdG9rZW4nOwogICAgY29uc3Qgc3ltYm9sPXQ/LnN5bWJvbHx8Jyc7CiAgICBjb25zdCBoYW5kbGU9dD8ucHJvZmlsZXx8dD8ucmVjaXBpZW50X2hhbmRsZXx8Jyc7CiAgICBjb25zdCBtZWRpYT10Py5pbWFnZV91cmwKICAgICAgPyBgPGltZyBzcmM9IiR7ZXNjKHQuaW1hZ2VfdXJsKX0iIGFsdD0iIiBvbmVycm9yPSJ0aGlzLnN0eWxlLmRpc3BsYXk9J25vbmUnO3RoaXMubmV4dEVsZW1lbnRTaWJsaW5nLnN0eWxlLmRpc3BsYXk9J2dyaWQnIj48c3BhbiBjbGFzcz0iaG9tZS12Mi10b2tlbi1mYWxsYmFjayIgc3R5bGU9ImRpc3BsYXk6bm9uZSI+JHtlc2MoaW5pdGlhbHMoc3ltYm9sfHxuYW1lfHwnUCcpKX08L3NwYW4+YAogICAgICA6IGA8c3BhbiBjbGFzcz0iaG9tZS12Mi10b2tlbi1mYWxsYmFjayI+JHtlc2MoaW5pdGlhbHMoc3ltYm9sfHxuYW1lfHwnUCcpKX08L3NwYW4+YDsKICAgIHJldHVybiBgPGRpdiBjbGFzcz0iaG9tZS12Mi10b2tlbi1taW5pIj4KICAgICAgPGRpdiBjbGFzcz0iaG9tZS12Mi10b2tlbi1tZWRpYSI+JHttZWRpYX08L2Rpdj4KICAgICAgPGRpdiBjbGFzcz0iaG9tZS12Mi10b2tlbi1jb3B5Ij4KICAgICAgICA8c21hbGw+JHtoYW5kbGU/YEAke2VzYyhoYW5kbGUpfWA6J1B1bXAnfSR7dD8uY3JlYXRlZF9hdD9gIMK3ICR7ZXNjKGFnbyh0LmNyZWF0ZWRfYXQpKX1gOicnfTwvc21hbGw+CiAgICAgICAgPHN0cm9uZz4ke2VzYyhuYW1lKX08L3N0cm9uZz4KICAgICAgICA8c3Bhbj4ke2VzYyhzeW1ib2wpfSR7dD9gIMK3ICR7Zm10TWModC5tYz8/dC5tYXJrZXRfY2FwX3VzZCl9IE1DYDonJ308L3NwYW4+CiAgICAgIDwvZGl2PgogICAgICA8Yj4ke3Q/YCR7Zm10TnVtKHQuc2VudHx8MCl9IFNlbnRgOifigJQnfTwvYj4KICAgIDwvZGl2PmA7CiAgfTsKCg==").decode()
static_css=base64.b64decode("LyogaG9tZS1leHBsb3JlLXN0YXRpYy1yZWZlcmVuY2UtdjEKICAgRXhwbG9yZSBvbiB0aGUgSG9tZSBwYWdlIGlzIGludGVudGlvbmFsbHkgc3RhdGljLCBtYXRjaGluZyB0aGUgcmVmZXJlbmNlLiAqLwouaG9tZS1yZWYtZXhwbG9yZS1jYXJkLAouaG9tZS1yZWYtZXhwbG9yZS1jYXJkICp7CiAgYW5pbWF0aW9uOm5vbmUhaW1wb3J0YW50Owp9Ci5ob21lLXJlZi1leHBsb3JlLXN0YWdlLAouaG9tZS1yZWYtZXhwbG9yZS1wcmltYXJ5LAouaG9tZS1yZWYtZXhwbG9yZS1zZWNvbmRhcnksCi5ob21lLXJlZi1tYWluLWFydCwKLmhvbWUtcmVmLXNpZGUtYXJ0ewogIHRyYW5zZm9ybTpub25lIWltcG9ydGFudDsKICB0cmFuc2l0aW9uOm5vbmUhaW1wb3J0YW50Owp9Cg==").decode()

start=s.find('      <a class="home-preview-card home-ref-card home-v2-explore-card" href="#/explore">')
if start < 0:
    # Already static is acceptable.
    if 'home-ref-explore-card' not in s:
        raise SystemExit("Could not locate current Home Explore preview.")
else:
    end_marker='      <a class="home-preview-card home-ref-card home-v2-payments-card" href="#/money">'
    end=s.find(end_marker,start)
    if end < 0:
        raise SystemExit("Could not locate Payments preview after Explore.")
    s=s[:start]+static_block+s[end:]

if old_helper in s:
    s=s.replace(old_helper,"",1)

# If the generated moving hotfix was installed, remove it from app.js.
marker='/* home-explore-motion-hotfix-v3'
if marker in s:
    s=s[:s.find(marker)].rstrip()+"\n"

app_path.write_text(s)

css_path=Path("src/styles.css")
css=css_path.read_text()
if 'home-explore-static-reference-v1' not in css:
    css += "\n\n"+static_css+"\n"
css_path.write_text(css)

print("Home Explore Static Reference v1 installed.")
PY

if ! node --check src/app.js; then
  restore
  echo "JS syntax check failed; restored."
  exit 2
fi

if ! npm run check; then
  restore
  echo "Project check failed; restored."
  exit 3
fi

node <<'NODE'
const fs=require('fs');
const app=fs.readFileSync('src/app.js','utf8');
const css=fs.readFileSync('src/styles.css','utf8');
const checks=[
  ['static Explore card',app.includes('home-ref-explore-card')],
  ['static Explore stage',app.includes('home-ref-explore-stage')],
  ['moving Explore card removed',!app.includes('home-v2-explore-card')],
  ['old repeated rail helper removed',!app.includes('const repeated=Array.from({length:Math.max(8,railTokens.length*3)}')],
  ['static CSS marker',css.includes('home-explore-static-reference-v1')],
  ['Launch wallet logic preserved',app.includes('function connectWallet')],
  ['confirmation retry preserved',app.includes('launch-confirmation-retry-v3')]
];
let bad=0;
for(const [name,ok] of checks){
  console.log((ok?'PASS':'FAIL')+' '+name);
  if(!ok)bad++;
}
if(bad)process.exit(1);
NODE

git add src/app.js src/styles.css
if git diff --cached --quiet; then
  echo "No new changes to commit."
else
  git commit -m "Make Home Explore preview static"
  git push origin main
fi

echo
echo "DONE: Home Explore Static Reference v1 installed, checked, committed, and pushed."
echo "Explore is now intentionally static like the reference site."
echo "No Launch, wallet, routing, payout, claims, or indexer logic was changed."
echo "No server restart was performed."
echo "Restart Console/Run manually once."
