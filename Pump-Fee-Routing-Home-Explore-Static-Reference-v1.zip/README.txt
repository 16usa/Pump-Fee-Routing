Pump-Fee-Routing — Home Explore Static Reference v1

Changes:
- Home > Explore is static, matching the reference site.
- No moving/marquee token rails.
- Uses the existing static two-panel Explore composition already styled in the project.
- Real token data/images are still used; if no image exists, a fallback is shown.
- No Launch/wallet/routing/payout/claims/indexer logic is changed.
- Installer checks JS and project integrity and restores files if validation fails.
- No automatic server restart.
