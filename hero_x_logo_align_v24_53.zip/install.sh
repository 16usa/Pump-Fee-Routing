#!/usr/bin/env bash
set -euo pipefail

PATCH_NAME="hero_x_logo_align_v24_53"
CSS="src/styles.css"

if [ ! -f "$CSS" ]; then
  echo "ERROR: missing src/styles.css"
  echo "Run this from the existing Replit project root."
  exit 1
fi

echo "==> Installing ${PATCH_NAME}"
mkdir -p ".patch-backups/${PATCH_NAME}"
cp "$CSS" ".patch-backups/${PATCH_NAME}/styles.css.before"

python3 "$(dirname "$0")/patch.py"

echo "==> Verifying patch"
grep -q 'hero-x-logo-align-v24-53' "$CSS"
grep -q 'width:.72em !important' "$CSS"
grep -q 'height:.74em !important' "$CSS"
grep -q 'vertical-align:-.10em !important' "$CSS"

echo "==> Running project check"
npm run check

echo "==> Git diff"
git diff --stat -- "$CSS"

git add "$CSS"
if git diff --cached --quiet; then
  echo "==> No new changes to commit."
else
  git commit -m "Align hero X logo with heading text"
  git push origin main
fi

echo
echo "PASS: ${PATCH_NAME} installed."
echo "No server restart was performed."
