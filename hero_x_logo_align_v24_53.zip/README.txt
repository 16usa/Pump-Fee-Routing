Hero X Logo Align v24.53

Checked against current GitHub main.

Current v24.52:
- X logo width/height: 0.86em
- vertical-align: -0.075em

That makes the mark visually taller than a normal capital letter.

v24.53:
- width: 0.72em
- height: 0.74em
- vertical-align: -0.10em
- keeps currentColor and the existing X SVG
- changes only size and vertical alignment
- no automatic server restart
