from pathlib import Path

css_path = Path("src/styles.css")
if not css_path.exists():
    raise SystemExit("ERROR: src/styles.css not found. Run from the existing Replit project root.")

css = css_path.read_text()
marker = "/* hero-x-logo-align-v24-53 */"

required = [
    "hero-x-logo-mark-v24-52",
    ".home-reference-v1 .home-hero .hero-copy h1 .hero-x-logo"
]
missing = [s for s in required if s not in css]
if missing:
    raise SystemExit("ERROR: v24.52 X logo styles not found: " + ", ".join(missing))

if marker not in css:
    css += r"""

/* hero-x-logo-align-v24-53
   Size/position correction: make the X mark read like a normal capital glyph,
   not a full em-square icon. */
.home-reference-v1 .home-hero .hero-copy h1 .hero-x-logo{
  width:.72em !important;
  height:.74em !important;
  vertical-align:-.10em !important;
  margin:0 .025em !important;
}

.home-reference-v1 .home-hero .hero-copy h1 .hero-x-logo svg{
  width:100% !important;
  height:100% !important;
}
"""
    css_path.write_text(css)
    print("PASS: X logo reduced to capital-letter scale and lowered on the baseline.")
else:
    print("No changes needed; v24.53 already installed.")
