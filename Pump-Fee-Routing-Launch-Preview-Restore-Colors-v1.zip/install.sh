#!/usr/bin/env bash
set -euo pipefail

[ -f src/styles.css ] || { echo "Missing src/styles.css. Run this from the Pump-Fee-Routing project root."; exit 1; }

if [ -n "$(git status --porcelain -- src/styles.css)" ]; then
  echo "STOP: src/styles.css has uncommitted changes."
  git status --short -- src/styles.css
  exit 2
fi

python3 - <<'PY'
from pathlib import Path
import base64

p=Path("src/styles.css")
css=p.read_text()
marker="launch-preview-restore-project-colors-v1"

if marker in css:
    raise SystemExit("Launch Preview Restore Colors v1 is already installed.")

if "launch-preview-usepaid-v1" not in css:
    raise SystemExit("Required Launch Preview UsePaid v1 styles were not found.")

css += base64.b64decode("Ci8qIGxhdW5jaC1wcmV2aWV3LXJlc3RvcmUtcHJvamVjdC1jb2xvcnMtdjEKICAgS2VlcCB0aGUgY29tcGFjdCBwcmV2aWV3IGxheW91dCwgcmVzdG9yZSB0aGUgcHJvamVjdCdzIG9yaWdpbmFsIHBhbGV0dGUuICovCi5sYXVuY2gtcHJldmlldy11c2VwYWlkewogIGJvcmRlci1jb2xvcjojMjkyOTI5IWltcG9ydGFudDsKICBiYWNrZ3JvdW5kOiMxMDEwMTAhaW1wb3J0YW50OwogIGJveC1zaGFkb3c6bm9uZSFpbXBvcnRhbnQ7Cn0KCi5sYXVuY2gtcHJldmlldy11c2VwYWlkIC5sYXVuY2gtcHJldmlldy1pbWFnZXsKICBiYWNrZ3JvdW5kOgogICAgcmFkaWFsLWdyYWRpZW50KGNpcmNsZSBhdCA1MCUgNDUlLCAjMjAyMDIwLCAjMDgwODA4IDY4JSkhaW1wb3J0YW50OwogIGNvbG9yOiNmZmYhaW1wb3J0YW50OwogIGJvcmRlci1jb2xvcjojMjQyNDI0IWltcG9ydGFudDsKfQoKLmxhdW5jaC1wcmV2aWV3LXVzZXBhaWQgLmxhdW5jaC1wcmV2aWV3LWltYWdlLmhhcy1pbWFnZXsKICBiYWNrZ3JvdW5kOiMwYTBhMGEhaW1wb3J0YW50Owp9CgoubGF1bmNoLXByZXZpZXctYmFkZ2V7CiAgYm9yZGVyLWNvbG9yOiMyOTI5MjkhaW1wb3J0YW50OwogIGJhY2tncm91bmQ6cmdiYSgxMCwxMCwxMCwuOTIpIWltcG9ydGFudDsKfQoKLmxhdW5jaC1wcmV2aWV3LXVzZXBhaWQgLmxhdW5jaC1wcmV2aWV3LXN0YXQ+c3BhbiwKLmxhdW5jaC1wcmV2aWV3LXVzZXBhaWQgLmxhdW5jaC1wcmV2aWV3LXNwbGl0ewogIGJvcmRlci1jb2xvcjojMjQyNDI0IWltcG9ydGFudDsKfQoKLmxhdW5jaC1wcmV2aWV3LXVzZXBhaWQgLmxhdW5jaC1wcmV2aWV3LXNwbGl0PmRpditkaXZ7CiAgYm9yZGVyLWxlZnQtY29sb3I6IzI0MjQyNCFpbXBvcnRhbnQ7Cn0K").decode()
p.write_text(css)
print("Launch Preview Restore Colors v1 installed.")
PY

npm run check

node <<'NODE'
const fs=require('fs');
const css=fs.readFileSync('src/styles.css','utf8');
const checks=[
  ['restore marker', css.includes('launch-preview-restore-project-colors-v1')],
  ['original card background', css.includes('background:#101010!important')],
  ['original card border', css.includes('border-color:#292929!important')],
  ['original image gradient', css.includes('#202020, #080808 68%')],
  ['original divider color', css.includes('border-color:#242424!important')]
];
let bad=0;
for(const [name,ok] of checks){
  console.log(`${ok?'PASS':'FAIL'} ${name}`);
  if(!ok) bad++;
}
if(bad) process.exit(1);
NODE

git add src/styles.css

if git diff --cached --quiet; then
  echo "No staged changes; nothing to commit."
else
  git commit -m "Restore Launch preview project colors"
fi

git push origin main

echo
echo "DONE: Launch Preview Restore Colors v1 checked, committed, and pushed to GitHub."
echo "Preview structure stays unchanged; only the project color palette is restored."
echo "No server restart was performed."
echo "Restart Console/Run manually once to load the restored colors."
