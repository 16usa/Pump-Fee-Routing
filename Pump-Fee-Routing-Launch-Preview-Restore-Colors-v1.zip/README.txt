Pump Fee Routing — Launch Preview Restore Colors v1

Keeps the compact preview structure from the previous patch.
Restores the project's original Launch color palette:
- preview card: #101010
- border: #292929
- image placeholder: original dark radial gradient
- dividers: #242424

No layout changes.
Installer checks, commits, and pushes origin/main.
No automatic server restart.
