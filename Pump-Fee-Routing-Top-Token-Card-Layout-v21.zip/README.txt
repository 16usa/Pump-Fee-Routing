Pump Fee Routing — Top Token Card Layout v21

SCOPE: only the internal arrangement inside Top Tokens cards.

Changed:
- image is inset inside the card
- platform badge stays top-left on image
- age stays top-right on image
- creator/profile pill stays bottom-left on image
- token name + ticker below image
- market cap directly below
- removes Owed and Sent rows from Top Tokens cards to match the reference

NOT changed:
- Top Tokens heading
- filters
- pagination
- grid columns
- section width
- View all tokens
- other sections

No automatic restart.

Install:
rm -rf /tmp/top-token-card-layout-v21
mkdir -p /tmp/top-token-card-layout-v21
unzip -o Pump-Fee-Routing-Top-Token-Card-Layout-v21.zip -d /tmp/top-token-card-layout-v21
bash /tmp/top-token-card-layout-v21/install.sh
