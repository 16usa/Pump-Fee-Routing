#!/usr/bin/env bash
set -euo pipefail

echo "== Top Token Card Layout v21 =="

for f in src/app.js src/styles.css; do
  if [ ! -f "$f" ]; then
    echo "ERROR: $f not found. Run this from the existing Replit project workspace."
    exit 1
  fi
done

python3 <<'PYCODE'
from pathlib import Path

app_path = Path("src/app.js")
css_path = Path("src/styles.css")
app = app_path.read_text()
css = css_path.read_text()

app_marker = 'data-top-token-layout="v21"'
css_marker = '/* top-token-card-layout-v21 */'

if app_marker not in app:
    start = app.find("function homeTopTokenCard(t){")
    end = app.find("\n\nfunction homeTopTokens(top){", start)
    if start < 0 or end < 0:
        raise SystemExit("ERROR: homeTopTokenCard() block not found.")

    new_fn = '''function homeTopTokenCard(t){
  const handle=t.profile||t.recipient_handle||'';
  const mint=t.mint||t.contract||'';
  const ageText=t.age||ago(t.created_at);
  const mc=t.mc??t.market_cap_usd;
  return `<a class="home-top-token-card" data-top-token-layout="v21" href="#/token/${encodeURIComponent(mint)}">
    <div class="home-top-token-media">
      ${tokenMedia(t,'home-top-token-fallback')}
      <div class="home-top-token-platform">${platformBadge(t.platform||'Pump')}</div>
      <div class="home-top-token-age">${esc(ageText||'')}</div>
      <div class="home-top-token-recipient">
        <i class="home-top-token-money-mark">$</i>
        ${handle?recipientAvatar(handle,handle,false,''):avatar(t.symbol||'T')}
        <span>${handle?esc(handle.replace(/^@/,'')):'Recipient'}</span>
      </div>
    </div>
    <div class="home-top-token-body">
      <div class="home-top-token-title">
        <strong>${esc(t.name)}</strong>
        <span>${esc(t.symbol||'')}</span>
      </div>
      <div class="home-top-token-market">
        <strong>${fmtMc(mc)}</strong>
        <span>MC</span>
      </div>
    </div>
  </a>`;
}'''

    app = app[:start] + new_fn + app[end:]
    app_path.write_text(app)
    print("PASS Top Tokens card markup changed")
else:
    print("PASS v21 card markup already installed")

if css_marker not in css:
    patch = r'''
/* top-token-card-layout-v21 */

/* ONLY internal layout of Top Tokens cards. */

.home-top-token-card[data-top-token-layout="v21"]{
  padding:7px 7px 10px;
  overflow:hidden;
}

.home-top-token-card[data-top-token-layout="v21"] .home-top-token-media{
  aspect-ratio:1/1;
  overflow:hidden;
  border:0;
  border-radius:11px;
  background:#080808;
}

.home-top-token-card[data-top-token-layout="v21"] .home-top-token-media>img{
  width:100%;
  height:100%;
  display:block;
  object-fit:cover;
}

.home-top-token-card[data-top-token-layout="v21"] .home-top-token-platform,
.home-top-token-card[data-top-token-layout="v21"] .home-top-token-age{
  top:7px;
  min-height:26px;
  display:flex;
  align-items:center;
  justify-content:center;
  padding:5px 8px;
  border:0;
  border-radius:999px;
  background:rgba(29,29,29,.88);
  color:#bdbdbd;
  backdrop-filter:blur(8px);
  -webkit-backdrop-filter:blur(8px);
  font-size:8px;
  line-height:1;
}

.home-top-token-card[data-top-token-layout="v21"] .home-top-token-platform{left:7px}
.home-top-token-card[data-top-token-layout="v21"] .home-top-token-age{right:7px}

.home-top-token-card[data-top-token-layout="v21"] .home-top-token-recipient{
  left:8px;
  right:auto;
  bottom:8px;
  width:max-content;
  max-width:calc(100% - 16px);
  min-height:31px;
  display:flex;
  align-items:center;
  gap:6px;
  padding:4px 9px 4px 5px;
  border:0;
  border-radius:999px;
  background:rgba(5,5,5,.92);
  box-shadow:0 1px 0 rgba(255,255,255,.06);
  backdrop-filter:blur(9px);
  -webkit-backdrop-filter:blur(9px);
}

.home-top-token-card[data-top-token-layout="v21"] .home-top-token-money-mark{
  width:18px;
  height:18px;
  display:grid;
  place-items:center;
  flex:0 0 18px;
  border-radius:50%;
  color:#f0f0f0;
  font-size:10px;
  line-height:1;
  font-style:normal;
  font-weight:700;
}

.home-top-token-card[data-top-token-layout="v21"] .home-top-token-recipient .avatar{
  width:22px;
  height:22px;
  flex:0 0 22px;
  border:0;
  font-size:7px;
}

.home-top-token-card[data-top-token-layout="v21"] .home-top-token-recipient span{
  min-width:0;
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
  color:#f1f1f1;
  font-size:10px;
  line-height:1;
  font-weight:600;
}

.home-top-token-card[data-top-token-layout="v21"] .home-top-token-body{
  padding:11px 6px 2px;
}

.home-top-token-card[data-top-token-layout="v21"] .home-top-token-title{
  min-width:0;
  display:flex;
  align-items:baseline;
  gap:6px;
}

.home-top-token-card[data-top-token-layout="v21"] .home-top-token-title strong{
  min-width:0;
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
  color:#f0f0f0;
  font-size:12px;
  line-height:1.15;
  font-weight:500;
  letter-spacing:-.015em;
}

.home-top-token-card[data-top-token-layout="v21"] .home-top-token-title span{
  min-width:0;
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
  color:#6f6f6f;
  font-size:9px;
  line-height:1;
  font-weight:400;
}

.home-top-token-card[data-top-token-layout="v21"] .home-top-token-market{
  display:flex;
  align-items:baseline;
  gap:6px;
  margin-top:10px;
}

.home-top-token-card[data-top-token-layout="v21"] .home-top-token-market strong{
  color:#f3f3f3;
  font-size:17px;
  line-height:1;
  font-weight:560;
  letter-spacing:-.035em;
}

.home-top-token-card[data-top-token-layout="v21"] .home-top-token-market span{
  color:#696969;
  font-size:9px;
  line-height:1;
  font-weight:400;
}

.home-top-token-card[data-top-token-layout="v21"] .home-top-token-sub,
.home-top-token-card[data-top-token-layout="v21"] .home-top-token-paid{
  display:none!important;
}

@media(max-width:640px){
  .home-top-token-card[data-top-token-layout="v21"]{
    padding:6px 6px 9px;
  }

  .home-top-token-card[data-top-token-layout="v21"] .home-top-token-media{
    border-radius:10px;
  }

  .home-top-token-card[data-top-token-layout="v21"] .home-top-token-platform,
  .home-top-token-card[data-top-token-layout="v21"] .home-top-token-age{
    top:6px;
    min-height:24px;
    padding:5px 7px;
    font-size:7px;
  }

  .home-top-token-card[data-top-token-layout="v21"] .home-top-token-platform{left:6px}
  .home-top-token-card[data-top-token-layout="v21"] .home-top-token-age{right:6px}

  .home-top-token-card[data-top-token-layout="v21"] .home-top-token-recipient{
    left:7px;
    bottom:7px;
    min-height:29px;
    max-width:calc(100% - 14px);
    padding:4px 8px 4px 4px;
    gap:5px;
  }

  .home-top-token-card[data-top-token-layout="v21"] .home-top-token-money-mark{
    width:17px;
    height:17px;
    flex-basis:17px;
    font-size:9px;
  }

  .home-top-token-card[data-top-token-layout="v21"] .home-top-token-recipient .avatar{
    width:21px;
    height:21px;
    flex-basis:21px;
  }

  .home-top-token-card[data-top-token-layout="v21"] .home-top-token-recipient span{
    font-size:9px;
  }

  .home-top-token-card[data-top-token-layout="v21"] .home-top-token-body{
    padding:10px 6px 2px;
  }

  .home-top-token-card[data-top-token-layout="v21"] .home-top-token-title strong{
    font-size:11px;
  }

  .home-top-token-card[data-top-token-layout="v21"] .home-top-token-title span{
    font-size:8px;
  }

  .home-top-token-card[data-top-token-layout="v21"] .home-top-token-market{
    margin-top:9px;
    gap:5px;
  }

  .home-top-token-card[data-top-token-layout="v21"] .home-top-token-market strong{
    font-size:16px;
  }

  .home-top-token-card[data-top-token-layout="v21"] .home-top-token-market span{
    font-size:8px;
  }
}
'''
    css_path.write_text(css.rstrip() + "\n\n" + patch + "\n")
    print("PASS v21 card layout CSS added")
else:
    print("PASS v21 CSS already installed")

app = app_path.read_text()
css = css_path.read_text()

segment = app[app.find("function homeTopTokenCard"):app.find("function homeTopTokens")]
checks = {
    "card marker": app_marker in app,
    "market row": "home-top-token-market" in segment,
    "old Owed markup removed": "fmtMoney(t.owed||0)" not in segment,
    "old Sent markup removed": "home-top-token-paid" not in segment,
    "CSS marker": css_marker in css,
}
for label, ok in checks.items():
    if not ok:
        raise SystemExit(f"ERROR: verification failed: {label}")
    print("PASS", label)
PYCODE

echo
echo "== Project checks =="
npm run check

echo
echo "== Git diff =="
git diff --stat

git add src/app.js src/styles.css

if git diff --cached --quiet; then
  echo "No new changes to commit."
else
  git commit -m "Match Top Tokens card internal layout"
  git push
fi

echo
echo "DONE: Top Token Card Layout v21 installed, checked, committed, and pushed."
echo "No server restart was performed."
echo "Restart Run/Console manually once, then reload the page."
