Home Pagers Match FEES ROUTE TO v24.16

Matches the page number and both arrow controls in these sections:
- Top Tokens
- Top X Profiles
- Recent Payments
- Most Payments
- Off Ramp
- On Ramp

Target reference:
- FEES ROUTE TO text in the Launch card

Sizing:
- Desktop: 11px
- Mobile: 9px

Only pager typography size is changed.
No automatic server restart.

Install in the existing Replit Shell:

rm -rf /tmp/home_pagers_match_fees_route_v24_16 && mkdir -p /tmp/home_pagers_match_fees_route_v24_16 && unzip -o home_pagers_match_fees_route_v24_16.zip -d /tmp/home_pagers_match_fees_route_v24_16 && bash /tmp/home_pagers_match_fees_route_v24_16/install.sh
