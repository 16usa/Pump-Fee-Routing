from pathlib import Path

css_path = Path("src/styles.css")
if not css_path.exists():
    raise SystemExit("ERROR: src/styles.css not found. Run this from the existing Replit project root.")

css = css_path.read_text()
marker = "/* explore-restore-right-image-edge-fade-v24-45 */"

required = [
    ".home-explore-reference-v8",
    ".home-explore-v8-stage",
    ".home-explore-v8-secondary-slot",
    ".home-explore-v8-secondary-card",
    ".home-explore-v8-footer",
]
missing = [s for s in required if s not in css]
if missing:
    raise SystemExit("ERROR: required Explore selectors not found: " + ", ".join(missing))

if marker in css:
    print("No changes needed; v24.45 already installed.")
    raise SystemExit(0)

css += r'''

/* explore-restore-right-image-edge-fade-v24-45
   Restore the right editorial image and add an all-around inner edge fade.
   Bottom remains stronger; footer stays crisp above the effect. */

/* Restore right image geometry broken by v24.43's generic child positioning. */
.home-explore-reference-v8 .home-explore-v8-secondary-slot{
  display:block !important;
  visibility:visible !important;
  opacity:1 !important;
  overflow:visible !important;
  z-index:3 !important;
}

.home-explore-reference-v8 .home-explore-v8-secondary-slot > .home-explore-v8-secondary-card{
  position:absolute !important;
  inset:0 !important;
  width:100% !important;
  height:100% !important;
  min-width:0 !important;
  min-height:0 !important;
  display:block !important;
  visibility:visible !important;
  opacity:1 !important;
  z-index:3 !important;
  overflow:hidden !important;
}

.home-explore-reference-v8
.home-explore-v8-secondary-slot
.home-explore-v8-secondary-card
> .home-explore-v8-media{
  position:absolute !important;
  inset:0 !important;
  width:100% !important;
  height:100% !important;
  display:block !important;
  visibility:visible !important;
  opacity:1 !important;
  overflow:hidden !important;
  z-index:1 !important;
}

.home-explore-reference-v8
.home-explore-v8-secondary-slot
.home-explore-v8-art.secondary{
  position:absolute !important;
  inset:0 !important;
  width:100% !important;
  height:100% !important;
  display:block !important;
  visibility:visible !important;
  opacity:1 !important;
  object-fit:cover !important;
  object-position:52% center !important;
  z-index:1 !important;
  filter:grayscale(1) saturate(.15) contrast(1.08) brightness(.62) !important;
  transform:scale(1.07) !important;
}

/* Remove older per-slot blur overlays. */
.home-explore-reference-v8 .home-explore-v8-primary-slot::before,
.home-explore-reference-v8 .home-explore-v8-primary-slot::after,
.home-explore-reference-v8 .home-explore-v8-secondary-slot::before,
.home-explore-reference-v8 .home-explore-v8-secondary-slot::after{
  content:none !important;
  display:none !important;
  background:none !important;
  -webkit-backdrop-filter:none !important;
  backdrop-filter:none !important;
  -webkit-mask-image:none !important;
  mask-image:none !important;
}

.home-explore-reference-v8 .home-explore-v8-bottom-shade{
  display:none !important;
}

/* All-around inner edge effect: soft at top/sides, clear center. */
.home-explore-reference-v8 .home-explore-v8-stage::before{
  content:"" !important;
  display:block !important;
  position:absolute !important;
  inset:0 !important;
  z-index:8 !important;
  pointer-events:none !important;
  background:
    radial-gradient(
      ellipse 76% 68% at 50% 45%,
      rgba(10,10,10,0) 0%,
      rgba(10,10,10,0) 52%,
      rgba(10,10,10,.08) 66%,
      rgba(10,10,10,.20) 78%,
      rgba(10,10,10,.42) 90%,
      rgba(10,10,10,.66) 100%
    ) !important;
  -webkit-backdrop-filter:blur(7px) saturate(.96) !important;
  backdrop-filter:blur(7px) saturate(.96) !important;
  -webkit-mask-image:
    radial-gradient(
      ellipse 76% 68% at 50% 45%,
      transparent 0%,
      transparent 50%,
      rgba(0,0,0,.16) 64%,
      rgba(0,0,0,.46) 78%,
      rgba(0,0,0,.78) 90%,
      #000 100%
    ) !important;
  mask-image:
    radial-gradient(
      ellipse 76% 68% at 50% 45%,
      transparent 0%,
      transparent 50%,
      rgba(0,0,0,.16) 64%,
      rgba(0,0,0,.46) 78%,
      rgba(0,0,0,.78) 90%,
      #000 100%
    ) !important;
  -webkit-mask-repeat:no-repeat !important;
  mask-repeat:no-repeat !important;
  -webkit-mask-size:100% 100% !important;
  mask-size:100% 100% !important;
}

/* Stronger version of the same effect at the bottom. */
.home-explore-reference-v8 .home-explore-v8-stage::after{
  content:"" !important;
  display:block !important;
  position:absolute !important;
  left:0 !important;
  right:0 !important;
  top:auto !important;
  bottom:0 !important;
  height:38% !important;
  z-index:9 !important;
  pointer-events:none !important;
  background:
    linear-gradient(
      to top,
      rgba(10,10,10,.78) 0%,
      rgba(10,10,10,.52) 24%,
      rgba(10,10,10,.28) 50%,
      rgba(10,10,10,.10) 73%,
      rgba(10,10,10,0) 100%
    ) !important;
  -webkit-backdrop-filter:blur(11px) saturate(.94) !important;
  backdrop-filter:blur(11px) saturate(.94) !important;
  -webkit-mask-image:
    linear-gradient(
      to top,
      #000 0%,
      rgba(0,0,0,.96) 24%,
      rgba(0,0,0,.72) 52%,
      rgba(0,0,0,.32) 78%,
      transparent 100%
    ) !important;
  mask-image:
    linear-gradient(
      to top,
      #000 0%,
      rgba(0,0,0,.96) 24%,
      rgba(0,0,0,.72) 52%,
      rgba(0,0,0,.32) 78%,
      transparent 100%
    ) !important;
}

/* Footer above all effects. */
.home-explore-reference-v8 .home-explore-v8-footer{
  position:absolute !important;
  left:18px !important;
  right:18px !important;
  bottom:14px !important;
  z-index:20 !important;
  display:flex !important;
  align-items:center !important;
  justify-content:space-between !important;
  visibility:visible !important;
  opacity:1 !important;
  -webkit-filter:none !important;
  filter:none !important;
}

.home-explore-reference-v8 .home-explore-v8-footer strong,
.home-explore-reference-v8 .home-explore-v8-footer span{
  position:relative !important;
  z-index:21 !important;
  visibility:visible !important;
  opacity:1 !important;
  -webkit-filter:none !important;
  filter:none !important;
}

@media(max-width:640px){
  .home-explore-reference-v8 .home-explore-v8-stage::before{
    background:
      radial-gradient(
        ellipse 80% 70% at 50% 43%,
        rgba(10,10,10,0) 0%,
        rgba(10,10,10,0) 50%,
        rgba(10,10,10,.08) 64%,
        rgba(10,10,10,.22) 78%,
        rgba(10,10,10,.46) 91%,
        rgba(10,10,10,.68) 100%
      ) !important;
    -webkit-backdrop-filter:blur(7px) saturate(.96) !important;
    backdrop-filter:blur(7px) saturate(.96) !important;
  }

  .home-explore-reference-v8 .home-explore-v8-stage::after{
    height:40% !important;
    background:
      linear-gradient(
        to top,
        rgba(10,10,10,.80) 0%,
        rgba(10,10,10,.54) 25%,
        rgba(10,10,10,.29) 52%,
        rgba(10,10,10,.10) 75%,
        rgba(10,10,10,0) 100%
      ) !important;
    -webkit-backdrop-filter:blur(11px) saturate(.94) !important;
    backdrop-filter:blur(11px) saturate(.94) !important;
  }

  .home-explore-reference-v8 .home-explore-v8-footer{
    left:14px !important;
    right:14px !important;
    bottom:11px !important;
  }
}
'''

css_path.write_text(css)

print("PASS: right Explore image geometry restored.")
print("PASS: all-around inner edge fade/blur enabled.")
print("PASS: bottom edge remains stronger.")
print("PASS: Explore / Open → stay sharp above the effect.")
