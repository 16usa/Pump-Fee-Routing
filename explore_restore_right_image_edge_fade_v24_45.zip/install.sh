#!/usr/bin/env bash
set -euo pipefail

PATCH_NAME="explore_restore_right_image_edge_fade_v24_45"
CSS="src/styles.css"

if [ ! -f "$CSS" ]; then
  echo "ERROR: missing src/styles.css"
  echo "Run this from the existing Replit project root."
  exit 1
fi

echo "==> Installing ${PATCH_NAME}"
mkdir -p ".patch-backups/${PATCH_NAME}"
cp "$CSS" ".patch-backups/${PATCH_NAME}/styles.css.before"

python3 "$(dirname "$0")/patch.py"

echo "==> Verifying patch"
grep -q 'explore-restore-right-image-edge-fade-v24-45' "$CSS"
grep -q 'home-explore-v8-art.secondary' "$CSS"
grep -q 'height:38% !important' "$CSS"
grep -q 'z-index:20 !important' "$CSS"

echo "==> Running project check"
npm run check

echo "==> Git diff"
git diff --stat -- src/styles.css

git add src/styles.css
if git diff --cached --quiet; then
  echo "==> No new changes to commit."
else
  git commit -m "Restore Explore right image and edge fade"
  git push origin main
fi

echo
echo "PASS: ${PATCH_NAME} installed."
echo "No server restart was performed."
