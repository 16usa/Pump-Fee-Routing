Explore Restore Right Image + Edge Fade v24.45

Checked against current GitHub main before building.

Root cause of missing right image:
v24.43 added a generic rule that forced direct slot children to position:relative.
That overrode the secondary card's original absolute fill geometry.

This patch:
- restores the secondary card to absolute fill geometry
- explicitly restores the right image visibility
- removes old per-slot blur overlays
- adds one all-around inner blur/fade around the preview perimeter
- keeps the bottom edge stronger
- keeps Explore / Open → crisp above the effect
- does not change primary card geometry
- does not restart the server
