Top Tokens Recipient Chip v24.6

Changes only the small recipient pill inside Top Tokens cards:
- removes the frame / border around the small avatar inside the pill;
- slightly enlarges that avatar;
- enlarges the pill itself by the same proportion;
- enlarges the inner content too (money mark, name, verified badge);
- no automatic server restart.

Install in the existing Replit Shell:

rm -rf /tmp/top_tokens_recipient_chip_v24_6 && mkdir -p /tmp/top_tokens_recipient_chip_v24_6 && unzip -o top_tokens_recipient_chip_v24_6.zip -d /tmp/top_tokens_recipient_chip_v24_6 && bash /tmp/top_tokens_recipient_chip_v24_6/install.sh
