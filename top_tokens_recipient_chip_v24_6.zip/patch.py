from pathlib import Path

path = Path('src/styles.css')
css = path.read_text()

marker = '/* top-tokens-recipient-chip-v24-6 */'
if marker not in css:
    css += r'''

/* top-tokens-recipient-chip-v24-6
   Top Tokens: enlarge the recipient pill, enlarge the avatar and content,
   and remove the border / frame around the avatar inside the pill. */
.home-top-token-recipient{
  gap: 8px;
  min-height: 42px;
  padding: 6px 12px 6px 10px;
  border-radius: 999px;
}

.home-top-token-recipient .home-top-token-money-mark{
  width: 24px;
  height: 24px;
  min-width: 24px;
  font-size: 13px;
}

.home-top-token-recipient .avatar,
.home-top-token-recipient .recipient-avatar,
.home-top-token-recipient .recipient-avatar-wrap{
  width: 28px;
  height: 28px;
  min-width: 28px;
  min-height: 28px;
  box-shadow: none !important;
  border: 0 !important;
  outline: 0 !important;
}

.home-top-token-recipient .avatar img,
.home-top-token-recipient .recipient-avatar img,
.home-top-token-recipient .recipient-avatar-wrap img{
  width: 100%;
  height: 100%;
  border-radius: 50%;
  box-shadow: none !important;
  border: 0 !important;
  outline: 0 !important;
}

.home-top-token-recipient b{
  font-size: 19px;
  line-height: 1;
}

.home-top-token-recipient .x-verified-badge.x-verified-compact{
  width: 15px;
  height: 15px;
  flex-basis: 15px;
  margin-left: 5px;
}

@media (max-width: 640px){
  .home-top-token-recipient{
    gap: 7px;
    min-height: 38px;
    padding: 5px 11px 5px 9px;
  }

  .home-top-token-recipient .home-top-token-money-mark{
    width: 22px;
    height: 22px;
    min-width: 22px;
    font-size: 12px;
  }

  .home-top-token-recipient .avatar,
  .home-top-token-recipient .recipient-avatar,
  .home-top-token-recipient .recipient-avatar-wrap{
    width: 26px;
    height: 26px;
    min-width: 26px;
    min-height: 26px;
  }

  .home-top-token-recipient b{
    font-size: 17px;
  }

  .home-top-token-recipient .x-verified-badge.x-verified-compact{
    width: 14px;
    height: 14px;
    flex-basis: 14px;
  }
}
'''
    path.write_text(css)
    print('src/styles.css: Top Tokens recipient chip enlarged and avatar frame removed')
else:
    print('src/styles.css: patch already installed')

print('PASS: CSS patch prepared')
