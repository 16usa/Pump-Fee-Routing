Pump Fee Routing — X Profile v1
Rebuilds each #/profile/<handle> page using the existing real profile API.
Includes X identity, bio/avatar when available, Total Received, Owed/Earned/Sent totals, Top Token, all associated tokens, payout history, and recipient-not-endorsement disclosure.
Opted-out handles render a private/disabled state instead of token/payment details.
No backend, database, payout, claim, Solana or worker execution logic is changed.
Runs npm check, commits, and pushes to origin/main. No automatic server restart.
