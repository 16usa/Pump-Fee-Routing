from pathlib import Path
import re

path = Path("src/styles.css")
css = path.read_text()

marker = "/* top-token-explore-badges-v21-1 */"
start = css.find(marker)
if start < 0:
    raise SystemExit("ERROR: top-token-explore-badges-v21-1 block not found")

tail = css[start:]

desktop_pattern = re.compile(
    r'(\.home-top-token-card\[data-top-token-layout="v21"\] \.home-top-token-recipient>b\{\s*'
    r'min-width:0;\s*overflow:hidden;\s*text-overflow:ellipsis;\s*white-space:nowrap;\s*'
    r'color:#f1f1f1;\s*)font-size:\d+px;(\s*line-height:1;\s*font-weight:650;\s*\})',
    re.S
)
tail, n1 = desktop_pattern.subn(r'\g<1>font-size:12px;\2', tail, count=1)
if n1 != 1:
    raise SystemExit("ERROR: specific desktop recipient name rule not found")

mobile_pattern = re.compile(
    r'(\.home-top-token-card\[data-top-token-layout="v21"\] \.home-top-token-recipient>b,\s*'
    r'\.home-top-token-card\[data-top-token-layout="v21"\] \.home-top-token-recipient>span\{\s*)'
    r'font-size:\d+px;(\s*\})',
    re.S
)
tail, n2 = mobile_pattern.subn(r'\g<1>font-size:12px;\2', tail, count=1)
if n2 != 1:
    raise SystemExit("ERROR: specific mobile recipient name rule not found")

css = css[:start] + tail

final_marker = "/* top-tokens-name-conflict-fix-v24-10 */"
if final_marker not in css:
    css += r'''

/* top-tokens-name-conflict-fix-v24-10 */
.home-top-token-card[data-top-token-layout="v21"] .home-top-token-recipient>b.x-recipient-name{
  font-size:12px !important;
  line-height:1 !important;
  font-weight:650 !important;
}

@media(max-width:640px){
  .home-top-token-card[data-top-token-layout="v21"] .home-top-token-recipient>b.x-recipient-name{
    font-size:12px !important;
  }
}
'''

path.write_text(css)
print("PASS: fixed actual high-specificity Top Tokens name rule")
