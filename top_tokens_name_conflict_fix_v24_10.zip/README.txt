Top Tokens Name Conflict Fix v24.10

Cause found:
The previous patches changed `.home-top-token-recipient b`, but the project already has a more specific selector:

.home-top-token-card[data-top-token-layout="v21"] .home-top-token-recipient>b

That selector was forcing GG to 11px desktop / 9px mobile, so the generic later rules did not visually change the name.

This patch fixes the actual specific rule and locks GG to 12px, matching the Launch identity row. The verified badge is left unchanged.

Install in the existing Replit Shell:

rm -rf /tmp/top_tokens_name_conflict_fix_v24_10 && mkdir -p /tmp/top_tokens_name_conflict_fix_v24_10 && unzip -o top_tokens_name_conflict_fix_v24_10.zip -d /tmp/top_tokens_name_conflict_fix_v24_10 && bash /tmp/top_tokens_name_conflict_fix_v24_10/install.sh

No automatic server restart.
