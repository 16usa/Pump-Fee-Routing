#!/usr/bin/env bash
set -euo pipefail

for f in src/app.js src/styles.css; do
  [ -f "$f" ] || {
    echo "Missing $f. Run this from the Pump-Fee-Routing project root."
    exit 1
  }
done

if [ -n "$(git status --porcelain -- src/app.js src/styles.css)" ]; then
  echo "STOP: src/app.js or src/styles.css has uncommitted changes."
  git status --short -- src/app.js src/styles.css
  exit 2
fi

python3 - <<'PY'
from pathlib import Path
import base64

app_path=Path("src/app.js")
css_path=Path("src/styles.css")
app=app_path.read_text()
css=css_path.read_text()

marker="launch-demo-bell-v1"
if marker in app or marker in css:
    raise SystemExit("Launch Demo Bell v1 is already installed.")

old=base64.b64decode("PHNwYW4gY2xhc3M9ImxhdW5jaC1kZW1vLWJlbGwiIGFyaWEtaGlkZGVuPSJ0cnVlIj7il5Q8L3NwYW4+").decode()
new=base64.b64decode("PHNwYW4gY2xhc3M9ImxhdW5jaC1kZW1vLWJlbGwiIGFyaWEtaGlkZGVuPSJ0cnVlIj48c3ZnIHZpZXdCb3g9IjAgMCAyNCAyNCIgZm9jdXNhYmxlPSJmYWxzZSI+PHBhdGggZD0iTTEyIDIyYTIuMjUgMi4yNSAwIDAgMCAyLjEyLTEuNUg5Ljg4QTIuMjUgMi4yNSAwIDAgMCAxMiAyMlptNy01LjI1LTEuNDUtMS43VjEwYTUuNTUgNS41NSAwIDAgMC00LjMtNS40MlYzLjc1YTEuMjUgMS4yNSAwIDAgMC0yLjUgMHYuODNBNS41NSA1LjU1IDAgMCAwIDYuNDUgMTB2NS4wNUw1IDE2Ljc1YTEgMSAwIDAgMCAuNzYgMS42NWgxMi40OGExIDEgMCAwIDAgLjc2LTEuNjVaIi8+PC9zdmc+PC9zcGFuPg==").decode()
css_add=base64.b64decode("Ci8qIGxhdW5jaC1kZW1vLWJlbGwtdjEgKi8KLmxhdW5jaC1kZW1vLXJvdGF0b3J7CiAgcG9zaXRpb246cmVsYXRpdmU7Cn0KLmxhdW5jaC1kZW1vLWNhcmQtZW5kewogIGFsaWduLXNlbGY6ZmxleC1zdGFydDsKICBwYWRkaW5nLXRvcDoycHg7Cn0KLmxhdW5jaC1kZW1vLWJlbGx7CiAgd2lkdGg6MThweDsKICBoZWlnaHQ6MThweDsKICBkaXNwbGF5OmdyaWQ7CiAgcGxhY2UtaXRlbXM6Y2VudGVyOwogIGNvbG9yOiNmNGY0ZjQ7Cn0KLmxhdW5jaC1kZW1vLWJlbGwgc3ZnewogIHdpZHRoOjE2cHg7CiAgaGVpZ2h0OjE2cHg7CiAgZGlzcGxheTpibG9jazsKICBmaWxsOmN1cnJlbnRDb2xvcjsKfQo=").decode()

if old not in app:
    raise SystemExit("Bell anchor not found in src/app.js.")

app=app.replace(old,new,1)
css += css_add
app += "\n/* "+marker+" */\n"

app_path.write_text(app)
css_path.write_text(css)
print("Launch Demo Bell v1 installed.")
PY

node --check src/app.js
npm run check

node <<'NODE'
const fs=require('fs');
const app=fs.readFileSync('src/app.js','utf8');
const css=fs.readFileSync('src/styles.css','utf8');

const checks=[
  ['bell svg added', app.includes('class="launch-demo-bell"') && app.includes('<svg viewBox="0 0 24 24"')],
  ['old circle icon removed', !app.includes('class="launch-demo-bell" aria-hidden="true">◔</span>')],
  ['bell positioned at top', css.includes('.launch-demo-card-end{') && css.includes('align-self:flex-start;')],
  ['bell white/currentColor', css.includes('.launch-demo-bell svg{') && css.includes('fill:currentColor;')],
  ['token preview untouched', app.includes('function updateLaunchPreview()')],
  ['patch marker', app.includes('launch-demo-bell-v1') || css.includes('launch-demo-bell-v1')]
];

let bad=0;
for(const [name,ok] of checks){
  console.log((ok?'PASS':'FAIL')+' '+name);
  if(!ok)bad++;
}
if(bad)process.exit(1);
NODE

git add src/app.js src/styles.css

if git diff --cached --quiet; then
  echo "No staged changes; nothing to commit."
else
  git commit -m "Polish Launch demo bell icon"
fi

git push origin main

echo
echo "DONE: Launch Demo Bell v1 checked, committed, and pushed to GitHub."
echo "Only the animated notification bell was changed."
echo "Token preview and the rest of Launch were not modified."
echo "No server restart was performed."
echo "Restart Console/Run manually once to load the update."
