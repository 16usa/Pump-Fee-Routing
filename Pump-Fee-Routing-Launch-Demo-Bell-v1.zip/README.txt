Pump Fee Routing — Launch Demo Bell v1

Changes ONLY the bell icon in the animated Launch notification block.

- Replaces the temporary circle/clock glyph with a clean inline bell SVG
- Places it at the top-right of the Paid notification scene
- Keeps all current demo logic and all 10 scenes
- Does not touch token preview or the rest of the Launch page
- Installer checks, commits, and pushes origin/main
- No automatic server restart
