Home Pager Current / Total v24.22

Changes pager labels from a single page number to current / total:
- 1 / 1
- 1 / 2
- 1 / 3
etc.

Applies to:
- Top Tokens (20 items per page)
- Top X Profiles (4 per page)
- Recent Payments (6 per page)
- Most Payments (6 per page)
- Off-ramp (6 per page)
- On-ramp (6 per page)

This patch changes the displayed counter only. It does not add new paging behavior
or automatic server restart.

Install in the existing Replit Shell:

rm -rf /tmp/home_pager_current_total_v24_22 && mkdir -p /tmp/home_pager_current_total_v24_22 && unzip -o home_pager_current_total_v24_22.zip -d /tmp/home_pager_current_total_v24_22 && bash /tmp/home_pager_current_total_v24_22/install.sh
