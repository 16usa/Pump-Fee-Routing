
from pathlib import Path

path = Path("src/app.js")
if not path.exists():
    raise SystemExit("ERROR: src/app.js not found. Run from the existing Replit project root.")

s = path.read_text()

replacements = [
(
"""function homeTopTokens(top){
  const rows=top.slice(0,20);""",
"""function homeTopTokens(top){
  const totalPages=Math.max(1,Math.ceil((top||[]).length/20));
  const rows=top.slice(0,20);"""
),
(
"""<div class="home-top-token-pager"><button disabled>‹</button><span>1</span><button disabled>›</button></div>""",
"""<div class="home-top-token-pager"><button disabled>‹</button><span>1 / ${totalPages}</span><button disabled>›</button></div>"""
),
(
"""function homeTopProfiles(profiles){
  const rows=(profiles||[]).slice(0,4);""",
"""function homeTopProfiles(profiles){
  const totalPages=Math.max(1,Math.ceil((profiles||[]).length/4));
  const rows=(profiles||[]).slice(0,4);"""
),
(
"""<div class="home-top-profiles-pager"><button disabled>‹</button><span>1</span><button disabled>›</button></div>""",
"""<div class="home-top-profiles-pager"><button disabled>‹</button><span>1 / ${totalPages}</span><button disabled>›</button></div>"""
),
(
"""function homeRecentPayments(h){
  const payments=(h.payments||[]).slice(0,6);""",
"""function homeRecentPayments(h){
  const totalPages=Math.max(1,Math.ceil((h.payments||[]).length/6));
  const payments=(h.payments||[]).slice(0,6);"""
),
(
"""<div class="home-recent-payments-pager"><button disabled>‹</button><span>1</span><button disabled>›</button></div>""",
"""<div class="home-recent-payments-pager"><button disabled>‹</button><span>1 / ${totalPages}</span><button disabled>›</button></div>"""
),
(
"""function homeMostPayments(h){
  const rows=(h.money?.topPaid||[]).slice(0,6);""",
"""function homeMostPayments(h){
  const totalPages=Math.max(1,Math.ceil((h.money?.topPaid||[]).length/6));
  const rows=(h.money?.topPaid||[]).slice(0,6);"""
),
(
"""<div class="home-most-payments-pager"><button disabled>‹</button><span>1 / 1</span><button disabled>›</button></div>""",
"""<div class="home-most-payments-pager"><button disabled>‹</button><span>1 / ${totalPages}</span><button disabled>›</button></div>"""
),
(
"""function homeOffRamp(h){
  const exchanges=(h.money?.exchange||[]).slice(0,6);""",
"""function homeOffRamp(h){
  const totalPages=Math.max(1,Math.ceil((h.money?.exchange||[]).length/6));
  const exchanges=(h.money?.exchange||[]).slice(0,6);"""
),
(
"""<div class="home-off-pager"><button disabled>‹</button><span>1</span><button disabled>›</button></div>""",
"""<div class="home-off-pager"><button disabled>‹</button><span>1 / ${totalPages}</span><button disabled>›</button></div>"""
),
(
"""function homeOnRamp(h){
  const orders=(h.money?.exchange||[]).filter(isOnRampOrder).slice(0,6);
  const inTransit=orders.reduce((sum,x)=>sum+Number(x.received_usd||x.gross_usd||0),0);""",
"""function homeOnRamp(h){
  const allOrders=(h.money?.exchange||[]).filter(isOnRampOrder);
  const totalPages=Math.max(1,Math.ceil(allOrders.length/6));
  const orders=allOrders.slice(0,6);
  const inTransit=orders.reduce((sum,x)=>sum+Number(x.received_usd||x.gross_usd||0),0);"""
),
(
"""<div class="home-on-pager"><button disabled>‹</button><span>1</span><button disabled>›</button></div>""",
"""<div class="home-on-pager"><button disabled>‹</button><span>1 / ${totalPages}</span><button disabled>›</button></div>"""
),
]

changed = 0
for old, new in replacements:
    if new in s:
        continue
    if old not in s:
        raise SystemExit("ERROR: expected app.js block not found:\n" + old[:120])
    s = s.replace(old, new, 1)
    changed += 1

path.write_text(s)
print(f"PASS: pager current/total labels added ({changed} edits)")
