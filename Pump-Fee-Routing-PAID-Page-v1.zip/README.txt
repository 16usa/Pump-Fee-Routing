Pump Fee Routing — $PAID Page v1
Rebuilds the protocol-cut/$PAID page using the reference site's structure while keeping this project's current backend semantics.
Includes hero, not-launched state, token purpose, 80/20 mechanics, buy/burn steps, cross-chain explanation, returned-payment accounting, and live ledger totals.
No live buy, burn, payout, Solana, worker, or database execution is enabled by this patch.
Runs npm check, commits, and pushes to origin/main. No automatic server restart.
