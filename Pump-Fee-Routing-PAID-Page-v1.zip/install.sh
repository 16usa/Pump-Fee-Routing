#!/usr/bin/env bash
set -euo pipefail

if [ ! -f src/app.js ] || [ ! -f src/styles.css ]; then
  echo "Run this from the Pump-Fee-Routing project root."
  exit 1
fi

if [ -n "$(git status --porcelain -- src/app.js src/styles.css)" ]; then
  echo "STOP: src/app.js or src/styles.css has uncommitted changes."
  git status --short -- src/app.js src/styles.css
  exit 2
fi

python3 - <<'PY'
from pathlib import Path

app_path = Path("src/app.js")
css_path = Path("src/styles.css")
app = app_path.read_text()
css = css_path.read_text()

marker = "/* paid-page-v1-reference */"
if marker in css:
    raise SystemExit("$PAID page v1 is already installed.")

start = app.find("function paidPage(){")
end = app.find("function optOutPage(){", start)
if start < 0 or end < 0:
    raise SystemExit("Could not locate paidPage()/optOutPage().")

replacement = r'''function paidInfoCard(label,value){
  return `<div class="paid-info-card"><span>${esc(label)}</span><b>${value}</b></div>`;
}

function paidStep(n,title,body){
  return `<div class="paid-step">
    <div class="paid-step-number">${esc(n)}</div>
    <div><h3>${esc(title)}</h3><p>${body}</p></div>
  </div>`;
}

function paidPage(){
  const m=state.money||{};
  const recipientPct=fmtNum((state.brand.recipientShareBps||8000)/100);
  const protocolPct=fmtNum((state.brand.protocolShareBps||2000)/100);

  return `<main class="paid-page">
    <section class="wrap paid-hero">
      <p class="eyebrow">Protocol</p>
      <h1>$PAID</h1>
      <p class="paid-lead">Each confirmed fee claim is split between the named recipient and the protocol. The recipient share is paid through the configured payout rail; the protocol share is reserved for open-market $PAID buybacks and burns.</p>

      <div class="paid-not-live">
        <span>Not launched yet</span>
        <h2>$PAID has not been issued.</h2>
        <p>Until a project token is launched and its execution policy is enabled, protocol-cut balances remain in the ledger as pending buybacks. No buy or burn is executed automatically by this page.</p>
      </div>
    </section>

    <section class="wrap paid-section">
      <h2>What it is for</h2>
      <p class="paid-copy">$PAID is designed as the protocol's value-accrual token rather than a governance or access token. Its role is simple: the protocol allocation can be used to buy the token on the open market and remove the purchased supply.</p>

      <div class="paid-info-grid">
        ${paidInfoCard('Ticker','$PAID')}
        ${paidInfoCard('Home chain','Solana')}
        ${paidInfoCard('Recipient share',`${recipientPct}%`)}
        ${paidInfoCard('Protocol share',`${protocolPct}%`)}
        ${paidInfoCard('Pending buybacks',fmtMoney(m.protocolPending||0))}
        ${paidInfoCard('Mechanism','Market buy → burn')}
      </div>
    </section>

    <section class="wrap paid-section">
      <h2>How the buy and burn works</h2>
      <div class="paid-steps">
        ${paidStep('1','A claim settles','Creator fees are claimed on chain and recorded as a fee event with a unique transaction reference.')}
        ${paidStep('2','The protocol cut is set aside',`${protocolPct}% of the confirmed claim is tracked separately as protocol accounting instead of recipient money.`)}
        ${paidStep('3','$PAID is bought on the open market','When live buyback execution is explicitly enabled, the protocol can acquire the token through the configured market adapter at prevailing market prices.')}
        ${paidStep('4','Purchased supply is burned','The resulting token amount can be sent to the configured burn destination, with transaction references retained for reconciliation.')}
      </div>
    </section>

    <section class="wrap paid-section paid-chain-section">
      <h2>Fees from other chains</h2>
      <p class="paid-copy">If additional launch rails are enabled later, their creator fees can still feed the same protocol accounting. Cross-chain movement belongs at the treasury layer; recipient payouts remain separate from that bridge path.</p>

      <div class="paid-flow-card">
        <div><span>Origin fees</span><b>Pump / future rails</b></div>
        <i>→</i>
        <div><span>Treasury</span><b>Reconciled balance</b></div>
        <i>→</i>
        <div><span>Buyback</span><b>$PAID on Solana</b></div>
      </div>
    </section>

    <section class="wrap paid-section">
      <h2>Unclaimed or returned payments</h2>
      <p class="paid-copy">If a payout provider returns an unclaimed recipient payment, that event should be recorded separately from the normal protocol cut. This keeps recipient reversals distinguishable from the fixed protocol allocation in the ledger.</p>

      <div class="paid-ledger-card">
        <div><span>Protocol cut pending</span><b>${fmtMoney(m.protocolPending||0)}</b></div>
        <div><span>Recipient currently owed</span><b>${fmtMoney(m.totalOwed||0)}</b></div>
        <div><span>Total paid</span><b>${fmtMoney(m.totalPaid||0)}</b></div>
      </div>
    </section>

    ${moneyFooter()}
  </main>`;
}
'''

app = app[:start] + replacement + app[end:]
app_path.write_text(app)

css += r'''

/* paid-page-v1-reference */
.paid-page{
  padding-top:56px;
  background:#000;
  color:#fff;
}
.paid-page .wrap{
  width:min(100% - 32px,720px);
}
.paid-hero{
  padding-top:10px;
  padding-bottom:18px;
}
.paid-hero .eyebrow{
  margin:0 0 18px;
  color:#676767;
  font-size:13px;
}
.paid-hero h1{
  margin:0;
  font-size:68px;
  line-height:.92;
  letter-spacing:-.06em;
  font-weight:560;
}
.paid-lead{
  max-width:680px;
  margin:25px 0 0;
  color:#929292;
  font-size:17px;
  line-height:1.55;
}
.paid-not-live{
  margin-top:42px;
  padding:27px 28px;
  border:1px solid #292929;
  border-radius:18px;
  background:#111;
}
.paid-not-live>span{
  display:inline-block;
  margin-bottom:12px;
  padding:7px 10px;
  border-radius:999px;
  background:#232323;
  color:#b2b2b2;
  font-size:10px;
  font-weight:650;
}
.paid-not-live h2{
  margin:0;
  font-size:25px;
  font-weight:550;
  letter-spacing:-.03em;
}
.paid-not-live p{
  margin:13px 0 0;
  color:#858585;
  font-size:13px;
  line-height:1.52;
}
.paid-section{
  padding-top:72px;
}
.paid-section>h2{
  margin:0 0 18px;
  font-size:31px;
  line-height:1;
  letter-spacing:-.04em;
  font-weight:540;
}
.paid-copy{
  max-width:680px;
  margin:0;
  color:#878787;
  font-size:14px;
  line-height:1.58;
}
.paid-info-grid{
  display:grid;
  grid-template-columns:1fr 1fr;
  gap:10px;
  margin-top:27px;
}
.paid-info-card{
  min-height:92px;
  display:grid;
  align-content:space-between;
  gap:15px;
  padding:16px 17px;
  border:1px solid #292929;
  border-radius:14px;
  background:#111;
}
.paid-info-card span{
  color:#686868;
  font-size:11px;
  font-weight:600;
}
.paid-info-card b{
  color:#fff;
  font-size:18px;
  font-weight:560;
}
.paid-steps{
  margin-top:10px;
  border-top:1px solid #202020;
}
.paid-step{
  display:grid;
  grid-template-columns:38px 1fr;
  gap:16px;
  padding:27px 0;
  border-bottom:1px solid #202020;
}
.paid-step-number{
  width:32px;
  height:32px;
  display:grid;
  place-items:center;
  border:1px solid #303030;
  border-radius:50%;
  color:#787878;
  font-size:10px;
  font-weight:700;
}
.paid-step h3{
  margin:1px 0 10px;
  font-size:21px;
  line-height:1.1;
  font-weight:550;
}
.paid-step p{
  margin:0;
  color:#858585;
  font-size:13px;
  line-height:1.52;
}
.paid-flow-card{
  margin-top:27px;
  padding:19px;
  display:grid;
  grid-template-columns:1fr auto 1fr auto 1fr;
  align-items:center;
  gap:12px;
  border:1px solid #292929;
  border-radius:16px;
  background:#101010;
}
.paid-flow-card>div{
  min-width:0;
  display:grid;
  gap:7px;
}
.paid-flow-card span{
  color:#666;
  font-size:10px;
}
.paid-flow-card b{
  overflow:hidden;
  text-overflow:ellipsis;
  color:#fff;
  font-size:13px;
  font-weight:550;
}
.paid-flow-card i{
  color:#555;
  font-size:17px;
  font-style:normal;
}
.paid-ledger-card{
  display:grid;
  grid-template-columns:repeat(3,1fr);
  gap:10px;
  margin-top:27px;
}
.paid-ledger-card>div{
  min-height:94px;
  display:grid;
  align-content:space-between;
  gap:13px;
  padding:16px;
  border:1px solid #292929;
  border-radius:14px;
  background:#111;
}
.paid-ledger-card span{
  color:#666;
  font-size:10px;
}
.paid-ledger-card b{
  font-size:18px;
  font-weight:560;
}
.paid-page .money-footer{
  margin-top:78px;
}

@media(max-width:640px){
  .paid-page{padding-top:42px}
  .paid-page .wrap{width:calc(100% - 32px)}
  .paid-hero{padding-top:5px}
  .paid-hero .eyebrow{margin-bottom:14px;font-size:10px}
  .paid-hero h1{font-size:52px}
  .paid-lead{margin-top:20px;font-size:13px;line-height:1.52}
  .paid-not-live{
    margin-top:32px;
    padding:21px 19px;
    border-radius:15px;
  }
  .paid-not-live h2{font-size:21px}
  .paid-not-live p{font-size:11px}
  .paid-section{padding-top:56px}
  .paid-section>h2{margin-bottom:15px;font-size:24px}
  .paid-copy{font-size:11px}
  .paid-info-grid{gap:8px;margin-top:21px}
  .paid-info-card{
    min-height:78px;
    padding:13px;
    border-radius:12px;
  }
  .paid-info-card span{font-size:9px}
  .paid-info-card b{font-size:15px}
  .paid-step{
    grid-template-columns:32px 1fr;
    gap:12px;
    padding:22px 0;
  }
  .paid-step-number{width:28px;height:28px;font-size:8px}
  .paid-step h3{font-size:18px;margin-bottom:8px}
  .paid-step p{font-size:11px}
  .paid-flow-card{
    grid-template-columns:1fr;
    gap:10px;
    margin-top:21px;
    padding:16px;
  }
  .paid-flow-card i{transform:rotate(90deg)}
  .paid-flow-card span{font-size:9px}
  .paid-flow-card b{font-size:12px}
  .paid-ledger-card{
    grid-template-columns:1fr;
    gap:8px;
    margin-top:21px;
  }
  .paid-ledger-card>div{
    min-height:74px;
    padding:13px;
  }
  .paid-ledger-card span{font-size:9px}
  .paid-ledger-card b{font-size:16px}
  .paid-page .money-footer{margin-top:60px}
}
'''
css_path.write_text(css)

print("$PAID page v1 patch installed.")
PY

npm run check

git add src/app.js src/styles.css

if git diff --cached --quiet; then
  echo "No staged changes; nothing to commit."
else
  git commit -m "Rebuild PAID protocol page"
fi

git push origin main

echo
echo "DONE: PAID page v1 checked, committed, and pushed to GitHub."
echo "No server restart was performed."
echo "Restart Console/Run manually if the old page is still being served."
