Pump Fee Routing — Explore Card Info v15.1

Fixes the installer verification bug from v15.

Important:
- The previous v15 DID already modify src/app.js and src/styles.css before its verification stopped.
- v15.1 is designed to detect that partial installation and continue safely.
- It does not duplicate the patch.
- It runs npm run check, commits, and pushes.
- It does not restart the server.

Install from the existing Replit Shell:

rm -rf /tmp/explore-card-info-v15-1
mkdir -p /tmp/explore-card-info-v15-1
unzip -o Pump-Fee-Routing-Explore-Card-Info-v15.1.zip -d /tmp/explore-card-info-v15-1
bash /tmp/explore-card-info-v15-1/install.sh

After DONE, restart Run/Console manually once.
