#!/usr/bin/env bash
set -euo pipefail

echo "== Explore Card Info v15.1 =="

for f in src/app.js src/styles.css; do
  if [ ! -f "$f" ]; then
    echo "ERROR: $f not found. Run this from the existing Replit project workspace."
    exit 1
  fi
done

python3 <<'PY'
from pathlib import Path
import re

app_path = Path("src/app.js")
css_path = Path("src/styles.css")

app = app_path.read_text()
css = css_path.read_text()

old = """            return `<div class="home-explore-v8-primary-card">
              <div class="home-explore-v8-media">
                ${renderTokenArt(token, 'primary')}
                <div class="home-top-token-age" data-explore-age-badge="v14">${esc(ageText || '')}</div>
                ${renderRecipient(token)}
                <div class="home-explore-v8-copy">
                  <div class="home-explore-v8-title"><strong>${esc(token.name || 'Token')}</strong><span>${esc(token.symbol || '')}</span></div>
                  <div class="home-explore-v8-stats"><span>${fmtMc(token.mc ?? token.market_cap_usd)} MC</span><b>${fmtMoney(token.sent || 0)}</b></div>
                </div>
              </div>
            </div>`;"""

new = """            return `<div class="home-explore-v8-primary-card" data-explore-card-info="v15">
              <div class="home-explore-v8-media">
                ${renderTokenArt(token, 'primary')}
                <div class="home-top-token-age" data-explore-age-badge="v14">${esc(ageText || '')}</div>
                ${renderRecipient(token)}
              </div>
              <div class="home-explore-v8-copy">
                <div class="home-explore-v8-title">
                  <strong>${esc(token.name || 'Token')}</strong>
                  <span>${esc(token.symbol || '')}</span>
                </div>
                <div class="home-explore-v8-stats">
                  <span>${fmtMc(token.mc ?? token.market_cap_usd)} MC</span>
                  <b><strong>${fmtMoney(token.sent || 0)}</strong><small>Sent</small></b>
                </div>
              </div>
            </div>`;"""

if 'data-explore-card-info="v15"' in app:
    print("PASS app structure already patched from previous v15 attempt")
elif old in app:
    app = app.replace(old, new, 1)
    app_path.write_text(app)
    print("PASS token information moved below image")
else:
    raise SystemExit("ERROR: Explore primary-card source block not found. Nothing changed.")

marker = "/* explore-card-info-v15 */"
css_patch = r"""
/* explore-card-info-v15 */

/* Left Explore token becomes a real two-part card:
   image above, data area below, shared Explore/Open footer untouched. */
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"]{
  box-sizing:border-box;
  display:grid;
  grid-template-rows:minmax(0,1fr) 62px;
  padding-bottom:42px;
  background:#0b0b0b;
}

.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] > .home-explore-v8-media{
  width:100%;
  height:auto;
  min-height:0;
  overflow:hidden;
  background:#0a0a0a;
}

/* Recipient pill remains over the image. */
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-recipient{
  left:12px;
  bottom:10px;
}

/* Token copy is a separate card section, not an image overlay. */
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] > .home-explore-v8-copy{
  position:relative;
  left:auto;
  right:auto;
  bottom:auto;
  z-index:6;
  box-sizing:border-box;
  display:grid;
  align-content:center;
  gap:5px;
  width:100%;
  min-width:0;
  padding:9px 13px 10px;
  border-top:1px solid #272727;
  background:#0b0b0b;
}

.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-title{
  display:flex;
  align-items:baseline;
  gap:7px;
  min-width:0;
}
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-title strong{
  min-width:0;
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
  color:#efefef;
  font-size:12px;
  line-height:1.15;
  font-weight:650;
}
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-title span{
  flex:0 0 auto;
  color:#6f6f6f;
  font-size:9px;
  line-height:1.15;
  font-weight:450;
}

.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-stats{
  display:flex;
  align-items:baseline;
  justify-content:space-between;
  gap:10px;
  min-width:0;
  color:#696969;
  font-size:9px;
  line-height:1.15;
}
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-stats > b{
  display:flex;
  align-items:baseline;
  gap:4px;
  flex:0 0 auto;
  color:#e8e8e8;
  font-size:12px;
  line-height:1.15;
  font-weight:650;
}
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-stats > b > strong{
  color:inherit;
  font:inherit;
}
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-stats > b > small{
  color:#666;
  font-size:9px;
  line-height:1.15;
  font-weight:450;
}

/* Keep only the footer fade needed for Explore/Open. */
.home-explore-reference-v8 .home-explore-v8-bottom-shade{
  height:18%;
  background:linear-gradient(180deg,rgba(23,23,23,0) 0%,rgba(23,23,23,.48) 52%,#171717 100%);
}

@media (max-width:640px){
  .home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"]{
    grid-template-rows:minmax(0,1fr) 53px;
    padding-bottom:36px;
  }
  .home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-recipient{
    left:8px;
    bottom:8px;
  }
  .home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] > .home-explore-v8-copy{
    gap:3px;
    padding:7px 10px 8px;
  }
  .home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-title strong{
    font-size:10px;
  }
  .home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-title span{
    font-size:7px;
  }
  .home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-stats{
    font-size:7px;
  }
  .home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-stats > b{
    gap:3px;
    font-size:10px;
  }
  .home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-stats > b > small{
    font-size:7px;
  }
  .home-explore-reference-v8 .home-explore-v8-bottom-shade{
    height:17%;
  }
}
"""

if marker not in css:
    css_path.write_text(css + "\n" + css_patch + "\n")
    print("PASS Explore v15 CSS added")
else:
    print("PASS CSS from previous v15 attempt already present")

# Robust verification. The previous v15 failed because its string check was too strict.
app = app_path.read_text()
css = css_path.read_text()

block_match = re.search(
    r'<div class="home-explore-v8-primary-card" data-explore-card-info="v15">(?P<body>.*?)</div>`;',
    app,
    flags=re.S
)
if not block_match:
    raise SystemExit("ERROR: v15 Explore card block not found after patching.")

body = block_match.group("body")
media_close = body.find("${renderRecipient(token)}")
copy_pos = body.find('<div class="home-explore-v8-copy">')
if media_close < 0 or copy_pos < 0 or copy_pos <= media_close:
    raise SystemExit("ERROR: copy is not positioned after the media content.")

checks = {
    "v15 card marker": 'data-explore-card-info="v15"' in app,
    "Sent label": '<small>Sent</small>' in app,
    "MC preserved": '${fmtMc(token.mc ?? token.market_cap_usd)} MC' in app,
    "age badge preserved": 'data-explore-age-badge="v14"' in app,
    "recipient pill preserved": '${renderRecipient(token)}' in body,
    "v15 CSS marker": marker in css,
    "copy section selector": '> .home-explore-v8-copy' in css,
}
for label, ok in checks.items():
    if not ok:
        raise SystemExit(f"ERROR: verification failed: {label}")
    print("PASS", label)

print("PASS robust structure verification")
PY

echo
echo "== Project checks =="
npm run check

echo
echo "== Git diff =="
git diff --stat

git add src/app.js src/styles.css

if git diff --cached --quiet; then
  echo "No new changes to commit (patch may already be installed and committed)."
else
  git commit -m "Separate Explore token image and stats"
  git push
fi

echo
echo "DONE: Explore Card Info v15.1 installed, checked, committed, and pushed."
echo "No server restart was performed."
echo "Restart Run/Console manually once, then reload the page."
