#!/usr/bin/env bash
set -euo pipefail

if [ ! -f src/app.js ] || [ ! -f src/styles.css ]; then
  echo "Run this from the Pump-Fee-Routing project root."
  exit 1
fi

if [ -n "$(git status --porcelain -- src/app.js src/styles.css)" ]; then
  echo "STOP: src/app.js or src/styles.css has uncommitted changes."
  git status --short -- src/app.js src/styles.css
  exit 2
fi

python3 - <<'PY'
from pathlib import Path

app_path = Path("src/app.js")
css_path = Path("src/styles.css")
app = app_path.read_text()
css = css_path.read_text()

marker = "/* capital-flow-v1-reference */"
if marker in css:
    raise SystemExit("Capital Flow v1 is already installed.")

start = app.find("function capitalFlowPage(){")
end = app.find("function paidPage(){", start)
if start < 0 or end < 0:
    raise SystemExit("Could not locate capitalFlowPage()/paidPage().")

replacement = r'''function capitalFlowStep(n,title,body,kind=''){
  return `<section class="capital-flow-step ${kind}">
    <div class="capital-flow-step-index">${esc(n)}</div>
    <div>
      <h2>${esc(title)}</h2>
      <div class="capital-flow-step-copy">${body}</div>
    </div>
  </section>`;
}

function capitalFlowPage(){
  const m=state.money||{};
  const exchanges=m.exchange||[];
  const offRamp=exchanges.filter(x=>!isOnRampOrder(x)).slice(0,8);

  return `<main class="capital-flow-page">
    <section class="wrap capital-flow-hero">
      <p class="eyebrow">Protocol</p>
      <h1>Capital flow</h1>
      <p class="capital-flow-lead">Creator fees from pump.fun are claimed on a schedule, converted through the configured exchange rail, and recorded for recipient payout. The protocol share covers execution costs and the project’s buyback / burn accounting.</p>
    </section>

    <section class="wrap capital-flow-pons">
      <h2>Pons fee flow</h2>
      <div class="capital-flow-pons-grid">
        <div><b>1</b><span>Native fees accrue and are claimed into the configured treasury.</span></div>
        <div><b>2</b><span>When Pons support is enabled, bridged assets can be converted onto the Solana payout rail.</span></div>
        <div><b>3</b><span>The recipient allocation is converted to dollars through the configured exchange and payout provider.</span></div>
        <div><b>4</b><span>Recipient and protocol allocations remain separate in the ledger from claim through payout.</span></div>
      </div>
      <p>Accrued fees, claimed funds, conversion and completed payouts are separate stages. Token-denominated fees remain held until the configured rail can process them.</p>
    </section>

    <section class="wrap capital-flow-feed">
      <p class="capital-flow-delay">Showing recent verified transfers while the feed refreshes.</p>
      <div class="capital-flow-feed-head">
        <h2>Off-ramp</h2>
        <div class="money-pager"><button disabled>‹</button><span>1</span><button disabled>›</button></div>
      </div>
      <div class="money-filter-tabs capital-flow-tabs">
        <button class="active">All</button>
        <button disabled>Deposits</button>
        <button disabled>Swaps</button>
        <button disabled>ACH</button>
      </div>
      <div class="capital-flow-transfer-list">
        ${offRamp.length
          ? offRamp.map(moneyOffRampCard).join('')
          : `<div class="capital-flow-empty">
              <div class="capital-flow-empty-route">${moneyRoundIcon('≋','sol')}<b>→</b>${moneyRoundIcon('$','payout')}</div>
              <strong>No verified transfers yet.</strong>
              <span>Claim, exchange and payout events will appear here when they are recorded.</span>
            </div>`}
      </div>
    </section>

    <section class="wrap capital-flow-story">
      ${capitalFlowStep('01','A token on pump.fun points its fees at us',
        `<p>At launch, the token routes its creator-fee share to the configured treasury and locks that destination. The indexer verifies the permanent route before the token becomes payable.</p>`,
        'pump')}

      ${capitalFlowStep('02','The exchange rail converts it to dollars',
        `<p>Confirmed recipient funds can be converted through the configured exchange adapter. Conversions and payouts are recorded separately so the ledger can distinguish what is claimed, converted, sent and still owed.</p>`,
        'exchange')}

      ${capitalFlowStep('03','The protocol share funds execution and buyback accounting',
        `<p>The protocol allocation is tracked separately from recipient balances. Execution costs and buyback / burn activity can be reconciled back to the originating fee events instead of being mixed into recipient payouts.</p>`,
        'protocol')}

      ${capitalFlowStep('04','USD reaches the configured payout balance',
        `<p>Converted recipient funds move onto the configured payout rail and remain identifiable as recipient liabilities until a confirmed payout is recorded.</p>`,
        'balance')}

      ${capitalFlowStep('05','The recipient receives the distribution',
        `<p>Each completed payout is linked to the recipient and the tokens that funded it. The public product can show the confirmed amount, recipient, status and reference without exposing server secrets.</p>`,
        'recipient')}

      ${capitalFlowStep('06','Payout operations',
        `<p>The current build keeps accounting and payout execution behind explicit provider configuration and read-only safeguards. Live sending is only available when the corresponding production adapters and secrets are enabled.</p>
         <div class="capital-flow-ops">
           <div><span>Recipient share</span><b>${fmtNum((state.brand.recipientShareBps||8000)/100)}%</b></div>
           <div><span>Protocol share</span><b>${fmtNum((state.brand.protocolShareBps||2000)/100)}%</b></div>
           <div><span>Currently owed</span><b>${fmtMoney(m.totalOwed||0)}</b></div>
           <div><span>Total paid</span><b>${fmtMoney(m.totalPaid||0)}</b></div>
         </div>`,
        'operations')}
    </section>

    ${moneyFooter()}
  </main>`;
}
'''

app = app[:start] + replacement + app[end:]
app_path.write_text(app)

css += r'''

/* capital-flow-v1-reference */
.capital-flow-page{
  padding-top:56px;
  background:#000;
  color:#fff;
}
.capital-flow-page .wrap{
  width:min(100% - 32px,720px);
}
.capital-flow-hero{
  padding-top:12px;
  padding-bottom:56px;
}
.capital-flow-hero .eyebrow{
  margin:0 0 18px;
  color:#666;
  font-size:13px;
}
.capital-flow-hero h1{
  margin:0;
  font-size:64px;
  line-height:.95;
  letter-spacing:-.055em;
  font-weight:560;
}
.capital-flow-lead{
  max-width:680px;
  margin:25px 0 0;
  color:#858585;
  font-size:17px;
  line-height:1.55;
}
.capital-flow-pons{
  padding:32px;
  border:1px solid #262626;
  border-radius:18px;
  background:#101010;
}
.capital-flow-pons h2{
  margin:0 0 22px;
  font-size:25px;
  font-weight:550;
  letter-spacing:-.035em;
}
.capital-flow-pons-grid{
  display:grid;
  gap:14px;
}
.capital-flow-pons-grid>div{
  display:grid;
  grid-template-columns:34px 1fr;
  gap:13px;
  align-items:start;
}
.capital-flow-pons-grid b{
  width:30px;
  height:30px;
  display:grid;
  place-items:center;
  border:1px solid #303030;
  border-radius:50%;
  color:#ddd;
  font-size:11px;
}
.capital-flow-pons-grid span{
  padding-top:5px;
  color:#b0b0b0;
  font-size:14px;
  line-height:1.45;
}
.capital-flow-pons>p{
  margin:22px 0 0;
  padding-top:20px;
  border-top:1px solid #242424;
  color:#6e6e6e;
  font-size:12px;
  line-height:1.5;
}
.capital-flow-feed{
  padding-top:68px;
}
.capital-flow-delay{
  margin:0 0 20px;
  color:#737373;
  font-size:12px;
}
.capital-flow-feed-head{
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap:12px;
}
.capital-flow-feed-head h2{
  margin:0;
  font-size:29px;
  font-weight:530;
  letter-spacing:-.035em;
}
.capital-flow-tabs{
  margin:20px 0 20px;
}
.capital-flow-transfer-list{
  display:grid;
  gap:12px;
}
.capital-flow-empty{
  min-height:150px;
  display:grid;
  place-items:center;
  align-content:center;
  gap:8px;
  padding:24px;
  border:1px dashed #2a2a2a;
  border-radius:18px;
  color:#707070;
  text-align:center;
}
.capital-flow-empty-route{
  display:flex;
  align-items:center;
  gap:10px;
  margin-bottom:4px;
}
.capital-flow-empty-route>b{
  color:#616161;
  font-size:18px;
}
.capital-flow-empty strong{
  color:#8b8b8b;
  font-size:13px;
}
.capital-flow-empty span{
  max-width:420px;
  font-size:11px;
  line-height:1.4;
}
.capital-flow-story{
  padding-top:78px;
  padding-bottom:8px;
}
.capital-flow-step{
  display:grid;
  grid-template-columns:46px 1fr;
  gap:18px;
  padding:32px 0;
  border-top:1px solid #1f1f1f;
}
.capital-flow-step:last-child{
  border-bottom:1px solid #1f1f1f;
}
.capital-flow-step-index{
  width:34px;
  height:34px;
  display:grid;
  place-items:center;
  border:1px solid #303030;
  border-radius:50%;
  color:#696969;
  font-size:10px;
  font-weight:700;
}
.capital-flow-step h2{
  margin:1px 0 13px;
  font-size:27px;
  line-height:1.08;
  letter-spacing:-.035em;
  font-weight:550;
}
.capital-flow-step-copy{
  color:#888;
  font-size:14px;
  line-height:1.55;
}
.capital-flow-step-copy p{
  margin:0;
}
.capital-flow-ops{
  display:grid;
  grid-template-columns:1fr 1fr;
  gap:10px;
  margin-top:20px;
}
.capital-flow-ops>div{
  min-height:86px;
  display:grid;
  align-content:space-between;
  gap:12px;
  padding:14px 16px;
  border:1px solid #262626;
  border-radius:13px;
  background:#111;
}
.capital-flow-ops span{
  color:#666;
  font-size:11px;
}
.capital-flow-ops b{
  color:#fff;
  font-size:20px;
  font-weight:550;
}

@media(max-width:640px){
  .capital-flow-page{padding-top:42px}
  .capital-flow-page .wrap{width:calc(100% - 32px)}
  .capital-flow-hero{padding-top:6px;padding-bottom:42px}
  .capital-flow-hero .eyebrow{font-size:10px;margin-bottom:14px}
  .capital-flow-hero h1{font-size:47px}
  .capital-flow-lead{margin-top:20px;font-size:13px;line-height:1.52}
  .capital-flow-pons{padding:22px 18px;border-radius:15px}
  .capital-flow-pons h2{font-size:21px;margin-bottom:18px}
  .capital-flow-pons-grid{gap:12px}
  .capital-flow-pons-grid>div{grid-template-columns:29px 1fr;gap:10px}
  .capital-flow-pons-grid b{width:27px;height:27px;font-size:9px}
  .capital-flow-pons-grid span{padding-top:4px;font-size:11px}
  .capital-flow-pons>p{margin-top:18px;padding-top:17px;font-size:10px}
  .capital-flow-feed{padding-top:52px}
  .capital-flow-delay{font-size:10px;margin-bottom:17px}
  .capital-flow-feed-head h2{font-size:23px}
  .capital-flow-tabs{margin:16px 0 17px}
  .capital-flow-empty{min-height:126px;border-radius:15px}
  .capital-flow-empty strong{font-size:11px}
  .capital-flow-empty span{font-size:9px}
  .capital-flow-story{padding-top:58px}
  .capital-flow-step{
    grid-template-columns:36px 1fr;
    gap:13px;
    padding:25px 0;
  }
  .capital-flow-step-index{width:29px;height:29px;font-size:8px}
  .capital-flow-step h2{font-size:21px;margin-bottom:11px}
  .capital-flow-step-copy{font-size:11px}
  .capital-flow-ops{grid-template-columns:1fr 1fr;gap:8px;margin-top:17px}
  .capital-flow-ops>div{min-height:70px;padding:12px}
  .capital-flow-ops span{font-size:9px}
  .capital-flow-ops b{font-size:16px}
}
'''
css_path.write_text(css)

print("Capital Flow v1 patch installed.")
PY

npm run check

git add src/app.js src/styles.css

if git diff --cached --quiet; then
  echo "No staged changes; nothing to commit."
else
  git commit -m "Rebuild Capital Flow page from reference"
fi

git push origin main

echo
echo "DONE: Capital Flow v1 checked, committed, and pushed to GitHub."
echo "No server restart was performed."
echo "Restart Console/Run manually if the old page is still being served."
