Pump Fee Routing — Capital Flow v1
Full Capital Flow page rebuild based on the current reference page structure.
Includes hero, Pons fee-flow roadmap, verified off-ramp feed, six explanatory capital-flow sections, live ledger totals, and the Money-style footer.
Uses real project exchange/ledger data. Pons wording is presented as future support until enabled.
No backend, Solana, database, or worker execution logic is changed.
Runs npm check, commits, and pushes to origin/main. No automatic server restart.
