#!/usr/bin/env bash
set -euo pipefail

echo "== Top Token Time Badge v21.1 =="

if [ ! -f src/styles.css ]; then
  echo "ERROR: src/styles.css not found. Run this from the existing Replit project workspace."
  exit 1
fi

python3 <<'PYCODE'
from pathlib import Path

css_path = Path("src/styles.css")
css = css_path.read_text()

if 'top-token-card-layout-v21' not in css:
    raise SystemExit("ERROR: Top Token Card Layout v21 is not installed.")

marker = "/* top-token-time-badge-v21-1 */"

patch = r'''
/* top-token-time-badge-v21-1 */

/*
  Scope: Top Tokens card only.
  Make the age/time pill the same visual size and typography as the Pump pill.
*/

.home-top-token-card[data-top-token-layout="v21"] .home-top-token-platform,
.home-top-token-card[data-top-token-layout="v21"] .home-top-token-age{
  box-sizing:border-box;
  width:46px;
  min-width:46px;
  height:26px;
  min-height:26px;
  padding:0;
  display:flex;
  align-items:center;
  justify-content:center;
  color:#d1d1d1;
  font-size:8px;
  line-height:1;
  font-weight:400;
  letter-spacing:0;
  white-space:nowrap;
}

.home-top-token-card[data-top-token-layout="v21"] .home-top-token-platform .platform-badge{
  color:inherit;
  font-size:inherit;
  line-height:inherit;
  font-weight:inherit;
  letter-spacing:inherit;
}

@media(max-width:640px){
  .home-top-token-card[data-top-token-layout="v21"] .home-top-token-platform,
  .home-top-token-card[data-top-token-layout="v21"] .home-top-token-age{
    width:42px;
    min-width:42px;
    height:24px;
    min-height:24px;
    padding:0;
    font-size:7px;
  }
}
'''

if marker not in css:
    css_path.write_text(css.rstrip() + "\n\n" + patch + "\n")
    print("PASS time badge matched to Pump badge")
else:
    print("PASS v21.1 already installed")

updated = css_path.read_text()
for label, ok in {
    "marker": marker in updated,
    "equal desktop width": "width:46px;" in updated[updated.rfind(marker):],
    "equal mobile width": "width:42px;" in updated[updated.rfind(marker):],
}.items():
    if not ok:
        raise SystemExit(f"ERROR: verification failed: {label}")
    print("PASS", label)
PYCODE

echo
echo "== Project checks =="
npm run check

echo
echo "== Git diff =="
git diff --stat

git add src/styles.css

if git diff --cached --quiet; then
  echo "No new changes to commit."
else
  git commit -m "Match Top Tokens time badge to Pump badge"
  git push
fi

echo
echo "DONE: Top Token Time Badge v21.1 installed, checked, committed, and pushed."
echo "No server restart was performed."
echo "Restart Run/Console manually once, then reload the page."
