Pump Fee Routing — Top Token Time Badge v21.1

Only changes the two top badges inside Top Tokens cards:
- time/age pill gets the same width and height as the Pump pill
- time text gets the same font size, weight, line height and color as Pump
- no other Top Tokens layout is changed
- no other sections are changed
- no automatic restart

Install:
rm -rf /tmp/top-token-time-badge-v21-1
mkdir -p /tmp/top-token-time-badge-v21-1
unzip -o Pump-Fee-Routing-Top-Token-Time-Badge-v21-1.zip -d /tmp/top-token-time-badge-v21-1
bash /tmp/top-token-time-badge-v21-1/install.sh
