#!/usr/bin/env bash
set -euo pipefail

if [ ! -f src/app.js ] || [ ! -f src/styles.css ]; then
  echo "Run this from the Pump-Fee-Routing project root."
  exit 1
fi

if [ -n "$(git status --porcelain -- src/app.js src/styles.css)" ]; then
  echo "STOP: src/app.js or src/styles.css has uncommitted changes."
  git status --short -- src/app.js src/styles.css
  exit 2
fi

python3 - <<'PY'
from pathlib import Path

app_path = Path("src/app.js")
css_path = Path("src/styles.css")
app = app_path.read_text()
css = css_path.read_text()

marker = "/* home-most-payments-v1 */"
if marker in css:
    raise SystemExit("Most Payments v1 is already installed.")

start = app.find("function homeMostPayments(h){")
end = app.find("function homeOffRamp(h){", start)
if start < 0 or end < 0:
    raise SystemExit("Could not locate homeMostPayments()/homeOffRamp().")

replacement = r'''function homeMostPaymentRow(x,index,tokens){
  const handle=x.handle||'';
  const name=x.display_name||handle||'Recipient';
  const received=Number(x.received||0);
  const related=(tokens||[]).filter(t=>String(t.recipient_handle||t.profile||'').toLowerCase()===String(handle).toLowerCase());
  const lead=related.sort((a,b)=>Number(b.sent||0)-Number(a.sent||0))[0]||null;
  const owed=related.reduce((sum,t)=>sum+Number(t.owed||0),0);
  return `<a class="home-most-payment-row" href="#/profile/${encodeURIComponent(handle)}">
    <div class="home-most-payment-route">
      <div class="home-most-token">
        ${lead?avatar(lead.symbol||lead.name,true,lead.image_url):avatar(name,true)}
        <i class="home-most-token-mark">●</i>
      </div>
      <span class="home-most-dollar">$</span>
      <div class="home-most-recipient">
        ${avatar(name,true,x.avatar_url||'')}
        <i class="home-most-x">X</i>
      </div>
    </div>
    <div class="home-most-payment-copy">
      <strong>${fmtMoney(received)}</strong>
      <span>${owed>0?`${fmtMoney(owed)} owed`:`${related.length||0} token${related.length===1?'':'s'}`}</span>
    </div>
  </a>`;
}

function homeMostPayments(h){
  const rows=(h.money?.topPaid||[]).slice(0,6);
  const tokens=h.tokens||[];
  return `<section class="wrap section home-most-payments">
    <p class="home-most-update">Ranked by all-time confirmed payments.</p>
    <div class="home-most-payments-head">
      <h2>Most Payments</h2>
      <div class="home-most-payments-pager"><button disabled>‹</button><span>1 / 1</span><button disabled>›</button></div>
    </div>
    <div class="home-most-payments-list">
      ${rows.length
        ? rows.map((x,i)=>homeMostPaymentRow(x,i,tokens)).join('')
        : `<div class="home-most-payments-empty">
            <div class="home-most-empty-route"><i></i><b>$</b><i></i></div>
            <strong>No completed payments yet.</strong>
            <span>Recipients will be ranked here after confirmed payouts.</span>
          </div>`}
    </div>
  </section>`;
}

'''

app = app[:start] + replacement + app[end:]
app_path.write_text(app)

css += r'''

/* home-most-payments-v1 */
.home-most-payments{padding-top:42px!important}
.home-most-update{
  margin:0 0 8px;
  color:#646464;
  font-size:8px;
  line-height:1.4;
}
.home-most-payments-head{
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap:12px;
  margin-bottom:14px;
}
.home-most-payments-head h2{
  margin:0;
  font-size:18px;
  line-height:1;
  letter-spacing:-.03em;
  font-weight:650;
}
.home-most-payments-pager{
  display:flex;
  align-items:center;
  gap:10px;
  color:#666;
  font-size:8px;
}
.home-most-payments-pager button{
  border:0;
  background:transparent;
  padding:0;
  color:#666;
  font-size:15px;
}
.home-most-payments-list{display:grid;gap:8px}
.home-most-payment-row{
  min-height:78px;
  display:grid;
  grid-template-columns:auto 1fr;
  align-items:center;
  gap:14px;
  padding:12px 14px;
  color:#fff;
  background:#191919;
  border:1px solid #303030;
  border-radius:14px;
}
.home-most-payment-route{
  display:flex;
  align-items:center;
  gap:7px;
}
.home-most-token,
.home-most-recipient{
  position:relative;
  width:42px;
  height:42px;
  flex:0 0 auto;
}
.home-most-token .avatar,
.home-most-recipient .avatar{
  width:42px;
  height:42px;
  border:0;
  font-size:13px;
}
.home-most-token-mark,
.home-most-x{
  position:absolute;
  right:-2px;
  bottom:-2px;
  width:16px;
  height:16px;
  display:grid;
  place-items:center;
  border:2px solid #191919;
  border-radius:5px;
  background:#080808;
  font-style:normal;
  font-size:7px;
}
.home-most-token-mark{color:#7dffb4}
.home-most-x{color:#fff}
.home-most-dollar{
  width:18px;
  display:grid;
  place-items:center;
  font-size:20px;
  font-weight:800;
}
.home-most-payment-copy{
  min-width:0;
  display:grid;
  justify-items:end;
  text-align:right;
}
.home-most-payment-copy strong{
  font-size:21px;
  line-height:1;
  letter-spacing:-.035em;
  font-weight:600;
}
.home-most-payment-copy span{
  margin-top:6px;
  max-width:120px;
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
  color:#707070;
  font-size:8px;
}
.home-most-payments-empty{
  min-height:150px;
  display:grid;
  place-items:center;
  align-content:center;
  gap:7px;
  padding:20px;
  border:1px dashed #272727;
  border-radius:14px;
  color:#646464;
  text-align:center;
}
.home-most-empty-route{
  display:flex;
  align-items:center;
  gap:9px;
  margin-bottom:5px;
}
.home-most-empty-route i{
  width:34px;
  height:34px;
  display:block;
  border-radius:50%;
  background:#111;
  border:1px solid #242424;
}
.home-most-empty-route b{font-size:18px;color:#5e5e5e}
.home-most-payments-empty strong{font-size:9px;color:#777}
.home-most-payments-empty span{font-size:7px;color:#555}

@media(max-width:640px){
  .home-most-payments{padding-top:38px!important}
  .home-most-payments-head h2{font-size:16px}
  .home-most-payment-row{
    min-height:72px;
    padding:11px 12px;
    gap:10px;
    border-radius:13px;
  }
  .home-most-token,
  .home-most-recipient,
  .home-most-token .avatar,
  .home-most-recipient .avatar{
    width:38px;
    height:38px;
  }
  .home-most-payment-route{gap:6px}
  .home-most-dollar{width:16px;font-size:18px}
  .home-most-payment-copy strong{font-size:19px}
}
'''
css_path.write_text(css)

print("Most Payments v1 patch installed.")
PY

npm run check

git add src/app.js src/styles.css

if git diff --cached --quiet; then
  echo "No staged changes; nothing to commit."
else
  git commit -m "Match home most payments"
fi

git push origin main

echo
echo "DONE: Most Payments patch checked, committed, and pushed to GitHub."
echo "No server restart was performed."
echo "Refresh the browser to see the updated Most Payments section."
