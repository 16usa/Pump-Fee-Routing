Pump Fee Routing — Most Payments v1
Scope: Home Most Payments section only.
Uses real recipient payout totals and matched token data; no demo rows are inserted.
Runs npm check, commits, and pushes to origin/main. No automatic server restart.
