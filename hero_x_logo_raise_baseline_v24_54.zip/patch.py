from pathlib import Path
import re

css_path = Path('src/styles.css')
if not css_path.exists():
    raise SystemExit('ERROR: src/styles.css not found. Run from the existing Replit project root.')

css = css_path.read_text()
marker = '/* hero-x-logo-raise-baseline-v24-54 */'

required = [
    'hero-x-logo-mark-v24-52',
    '.home-reference-v1 .home-hero .hero-copy h1 .hero-x-logo'
]
missing = [s for s in required if s not in css]
if missing:
    raise SystemExit('ERROR: base X logo styles not found: ' + ', '.join(missing))

# Adjust only the logo baseline alignment. Keep size untouched.
pattern = re.compile(
    r'(\/\* hero-x-logo-align-v24-53.*?\.home-reference-v1 \.home-hero \.hero-copy h1 \.hero-x-logo\{[^}]*?vertical-align:)([^;]+)(; !?important?[^}]*\})',
    re.S
)
# Simpler targeted replacement first for known rule body.
if 'hero-x-logo-align-v24-53' in css:
    css2 = css.replace('vertical-align:-.10em !important;', 'vertical-align:-.035em !important;')
    if css2 == css:
        css2 = css.replace('vertical-align:-.10em!important;', 'vertical-align:-.035em!important;')
    css = css2

# Fallback / final override to guarantee effect.
if marker not in css:
    css += r'''

/* hero-x-logo-raise-baseline-v24-54
   Raise the inline X mark slightly so its bottom sits closer to the text baseline.
   Size stays unchanged; this is only a vertical position correction. */
.home-reference-v1 .home-hero .hero-copy h1 .hero-x-logo{
  vertical-align:-.035em !important;
}
'''

css_path.write_text(css)
print('PASS: X logo raised slightly so the bottom aligns better with the heading text.')
