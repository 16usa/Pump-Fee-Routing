Patch: hero_x_logo_raise_baseline_v24_54

What it does:
- slightly raises the inline X logo in the hero heading
- keeps the current logo size
- aligns the bottom of the X more closely with the bottom of the surrounding text

Install from your Replit project root via Shell.
No automatic server restart is performed.
