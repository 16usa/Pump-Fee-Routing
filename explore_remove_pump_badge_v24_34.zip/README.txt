Patch: explore_remove_pump_badge_v24_34

What it does:
- Removes the round Pump platform badge from the top-left corner of the projected Top Tokens card inside the Explore preview block.
- Only affects the Explore projected preview card.
- Does not restart the server.

Run from the existing Replit project root.
