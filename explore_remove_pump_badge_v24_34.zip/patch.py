from pathlib import Path

css_path = Path('src/styles.css')
if not css_path.exists():
    raise SystemExit('ERROR: src/styles.css not found. Run from the existing Replit project root.')

css = css_path.read_text()
marker_base = '/* explore-project-top-token-card-v24-32 */'
marker_new = '/* explore-remove-pump-badge-v24-34 */'

if marker_base not in css:
    raise SystemExit('ERROR: v24.32 Explore Top Tokens projection styles not found in src/styles.css')

if marker_new in css:
    print('No changes needed; pump badge removal already installed.')
    raise SystemExit(0)

css += '''\n\n/* explore-remove-pump-badge-v24-34 */\n.home-explore-reference-v8 .home-explore-top-token-card[data-top-token-layout="v21"][data-explore-projection="top-token-v24-32"] .home-top-token-platform{\n  display:none !important;\n}\n'''

css_path.write_text(css)
print('PASS: Removed the top-left Pump platform badge from the Explore projected Top Tokens card.')
