Pump Fee Routing — Opt-out Page v1
Rebuilds the user-facing opt-out flow while preserving the existing X OAuth backend.
Also surfaces the completed state from the existing #/opt-out?done=<handle> callback.
No backend or worker execution logic is changed.
Runs npm check, commits, and pushes to origin/main. No automatic restart.
