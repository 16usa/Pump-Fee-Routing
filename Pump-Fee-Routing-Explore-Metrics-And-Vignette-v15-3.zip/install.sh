#!/usr/bin/env bash
set -euo pipefail

echo "== Explore Metrics + Vignette v15.3 =="

for f in src/app.js src/styles.css; do
  if [ ! -f "$f" ]; then
    echo "ERROR: $f not found. Run this from the existing Replit project workspace."
    exit 1
  fi
done

python3 <<'PYCODE'
from pathlib import Path
import re

app_path = Path('src/app.js')
css_path = Path('src/styles.css')

app = app_path.read_text()
css = css_path.read_text()

if 'data-explore-card-info="v15"' not in app:
    raise SystemExit('ERROR: Explore Card Info v15/v15.1 is not installed yet. Install v15.1 first.')

old_block = '''<div class="home-explore-v8-stats">
                  <span>${fmtMc(token.mc ?? token.market_cap_usd)} MC</span>
                  <b><strong>${fmtMoney(token.sent || 0)}</strong><small>Sent</small></b>
                </div>'''

new_block = '''<div class="home-explore-v8-stats" data-explore-metrics="v15-3">
                  <span>
                    <strong>${fmtMc(token.mc ?? token.market_cap_usd)}</strong>
                    <small>MC</small>
                  </span>
                  <b>
                    <strong>${fmtMoney(token.sent || 0)}</strong>
                    <small>Sent</small>
                  </b>
                </div>'''

if 'data-explore-metrics="v15-3"' in app:
    print('PASS metrics markup already installed')
elif old_block in app:
    app = app.replace(old_block, new_block, 1)
    app_path.write_text(app)
    print('PASS metrics markup updated')
else:
    pattern = re.compile(r'(<div class="home-explore-v8-primary-card" data-explore-card-info="v15">.*?<div class="home-explore-v8-stats">)(.*?)(</div>\s*</div>\s*</div>`;)', re.S)
    m = pattern.search(app)
    if not m:
        raise SystemExit('ERROR: Explore stats block not found. Nothing changed.')
    replacement_inner = '''
                  <span>
                    <strong>${fmtMc(token.mc ?? token.market_cap_usd)}</strong>
                    <small>MC</small>
                  </span>
                  <b>
                    <strong>${fmtMoney(token.sent || 0)}</strong>
                    <small>Sent</small>
                  </b>
                '''
    replacement = m.group(1) + replacement_inner + m.group(3)
    app = app[:m.start()] + replacement + app[m.end():]
    app = app.replace('<div class="home-explore-v8-stats">', '<div class="home-explore-v8-stats" data-explore-metrics="v15-3">', 1)
    app_path.write_text(app)
    print('PASS metrics markup updated via fallback')

marker = '/* explore-metrics-and-vignette-v15-3 */'
css_patch = '''
/* explore-metrics-and-vignette-v15-3 */

/* Make MC value and Sent value use the same visual treatment.
   Labels MC/Sent stay small like the ticker text. */
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-stats[data-explore-metrics="v15-3"]{
  display:flex;
  align-items:baseline;
  justify-content:space-between;
  gap:12px;
  min-width:0;
}
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-stats[data-explore-metrics="v15-3"] > span,
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-stats[data-explore-metrics="v15-3"] > b{
  display:flex;
  align-items:baseline;
  gap:4px;
  min-width:0;
}
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-stats[data-explore-metrics="v15-3"] > span{
  flex:1 1 auto;
  justify-content:flex-start;
  color:#e8e8e8;
  font-size:12px;
  line-height:1.15;
  font-weight:650;
}
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-stats[data-explore-metrics="v15-3"] > b{
  flex:0 0 auto;
  justify-content:flex-end;
  color:#e8e8e8;
  font-size:12px;
  line-height:1.15;
  font-weight:650;
}
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-stats[data-explore-metrics="v15-3"] > span > strong,
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-stats[data-explore-metrics="v15-3"] > b > strong{
  color:inherit;
  font:inherit;
}
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-stats[data-explore-metrics="v15-3"] > span > small,
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-stats[data-explore-metrics="v15-3"] > b > small{
  color:#6f6f6f;
  font-size:9px;
  line-height:1.15;
  font-weight:450;
  letter-spacing:0;
}

/* Add a soft vignette around the whole image instead of only a bottom fade. */
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] > .home-explore-v8-media{
  position:relative;
  isolation:isolate;
}
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] > .home-explore-v8-media::after{
  content:"";
  position:absolute;
  inset:0;
  border-radius:inherit;
  pointer-events:none;
  z-index:1;
  background:
    radial-gradient(120% 92% at 50% 48%, rgba(0,0,0,0) 56%, rgba(0,0,0,0.18) 82%, rgba(0,0,0,0.34) 100%),
    linear-gradient(180deg, rgba(0,0,0,0.16) 0%, rgba(0,0,0,0.02) 22%, rgba(0,0,0,0.02) 68%, rgba(0,0,0,0.46) 100%);
  box-shadow:
    inset 0 0 0 1px rgba(255,255,255,0.02),
    inset 0 32px 44px -36px rgba(0,0,0,0.28),
    inset 0 -58px 72px -36px rgba(0,0,0,0.58),
    inset 24px 0 36px -28px rgba(0,0,0,0.18),
    inset -24px 0 36px -28px rgba(0,0,0,0.18);
}
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] > .home-explore-v8-media > img,
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] > .home-explore-v8-media > video,
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] > .home-explore-v8-media > canvas,
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] > .home-explore-v8-media > .home-explore-v8-art{
  position:relative;
  z-index:0;
}
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-top-token-age,
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-recipient{
  z-index:3;
}

@media (max-width:640px){
  .home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-stats[data-explore-metrics="v15-3"]{
    gap:8px;
  }
  .home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-stats[data-explore-metrics="v15-3"] > span,
  .home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-stats[data-explore-metrics="v15-3"] > b{
    gap:3px;
    font-size:10px;
  }
  .home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-stats[data-explore-metrics="v15-3"] > span > small,
  .home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-stats[data-explore-metrics="v15-3"] > b > small{
    font-size:7px;
  }
  .home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] > .home-explore-v8-media::after{
    box-shadow:
      inset 0 0 0 1px rgba(255,255,255,0.02),
      inset 0 24px 34px -30px rgba(0,0,0,0.26),
      inset 0 -46px 56px -30px rgba(0,0,0,0.56),
      inset 18px 0 28px -22px rgba(0,0,0,0.16),
      inset -18px 0 28px -22px rgba(0,0,0,0.16);
  }
}
'''

if marker in css:
    print('PASS CSS marker already present')
else:
    css_path.write_text(css + '
' + css_patch + '
')
    print('PASS CSS patch added')

app = app_path.read_text()
css = css_path.read_text()
checks = {
    'metrics marker in app': 'data-explore-metrics="v15-3"' in app,
    'MC small label markup': '<small>MC</small>' in app,
    'Sent small label markup': '<small>Sent</small>' in app,
    'css marker': marker in css,
    'vignette pseudo': '> .home-explore-v8-media::after' in css,
}
for label, ok in checks.items():
    if not ok:
        raise SystemExit(f'ERROR: verification failed: {label}')
    print('PASS', label)
PYCODE

echo
echo "== Project checks =="
npm run check

echo
echo "== Git diff =="
git diff --stat

git add src/app.js src/styles.css

if git diff --cached --quiet; then
  echo "No new changes to commit (patch may already be installed)."
else
  git commit -m "Match Explore metric typography and image vignette"
  git push
fi

echo
echo "DONE: Explore Metrics + Vignette v15.3 installed, checked, committed, and pushed."
echo "No server restart was performed."
echo "Restart Run/Console manually once, then reload the page."
