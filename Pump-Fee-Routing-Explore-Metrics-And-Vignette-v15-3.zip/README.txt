Pump Fee Routing — Explore Metrics + Vignette v15.3

What this patch changes in the LEFT Explore card:
- MC number now uses the same size/style as the Sent amount.
- MC label and Sent label are now small like the ticker text.
- Adds a soft vignette around the whole image area (not only a bottom fade).
- Keeps the age badge and recipient pill above the image.
- Does not restart the server.

Requirements:
- Explore Card Info v15/v15.1 must already be installed.

Install in the existing Replit Shell:

rm -rf /tmp/explore-metrics-v15-3
mkdir -p /tmp/explore-metrics-v15-3
unzip -o Pump-Fee-Routing-Explore-Metrics-And-Vignette-v15-3.zip -d /tmp/explore-metrics-v15-3
bash /tmp/explore-metrics-v15-3/install.sh
