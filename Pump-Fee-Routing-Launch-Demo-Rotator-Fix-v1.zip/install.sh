#!/usr/bin/env bash
set -euo pipefail

[ -f src/app.js ] || {
  echo "Missing src/app.js. Run this from the Pump-Fee-Routing project root."
  exit 1
}

if [ -n "$(git status --porcelain -- src/app.js)" ]; then
  echo "STOP: src/app.js has uncommitted changes."
  git status --short -- src/app.js
  exit 2
fi

python3 - <<'PY'
from pathlib import Path
import base64

p=Path("src/app.js")
app=p.read_text()

marker="launch-demo-rotator-fix-v1"
if marker in app:
    raise SystemExit("Launch Demo Rotator Fix v1 is already installed.")

if "launch-demo-rotator-v1" not in app:
    raise SystemExit("Launch Demo Rotator v1 was not found.")

old=base64.b64decode("bGV0IGxhdW5jaERlbW9TY2VuZUluZGV4PTA7CmxldCBsYXVuY2hEZW1vVGltZXI9bnVsbDsKCmZ1bmN0aW9uIGdldExhdW5jaERlbW9SZWNpcGllbnQoKXs=").decode()
new=base64.b64decode("bGV0IGxhdW5jaERlbW9TY2VuZUluZGV4PTA7CmxldCBsYXVuY2hEZW1vVGltZXI9bnVsbDsKCmZ1bmN0aW9uIGxhdW5jaERlbW9Fc2NhcGVIdG1sKHZhbHVlKXsKICByZXR1cm4gU3RyaW5nKHZhbHVlPz8nJykKICAgIC5yZXBsYWNlQWxsKCcmJywnJmFtcDsnKQogICAgLnJlcGxhY2VBbGwoJzwnLCcmbHQ7JykKICAgIC5yZXBsYWNlQWxsKCc+JywnJmd0OycpCiAgICAucmVwbGFjZUFsbCgnIicsJyZxdW90OycpCiAgICAucmVwbGFjZUFsbCgiJyIsIiYjMDM5OyIpOwp9CgpmdW5jdGlvbiBnZXRMYXVuY2hEZW1vUmVjaXBpZW50KCl7").decode()

if old not in app:
    raise SystemExit("Rotator state anchor not found.")
app=app.replace(old,new,1)

payload=base64.b64decode("Skh0bGMyTmhjR1ZJZEcxc0tIQnliMlpwYkdVdVlYWmhkR0Z5VlhKc0tYMD18Skh0c1lYVnVZMmhFWlcxdlJYTmpZWEJsU0hSdGJDaHdjbTltYVd4bExtRjJZWFJoY2xWeWJDbDkKSkh0bGMyTmhjR1ZJZEcxc0tIQnliMlpwYkdVdWFXNXBkR2xoYkh4OEowY25LWDA9fEpIdHNZWFZ1WTJoRVpXMXZSWE5qWVhCbFNIUnRiQ2h3Y205bWFXeGxMbWx1YVhScFlXeDhmQ2RISnlsOQpKSHRsYzJOaGNHVklkRzFzS0hKbFkybHdhV1Z1ZEM1dVlXMWxLWDA9fEpIdHNZWFZ1WTJoRVpXMXZSWE5qWVhCbFNIUnRiQ2h5WldOcGNHbGxiblF1Ym1GdFpTbDk=").decode()
for row in payload.splitlines():
    a64,b64=row.split("|",1)
    a=base64.b64decode(a64).decode()
    b=base64.b64decode(b64).decode()
    if a not in app:
        raise SystemExit("Expected escapeHtml call not found: "+a)
    app=app.replace(a,b,1)

app += "\n/* launch-demo-rotator-fix-v1 */\n"
p.write_text(app)
print("Launch Demo Rotator Fix v1 installed.")
PY

node --check src/app.js
npm run check

node <<'NODE'
const fs=require('fs');
const app=fs.readFileSync('src/app.js','utf8');
const checks=[
  ['local escape helper', app.includes('function launchDemoEscapeHtml(value)')],
  ['no old avatar escape call', !app.includes('${escapeHtml(profile.avatarUrl)}')],
  ['avatar uses local helper', app.includes('${launchDemoEscapeHtml(profile.avatarUrl)}')],
  ['recipient uses local helper', app.includes('${launchDemoEscapeHtml(recipient.name)}')],
  ['fix marker', app.includes('launch-demo-rotator-fix-v1')]
];
let bad=0;
for(const [name,ok] of checks){
  console.log((ok?'PASS':'FAIL')+' '+name);
  if(!ok)bad++;
}
if(bad)process.exit(1);
NODE

git add src/app.js

if git diff --cached --quiet; then
  echo "No staged changes; nothing to commit."
else
  git commit -m "Fix Launch demo rotator rendering"
fi

git push origin main

echo
echo "DONE: Launch Demo Rotator Fix v1 checked, committed, and pushed to GitHub."
echo "The blank demo card was caused by an undefined escapeHtml function."
echo "No server restart was performed."
echo "Restart Console/Run manually once to load the fix."
