Pump Fee Routing — Launch Demo Rotator Fix v1

Fixes the blank animated payment demo card on Launch.

Cause:
The rotator code called escapeHtml(), but that helper did not exist in src/app.js,
so rendering stopped before content was inserted.

Fix:
Adds a local launchDemoEscapeHtml() helper and updates the rotator to use it.

The 10-scene rotator remains:
$5 / $10 / $20 / $50 / $100 × 2 states.

Installer checks, commits, and pushes origin/main.
No automatic server restart.
