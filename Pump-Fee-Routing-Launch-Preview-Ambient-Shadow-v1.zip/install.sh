#!/usr/bin/env bash
set -euo pipefail

[ -f src/styles.css ] || {
  echo "Missing src/styles.css. Run this from the Pump-Fee-Routing project root."
  exit 1
}

if [ -n "$(git status --porcelain -- src/styles.css)" ]; then
  echo "STOP: src/styles.css has uncommitted changes."
  git status --short -- src/styles.css
  exit 2
fi

python3 - <<'PY'
from pathlib import Path
import base64

p = Path("src/styles.css")
css = p.read_text()

marker = "launch-preview-ambient-shadow-v1"
if marker in css:
    raise SystemExit("Launch Preview Ambient Shadow v1 is already installed.")

if "launch-preview-restore-project-colors-v1" not in css:
    raise SystemExit("Expected current Launch preview color patch was not found.")

css += base64.b64decode("Ci8qIGxhdW5jaC1wcmV2aWV3LWFtYmllbnQtc2hhZG93LXYxCiAgIFNvZnQgYW1iaWVudCBzaGFkb3cgYXJvdW5kIHRoZSBleGlzdGluZyBMYXVuY2ggcHJldmlldyBjYXJkLgogICBMYXlvdXQsIGNvbG9ycywgc2l6aW5nIGFuZCBpbWFnZSB0cmVhdG1lbnQgc3RheSB1bmNoYW5nZWQuICovCi5sYXVuY2gtcHJldmlldy11c2VwYWlkewogIGJveC1zaGFkb3c6CiAgICAwIDEwcHggMjZweCByZ2JhKDAsMCwwLC4zNCksCiAgICAwIDI4cHggNzJweCByZ2JhKDAsMCwwLC41MiksCiAgICAwIDAgMjRweCByZ2JhKDI1NSwyNTUsMjU1LC4wMjUpIWltcG9ydGFudDsKfQo=").decode()
p.write_text(css)
print("Launch Preview Ambient Shadow v1 installed.")
PY

npm run check

node <<'NODE'
const fs=require('fs');
const css=fs.readFileSync('src/styles.css','utf8');
const checks=[
  ['shadow marker', css.includes('launch-preview-ambient-shadow-v1')],
  ['soft lower shadow', css.includes('0 28px 72px rgba(0,0,0,.52)')],
  ['subtle ambient edge', css.includes('0 0 24px rgba(255,255,255,.025)')]
];
let bad=0;
for (const [name,ok] of checks) {
  console.log((ok?'PASS':'FAIL')+' '+name);
  if(!ok) bad++;
}
if(bad) process.exit(1);
NODE

git add src/styles.css

if git diff --cached --quiet; then
  echo "No staged changes; nothing to commit."
else
  git commit -m "Add Launch preview ambient shadow"
fi

git push origin main

echo
echo "DONE: Launch Preview Ambient Shadow v1 checked, committed, and pushed to GitHub."
echo "Only the preview card shadow was changed."
echo "No server restart was performed."
echo "Restart Console/Run manually once to load the shadow."
