Pump Fee Routing — Launch Preview Ambient Shadow v1

Changes only the shadow around the Launch preview card.
Keeps the current colors, layout, square image, spacing, typography,
and information structure.

Installer checks, commits, and pushes origin/main.
No automatic server restart.
