Patch: Explore Border Cleanup v15.5

What it does:
- removes the border/frame around the LEFT Explore inner card
- removes the border/frame around images/modules inside the Explore block
- keeps the main outer Explore container border intact
- does not restart the server

Run from the existing Replit project workspace:
  rm -rf /tmp/explore-border-cleanup-v15-5
  mkdir -p /tmp/explore-border-cleanup-v15-5
  unzip -o Pump-Fee-Routing-Explore-Border-Cleanup-v15-5.zip -d /tmp/explore-border-cleanup-v15-5
  bash /tmp/explore-border-cleanup-v15-5/install.sh
