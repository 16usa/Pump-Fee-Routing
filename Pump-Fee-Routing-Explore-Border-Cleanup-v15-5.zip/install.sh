#!/usr/bin/env bash
set -euo pipefail

echo "== Explore Border Cleanup v15.5 =="

for f in src/app.js src/styles.css; do
  if [ ! -f "$f" ]; then
    echo "ERROR: $f not found. Run this from the existing Replit project workspace."
    exit 1
  fi
done

python3 <<'PYCODE'
from pathlib import Path

app_path = Path("src/app.js")
css_path = Path("src/styles.css")

app = app_path.read_text()
css = css_path.read_text()

if 'data-explore-card-info="v15"' not in app:
    raise SystemExit("ERROR: Explore Card Info v15 is not installed yet. Install the Explore v15 series first.")

marker = "/* explore-border-cleanup-v15-5 */"
css_patch = """
/* explore-border-cleanup-v15-5 */

/* Remove the inner card frames in the Explore preview block.
   Keep only the main outer Explore container border. */
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info=\"v15\"],
.home-explore-reference-v8 .home-explore-v8-secondary-card{
  border:0 !important;
  box-shadow:none !important;
  background:transparent !important;
}

/* Remove borders around the actual images/modules inside the Explore block. */
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info=\"v15\"] > .home-explore-v8-media,
.home-explore-reference-v8 .home-explore-v8-secondary-card > .home-explore-v8-media{
  border:0 !important;
  box-shadow:none !important;
  background:#0a0a0a;
}

/* Keep the info area clean without extra divider lines. */
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info=\"v15\"] > .home-explore-v8-copy{
  border-top:0 !important;
}

@media (max-width:640px){
  .home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info=\"v15\"],
  .home-explore-reference-v8 .home-explore-v8-secondary-card,
  .home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info=\"v15\"] > .home-explore-v8-media,
  .home-explore-reference-v8 .home-explore-v8-secondary-card > .home-explore-v8-media{
    box-shadow:none !important;
  }
}
"""

if marker in css:
    print("PASS border cleanup already installed")
else:
    css_path.write_text(css + "\n" + css_patch + "\n")
    print("PASS border cleanup CSS added")

css = css_path.read_text()
checks = {
    "marker exists": marker in css,
    "primary card border removed": '.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info=\\"v15\\"],' in css,
    "secondary card border removed": '.home-explore-reference-v8 .home-explore-v8-secondary-card{' in css,
    "media border removed": '> .home-explore-v8-media{' in css,
}
for label, ok in checks.items():
    if not ok:
        raise SystemExit(f"ERROR: verification failed: {label}")
    print("PASS", label)
PYCODE

echo
echo "== Project checks =="
npm run check

echo
echo "== Git diff =="
git diff --stat

git add src/styles.css

if git diff --cached --quiet; then
  echo "No new changes to commit."
else
  git commit -m "Remove Explore inner card and image borders"
  git push
fi

echo
echo "DONE: Explore Border Cleanup v15.5 installed, checked, committed, and pushed."
echo "No server restart was performed."
echo "Restart Run/Console manually once, then reload the page."
