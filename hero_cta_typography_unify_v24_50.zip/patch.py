from pathlib import Path

css_path = Path("src/styles.css")
if not css_path.exists():
    raise SystemExit("ERROR: src/styles.css not found. Run this from the existing Replit project root.")

css = css_path.read_text()
marker = "/* hero-cta-typography-unify-v24-50 */"

required = [
    ".home-reference-v1 .home-hero .btn-light",
    ".home-reference-v1 .home-hero .text-link",
    "hero-docs-black-pill-v24-48",
]
missing = [s for s in required if s not in css]
if missing:
    raise SystemExit("ERROR: required hero CTA styles not found: " + ", ".join(missing))

if marker not in css:
    css += r'''

/* hero-cta-typography-unify-v24-50
   Resolve accumulated mobile font-size conflicts by defining BOTH hero CTAs
   from one final shared typography rule. Visual colors/backgrounds stay separate. */
.home-reference-v1 .home-hero .btn-light,
.home-reference-v1 .home-hero .text-link{
  font-family:inherit !important;
  font-size:13px !important;
  line-height:normal !important;
  font-weight:700 !important;
  letter-spacing:0 !important;
}

@media(max-width:640px){
  .home-reference-v1 .home-hero .btn-light,
  .home-reference-v1 .home-hero .text-link{
    font-size:10px !important;
    line-height:normal !important;
    font-weight:700 !important;
  }
}
'''
    css_path.write_text(css)
    print("PASS: both hero CTA labels now use one shared typography rule.")
    print("PASS: mobile font-size is identical on both buttons: 10px.")
else:
    print("No changes needed; v24.50 already installed.")
