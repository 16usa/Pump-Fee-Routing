#!/usr/bin/env bash
set -euo pipefail

PATCH_NAME="hero_cta_typography_unify_v24_50"
CSS="src/styles.css"

if [ ! -f "$CSS" ]; then
  echo "ERROR: missing src/styles.css"
  echo "Run this from the existing Replit project root."
  exit 1
fi

echo "==> Installing ${PATCH_NAME}"
mkdir -p ".patch-backups/${PATCH_NAME}"
cp "$CSS" ".patch-backups/${PATCH_NAME}/styles.css.before"

python3 "$(dirname "$0")/patch.py"

echo "==> Verifying shared CTA typography"
grep -q 'hero-cta-typography-unify-v24-50' "$CSS"
grep -q '.home-reference-v1 .home-hero .btn-light,' "$CSS"
grep -q 'font-size:10px !important' "$CSS"

echo "==> Running project check"
npm run check

echo "==> Git diff"
git diff --stat -- "$CSS"

git add "$CSS"
if git diff --cached --quiet; then
  echo "==> No new changes to commit."
else
  git commit -m "Unify hero CTA typography"
  git push origin main
fi

echo
echo "PASS: ${PATCH_NAME} installed."
echo "No server restart was performed."
