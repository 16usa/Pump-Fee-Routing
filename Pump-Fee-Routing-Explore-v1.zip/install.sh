#!/usr/bin/env bash
set -euo pipefail

if [ ! -f src/app.js ] || [ ! -f src/styles.css ]; then
  echo "Run this from the Pump-Fee-Routing project root."
  exit 1
fi

if [ -n "$(git status --porcelain -- src/app.js src/styles.css)" ]; then
  echo "STOP: src/app.js or src/styles.css has uncommitted changes."
  git status --short -- src/app.js src/styles.css
  exit 2
fi

python3 - <<'PY'
from pathlib import Path

app_path = Path("src/app.js")
css_path = Path("src/styles.css")
app = app_path.read_text()
css = css_path.read_text()

marker = "/* explore-v1-usepaid */"
if marker in css:
    raise SystemExit("Explore v1 is already installed.")

start = app.find("function explorePage(){")
end = app.find("function moneyPage(){", start)
if start < 0 or end < 0:
    raise SystemExit("Could not locate explorePage()/moneyPage().")

replacement = r'''function exploreTrendingCard(t){
  return `<a class="explore-trend-card" href="#/token/${encodeURIComponent(t.mint||t.contract||'')}">
    ${avatar(t.symbol||t.name,true,t.image_url)}
    <div>
      <strong>${esc(t.name)}</strong>
      <span>${esc(t.symbol||'')}</span>
      <small>Sent ${fmtNum(t.sent||0)}</small>
    </div>
  </a>`;
}

function exploreTokenCard(t){
  const mint=t.mint||t.contract||'';
  const handle=t.profile||t.recipient_handle||'';
  return `<a class="explore-token-card" href="#/token/${encodeURIComponent(mint)}">
    <div class="explore-token-image">
      ${t.image_url?`<img src="${esc(t.image_url)}" alt="">`:`<div class="explore-token-fallback">${esc(initials(t.symbol||t.name||'T'))}</div>`}
    </div>
    <div class="explore-token-info">
      <div class="explore-token-meta">
        ${platformBadge(t.platform||'Pump')}
        <span class="explore-token-profile">${handle?`@${esc(handle)}`:'Recipient'}</span>
        <span class="explore-token-age">${esc(t.age||ago(t.created_at))}</span>
      </div>
      <div class="explore-token-name">
        <strong>${esc(t.name)}</strong>
        <span>${esc(t.symbol||'')}</span>
      </div>
      <div class="explore-token-stats">
        <div><b>${fmtMc(t.mc??t.market_cap_usd)}</b><small>MC</small></div>
        <div><b>${fmtNum(t.sent||0)}</b><small>Sent</small></div>
        <div><b>${fmtNum(t.owed||0)}</b><small>Owed</small></div>
      </div>
      <div class="explore-token-contract">${mint?`${esc(mint.slice(0,6))}...${esc(mint.slice(-6))}`:'-'}</div>
    </div>
  </a>`;
}

function exploreTrending(tokens){
  const trending=(tokens||[]).slice(0,10);
  return `<section class="wrap section explore-trending">
    <div class="explore-section-head"><h2>Trending</h2><a href="#/explore">View all</a></div>
    ${trending.length
      ? `<div class="explore-trending-strip">${trending.map(exploreTrendingCard).join('')}</div>`
      : `<div class="explore-trending-strip explore-trending-empty">
          ${Array.from({length:3},()=>`<div class="explore-trend-skeleton"><i></i><span></span></div>`).join('')}
        </div>`}
  </section>`;
}

function explorePage(){
  const tokens=state.tokens||[];
  return `<main class="explore-page">
    <section class="wrap explore-head explore-hero">
      <div>
        <h1>Explore tokens</h1>
        <p>pump.fun launches the tokens. ${esc(state.brand.name)} claims the creator fees on chain and pays them to an X account in dollars through X Money, with a public confirmation for every payout.</p>
        <button class="btn-light" data-action="go-launch">Launch a token</button>
      </div>
    </section>

    ${exploreTrending(tokens)}

    <section class="wrap section launches explore-launches">
      <div class="explore-section-head explore-launches-head"><h2>All launches</h2></div>

      <div class="explore-venue-tabs">
        <button class="${state.explore.venue==='pump'?'active':''}" data-venue="pump">● Pump</button>
        <button class="${state.explore.venue==='pons'?'active':''}" data-venue="pons">■ Pons</button>
      </div>

      <input class="explore-search" id="tokenSearch" placeholder="Search by contract address" value="${esc(state.explore.query)}">

      <div class="sorts explore-sorts">
        <button class="${state.explore.sort==='sent'?'active':''}" data-sort="sent">Total X Payments</button>
        <button class="${state.explore.sort==='mc'?'active':''}" data-sort="mc">Market Cap</button>
        <button class="${state.explore.sort==='recent'?'active':''}" data-sort="recent">Recent</button>
      </div>

      <div class="explore-launch-grid" id="launchGrid">
        ${tokens.length?tokens.map(exploreTokenCard).join(''):`<div class="explore-empty"><span>No launches match this search.</span></div>`}
      </div>
    </section>

    ${footer()}
  </main>`;
}
'''

app = app[:start] + replacement + chr(10) + app[end:]

app = app.replace(
    "state.tokens.map(t=>tokenCard(t,false)).join('')||'<div class=\"empty\">No launches.</div>'",
    "state.tokens.map(exploreTokenCard).join('')||'<div class=\"explore-empty\"><span>No launches.</span></div>'"
)
app = app.replace(
    "state.tokens.map(t=>tokenCard(t,false)).join('')||'<div class=\"empty\">No launches match this search.</div>'",
    "state.tokens.map(exploreTokenCard).join('')||'<div class=\"explore-empty\"><span>No launches match this search.</span></div>'"
)

old_handler = "state.explore.venue=venue.dataset.venue;await refreshTokens();"
new_handler = "state.explore.venue=state.explore.venue===venue.dataset.venue?'':venue.dataset.venue;await refreshTokens();"
if old_handler not in app:
    raise SystemExit("Could not locate venue handler.")
app = app.replace(old_handler, new_handler, 1)

app_path.write_text(app)

css += r'''

/* explore-v1-usepaid */
.explore-page{overflow:hidden}
.explore-page .explore-hero{
  padding:78px 0 34px;
  display:block;
}
.explore-page .explore-hero>div{max-width:760px}
.explore-page .explore-hero h1{
  margin:0;
  font-size:clamp(48px,7vw,72px);
  line-height:.94;
  letter-spacing:-.06em;
  font-weight:650;
}
.explore-page .explore-hero p{
  max-width:690px;
  margin:24px 0 27px;
  color:#858585;
  font-size:14px;
  line-height:1.58;
}
.explore-page .explore-hero .btn-light{
  padding:12px 19px;
  font-size:13px;
}
.explore-section-head{
  display:flex;
  align-items:baseline;
  justify-content:space-between;
  gap:14px;
  margin-bottom:16px;
}
.explore-section-head h2{
  margin:0;
  font-size:20px;
  letter-spacing:-.035em;
  font-weight:650;
}
.explore-section-head a{
  color:#666;
  font-size:10px;
}
.explore-trending{padding-top:44px;padding-bottom:46px}
.explore-trending-strip{
  display:flex;
  gap:8px;
  overflow-x:auto;
  padding-bottom:4px;
  scrollbar-width:none;
  scroll-snap-type:x mandatory;
}
.explore-trending-strip::-webkit-scrollbar{display:none}
.explore-trend-card{
  flex:0 0 188px;
  min-width:0;
  display:flex;
  align-items:center;
  gap:9px;
  padding:9px;
  scroll-snap-align:start;
  color:#fff;
  background:#111;
  border:1px solid #252525;
  border-radius:12px;
}
.explore-trend-card .avatar{
  width:38px;
  height:38px;
  border-radius:9px;
  font-size:12px;
}
.explore-trend-card>div:last-child{
  min-width:0;
  display:grid;
}
.explore-trend-card strong{
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
  font-size:10px;
}
.explore-trend-card span,
.explore-trend-card small{
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
  color:#666;
  font-size:8px;
}
.explore-trend-skeleton{
  flex:0 0 188px;
  height:58px;
  display:flex;
  align-items:center;
  gap:9px;
  padding:9px;
  border:1px dashed #202020;
  border-radius:12px;
}
.explore-trend-skeleton i{
  width:38px;
  height:38px;
  border-radius:9px;
  background:#0e0e0e;
}
.explore-trend-skeleton span{
  width:80px;
  height:7px;
  border-radius:999px;
  background:#101010;
}
.explore-launches{padding-top:42px}
.explore-launches-head{margin-bottom:17px}
.explore-venue-tabs{
  display:flex;
  align-items:center;
  gap:14px;
  margin-bottom:15px;
}
.explore-venue-tabs button{
  border:0;
  background:transparent;
  padding:4px 0;
  color:#5f5f5f;
  font-size:10px;
  cursor:pointer;
}
.explore-venue-tabs button.active{color:#fff}
.explore-search{
  width:100%;
  height:42px;
  margin:0 0 17px;
  padding:0 15px;
  color:#fff;
  background:#080808;
  border:1px solid #292929;
  border-radius:999px;
  outline:none;
  font-size:10px;
}
.explore-search:focus{border-color:#555}
.explore-sorts{
  display:flex;
  gap:28px;
  margin:0 0 15px;
}
.explore-sorts button{
  margin:0;
  padding:4px 0;
  color:#666;
  font-size:10px;
  font-weight:600;
}
.explore-sorts button.active{color:#fff}
.explore-launch-grid{
  display:grid;
  grid-template-columns:repeat(2,minmax(0,1fr));
  gap:9px;
}
.explore-token-card{
  min-width:0;
  min-height:124px;
  display:grid;
  grid-template-columns:112px minmax(0,1fr);
  overflow:hidden;
  color:#fff;
  background:#121212;
  border:1px solid #252525;
  border-radius:14px;
}
.explore-token-image{
  min-height:124px;
  display:grid;
  place-items:center;
  overflow:hidden;
  background:#080808;
}
.explore-token-image img{
  width:100%;
  height:100%;
  display:block;
  object-fit:cover;
}
.explore-token-fallback{
  width:100%;
  height:100%;
  display:grid;
  place-items:center;
  background:radial-gradient(circle at 50% 44%,#1b1b1b,#080808 68%);
  color:#e8e8e8;
  font-size:28px;
  font-weight:850;
  font-style:italic;
}
.explore-token-info{
  min-width:0;
  padding:10px 11px;
}
.explore-token-meta{
  min-width:0;
  display:flex;
  align-items:center;
  gap:5px;
  font-size:8px;
}
.explore-token-profile{
  min-width:0;
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
  color:#717171;
}
.explore-token-age{
  margin-left:auto;
  color:#6a6a6a;
  white-space:nowrap;
}
.explore-token-name{
  min-width:0;
  display:flex;
  align-items:baseline;
  gap:5px;
  margin-top:9px;
}
.explore-token-name strong{
  min-width:0;
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
  font-size:12px;
}
.explore-token-name span{
  color:#666;
  font-size:8px;
  white-space:nowrap;
}
.explore-token-stats{
  display:flex;
  flex-wrap:wrap;
  gap:10px;
  margin-top:9px;
}
.explore-token-stats>div{
  display:flex;
  align-items:baseline;
  gap:3px;
}
.explore-token-stats b{font-size:10px}
.explore-token-stats small{color:#626262;font-size:7px}
.explore-token-contract{
  margin-top:10px;
  color:#585858;
  font:8px ui-monospace,SFMono-Regular,Menlo,monospace;
}
.explore-empty{
  grid-column:1/-1;
  min-height:150px;
  display:grid;
  place-items:center;
  padding:24px;
  border:1px dashed #292929;
  border-radius:14px;
  color:#626262;
  text-align:center;
  font-size:10px;
}
.explore-page .site-footer{margin-top:72px}

@media(max-width:640px){
  .explore-page .wrap{width:calc(100% - 32px)}
  .explore-page .explore-hero{padding:52px 0 27px}
  .explore-page .explore-hero h1{font-size:48px}
  .explore-page .explore-hero p{
    margin:20px 0 23px;
    font-size:12px;
    line-height:1.55;
  }
  .explore-page .explore-hero .btn-light{
    padding:11px 17px;
    font-size:11px;
  }
  .explore-trending{padding-top:36px;padding-bottom:36px}
  .explore-section-head h2{font-size:18px}
  .explore-trending-strip{
    margin-right:-16px;
    padding-right:16px;
  }
  .explore-trend-card,
  .explore-trend-skeleton{flex-basis:156px}
  .explore-launches{padding-top:32px}
  .explore-search{height:44px;font-size:11px}
  .explore-sorts{
    gap:24px;
    overflow-x:auto;
    scrollbar-width:none;
  }
  .explore-sorts::-webkit-scrollbar{display:none}
  .explore-sorts button{
    flex:0 0 auto;
    font-size:10px;
  }
  .explore-launch-grid{grid-template-columns:1fr;gap:8px}
  .explore-token-card{
    grid-template-columns:88px minmax(0,1fr);
    min-height:112px;
    border-radius:13px;
  }
  .explore-token-image{min-height:112px}
  .explore-token-info{padding:9px 10px}
  .explore-empty{min-height:150px}
  .explore-page .site-footer{margin-top:58px}
}
'''
css_path.write_text(css)

print("Explore v1 patch installed.")
PY

npm run check

git add src/app.js src/styles.css

if git diff --cached --quiet; then
  echo "No staged changes; nothing to commit."
else
  git commit -m "Match Explore page"
fi

git push origin main

echo
echo "DONE: Explore patch checked, committed, and pushed to GitHub."
echo "No server restart was performed."
echo "Refresh the browser and open #/explore."
