Pump Fee Routing — Explore v1
First full Explore-page pass based on the supplied reference and current UsePaid Explore structure.
Reworks hero copy/layout, Trending, Pump/Pons venue controls, search/sorts, token cards and empty states.
Uses only real project data; no demo tokens are inserted.
Runs npm check, commits, and pushes to origin/main. No automatic server restart.
