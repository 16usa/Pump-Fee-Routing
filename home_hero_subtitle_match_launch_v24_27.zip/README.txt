Home Hero Subtitle Match Launch v24.27

Changes only the muted descriptive paragraph below:
Route token fees / through X Money

It now matches the descriptive paragraph on the Launch page:
Launch and direct fees through X Money

Exact reference sizes from the current project:
- desktop: 15px
- mobile: 12px
- line-height: 1.55

The hero headline and buttons are not changed.
No automatic server restart.

Install in the existing Replit Shell:

rm -rf /tmp/home_hero_subtitle_match_launch_v24_27 && mkdir -p /tmp/home_hero_subtitle_match_launch_v24_27 && unzip -o home_hero_subtitle_match_launch_v24_27.zip -d /tmp/home_hero_subtitle_match_launch_v24_27 && bash /tmp/home_hero_subtitle_match_launch_v24_27/install.sh
