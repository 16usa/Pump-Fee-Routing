from pathlib import Path

path = Path("src/styles.css")
if not path.exists():
    raise SystemExit("ERROR: src/styles.css not found. Run from the existing Replit project root.")

css = path.read_text()
marker = "/* home-hero-subtitle-match-launch-v24-27 */"

if marker not in css:
    css += '''

/* home-hero-subtitle-match-launch-v24-27
   Match the Home hero description to the Launch hero description size. */
.home-reference-v1 .home-hero .hero-copy>p{
  font-size:15px !important;
  line-height:1.55 !important;
}

@media(max-width:760px){
  .home-reference-v1 .home-hero .hero-copy>p{
    font-size:12px !important;
    line-height:1.55 !important;
  }
}
'''
    path.write_text(css)
    print("PASS: Home hero description now matches Launch description size")
else:
    print("Patch already installed")
