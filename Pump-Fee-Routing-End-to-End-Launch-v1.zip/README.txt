Pump Fee Routing — End-to-End Launch v1

Adds a real user-signed Pump launch flow while keeping server-owned money movement read-only.

Flow:
1. Launch intent / X recipient marker
2. Pump metadata upload
3. Pump token creation (0 SOL create-only, or positive SOL create+buy)
4. Wallet approval + on-chain confirmation
5. Second wallet approval for permanent 100% treasury fee routing
6. Immediate verification and registration in Explore

Creator private keys are never sent to this server.
Runs syntax checks, npm run check, commit, and push. No automatic restart.
