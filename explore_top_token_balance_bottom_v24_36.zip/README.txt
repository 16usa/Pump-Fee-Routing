Patch v24.36
- makes the Explore projected top-token card occupy a bit more than half the block
- stretches it lower
- leaves a small clean bottom gap instead of fully touching the block bottom
- slightly narrows the right grayscale preview so the balance stays clean
