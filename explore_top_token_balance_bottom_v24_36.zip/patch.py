from pathlib import Path

css_path = Path('src/styles.css')
if not css_path.exists():
    raise SystemExit('ERROR: src/styles.css not found. Run from the existing Replit project root.')

css = css_path.read_text()
marker = '/* explore-top-token-balance-bottom-v24-36 */'

if '.home-explore-top-token-card' not in css or 'data-explore-projection="top-token-v24-32"' not in css:
    raise SystemExit('ERROR: Explore projected Top Token card selectors not found in src/styles.css')

if marker not in css:
    css += r'''

/* explore-top-token-balance-bottom-v24-36
   Make the projected Explore top-token card occupy a little more than half
   of the block, stretch lower, and leave a clean bottom gap that visually
   matches the inner image-to-card padding. */
.home-explore-reference-v8 .home-explore-v8-primary-slot{
  left:0 !important;
  top:0 !important;
  bottom:14px !important;
  width:60.5% !important;
  height:auto !important;
  z-index:4 !important;
  display:flex !important;
  align-items:stretch !important;
  justify-content:flex-start !important;
  overflow:visible !important;
}

.home-explore-reference-v8 .home-explore-top-token-card[data-top-token-layout="v21"][data-explore-projection="top-token-v24-32"]{
  width:100% !important;
  min-height:100% !important;
}

.home-explore-reference-v8 .home-explore-v8-secondary-slot{
  right:0 !important;
  top:12% !important;
  bottom:14px !important;
  width:27.5% !important;
  height:auto !important;
  z-index:3 !important;
}

@media(max-width:640px){
  .home-explore-reference-v8 .home-explore-v8-primary-slot{
    left:0 !important;
    top:0 !important;
    bottom:14px !important;
    width:60.5% !important;
  }

  .home-explore-reference-v8 .home-explore-top-token-card[data-top-token-layout="v21"][data-explore-projection="top-token-v24-32"]{
    min-height:100% !important;
  }

  .home-explore-reference-v8 .home-explore-v8-secondary-slot{
    top:12% !important;
    bottom:14px !important;
    width:27.5% !important;
  }
}
'''
    css_path.write_text(css)
    print('PASS: Explore projected card now stretches lower with a small balanced bottom gap.')
else:
    print('No changes needed; patch already installed.')
