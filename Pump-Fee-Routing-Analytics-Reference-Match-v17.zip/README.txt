Pump Fee Routing — Analytics Reference Match v17

Changes only the HOME Analytics preview block so it visually matches the supplied reference more closely:

- removes the old Analytics/Open header row from the top of the card
- shows Fees on the left and 1D on the right
- keeps the large total amount
- replaces the bar chart with a smooth curve/area chart look
- moves Analytics / Open → to the bottom footer
- adds the same lower fade treatment used in the reference
- does not restart the server automatically

Install from the existing Replit workspace:

rm -rf /tmp/analytics-reference-match-v17
mkdir -p /tmp/analytics-reference-match-v17
unzip -o Pump-Fee-Routing-Analytics-Reference-Match-v17.zip -d /tmp/analytics-reference-match-v17
bash /tmp/analytics-reference-match-v17/install.sh
