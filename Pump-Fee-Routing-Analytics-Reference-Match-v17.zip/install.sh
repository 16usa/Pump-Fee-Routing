#!/usr/bin/env bash
set -euo pipefail

echo "== Analytics Reference Match v17 =="

for f in src/app.js src/styles.css; do
  if [ ! -f "$f" ]; then
    echo "ERROR: $f not found. Run this from the existing Replit project workspace."
    exit 1
  fi
done

python3 <<'PYCODE'
from pathlib import Path

app_path = Path('src/app.js')
css_path = Path('src/styles.css')
app = app_path.read_text()
css = css_path.read_text()

app_marker = 'data-analytics-reference="v17"'
css_marker = '/* analytics-reference-match-v17 */'

if app_marker not in app:
    start = app.find('<a class="home-preview-card home-ref-card home-v2-analytics-card" href="#/money">')
    if start < 0:
        start = app.find('<a class="home-preview-card home-ref-card home-v2-analytics-card" data-analytics-reference="v17" href="#/money">')
    if start < 0:
        raise SystemExit('ERROR: analytics preview card markup not found.')
    end = app.find("\n\n      <a class=\"home-preview-card home-ref-card home-v2-launch-card\" href=\"#/launch\">", start)
    if end < 0:
        raise SystemExit('ERROR: could not locate end of analytics preview card block.')

    new_block = '''<a class="home-preview-card home-ref-card home-v2-analytics-card" data-analytics-reference="v17" href="#/money">
        <div class="home-v2-analytics-stage">
          <div class="home-v2-analytics-topline"><strong>Fees</strong><span>1D</span></div>
          <strong class="home-v2-analytics-total">${fmtMoney(total)}</strong>
          <div class="home-v2-analytics-graph" aria-hidden="true">
            <svg viewBox="0 0 100 42" preserveAspectRatio="none" role="presentation">
              <defs>
                <linearGradient id="homeAnalyticsFillV17" x1="0" x2="0" y1="0" y2="1">
                  <stop offset="0%" stop-color="rgba(255,255,255,0.18)"/>
                  <stop offset="68%" stop-color="rgba(255,255,255,0.06)"/>
                  <stop offset="100%" stop-color="rgba(255,255,255,0)"/>
                </linearGradient>
              </defs>
              <path class="grid" d="M0 9.5 H100 M0 25.5 H100"/>
              <path class="area" d="M0 34 C8 33 13 31 18 32 C23 33 27 36 33 35 C40 34 44 26 50 24 C58 21 64 32 69 33 C74 34 80 27 85 28 C91 29 95 34 100 33 L100 42 L0 42 Z" fill="url(#homeAnalyticsFillV17)"/>
              <path class="line" d="M0 34 C8 33 13 31 18 32 C23 33 27 36 33 35 C40 34 44 26 50 24 C58 21 64 32 69 33 C74 34 80 27 85 28 C91 29 95 34 100 33"/>
            </svg>
          </div>
          <div class="home-v2-analytics-bottom-shade" aria-hidden="true"></div>
          <div class="home-v2-analytics-footer"><strong>Analytics</strong><span>Open →</span></div>
        </div>
      </a>'''
    app = app[:start] + new_block + app[end:]
    app_path.write_text(app)
    print('PASS analytics preview markup updated')
else:
    print('PASS analytics preview markup already installed')

if css_marker not in css:
    css_patch = r'''
/* analytics-reference-match-v17 */
.home-reference-v2-previews .home-preview-card.home-v2-analytics-card[data-analytics-reference="v17"]{
  position:relative;
  display:block;
  min-height:246px;
  padding:12px;
  overflow:hidden;
  border:1px solid #303030;
  border-radius:20px;
  background:#171717;
  box-shadow:none;
  isolation:isolate;
}
.home-v2-analytics-card[data-analytics-reference="v17"] .home-v2-analytics-stage{
  position:relative;
  min-height:220px;
  padding:14px 14px 44px;
}
.home-v2-analytics-card[data-analytics-reference="v17"] .home-v2-analytics-topline{
  display:flex;
  align-items:center;
  justify-content:space-between;
  margin-bottom:12px;
}
.home-v2-analytics-card[data-analytics-reference="v17"] .home-v2-analytics-topline strong,
.home-v2-analytics-card[data-analytics-reference="v17"] .home-v2-analytics-topline span{
  color:#b9b9b9;
  font-size:12px;
  line-height:1;
  font-weight:450;
  letter-spacing:.02em;
}
.home-v2-analytics-card[data-analytics-reference="v17"] .home-v2-analytics-total{
  display:block;
  color:#f5f5f5;
  font-size:31px;
  line-height:.98;
  letter-spacing:-.05em;
  font-weight:520;
}
.home-v2-analytics-card[data-analytics-reference="v17"] .home-v2-analytics-graph{
  position:relative;
  margin-top:22px;
  height:128px;
  border-radius:12px;
  overflow:hidden;
}
.home-v2-analytics-card[data-analytics-reference="v17"] .home-v2-analytics-graph svg{
  width:100%;
  height:100%;
  display:block;
}
.home-v2-analytics-card[data-analytics-reference="v17"] .home-v2-analytics-graph .grid{
  stroke:rgba(255,255,255,.08);
  stroke-width:.65;
  fill:none;
}
.home-v2-analytics-card[data-analytics-reference="v17"] .home-v2-analytics-graph .line{
  stroke:rgba(255,255,255,.34);
  stroke-width:1.15;
  fill:none;
  filter:drop-shadow(0 0 8px rgba(255,255,255,.09));
}
.home-v2-analytics-card[data-analytics-reference="v17"] .home-v2-analytics-bottom-shade{
  position:absolute;
  left:-12px;
  right:-12px;
  bottom:-12px;
  z-index:2;
  height:80px;
  pointer-events:none;
  background:linear-gradient(180deg,rgba(23,23,23,0) 0%,rgba(23,23,23,.55) 54%,#171717 100%);
}
.home-v2-analytics-card[data-analytics-reference="v17"] .home-v2-analytics-footer{
  position:absolute;
  left:6px;
  right:6px;
  bottom:3px;
  z-index:3;
  display:flex;
  align-items:center;
  justify-content:space-between;
  pointer-events:none;
}
.home-v2-analytics-card[data-analytics-reference="v17"] .home-v2-analytics-footer strong,
.home-v2-analytics-card[data-analytics-reference="v17"] .home-v2-analytics-footer span{
  color:#d0d0d0;
  font-size:12px;
  line-height:1;
  font-weight:420;
  letter-spacing:0;
  white-space:nowrap;
}
@media(max-width:640px){
  .home-reference-v2-previews .home-preview-card.home-v2-analytics-card[data-analytics-reference="v17"]{
    min-height:218px;
    padding:9px;
    border-radius:16px;
  }
  .home-v2-analytics-card[data-analytics-reference="v17"] .home-v2-analytics-stage{
    min-height:198px;
    padding:12px 10px 38px;
  }
  .home-v2-analytics-card[data-analytics-reference="v17"] .home-v2-analytics-topline{
    margin-bottom:11px;
  }
  .home-v2-analytics-card[data-analytics-reference="v17"] .home-v2-analytics-topline strong,
  .home-v2-analytics-card[data-analytics-reference="v17"] .home-v2-analytics-topline span{
    font-size:11px;
  }
  .home-v2-analytics-card[data-analytics-reference="v17"] .home-v2-analytics-total{
    font-size:28px;
  }
  .home-v2-analytics-card[data-analytics-reference="v17"] .home-v2-analytics-graph{
    margin-top:18px;
    height:122px;
  }
  .home-v2-analytics-card[data-analytics-reference="v17"] .home-v2-analytics-bottom-shade{
    left:-9px;
    right:-9px;
    bottom:-9px;
    height:71px;
  }
  .home-v2-analytics-card[data-analytics-reference="v17"] .home-v2-analytics-footer{
    left:4px;
    right:4px;
    bottom:2px;
  }
  .home-v2-analytics-card[data-analytics-reference="v17"] .home-v2-analytics-footer strong,
  .home-v2-analytics-card[data-analytics-reference="v17"] .home-v2-analytics-footer span{
    font-size:11px;
  }
}
'''
    css_path.write_text(css.rstrip() + '\n\n' + css_patch + '\n')
    print('PASS analytics reference CSS added')
else:
    print('PASS analytics reference CSS already installed')

app = app_path.read_text()
css = css_path.read_text()
checks = {
    'analytics marker': app_marker in app,
    'analytics topline': 'home-v2-analytics-topline' in app,
    'analytics footer': 'home-v2-analytics-footer' in app,
    'analytics graph': 'home-v2-analytics-graph' in app,
    'css marker': css_marker in css,
}
for label, ok in checks.items():
    if not ok:
        raise SystemExit(f'ERROR: verification failed: {label}')
    print('PASS', label)
PYCODE

echo
 echo "== Project checks =="
npm run check

echo
 echo "== Git diff =="
git diff --stat

git add src/app.js src/styles.css

if git diff --cached --quiet; then
  echo "No new changes to commit."
else
  git commit -m "Match Analytics preview to reference layout"
  git push
fi

echo
 echo "DONE: Analytics Reference Match v17 installed, checked, committed, and pushed."
echo "No server restart was performed."
echo "Restart Run/Console manually once, then reload the page."
