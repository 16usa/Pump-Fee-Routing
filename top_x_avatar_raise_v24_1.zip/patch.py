
from pathlib import Path

path=Path("src/styles.css")
css=path.read_text()

marker="/* top-x-avatar-raise-v24-1 */"
if marker not in css:
    css += r'''
/* top-x-avatar-raise-v24-1
   Avatar is larger and sits mostly inside the cover.
   Only about one third crosses the cover/body divider.
   Content below follows upward with it. */
.home-profile-feature[data-profile-layout="v22"] .home-profile-avatar{
  left:20px;
  bottom:-27px;
}

.home-profile-feature[data-profile-layout="v22"] .home-profile-avatar .avatar{
  width:80px;
  height:80px;
  border-width:4px;
}

.home-profile-feature[data-profile-layout="v22"] .home-profile-feature-body{
  padding-top:36px;
}

@media(max-width:640px){
  .home-profile-feature[data-profile-layout="v22"] .home-profile-avatar{
    left:14px;
    bottom:-24px;
  }

  .home-profile-feature[data-profile-layout="v22"] .home-profile-avatar .avatar{
    width:72px;
    height:72px;
    border-width:3px;
  }

  .home-profile-feature[data-profile-layout="v22"] .home-profile-feature-body{
    padding-top:32px;
  }
}
'''
    path.write_text(css)
    print("src/styles.css: Top X avatar raised and enlarged")
else:
    print("src/styles.css: patch already installed")

print("PASS: CSS patch prepared")
