Top X Avatar Raise v24.1

Changes only the Top X Profiles card layout:
- avatar is slightly larger;
- avatar is moved upward;
- only about one third of the avatar crosses the cover/body divider;
- name, @username, Paid Profile badge and stats all move upward with it;
- no automatic server restart.

Install in existing Replit Shell:

rm -rf /tmp/top_x_avatar_raise_v24_1 && mkdir -p /tmp/top_x_avatar_raise_v24_1 && unzip -o top_x_avatar_raise_v24_1.zip -d /tmp/top_x_avatar_raise_v24_1 && bash /tmp/top_x_avatar_raise_v24_1/install.sh
