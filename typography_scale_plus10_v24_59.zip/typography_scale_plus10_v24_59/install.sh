#!/usr/bin/env bash
set -euo pipefail

PATCH_NAME="typography_scale_plus10_v24_59"
CSS="src/styles.css"
PREV_MARKER="typography-scale-110-v24-58"
MARKER="typography-scale-plus10-v24-59"
BACKUP=".patch-backups/${PATCH_NAME}/styles.css.before"

if [ ! -f "$CSS" ]; then
  echo "ERROR: missing $CSS"
  echo "Run this from the existing Replit project root."
  exit 1
fi

if grep -q "$MARKER" "$CSS"; then
  echo "PASS: ${PATCH_NAME} is already installed."
  exit 0
fi

if ! grep -q "$PREV_MARKER" "$CSS"; then
  echo "ERROR: v24.58 (+10%) is not installed."
  echo "Install typography_scale_110_v24_58 first."
  exit 1
fi

echo "==> Backing up current +10% typography state"
mkdir -p "$(dirname "$BACKUP")"
cp "$CSS" "$BACKUP"

echo "==> Applying another +10% typography scale"
python3 "$(dirname "$0")/patch.py"

echo "==> Verifying marker"
grep -q "$MARKER" "$CSS"

echo "==> Running project check"
npm run check

echo "==> Git diff"
git diff --stat -- "$CSS"

git add "$CSS"
if git diff --cached --quiet; then
  echo "==> No new changes to commit."
else
  git commit -m "Increase typography by another 10 percent"
  git push origin main
fi

echo
echo "PASS: ${PATCH_NAME} installed."
echo "No server restart was performed."
echo "Rollback restores the exact v24.58 (+10%) state."
