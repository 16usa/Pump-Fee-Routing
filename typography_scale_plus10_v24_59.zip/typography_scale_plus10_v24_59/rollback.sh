#!/usr/bin/env bash
set -euo pipefail

PATCH_NAME="typography_scale_plus10_v24_59"
CSS="src/styles.css"
BACKUP=".patch-backups/${PATCH_NAME}/styles.css.before"

if [ ! -f "$BACKUP" ]; then
  echo "ERROR: rollback backup not found: $BACKUP"
  exit 1
fi

echo "==> Restoring exact pre-v24.59 typography (+10% state)"
cp "$BACKUP" "$CSS"

echo "==> Running project check"
npm run check

echo "==> Git diff"
git diff --stat -- "$CSS"

git add "$CSS"
if git diff --cached --quiet; then
  echo "==> No rollback changes to commit."
else
  git commit -m "Rollback second 10 percent typography increase"
  git push origin main
fi

echo
echo "PASS: restored exact v24.58 (+10%) typography state."
echo "No server restart was performed."
