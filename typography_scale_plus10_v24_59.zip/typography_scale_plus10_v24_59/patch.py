from pathlib import Path
import re

CSS = Path('src/styles.css')
PREV_MARKER = '/* typography-scale-110-v24-58 */'
MARKER = '/* typography-scale-plus10-v24-59 */'

if not CSS.exists():
    raise SystemExit('ERROR: src/styles.css not found. Run from the existing Replit project root.')

src = CSS.read_text()

if MARKER in src:
    print('PASS: typography_scale_plus10_v24_59 is already installed.')
    raise SystemExit(0)

if PREV_MARKER not in src:
    raise SystemExit('ERROR: v24.58 (+10%) is not installed. Install typography_scale_110_v24_58 first.')

font_size_decl = re.compile(r'(?P<prefix>font-size\s*:\s*)(?P<value>[^;}]+)', re.I)
px_number = re.compile(r'(?<![A-Za-z0-9_.-])(\d+(?:\.\d+)?)px\b', re.I)

changed_declarations = 0
changed_values = 0

def fmt(n):
    return f'{n:.3f}'.rstrip('0').rstrip('.')

def scale_value(value):
    global changed_values
    local = 0
    def repl(m):
        nonlocal local
        n = float(m.group(1))
        if n == 0:
            return m.group(0)
        local += 1
        return f'{fmt(n * 1.10)}px'
    out = px_number.sub(repl, value)
    changed_values += local
    return out, local

def decl_repl(m):
    global changed_declarations
    value, count = scale_value(m.group('value'))
    if count:
        changed_declarations += 1
    return m.group('prefix') + value

new_src = font_size_decl.sub(decl_repl, src)

if changed_declarations == 0:
    raise SystemExit('ERROR: no px-based font-size declarations were found.')

new_src += f'''\n\n{MARKER}\n/*\n  Second typography experiment: +10% on top of v24.58.\n  This compounds to about 121% of the original px-based typography.\n  Rollback restores the exact v24.58 state present before this patch.\n*/\n'''

CSS.write_text(new_src)
print(f'PASS: scaled {changed_declarations} font-size declarations by another 10%.')
print(f'PASS: scaled {changed_values} px values, including px values inside clamp().')
print('PASS: rollback target is the exact pre-v24.59 stylesheet (+10% state).')
