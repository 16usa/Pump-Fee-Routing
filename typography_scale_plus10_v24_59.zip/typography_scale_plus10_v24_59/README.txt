Typography Scale +10% on top — v24.59

Purpose
- Apply another +10% to the typography that already has v24.58 installed.
- This is multiplicative: 110% x 110% = about 121% of the original px-based typography.

Safety
- The installer refuses to run unless v24.58 is already present.
- Before changing anything, it backs up the exact current stylesheet.
- rollback.sh restores that exact pre-v24.59 state, i.e. the +10% version.

What changes
- px-based font-size declarations only, including px values inside clamp(...).

What does not change
- card sizes
- padding/margins
- borders
- images
- 3D/layout geometry
- unitless line-height rules

No automatic server restart.
