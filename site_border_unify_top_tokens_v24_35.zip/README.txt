site_border_unify_top_tokens_v24_35

Reference color:
Top Tokens outer border = #252525

This patch standardizes structural border/divider colors across src/styles.css:
- cards
- preview modules
- panels
- inputs / structural controls
- topbar/footer separators
- dashed empty-state frames
- section separators
- shared --line / --line2 / --home-ref-border variables
- known 1px divider backgrounds

It preserves border thickness, solid/dashed style, radius, icon strokes/rings, and semantic active/success/error accents.

No automatic restart.
