#!/usr/bin/env bash
set -euo pipefail

PATCH_NAME="site_border_unify_top_tokens_v24_35"
CSS="src/styles.css"

if [ ! -f "$CSS" ]; then
  echo "ERROR: missing src/styles.css"
  echo "Run this from the existing Replit project root."
  exit 1
fi

echo "==> Installing ${PATCH_NAME}"
mkdir -p ".patch-backups/${PATCH_NAME}"
cp "$CSS" ".patch-backups/${PATCH_NAME}/styles.css.before"

python3 "$(dirname "$0")/patch.py"

echo "==> Verifying patch marker"
grep -q 'site-border-unify-top-tokens-v24-35' "$CSS"
grep -q -- '--site-structural-border:#252525' "$CSS"

echo "==> Running project check"
npm run check

echo "==> Git diff"
git diff -- src/styles.css

git add src/styles.css
if git diff --cached --quiet; then
  echo "==> No new changes to commit."
else
  git commit -m "Unify structural borders with Top Tokens"
  git push origin main
fi

echo
echo "PASS: ${PATCH_NAME} installed."
echo "Structural card/frame/divider colors now use #252525."
echo "No server restart was performed."
