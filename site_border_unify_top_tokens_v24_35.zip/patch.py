from pathlib import Path
import re

CSS = Path('src/styles.css')
if not CSS.exists():
    raise SystemExit('ERROR: src/styles.css not found. Run from the existing Replit project root.')

text = CSS.read_text()
original = text
TARGET = '#252525'

# Shared structural line/border variables.
text = re.sub(r'(--line\s*:\s*)[^;]+', rf'\g<1>{TARGET}', text)
text = re.sub(r'(--line2\s*:\s*)[^;]+', rf'\g<1>{TARGET}', text)
text = re.sub(r'(--home-ref-border\s*:\s*)[^;]+', rf'\g<1>{TARGET}', text)

# Preserve icon strokes/rings and semantic state accents.
SKIP_SELECTOR = re.compile(
    r'avatar|verified|paid-icon|money-mark|pump-logo|menu-btn|'
    r'home-v2-launch-search\s*>\s*i|mini-icon|route-line|'
    r'optout-effects\s*>\s*b|optout-progress[^,{]*\s+b|home-on-money|'
    r'\.active\b|\.good\b|\.done\b|\.success\b|\.error\b|\.danger\b',
    re.I
)

PROP = re.compile(
    r'(?P<prefix>(?:^|;)\s*)'
    r'(?P<prop>border(?:-(?:top|right|bottom|left|block|inline)'
    r'(?:-(?:start|end))?)?(?:-color)?|border-color)'
    r'(?P<sep>\s*:\s*)'
    r'(?P<val>[^;}]*)',
    re.I
)

COLOR = re.compile(
    r'#[0-9a-fA-F]{3,8}\b|'
    r'rgba?\([^)]*\)|hsla?\([^)]*\)|'
    r'\bcurrentColor\b|'
    r'var\(--home-ref-border\)|var\(--line2?\)',
    re.I
)

changed = []

def normalize_body(selector, body):
    if SKIP_SELECTOR.search(selector):
        return body

    def repl(m):
        val = m.group('val')
        stripped = re.sub(r'\s*!important\s*$', '', val, flags=re.I).strip().lower()
        if stripped in {'0', 'none', 'initial', 'inherit', 'unset'}:
            return m.group(0)
        if 'transparent' in stripped:
            return m.group(0)

        new_val, n = COLOR.subn(TARGET, val)
        if not n:
            return m.group(0)
        if new_val != val:
            changed.append((selector.strip(), m.group('prop'), val.strip(), new_val.strip()))
        return f"{m.group('prefix')}{m.group('prop')}{m.group('sep')}{new_val}"

    return PROP.sub(repl, body)

BLOCK = re.compile(r'(?P<selector>[^{}]+)\{(?P<body>[^{}]*)\}', re.S)

def block_repl(m):
    selector = m.group('selector')
    body = m.group('body')
    return f"{selector}{{{normalize_body(selector, body)}}}"

text = BLOCK.sub(block_repl, text)

# Known structural separators implemented with background instead of border.
text = re.sub(
    r'(\.home-route-rail\s+span\s*\{[^{}]*?background\s*:\s*)#[0-9a-fA-F]{3,8}',
    rf'\g<1>{TARGET}',
    text,
    flags=re.S,
)
text = re.sub(
    r'(\.launch-divider\s*\{[^{}]*?background\s*:\s*)#[0-9a-fA-F]{3,8}',
    rf'\g<1>{TARGET}',
    text,
    flags=re.S,
)

marker = '/* site-border-unify-top-tokens-v24-35 */'
if marker not in text:
    text += '\n\n' + marker + '\n:root{--site-structural-border:#252525;}\n'

if text == original:
    print('No changes needed: structural borders already use #252525.')
else:
    CSS.write_text(text)
    print(f'PASS: standardized {len(changed)} structural border declarations to {TARGET}.')
    print('PASS: shared line variables and known 1px structural dividers also use #252525.')
    print('NOTE: icon strokes/rings and semantic active/success/error accents were intentionally preserved.')
