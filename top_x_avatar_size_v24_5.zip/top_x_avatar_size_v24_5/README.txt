Top X Avatar Size v24.5

Changes:
- slightly enlarges the Top X profile avatar;
- keeps the current vertical position;
- does not bring back the removed outer translucent ring;
- no automatic server restart.

Install in the existing Replit Shell:

rm -rf /tmp/top_x_avatar_size_v24_5 && mkdir -p /tmp/top_x_avatar_size_v24_5 && unzip -o top_x_avatar_size_v24_5.zip -d /tmp/top_x_avatar_size_v24_5 && bash /tmp/top_x_avatar_size_v24_5/install.sh
