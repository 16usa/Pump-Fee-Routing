from pathlib import Path

path=Path("src/styles.css")
css=path.read_text()

marker="/* top-x-avatar-size-v24-5 */"
if marker not in css:
    css += r'''

/* top-x-avatar-size-v24-5
   Slightly enlarge the Top X avatar while keeping the current position. */
.home-profile-feature[data-profile-layout="v22"] .home-profile-avatar .avatar{
  width:86px;
  height:86px;
}

@media(max-width:640px){
  .home-profile-feature[data-profile-layout="v22"] .home-profile-avatar .avatar{
    width:76px;
    height:76px;
  }
}
'''
    path.write_text(css)
    print("src/styles.css: Top X avatar slightly enlarged")
else:
    print("src/styles.css: patch already installed")

print("PASS: CSS patch prepared")
