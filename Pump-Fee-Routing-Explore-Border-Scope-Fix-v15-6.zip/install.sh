#!/usr/bin/env bash
set -euo pipefail

echo "== Explore Border Scope Fix v15.6 =="

for f in src/app.js src/styles.css; do
  if [ ! -f "$f" ]; then
    echo "ERROR: $f not found. Run this from the existing Replit project workspace."
    exit 1
  fi
done

python3 <<'PYCODE'
from pathlib import Path

css_path = Path("src/styles.css")
app_path = Path("src/app.js")
css = css_path.read_text()
app = app_path.read_text()

if 'home-explore-reference-v8' not in css or 'data-explore-card-info="v15"' not in app:
    raise SystemExit("ERROR: expected Explore v8/v15 structure not found.")

marker = "/* explore-border-scope-fix-v15-6 */"
patch = """
/* explore-border-scope-fix-v15-6 */

/* Restore the INNER CARD construction that v15.5 removed.
   Only the image/media frames stay borderless. */
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info=\"v15\"],
.home-explore-reference-v8 .home-explore-v8-secondary-card{
  background:#0b0b0b !important;
  box-shadow:0 8px 22px rgba(0,0,0,.22) !important;
}

/* Restore original card edges from the reference geometry. */
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info=\"v15\"]{
  border:1px solid #2b2b2b !important;
  border-left:0 !important;
  border-top:0 !important;
  border-bottom:0 !important;
  border-radius:0 15px 15px 0 !important;
}
.home-explore-reference-v8 .home-explore-v8-secondary-card{
  border:1px solid #2b2b2b !important;
  border-right:0 !important;
  border-bottom:0 !important;
  border-radius:15px 0 0 0 !important;
}

/* Restore the information-section divider under the image. */
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info=\"v15\"] > .home-explore-v8-copy{
  border-top:1px solid #272727 !important;
}

/* THIS is the only thing that remains borderless: the images/media themselves. */
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info=\"v15\"] > .home-explore-v8-media,
.home-explore-reference-v8 .home-explore-v8-secondary-card > .home-explore-v8-media{
  border:0 !important;
  box-shadow:none !important;
}

@media (max-width:640px){
  .home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info=\"v15\"]{
    border-radius:0 12px 12px 0 !important;
  }
  .home-explore-reference-v8 .home-explore-v8-secondary-card{
    border-radius:12px 0 0 0 !important;
  }
}
"""

if marker in css:
    print("PASS v15.6 already installed")
else:
    css_path.write_text(css.rstrip() + "\n\n" + patch + "\n")
    print("PASS restored card construction; image frames remain removed")

css = css_path.read_text()
checks = {
    "marker": marker in css,
    "primary card border restored": 'border-left:0 !important;' in css,
    "secondary card border restored": 'border-right:0 !important;' in css,
    "info divider restored": 'border-top:1px solid #272727 !important;' in css,
    "media border remains removed": 'border:0 !important;' in css,
}
for label, ok in checks.items():
    if not ok:
        raise SystemExit(f"ERROR: verification failed: {label}")
    print("PASS", label)
PYCODE

echo
echo "== Project checks =="
npm run check

echo
echo "== Git diff =="
git diff --stat

git add src/styles.css
if git diff --cached --quiet; then
  echo "No new changes to commit."
else
  git commit -m "Restore Explore card frames, keep image frames removed"
  git push
fi

echo
echo "DONE: Explore Border Scope Fix v15.6 installed, checked, committed, and pushed."
echo "No server restart was performed."
echo "Restart Run/Console manually once, then reload the page."
