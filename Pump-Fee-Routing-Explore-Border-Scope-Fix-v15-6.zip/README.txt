Pump Fee Routing — Explore Border Scope Fix v15.6

This corrects v15.5/v15.5.1.

It restores:
- the left inner Explore card construction
- the right inner Explore card construction
- the divider between the image and info section

It keeps removed:
- border around the LEFT image
- border around the RIGHT image

It does NOT restart the server.

Install in existing Replit Shell:
rm -rf /tmp/explore-border-scope-fix-v15-6
mkdir -p /tmp/explore-border-scope-fix-v15-6
unzip -o Pump-Fee-Routing-Explore-Border-Scope-Fix-v15-6.zip -d /tmp/explore-border-scope-fix-v15-6
bash /tmp/explore-border-scope-fix-v15-6/install.sh
