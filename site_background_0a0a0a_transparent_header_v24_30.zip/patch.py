from pathlib import Path
import re

path = Path("src/styles.css")
if not path.exists():
    raise SystemExit("ERROR: src/styles.css not found. Run from the existing Replit project root.")

css = path.read_text()

def convert_background(match):
    prop = match.group(1)
    value = match.group(2)

    # Pure-black HEX used only inside background/background-color declarations.
    value = re.sub(r"(?i)#000000(?![0-9a-f])", "#0A0A0A", value)
    value = re.sub(r"(?i)#000(?![0-9a-f])", "#0A0A0A", value)

    # Preserve opacity while changing the black base from 0,0,0 to 10,10,10.
    value = re.sub(
        r"rgba\(\s*0\s*,\s*0\s*,\s*0\s*,\s*([^)]+)\)",
        r"rgba(10,10,10,\1)",
        value,
        flags=re.I,
    )
    value = re.sub(
        r"rgb\(\s*0\s*,\s*0\s*,\s*0\s*\)",
        "rgb(10,10,10)",
        value,
        flags=re.I,
    )
    return prop + value

# Update only CSS background/background-color values, not black text/icons.
css = re.sub(
    r"((?:background|background-color)\s*:\s*)([^;}]+)",
    convert_background,
    css,
    flags=re.I,
)

# Theme variable.
css = re.sub(
    r"(--bg\s*:\s*)#(?:000000|000)(?![0-9a-f])",
    r"\1#0A0A0A",
    css,
    flags=re.I,
)

marker = "/* site-background-0a0a0a-transparent-header-v24-30 */"
if marker not in css:
    css += r'''

/* site-background-0a0a0a-transparent-header-v24-30
   Global site background = #0A0A0A.
   Sticky header keeps the original 90% opacity effect. */
:root{
  --bg:#0A0A0A !important;
  background:#0A0A0A !important;
}

html,
body{
  background:#0A0A0A !important;
}

.topbar,
.home-page .topbar{
  background:rgba(10,10,10,.90) !important;
}
'''

path.write_text(css)
print("PASS: site backgrounds changed to #0A0A0A; header transparency preserved at 90% opacity")
