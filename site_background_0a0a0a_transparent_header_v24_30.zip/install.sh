#!/usr/bin/env bash
set -euo pipefail

PATCH_NAME="site_background_0a0a0a_transparent_header_v24_30"
CSS="src/styles.css"

if [ ! -f "$CSS" ]; then
  echo "ERROR: missing $CSS"
  echo "Run this from the existing Replit project root."
  exit 1
fi

echo "==> Installing ${PATCH_NAME}"

mkdir -p ".patch-backups/${PATCH_NAME}"
cp "$CSS" ".patch-backups/${PATCH_NAME}/styles.css.before"

python3 "$(dirname "$0")/patch.py"

echo "==> Running project check"
npm run check

echo "==> Git diff"
git diff -- src/styles.css

git add src/styles.css

if git diff --cached --quiet; then
  echo "==> No new changes to commit."
else
  git commit -m "Use #0A0A0A site background with transparent header"
  git push origin main
fi

echo
echo "PASS: ${PATCH_NAME} installed."
echo "No server restart was performed."
