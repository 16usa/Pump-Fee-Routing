Site Background #0A0A0A + Transparent Header v24.30

What this patch does:
- changes pure-black CSS backgrounds (#000 / #000000) to #0A0A0A;
- changes black rgba backgrounds to the same #0A0A0A base while preserving alpha;
- keeps the sticky header transparent:
  rgba(10,10,10,.90)
  = #0A0A0A base with 90% opacity / 10% transparency;
- changes only background/background-color values, not black text or icons;
- updates --bg to #0A0A0A;
- no automatic server restart.

Install in the existing Replit Shell:

rm -rf /tmp/site_background_0a0a0a_transparent_header_v24_30 && mkdir -p /tmp/site_background_0a0a0a_transparent_header_v24_30 && unzip -o site_background_0a0a0a_transparent_header_v24_30.zip -d /tmp/site_background_0a0a0a_transparent_header_v24_30 && bash /tmp/site_background_0a0a0a_transparent_header_v24_30/install.sh
