Patch v24.37
- removes the thin inner border from the projected Top Token card inside the Explore block
- keeps the main Explore block border intact
- preserves all existing sizing, layout, and footer spacing
