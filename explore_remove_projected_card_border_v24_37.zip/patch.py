from pathlib import Path

css_path = Path('src/styles.css')
if not css_path.exists():
    raise SystemExit('ERROR: src/styles.css not found. Run from the existing Replit project root.')

css = css_path.read_text()
marker = '/* explore-remove-projected-card-border-v24-37 */'

if 'data-explore-projection="top-token-v24-32"' not in css:
    raise SystemExit('ERROR: Explore projected Top Token card selector not found in src/styles.css')

if marker not in css:
    css += r'''

/* explore-remove-projected-card-border-v24-37
   Remove the thin inner border from the projected Top Token card
   inside the Explore preview block, while preserving the block itself. */
.home-explore-reference-v8 .home-explore-top-token-card[data-top-token-layout="v21"][data-explore-projection="top-token-v24-32"]{
  border:none !important;
  outline:none !important;
  box-shadow:none !important;
}
'''
    css_path.write_text(css)
    print('PASS: Thin border removed from the projected Explore top-token card.')
else:
    print('No changes needed; patch already installed.')
