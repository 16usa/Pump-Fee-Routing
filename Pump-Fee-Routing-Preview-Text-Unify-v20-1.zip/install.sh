#!/usr/bin/env bash
set -euo pipefail

echo "== Preview Text Unify v20.1 =="

if [ ! -f src/styles.css ]; then
  echo "ERROR: src/styles.css not found. Run this from the existing Replit project workspace."
  exit 1
fi

python3 <<'PYCODE'
from pathlib import Path

css_path = Path("src/styles.css")
css = css_path.read_text()

required = [
    "home-explore-v8-footer",
    "home-v2-payments-footer",
    "home-v2-analytics-footer",
    "home-v2-analytics-topline",
    "home-v2-launch-footer",
    "home-v2-launch-eyebrow",
    "home-v2-docs-footer",
]
for needle in required:
    if needle not in css:
        raise SystemExit(f"ERROR: expected selector missing: {needle}")

marker = "/* preview-text-unify-v20-1 */"

patch = r'''
/* preview-text-unify-v20-1 */

/*
  Footer text reference = Docs -> Open.
  IMPORTANT:
  FEES ROUTE TO in Launch is NOT changed.
  Analytics Fees / 1D are matched to FEES ROUTE TO.
*/

/* Footer labels only: Explore, Payments, Analytics, Launch, Docs. */
.home-explore-reference-v8 .home-explore-v8-footer strong,
.home-explore-reference-v8 .home-explore-v8-footer span,
.home-v2-payments-card[data-payments-reference="v16"] .home-v2-payments-footer strong,
.home-v2-payments-card[data-payments-reference="v16"] .home-v2-payments-footer span,
.home-v2-analytics-card[data-analytics-reference="v17"] .home-v2-analytics-footer strong,
.home-v2-analytics-card[data-analytics-reference="v17"] .home-v2-analytics-footer span,
.home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-footer strong,
.home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-footer span,
.home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-footer strong,
.home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-footer span{
  color:#888 !important;
  font-size:13px !important;
  line-height:1 !important;
  font-weight:430 !important;
  letter-spacing:0 !important;
  white-space:nowrap;
}

/* Restore/preserve FEES ROUTE TO exactly as Launch v18 defined it.
   This also neutralizes the old v20 patch if it was installed earlier. */
.home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-eyebrow{
  color:#777 !important;
  font-size:11px !important;
  line-height:1 !important;
  font-weight:520 !important;
  letter-spacing:.13em !important;
}

/* Analytics Fees + 1D use the SAME visual typography as FEES ROUTE TO. */
.home-v2-analytics-card[data-analytics-reference="v17"] .home-v2-analytics-topline strong,
.home-v2-analytics-card[data-analytics-reference="v17"] .home-v2-analytics-topline span{
  color:#777 !important;
  font-size:11px !important;
  line-height:1 !important;
  font-weight:520 !important;
  letter-spacing:.13em !important;
}

@media(max-width:640px){
  .home-explore-reference-v8 .home-explore-v8-footer strong,
  .home-explore-reference-v8 .home-explore-v8-footer span,
  .home-v2-payments-card[data-payments-reference="v16"] .home-v2-payments-footer strong,
  .home-v2-payments-card[data-payments-reference="v16"] .home-v2-payments-footer span,
  .home-v2-analytics-card[data-analytics-reference="v17"] .home-v2-analytics-footer strong,
  .home-v2-analytics-card[data-analytics-reference="v17"] .home-v2-analytics-footer span,
  .home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-footer strong,
  .home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-footer span,
  .home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-footer strong,
  .home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-footer span{
    color:#888 !important;
    font-size:12px !important;
  }

  .home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-eyebrow{
    color:#777 !important;
    font-size:9px !important;
    line-height:1 !important;
    font-weight:520 !important;
    letter-spacing:.14em !important;
  }

  .home-v2-analytics-card[data-analytics-reference="v17"] .home-v2-analytics-topline strong,
  .home-v2-analytics-card[data-analytics-reference="v17"] .home-v2-analytics-topline span{
    color:#777 !important;
    font-size:9px !important;
    line-height:1 !important;
    font-weight:520 !important;
    letter-spacing:.14em !important;
  }
}
'''

if marker not in css:
    css_path.write_text(css.rstrip() + "\n\n" + patch + "\n")
    print("PASS corrected typography rules appended")
else:
    print("PASS v20.1 already installed")

updated = css_path.read_text()
checks = {
    "marker": marker in updated,
    "Launch eyebrow preserved": "home-v2-launch-eyebrow" in updated[updated.rfind(marker):],
    "Analytics topline matched": "home-v2-analytics-topline strong" in updated[updated.rfind(marker):],
    "Footer labels unified": "home-v2-docs-footer strong" in updated[updated.rfind(marker):],
}
for label, ok in checks.items():
    if not ok:
        raise SystemExit(f"ERROR: verification failed: {label}")
    print("PASS", label)
PYCODE

echo
echo "== Project checks =="
npm run check

echo
echo "== Git diff =="
git diff --stat

git add src/styles.css

if git diff --cached --quiet; then
  echo "No new changes to commit."
else
  git commit -m "Correct preview label typography"
  git push
fi

echo
echo "DONE: Preview Text Unify v20.1 installed, checked, committed, and pushed."
echo "No server restart was performed."
echo "Restart Run/Console manually once, then reload the page."
