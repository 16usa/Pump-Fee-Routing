Pump Fee Routing — Preview Text Unify v20.1

CORRECTION to v20.

Untouched:
- Launch -> FEES ROUTE TO keeps its existing color, size, weight, and tracking.

Changed:
- Analytics -> Fees and 1D are made the same typography as Launch -> FEES ROUTE TO.
- Footer labels remain unified to the Docs/Open reference:
  Explore / Open
  Payments / Open
  Analytics / Open
  Launch / Open
  Docs / Open

If old v20 was already installed, this patch overrides its wrong FEES ROUTE TO change.

No automatic restart.

Install:
rm -rf /tmp/preview-text-unify-v20-1
mkdir -p /tmp/preview-text-unify-v20-1
unzip -o Pump-Fee-Routing-Preview-Text-Unify-v20-1.zip -d /tmp/preview-text-unify-v20-1
bash /tmp/preview-text-unify-v20-1/install.sh
