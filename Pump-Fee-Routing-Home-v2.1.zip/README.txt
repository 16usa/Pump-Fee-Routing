Pump Fee Routing — Home v2.1
Same Home v2 UI patch, but the installer ignores unrelated Replit/.conversation changes and uploaded ZIP files.
It blocks only if src/app.js or src/styles.css already have uncommitted changes.
Runs npm check, commits, and pushes to origin/main.
No automatic server restart.
