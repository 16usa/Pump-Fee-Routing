Top Tokens Inner Avatar Downsize v24.24

What this changes:
- slightly reduces the recipient avatar inside the Top Tokens pill;
- makes the left dollar circle the same reduced size;
- reduces the dollar glyph proportionally;
- keeps avatar and dollar circle matched.

Target:
- Top Tokens card recipient pill only.

Install from the existing Replit Shell:

rm -rf /tmp/top_tokens_inner_avatar_downsize_v24_24 && mkdir -p /tmp/top_tokens_inner_avatar_downsize_v24_24 && unzip -o top_tokens_inner_avatar_downsize_v24_24.zip -d /tmp/top_tokens_inner_avatar_downsize_v24_24 && bash /tmp/top_tokens_inner_avatar_downsize_v24_24/install.sh
