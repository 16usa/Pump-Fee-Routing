Pump Fee Routing — Launch Preview Recipient v1

Changes the Launch token preview to match the reference:
- image overlay uses the resolved X recipient profile, not the token ticker
- overlay shows project mark + X avatar + display name + verified badge
- token name and ticker stay together below the image
- $0 MC and $0 Sent appear together on the next row
- X Money sent to shows avatar + display name + verified badge
- unresolved recipient shows a dash
- existing project colors, card shadow and square image are preserved

Installer checks, commits and pushes origin/main.
No automatic server restart.
