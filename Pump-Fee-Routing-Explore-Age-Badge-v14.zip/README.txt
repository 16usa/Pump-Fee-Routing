Pump Fee Routing — Explore Age Badge v14

Changes only the large LEFT token card inside the Home Explore module.

What it does:
- Adds the token age/time badge in the TOP-RIGHT corner of the image.
- Uses the same CSS class as Top Tokens: home-top-token-age.
- Uses the same data logic as Top Tokens:
    token.age || ago(token.created_at)
- Therefore the badge has the same size, color, background, border,
  blur, rounding and positioning as the Top Tokens age badge.

Does NOT change:
- token image
- X avatar / recipient pill
- Explore / Open labels
- card geometry
- Payments
- Analytics
- other modules

Install in the EXISTING Replit Shell:

rm -rf /tmp/explore-age-v14
mkdir -p /tmp/explore-age-v14
unzip -o Pump-Fee-Routing-Explore-Age-Badge-v14.zip -d /tmp/explore-age-v14
bash /tmp/explore-age-v14/install.sh

The installer checks the project, commits and pushes.
It does NOT restart the server.
Restart Run/Console manually once afterward.
