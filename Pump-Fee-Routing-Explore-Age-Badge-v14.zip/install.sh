#!/usr/bin/env bash
set -euo pipefail

echo "== Explore Age Badge v14 =="

if [ ! -f "src/app.js" ]; then
  echo "ERROR: src/app.js not found. Run this from the existing Replit project workspace."
  exit 1
fi

python3 <<'PY'
from pathlib import Path

p = Path("src/app.js")
s = p.read_text()

marker = "/* explore-age-badge-v14 */"

old = """          const renderPrimary = (token) => {
            if (!token) {
              return `<div class="home-explore-v8-primary-card is-empty"><div class="home-explore-v8-media">${renderTokenArt(null, 'primary')}</div></div>`;
            }
            return `<div class="home-explore-v8-primary-card">
              <div class="home-explore-v8-media">
                ${renderTokenArt(token, 'primary')}
                ${renderRecipient(token)}
"""

new = """          const renderPrimary = (token) => {
            if (!token) {
              return `<div class="home-explore-v8-primary-card is-empty"><div class="home-explore-v8-media">${renderTokenArt(null, 'primary')}</div></div>`;
            }
            const ageText = token.age || ago(token.created_at);
            return `<div class="home-explore-v8-primary-card">
              <div class="home-explore-v8-media">
                ${renderTokenArt(token, 'primary')}
                <div class="home-top-token-age" data-explore-age-badge="v14">${esc(ageText || '')}</div>
                ${renderRecipient(token)}
"""

if 'data-explore-age-badge="v14"' in s:
    print("PASS Explore age badge already installed")
elif old in s:
    s = s.replace(old, new, 1)
    print("PASS Explore age badge added")
else:
    raise SystemExit("ERROR: Explore primary-card anchor changed; nothing modified.")

p.write_text(s)

check = p.read_text()
required = [
    'const ageText = token.age || ago(token.created_at);',
    'class="home-top-token-age"',
    'data-explore-age-badge="v14"',
]
for item in required:
    if item not in check:
        raise SystemExit(f"ERROR: verification failed: {item}")
print("PASS verification complete")
PY

echo
echo "== Project checks =="
npm run check

echo
echo "== Git diff =="
git diff --stat

git add src/app.js

if git diff --cached --quiet; then
  echo "No new changes to commit (patch may already be installed)."
else
  git commit -m "Add token age to Explore preview"
  git push
fi

echo
echo "DONE: Explore Age Badge v14 installed, checked, committed, and pushed."
echo "No server restart was performed."
echo "Restart Run/Console manually once, then reload the page."
