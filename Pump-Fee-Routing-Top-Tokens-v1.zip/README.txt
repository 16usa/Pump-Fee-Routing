Pump Fee Routing — Top Tokens v1
Scope: Home Top Tokens section only.
Adds the two-column mobile token-card layout and real-data card fields matching the reference structure.
No demo token data is created. When the database is empty, neutral skeleton placeholders are shown.
Runs npm check, commits, and pushes to origin/main. No automatic server restart.
