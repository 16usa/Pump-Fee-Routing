#!/usr/bin/env bash
set -euo pipefail

if [ ! -f src/app.js ] || [ ! -f src/styles.css ]; then
  echo "Run this from the Pump-Fee-Routing project root."
  exit 1
fi

if [ -n "$(git status --porcelain -- src/app.js src/styles.css)" ]; then
  echo "STOP: src/app.js or src/styles.css has uncommitted changes."
  git status --short -- src/app.js src/styles.css
  exit 2
fi

python3 - <<'PY'
from pathlib import Path

app_path = Path("src/app.js")
css_path = Path("src/styles.css")
app = app_path.read_text()
css = css_path.read_text()

marker = "/* home-top-tokens-v1 */"
if marker in css:
    raise SystemExit("Top Tokens v1 is already installed.")

insert_before = "function homeMostPayments(h){"
idx = app.find(insert_before)
if idx < 0:
    raise SystemExit("Could not locate homeMostPayments() in src/app.js")

helper = r'''function homeTopTokenCard(t){
  const handle=t.profile||t.recipient_handle||'';
  const mint=t.mint||t.contract||'';
  const ageText=t.age||ago(t.created_at);
  return `<a class="home-top-token-card" href="#/token/${encodeURIComponent(mint)}">
    <div class="home-top-token-media">
      ${t.image_url?`<img src="${esc(t.image_url)}" alt="">`:`<div class="home-top-token-fallback">${esc(initials(t.symbol||t.name||'T'))}</div>`}
      <div class="home-top-token-platform">${platformBadge(t.platform||'Pump')}</div>
      <div class="home-top-token-age">${esc(ageText||'')}</div>
      <div class="home-top-token-recipient">
        ${avatar(handle||t.symbol)}
        <span>${handle?`@${esc(handle)}`:'Recipient'}</span>
      </div>
    </div>
    <div class="home-top-token-body">
      <div class="home-top-token-title"><strong>${esc(t.name)}</strong><span>${esc(t.symbol||'')}</span></div>
      <div class="home-top-token-sub"><span>${fmtMc(t.mc??t.market_cap_usd)} MC</span><span>${fmtMoney(t.owed||0)} Owed</span></div>
      <div class="home-top-token-paid"><small>Sent</small><b>${fmtMoney(t.sent||0)}</b></div>
    </div>
  </a>`;
}

function homeTopTokens(top){
  const rows=top.slice(0,20);
  return `<section class="wrap section home-top-tokens">
    <div class="home-top-tokens-head">
      <h2>Top Tokens</h2>
      <div class="home-top-tokens-controls">
        <div class="home-top-token-tabs">
          <button class="active">● Pump</button>
          <button disabled>■ Pons</button>
          <button>All</button>
        </div>
        <div class="home-top-token-pager"><button disabled>‹</button><span>1</span><button disabled>›</button></div>
      </div>
    </div>
    ${rows.length
      ? `<div class="home-top-token-grid">${rows.map(homeTopTokenCard).join('')}</div>`
      : `<div class="home-top-token-empty">
          <div class="home-top-token-skeleton"><i></i><span>No registered tokens yet.</span></div>
          <div class="home-top-token-skeleton"><i></i><span>Verified tokens will appear here.</span></div>
        </div>`}
    <a class="home-top-tokens-view" href="#/explore">View all tokens →</a>
  </section>`;
}

'''

app = app[:idx] + helper + app[idx:]

old = '''    <section class="wrap section home-top-tokens">
      ${sectionTitle('Top Tokens','#/explore')}
      <div class="tabs"><button class="active">● Pump</button><button disabled>■ Pons</button><button>All</button></div>
      <div class="token-grid">${top.slice(0,12).map(t=>tokenCard(t,true)).join('')||'<div class="empty">No registered tokens yet.</div>'}</div>
      ${top.length?pager(1,Math.max(1,Math.ceil(top.length/12))):''}
    </section>'''

new = '''    ${homeTopTokens(top)}'''

if old not in app:
    raise SystemExit("Could not locate the existing Home Top Tokens block.")
app = app.replace(old, new, 1)
app_path.write_text(app)

css += r'''

/* home-top-tokens-v1 */
.home-top-tokens{padding-top:46px!important}
.home-top-tokens-head{margin-bottom:14px}
.home-top-tokens-head>h2{
  margin:0 0 11px;
  font-size:18px;
  line-height:1;
  letter-spacing:-.03em;
  font-weight:650;
}
.home-top-tokens-controls{
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap:12px;
}
.home-top-token-tabs{display:flex;align-items:center;gap:12px}
.home-top-token-tabs button,
.home-top-token-pager button{
  border:0;
  background:transparent;
  color:#5f5f5f;
  padding:0;
  font-size:9px;
  cursor:pointer;
}
.home-top-token-tabs button.active{color:#fff}
.home-top-token-tabs button:disabled{opacity:.28}
.home-top-token-pager{
  display:flex;
  align-items:center;
  gap:10px;
  color:#656565;
  font-size:8px;
}
.home-top-token-pager button{font-size:15px;line-height:1;color:#666}
.home-top-token-grid{
  display:grid;
  grid-template-columns:repeat(4,minmax(0,1fr));
  gap:9px;
}
.home-top-token-card{
  min-width:0;
  overflow:hidden;
  color:#fff;
  background:#141414;
  border:1px solid #252525;
  border-radius:13px;
}
.home-top-token-media{
  position:relative;
  aspect-ratio:1/1;
  overflow:hidden;
  background:#080808;
  border-bottom:1px solid #232323;
}
.home-top-token-media>img{
  width:100%;
  height:100%;
  display:block;
  object-fit:cover;
}
.home-top-token-fallback{
  width:100%;
  height:100%;
  display:grid;
  place-items:center;
  font-size:38px;
  font-weight:900;
  font-style:italic;
  background:radial-gradient(circle at 50% 42%,#202020,#090909 66%);
}
.home-top-token-platform,
.home-top-token-age{
  position:absolute;
  top:7px;
  z-index:2;
  padding:4px 6px;
  border:1px solid rgba(255,255,255,.12);
  border-radius:999px;
  background:rgba(0,0,0,.72);
  backdrop-filter:blur(7px);
  font-size:7px;
}
.home-top-token-platform{left:7px}
.home-top-token-age{right:7px;color:#b9b9b9}
.home-top-token-platform .platform-badge{font-size:7px}
.home-top-token-recipient{
  position:absolute;
  left:7px;
  right:7px;
  bottom:7px;
  display:flex;
  align-items:center;
  gap:5px;
  width:max-content;
  max-width:calc(100% - 14px);
  padding:4px 7px 4px 4px;
  overflow:hidden;
  border:1px solid rgba(255,255,255,.13);
  border-radius:999px;
  background:rgba(0,0,0,.78);
  backdrop-filter:blur(8px);
}
.home-top-token-recipient .avatar{
  width:17px;
  height:17px;
  border:0;
  font-size:6px;
}
.home-top-token-recipient span{
  min-width:0;
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
  color:#d0d0d0;
  font-size:7px;
}
.home-top-token-body{padding:9px}
.home-top-token-title{
  display:flex;
  align-items:baseline;
  gap:5px;
  min-width:0;
}
.home-top-token-title strong{
  min-width:0;
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
  font-size:10px;
}
.home-top-token-title span{
  color:#656565;
  font-size:7px;
  white-space:nowrap;
}
.home-top-token-sub{
  display:flex;
  justify-content:space-between;
  gap:5px;
  margin-top:5px;
  color:#606060;
  font-size:7px;
}
.home-top-token-sub span{
  min-width:0;
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
}
.home-top-token-paid{
  display:flex;
  align-items:baseline;
  justify-content:space-between;
  margin-top:9px;
  padding-top:8px;
  border-top:1px solid #242424;
}
.home-top-token-paid small{color:#616161;font-size:7px}
.home-top-token-paid b{font-size:11px;letter-spacing:-.02em}
.home-top-token-empty{
  display:grid;
  grid-template-columns:repeat(2,minmax(0,1fr));
  gap:8px;
}
.home-top-token-skeleton{
  min-height:185px;
  display:flex;
  flex-direction:column;
  align-items:center;
  justify-content:center;
  gap:13px;
  border:1px dashed #252525;
  border-radius:13px;
  color:#595959;
  font-size:8px;
  text-align:center;
  padding:16px;
}
.home-top-token-skeleton i{
  width:54px;
  height:54px;
  border-radius:11px;
  background:linear-gradient(135deg,#111,#191919,#0b0b0b);
  border:1px solid #1f1f1f;
}
.home-top-tokens-view{
  display:block;
  width:max-content;
  margin:14px 0 0 auto;
  color:#6c6c6c;
  font-size:8px;
}
@media(max-width:850px){
  .home-top-token-grid{grid-template-columns:repeat(3,minmax(0,1fr))}
}
@media(max-width:640px){
  .home-top-tokens{padding-top:38px!important}
  .home-top-tokens-head>h2{font-size:16px;margin-bottom:10px}
  .home-top-token-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}
  .home-top-token-card{border-radius:12px}
  .home-top-token-body{padding:8px}
  .home-top-token-title strong{font-size:9px}
  .home-top-token-paid b{font-size:10px}
  .home-top-token-empty{grid-template-columns:repeat(2,minmax(0,1fr))}
  .home-top-token-skeleton{min-height:170px;padding:12px}
}
'''
css_path.write_text(css)

print("Top Tokens v1 patch installed.")
PY

npm run check

git add src/app.js src/styles.css

if git diff --cached --quiet; then
  echo "No staged changes; nothing to commit."
else
  git commit -m "Match home top tokens"
fi

git push origin main

echo
echo "DONE: Top Tokens patch checked, committed, and pushed to GitHub."
echo "No server restart was performed."
echo "Refresh the browser to see the updated Top Tokens section."
