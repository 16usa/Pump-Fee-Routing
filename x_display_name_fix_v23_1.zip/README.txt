X Display Name Fix v23.1

Correct behavior after this patch:
- Primary X account name = DISPLAY NAME, for example: GG
- @reptilonx is the username/handle, not the primary name
- The same blue verified badge remains next to GG
- This applies to the sitewide identity system introduced in v23

The regression happened because the batch lookup could fall back to the old
database value "reptilonx". This patch detects that a stored "name" is actually
just the handle and refreshes it through the already-working single X profile
lookup. The frontend also refuses to replace a real display name with a handle.

Install in the existing Replit Shell:

rm -rf /tmp/x_display_name_fix_v23_1 && mkdir -p /tmp/x_display_name_fix_v23_1 && unzip -o x_display_name_fix_v23_1.zip -d /tmp/x_display_name_fix_v23_1 && bash /tmp/x_display_name_fix_v23_1/install.sh

No automatic server restart.
