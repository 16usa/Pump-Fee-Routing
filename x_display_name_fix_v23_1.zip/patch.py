
from pathlib import Path

app_path=Path("src/app.js")
api_path=Path("server/api.js")

app=app_path.read_text()
api=api_path.read_text()

# 1) Backend: replace the batch resolver with a version that falls back
# to the already-working single-profile X endpoint for stale handle-shaped names.
start=api.find("/* x-identities-batch-v23 */")
if start < 0:
    start=api.find("/* x-identities-batch-v23-1 */")
end=api.find("\n\nexport async function handleApi", start)
if start < 0 or end < 0:
    raise SystemExit("ERROR: X identities resolver block not found in server/api.js")

new_block = r'''/* x-identities-batch-v23-1 */
function cacheXIdentityUser(u){
  const username=String(u?.username||'').replace(/^@/,'').trim();
  if(!username) return null;

  const avatarUrl=largerXAvatar(u?.profile_image_url||u?.profileImageUrl||'');
  const bannerUrl=String(u?.profile_banner_url||u?.profileBannerUrl||'').trim();
  const displayName=String(u?.name||username).trim()||username;
  const verifiedType=String(u?.verified_type||u?.verifiedType||'');
  const verified=Boolean(u?.verified);

  db.prepare(`INSERT INTO recipients(
    handle,x_user_id,display_name,avatar_url,banner_url,verified,verified_type
  ) VALUES(?,?,?,?,?,?,?)
  ON CONFLICT(handle) DO UPDATE SET
    x_user_id=COALESCE(NULLIF(excluded.x_user_id,''),recipients.x_user_id),
    display_name=COALESCE(NULLIF(excluded.display_name,''),recipients.display_name),
    avatar_url=COALESCE(NULLIF(excluded.avatar_url,''),recipients.avatar_url),
    banner_url=COALESCE(NULLIF(excluded.banner_url,''),recipients.banner_url),
    verified=excluded.verified,
    verified_type=excluded.verified_type,
    updated_at=CURRENT_TIMESTAMP`)
    .run(
      username,
      String(u?.id||''),
      displayName,
      avatarUrl,
      bannerUrl,
      verified?1:0,
      verifiedType
    );

  return {
    username,
    name:displayName,
    profileImageUrl:avatarUrl,
    profileBannerUrl:bannerUrl,
    verified,
    verifiedType
  };
}

async function fetchSingleXIdentity(username){
  if(!config.xBearerToken) return null;

  try{
    const fields='id,name,username,profile_image_url,profile_banner_url,verified,verified_type';
    const r=await fetch(
      `https://api.x.com/2/users/by/username/${encodeURIComponent(username)}?user.fields=${encodeURIComponent(fields)}`,
      {
        headers:{authorization:`Bearer ${config.xBearerToken}`,accept:'application/json'},
        signal:AbortSignal.timeout(12000)
      }
    );

    if(!r.ok) return null;
    const payload=await r.json().catch(()=>({}));
    if(!payload?.data) return null;
    return cacheXIdentityUser(payload.data);
  }catch{
    return null;
  }
}

async function resolveXIdentities(handles){
  const usernames=[...new Set((handles||[])
    .map(x=>String(x||'').replace(/^@/,'').trim())
    .filter(x=>/^[A-Za-z0-9_]{1,15}$/.test(x))
  )].slice(0,100);

  if(!usernames.length) return [];

  const live=new Map();

  if(config.xBearerToken){
    // Fast path: X batch lookup.
    try{
      const fields='id,name,username,profile_image_url,profile_banner_url,verified,verified_type';
      const r=await fetch(
        `https://api.x.com/2/users/by?usernames=${encodeURIComponent(usernames.join(','))}&user.fields=${encodeURIComponent(fields)}`,
        {
          headers:{authorization:`Bearer ${config.xBearerToken}`,accept:'application/json'},
          signal:AbortSignal.timeout(15000)
        }
      );

      if(r.ok){
        const payload=await r.json().catch(()=>({}));
        for(const u of (payload?.data||[])){
          const identity=cacheXIdentityUser(u);
          if(identity) live.set(identity.username.toLowerCase(),identity);
        }
      }
    }catch{}

    // Reliable fallback: if the DB name is still literally the @handle,
    // refresh that account through the single X profile lookup.
    const getStored=db.prepare(`SELECT handle,display_name FROM recipients
      WHERE handle=? COLLATE NOCASE`);

    const stale=usernames.filter(username=>{
      if(live.has(username.toLowerCase())) return false;
      const row=getStored.get(username);
      const stored=String(row?.display_name||'').replace(/^@/,'').trim();
      return !stored || stored.toLowerCase()===username.toLowerCase();
    });

    for(let i=0;i<stale.length;i+=4){
      const group=stale.slice(i,i+4);
      const resolved=await Promise.all(group.map(fetchSingleXIdentity));
      resolved.filter(Boolean).forEach(identity=>{
        live.set(identity.username.toLowerCase(),identity);
      });
    }
  }

  const get=db.prepare(`SELECT handle,display_name,avatar_url,banner_url,verified,verified_type
    FROM recipients WHERE handle=? COLLATE NOCASE`);

  return usernames.map(username=>{
    const current=live.get(username.toLowerCase());
    if(current) return current;

    const row=get.get(username)||{};
    return {
      username:String(row.handle||username),
      name:String(row.display_name||username),
      profileImageUrl:String(row.avatar_url||''),
      profileBannerUrl:String(row.banner_url||''),
      verified:Boolean(row.verified),
      verifiedType:String(row.verified_type||'')
    };
  });
}
'''

if "/* x-identities-batch-v23-1 */" not in api:
    api=api[:start]+new_block+api[end:]
    print("server/api.js: live X display-name fallback installed")
else:
    # Replace existing v23.1 block too, so the patch is idempotent and update-safe.
    api=api[:start]+new_block+api[end:]
    print("server/api.js: live X display-name fallback refreshed")

# 2) Frontend: prefer a real display name over a value identical to @handle.
old_xidentity = r'''function xIdentity(handle,source={}){
  const clean=String(
    handle||
    source?.recipient_handle||
    source?.profile||
    source?.handle||
    source?.username||
    ''
  ).replace(/^@/,'').trim();

  const stored=typeof moneyProfile==='function'?moneyProfile(clean):null;
  const isToken=!!(source?.mint||source?.contract||source?.symbol);

  const name=String(
    source?.recipient_display_name||
    (!isToken?source?.display_name:'')||
    stored?.display_name||
    clean||
    'Recipient'
  );

  const avatarUrl=String(
    source?.recipient_avatar_url||
    source?.avatar_url||
    stored?.avatar_url||
    ''
  );

  const verifiedValue=
    source?.recipient_verified ??
    source?.verified ??
    stored?.verified ??
    0;

  const verifiedType=String(
    source?.recipient_verified_type||
    source?.verified_type||
    stored?.verified_type||
    ''
  );

  return {
    handle:clean,
    name,
    avatarUrl,
    verified:xIsVerified(verifiedValue,verifiedType),
    verifiedType
  };
}'''

new_xidentity = r'''function xIdentity(handle,source={}){
  const clean=String(
    handle||
    source?.recipient_handle||
    source?.profile||
    source?.handle||
    source?.username||
    ''
  ).replace(/^@/,'').trim();

  const stored=typeof moneyProfile==='function'?moneyProfile(clean):null;
  const isToken=!!(source?.mint||source?.contract||source?.symbol);

  const rawCandidates=[
    source?.recipient_display_name,
    !isToken?source?.display_name:'',
    stored?.display_name
  ].map(x=>String(x||'').trim()).filter(Boolean);

  const realName=rawCandidates.find(
    value=>value.replace(/^@/,'').toLowerCase()!==clean.toLowerCase()
  );
  const name=String(realName||rawCandidates[0]||clean||'Recipient');

  const avatarUrl=String(
    source?.recipient_avatar_url||
    source?.avatar_url||
    stored?.avatar_url||
    ''
  );

  const verifiedValue=
    source?.recipient_verified ??
    source?.verified ??
    stored?.verified ??
    0;

  const verifiedType=String(
    source?.recipient_verified_type||
    source?.verified_type||
    stored?.verified_type||
    ''
  );

  return {
    handle:clean,
    name,
    avatarUrl,
    verified:xIsVerified(verifiedValue,verifiedType),
    verifiedType
  };
}'''

if new_xidentity not in app:
    if old_xidentity not in app:
        raise SystemExit("ERROR: xIdentity helper target not found in src/app.js")
    app=app.replace(old_xidentity,new_xidentity,1)
    print("src/app.js: display name now wins over @handle")
else:
    print("src/app.js: display-name preference already installed")

# 3) Do not allow hydration to downgrade GG back to reptilonx.
old_apply = r'''function applyLiveXIdentity(row,identity){
  if(!row||!identity)return row;
  const isToken=!!(row.mint||row.contract||row.symbol);
  const base={
    ...row,
    recipient_display_name:identity.name||row.recipient_display_name||'',
    recipient_avatar_url:identity.profileImageUrl||row.recipient_avatar_url||'',
    recipient_verified:identity.verified?1:0,
    recipient_verified_type:identity.verifiedType||row.recipient_verified_type||''
  };
  if(isToken)return base;
  return {
    ...base,
    display_name:identity.name||row.display_name||identity.username,
    avatar_url:identity.profileImageUrl||row.avatar_url||'',
    banner_url:identity.profileBannerUrl||row.banner_url||'',
    verified:identity.verified?1:0,
    verified_type:identity.verifiedType||row.verified_type||''
  };
}'''

new_apply = r'''function applyLiveXIdentity(row,identity){
  if(!row||!identity)return row;
  const isToken=!!(row.mint||row.contract||row.symbol);
  const handle=identityHandle(row).toLowerCase();
  const incoming=String(identity.name||'').trim();
  const current=String(
    row.recipient_display_name||
    row.display_name||
    ''
  ).trim();

  const incomingIsHandle=
    incoming.replace(/^@/,'').toLowerCase()===handle;
  const currentIsReal=
    current &&
    current.replace(/^@/,'').toLowerCase()!==handle;

  const displayName=(incoming && !(incomingIsHandle&&currentIsReal))
    ? incoming
    : (current||incoming||identity.username||handle);

  const base={
    ...row,
    recipient_display_name:displayName,
    recipient_avatar_url:identity.profileImageUrl||row.recipient_avatar_url||'',
    recipient_verified:identity.verified?1:0,
    recipient_verified_type:identity.verifiedType||row.recipient_verified_type||''
  };
  if(isToken)return base;
  return {
    ...base,
    display_name:displayName,
    avatar_url:identity.profileImageUrl||row.avatar_url||'',
    banner_url:identity.profileBannerUrl||row.banner_url||'',
    verified:identity.verified?1:0,
    verified_type:identity.verifiedType||row.verified_type||''
  };
}'''

if new_apply not in app:
    if old_apply not in app:
        raise SystemExit("ERROR: applyLiveXIdentity target not found in src/app.js")
    app=app.replace(old_apply,new_apply,1)
    print("src/app.js: hydration can no longer replace display name with handle")
else:
    print("src/app.js: hydration protection already installed")

for needle in [
    "x-identities-batch-v23-1",
    "fetchSingleXIdentity",
    "const realName=rawCandidates.find",
    "incomingIsHandle"
]:
    if needle not in (api+app):
        raise SystemExit(f"ERROR: sanity check failed: {needle}")

app_path.write_text(app)
api_path.write_text(api)
print("PASS: X display-name correction prepared")
