#!/usr/bin/env bash
set -euo pipefail

PATCH_NAME="x_display_name_fix_v23_1"
FILES=(src/app.js server/api.js)

for f in "${FILES[@]}"; do
  if [ ! -f "$f" ]; then
    echo "ERROR: missing $f"
    echo "Run this from the existing Replit project root."
    exit 1
  fi
done

echo "==> Installing ${PATCH_NAME}"

mkdir -p ".patch-backups/${PATCH_NAME}"
cp src/app.js ".patch-backups/${PATCH_NAME}/app.js.before"
cp server/api.js ".patch-backups/${PATCH_NAME}/api.js.before"

python3 "$(dirname "$0")/patch.py"

echo "==> Running project check"
npm run check

echo "==> Git diff"
git diff -- src/app.js server/api.js

git add src/app.js server/api.js

if git diff --cached --quiet; then
  echo "==> No new changes to commit."
else
  git commit -m "Fix X display names instead of usernames"
  git push origin main
fi

echo
echo "PASS: ${PATCH_NAME} installed."
echo "No server restart was performed."
