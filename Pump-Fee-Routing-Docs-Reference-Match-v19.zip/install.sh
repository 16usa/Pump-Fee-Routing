#!/usr/bin/env bash
set -euo pipefail

echo "== Docs Reference Match v19 =="

for f in src/app.js src/styles.css; do
  if [ ! -f "$f" ]; then
    echo "ERROR: $f not found. Run this from the existing Replit project workspace."
    exit 1
  fi
done

python3 <<'PYCODE'
from pathlib import Path

app_path = Path("src/app.js")
css_path = Path("src/styles.css")
app = app_path.read_text()
css = css_path.read_text()

app_marker = 'data-docs-reference="v19"'
css_marker = '/* docs-reference-match-v19 */'

if app_marker not in app:
    old = '''      <a class="home-preview-card home-ref-card home-v2-docs-card" href="#/docs">
        <div class="home-preview-label"><b>Docs</b><span>Open →</span></div>
        <small class="home-v2-docs-eyebrow">Sharing config</small>
        <strong class="home-v2-docs-title">Attribution is per-mint</strong>
        <p>One config account per token mint. The treasury appears in its shareholders array, so a single wallet gets clean per-token attribution.</p>
        <div class="home-v2-docs-fields">
          <span><small>Off</small><small>Len</small><small>Field</small></span>
          <b><i>0</i><i>8</i><em>discriminator</em></b>
          <b><i>11</i><i>32</i><em>token mint</em></b>
          <b><i>43</i><i>32</i><em>admin</em></b>
          <b><i>75</i><i>1</i><em>revoke flag</em></b>
        </div>
        <div class="home-v2-docs-bottom">
          <span><small>Detection</small><b>On-chain</b></span>
          <span><small>Claiming</small><b>Creator fees</b></span>
        </div>
      </a>'''

    new = '''      <a class="home-preview-card home-ref-card home-v2-docs-card" data-docs-reference="v19" href="#/docs">
        <div class="home-v2-docs-stage">
          <div class="home-v2-docs-preview">
            <strong class="home-v2-docs-title">Attribution is per-mint</strong>
            <p>One 1024-byte config account per token mint. The treasury appears in its shareholders array, so a single wallet gets clean per-token attribution.</p>
            <div class="home-v2-docs-fields">
              <span><small>OFF</small><small>LEN</small><small>FIELD</small></span>
              <b><i>0</i><i>8</i><em>discriminator</em></b>
              <b><i>11</i><i>32</i><em>token mint</em></b>
              <b><i>43</i><i>32</i><em>admin</em></b>
              <b><i>75</i><i>1</i><em>revoke flag</em></b>
              <b class="home-v2-docs-soft-row"><i>76</i><i>4</i><em>shareholder count</em></b>
            </div>
          </div>
          <div class="home-v2-docs-bottom-shade" aria-hidden="true"></div>
          <div class="home-v2-docs-footer"><strong>Docs</strong><span>Open →</span></div>
        </div>
      </a>'''

    if old not in app:
        raise SystemExit("ERROR: current Docs preview block was not found exactly.")
    app = app.replace(old, new, 1)
    app_path.write_text(app)
    print("PASS Docs preview markup updated")
else:
    print("PASS Docs v19 markup already installed")

css = css_path.read_text()
if css_marker not in css:
    css_patch = r'''
/* docs-reference-match-v19 */
.home-reference-v2-previews .home-preview-card.home-v2-docs-card[data-docs-reference="v19"]{
  position:relative;
  display:block;
  min-height:246px;
  padding:0;
  overflow:hidden;
  border:1px solid #303030;
  border-radius:20px;
  background:#171717;
  box-shadow:none;
  isolation:isolate;
}
.home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-stage{
  position:relative;
  min-height:246px;
  padding:20px 20px 48px;
  overflow:hidden;
}
.home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-preview{
  position:relative;
  z-index:1;
  overflow:hidden;
}
.home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-title{
  display:block;
  margin:0;
  color:#e8e8e8;
  font-size:17px;
  line-height:1.12;
  font-weight:620;
  letter-spacing:-.025em;
}
.home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-preview>p{
  max-width:95%;
  margin:12px 0 18px;
  color:#8b8b8b;
  font-size:12px;
  line-height:1.45;
  font-weight:400;
}
.home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-fields{
  display:grid;
  grid-template-columns:1fr;
  gap:8px;
  padding:0;
  border:0;
  border-radius:0;
  background:transparent;
  font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,monospace;
}
.home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-fields>span,
.home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-fields>b{
  display:grid;
  grid-template-columns:64px 64px minmax(0,1fr);
  align-items:baseline;
  gap:12px;
  grid-column:auto;
}
.home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-fields>span{
  color:#777;
  font-size:11px;
  line-height:1.1;
  letter-spacing:.08em;
}
.home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-fields>span small{
  color:inherit;
  font-size:inherit;
  text-transform:uppercase;
}
.home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-fields>b{
  color:#aaa;
  font-size:11px;
  line-height:1.1;
  font-weight:430;
}
.home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-fields b i,
.home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-fields b em{
  color:inherit;
  font:inherit;
  font-style:normal;
}
.home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-fields b i{color:#717171}
.home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-soft-row{
  opacity:.32;
  filter:blur(.15px);
}
.home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-bottom-shade{
  position:absolute;
  left:0;
  right:0;
  bottom:0;
  z-index:2;
  height:105px;
  pointer-events:none;
  background:linear-gradient(180deg,rgba(23,23,23,0) 0%,rgba(23,23,23,.18) 24%,rgba(23,23,23,.66) 66%,#171717 100%);
}
.home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-footer{
  position:absolute;
  left:20px;
  right:20px;
  bottom:17px;
  z-index:3;
  display:flex;
  align-items:center;
  justify-content:space-between;
  pointer-events:none;
}
.home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-footer strong,
.home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-footer span{
  color:#c8c8c8;
  font-size:13px;
  line-height:1;
  font-weight:430;
  letter-spacing:0;
  white-space:nowrap;
}
.home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-footer span{color:#888}
.home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-eyebrow,
.home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-bottom,
.home-v2-docs-card[data-docs-reference="v19"]>.home-preview-label{display:none!important}
@media(max-width:640px){
  .home-reference-v2-previews .home-preview-card.home-v2-docs-card[data-docs-reference="v19"]{
    min-height:218px;
    border-radius:16px;
  }
  .home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-stage{
    min-height:218px;
    padding:17px 16px 43px;
  }
  .home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-title{font-size:15px}
  .home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-preview>p{
    margin:10px 0 15px;
    font-size:10px;
    line-height:1.42;
  }
  .home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-fields{gap:7px}
  .home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-fields>span,
  .home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-fields>b{
    grid-template-columns:48px 48px minmax(0,1fr);
    gap:10px;
  }
  .home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-fields>span{font-size:9px}
  .home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-fields>b{font-size:9px}
  .home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-bottom-shade{height:92px}
  .home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-footer{
    left:16px;
    right:16px;
    bottom:14px;
  }
  .home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-footer strong,
  .home-v2-docs-card[data-docs-reference="v19"] .home-v2-docs-footer span{font-size:12px}
}
'''
    css_path.write_text(css.rstrip() + "\n\n" + css_patch + "\n")
    print("PASS Docs reference CSS added")
else:
    print("PASS Docs v19 CSS already installed")

app = app_path.read_text()
css = css_path.read_text()
checks = {
    "docs marker": app_marker in app,
    "docs footer": "home-v2-docs-footer" in app,
    "css marker": css_marker in css,
    "docs lower fade": "home-v2-docs-bottom-shade" in css,
}
for label, ok in checks.items():
    if not ok:
        raise SystemExit(f"ERROR: verification failed: {label}")
    print("PASS", label)
PYCODE

echo
echo "== Project checks =="
npm run check

echo
echo "== Git diff =="
git diff --stat

git add src/app.js src/styles.css
if git diff --cached --quiet; then
  echo "No new changes to commit."
else
  git commit -m "Match Docs preview to reference layout"
  git push
fi

echo
echo "DONE: Docs Reference Match v19 installed, checked, committed, and pushed."
echo "No server restart was performed."
echo "Restart Run/Console manually once, then reload the page."
