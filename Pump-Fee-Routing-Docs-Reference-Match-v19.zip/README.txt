Pump Fee Routing — Docs Reference Match v19

Changes only the HOME Docs preview block:
- removes top Docs/Open header
- removes Sharing config
- removes Detection/Claiming mini cards
- keeps a simplified document preview
- adds a soft lower fade like the reference
- moves Docs / Open → to the bottom footer
- no automatic server restart

Install:
rm -rf /tmp/docs-reference-match-v19
mkdir -p /tmp/docs-reference-match-v19
unzip -o Pump-Fee-Routing-Docs-Reference-Match-v19.zip -d /tmp/docs-reference-match-v19
bash /tmp/docs-reference-match-v19/install.sh
