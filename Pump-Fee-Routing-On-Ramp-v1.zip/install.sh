#!/usr/bin/env bash
set -euo pipefail

if [ ! -f src/app.js ] || [ ! -f src/styles.css ]; then
  echo "Run this from the Pump-Fee-Routing project root."
  exit 1
fi

if [ -n "$(git status --porcelain -- src/app.js src/styles.css)" ]; then
  echo "STOP: src/app.js or src/styles.css has uncommitted changes."
  git status --short -- src/app.js src/styles.css
  exit 2
fi

python3 - <<'PY'
from pathlib import Path

app_path = Path("src/app.js")
css_path = Path("src/styles.css")
app = app_path.read_text()
css = css_path.read_text()

marker = "/* home-on-ramp-v1 */"
if marker in css:
    raise SystemExit("On-ramp v1 is already installed.")

start = app.find("function homeOnRamp(){")
end = app.find("function homePage(){", start)
if start < 0 or end < 0:
    raise SystemExit("Could not locate homeOnRamp()/homePage().")

replacement = r'''function isOnRampOrder(x){
  const side=String(x?.side||'').toLowerCase();
  return ['buy','deposit','onramp','on-ramp','transfer_in','transfer-in','withdrawal','withdraw'].some(v=>side.includes(v));
}

function homeOnRampCard(x,i){
  const provider=String(x.provider||'Kraken');
  const usd=Number(x.received_usd||x.gross_usd||0);
  const native=Number(x.volume_native||0);
  const pair=String(x.pair||'SOLUSD').toUpperCase();
  const status=String(x.status||'queued');
  const amount=usd>0?fmtMoney(usd):(native>0?`${fmtNum(native)} SOL`:'$0.00');
  return `<button class="home-on-card expandable" data-expand="home-on-${i}">
    <div class="home-on-main">
      <div class="home-on-copy">
        <strong>${esc(amount)}</strong>
        <span>from ${esc(provider)}</span>
      </div>
      <div class="home-on-route">
        <span class="home-on-provider">${esc((provider[0]||'K').toUpperCase())}</span>
        <span class="home-on-arrow">→</span>
        <span class="home-on-sol">≋</span>
      </div>
      <div class="home-on-meta">
        <span class="home-on-status">${esc(status)}</span>
        <time>${esc(ago(x.filled_at||x.created_at))}</time>
      </div>
      <span class="chev">⌄</span>
    </div>
    <div class="tx-details hidden">
      <div><span>Provider</span><b>${esc(provider)}</b></div>
      <div><span>Pair</span><b>${esc(pair)}</b></div>
      <div><span>Side</span><b>${esc(x.side||'')}</b></div>
      <div><span>Reference</span><b>${esc(x.provider_ref||x.id||'')}</b></div>
    </div>
  </button>`;
}

function homeOnRamp(h){
  const orders=(h.money?.exchange||[]).filter(isOnRampOrder).slice(0,6);
  return `<section class="wrap section home-on-ramp">
    <div class="home-on-head">
      <h2>On-ramp</h2>
      <div class="home-on-total">
        <b>${fmtMoney(orders.reduce((sum,x)=>sum+Number(x.received_usd||x.gross_usd||0),0))}</b>
        <span>received</span>
      </div>
      <div class="home-on-pager"><button disabled>‹</button><span>1</span><button disabled>›</button></div>
    </div>
    <div class="home-on-tabs">
      <button class="active">All</button>
      <button disabled>Kraken</button>
      <button disabled>Bank</button>
      <button disabled>Other</button>
    </div>
    <div class="home-on-list">
      ${orders.length
        ? orders.map(homeOnRampCard).join('')
        : `<div class="home-on-empty">
            <div class="home-on-empty-route"><i>K</i><span>→</span><b>≋</b></div>
            <strong>No on-ramp activity yet.</strong>
            <span>Confirmed funding events will appear here without demo data.</span>
          </div>`}
    </div>
  </section>`;
}

'''

app = app[:start] + replacement + app[end:]

old_call = "    ${homeOnRamp()}"
if old_call not in app:
    raise SystemExit("Could not locate homeOnRamp() call.")
app = app.replace(old_call, "    ${homeOnRamp(h)}", 1)

app_path.write_text(app)

css += r'''

/* home-on-ramp-v1 */
.home-on-ramp{padding-top:42px!important}
.home-on-head{
  display:grid;
  grid-template-columns:1fr auto auto;
  align-items:end;
  gap:12px;
  margin-bottom:10px;
}
.home-on-head h2{
  margin:0;
  font-size:18px;
  line-height:1;
  letter-spacing:-.03em;
  font-weight:650;
}
.home-on-total{
  display:flex;
  align-items:baseline;
  gap:5px;
  color:#666;
}
.home-on-total b{color:#8b8b8b;font-size:9px;font-weight:600}
.home-on-total span{font-size:7px}
.home-on-pager{
  display:flex;
  align-items:center;
  gap:10px;
  color:#666;
  font-size:8px;
}
.home-on-pager button{
  border:0;
  background:transparent;
  color:#666;
  padding:0;
  font-size:15px;
}
.home-on-tabs{
  display:flex;
  align-items:center;
  gap:10px;
  margin-bottom:14px;
}
.home-on-tabs button{
  border:0;
  background:transparent;
  color:#747474;
  padding:7px 9px;
  border-radius:999px;
  font-size:9px;
}
.home-on-tabs button.active{color:#fff;background:#191919}
.home-on-tabs button:disabled{opacity:.58}
.home-on-list{display:grid;gap:8px}
.home-on-card{
  width:100%;
  padding:12px;
  color:#fff;
  text-align:left;
  background:#191919;
  border:1px solid #303030;
  border-radius:14px;
}
.home-on-main{
  display:grid;
  grid-template-columns:minmax(0,1fr) auto auto 12px;
  align-items:center;
  gap:10px;
}
.home-on-copy{min-width:0;display:grid}
.home-on-copy strong{
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
  font-size:20px;
  line-height:1;
  letter-spacing:-.035em;
  font-weight:580;
}
.home-on-copy span{
  margin-top:5px;
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
  color:#969696;
  font-size:9px;
}
.home-on-route{display:flex;align-items:center;gap:6px}
.home-on-provider,
.home-on-sol{
  width:34px;
  height:34px;
  display:grid;
  place-items:center;
  flex:0 0 auto;
  border:1px solid #292929;
  border-radius:50%;
  background:#080808;
}
.home-on-provider{font-size:11px;font-weight:750}
.home-on-sol{font-size:18px;font-weight:800}
.home-on-arrow{color:#656565;font-size:12px}
.home-on-meta{
  min-width:58px;
  display:grid;
  justify-items:end;
  gap:6px;
}
.home-on-status{
  max-width:90px;
  padding:4px 7px;
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
  border-radius:999px;
  color:#c8c8c8;
  background:#303030;
  font-size:7px;
  text-transform:capitalize;
}
.home-on-meta time{color:#828282;font-size:8px}
.home-on-main>.chev{color:#737373;font-size:11px}
.home-on-card .tx-details{
  margin-top:11px;
  padding-top:10px;
  border-top:1px solid #303030;
}
.home-on-empty{
  min-height:145px;
  display:grid;
  place-items:center;
  align-content:center;
  gap:7px;
  padding:20px;
  border:1px dashed #272727;
  border-radius:14px;
  color:#646464;
  text-align:center;
}
.home-on-empty-route{
  display:flex;
  align-items:center;
  gap:9px;
  margin-bottom:5px;
}
.home-on-empty-route i,
.home-on-empty-route b{
  width:34px;
  height:34px;
  display:grid;
  place-items:center;
  border-radius:50%;
  background:#111;
  border:1px solid #242424;
  color:#777;
  font-style:normal;
  font-size:11px;
}
.home-on-empty-route b{font-size:17px}
.home-on-empty-route>span{color:#5c5c5c}
.home-on-empty strong{font-size:9px;color:#777}
.home-on-empty>span{font-size:7px;color:#555}

@media(max-width:640px){
  .home-on-ramp{padding-top:38px!important}
  .home-on-head h2{font-size:16px}
  .home-on-total{display:none}
  .home-on-card{padding:11px;border-radius:13px}
  .home-on-main{
    grid-template-columns:minmax(0,1fr) auto auto 10px;
    gap:7px;
  }
  .home-on-copy strong{font-size:18px}
  .home-on-copy span{font-size:8px;max-width:118px}
  .home-on-provider,.home-on-sol{width:31px;height:31px}
  .home-on-route{gap:4px}
  .home-on-meta{min-width:50px}
  .home-on-status{padding:4px 6px;font-size:6.5px}
}
'''
css_path.write_text(css)

print("On-ramp v1 patch installed.")
PY

npm run check

git add src/app.js src/styles.css

if git diff --cached --quiet; then
  echo "No staged changes; nothing to commit."
else
  git commit -m "Match home on-ramp"
fi

git push origin main

echo
echo "DONE: On-ramp patch checked, committed, and pushed to GitHub."
echo "No server restart was performed."
echo "Refresh the browser to see the updated On-ramp section."
