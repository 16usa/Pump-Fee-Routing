Pump Fee Routing — On-ramp v1
Scope: Home On-ramp section only.
Uses real exchange-order rows only when their side represents inbound funding (buy/deposit/on-ramp/withdrawal-style events).
No demo activity is created.
Runs npm check, commits, and pushes to origin/main. No automatic server restart.
