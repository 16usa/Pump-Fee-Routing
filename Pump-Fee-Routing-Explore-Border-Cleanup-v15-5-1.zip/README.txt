Pump Fee Routing — Explore Border Cleanup v15.5.1

This fixes the verification bug in v15.5.
The previous v15.5 attempt already wrote the CSS before its check failed, so v15.5.1 safely detects that state and continues.

Changes:
- removes the border/frame around the LEFT inner Explore token card
- removes the border/frame around the RIGHT inner Explore token card
- removes the borders around the token images inside the Explore block
- removes the divider line between the left image and its info section
- keeps the large OUTER Explore block border unchanged
- no automatic server restart

Install in the existing Replit Shell:

rm -rf /tmp/explore-border-cleanup-v15-5-1
mkdir -p /tmp/explore-border-cleanup-v15-5-1
unzip -o Pump-Fee-Routing-Explore-Border-Cleanup-v15-5-1.zip -d /tmp/explore-border-cleanup-v15-5-1
bash /tmp/explore-border-cleanup-v15-5-1/install.sh
