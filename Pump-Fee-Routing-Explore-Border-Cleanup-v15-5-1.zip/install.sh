#!/usr/bin/env bash
set -euo pipefail

echo "== Explore Border Cleanup v15.5.1 =="

for f in src/app.js src/styles.css; do
  if [ ! -f "$f" ]; then
    echo "ERROR: $f not found. Run this from the existing Replit project workspace."
    exit 1
  fi
done

python3 <<'PYCODE'
from pathlib import Path

app_path = Path("src/app.js")
css_path = Path("src/styles.css")

app = app_path.read_text()
css = css_path.read_text()

if 'data-explore-card-info="v15"' not in app:
    raise SystemExit("ERROR: Explore Card Info v15 is not installed yet.")

marker = "/* explore-border-cleanup-v15-5 */"
css_patch = r'''
/* explore-border-cleanup-v15-5 */

/* Remove only the INNER frames in the Explore preview.
   Keep the large outer Explore container border unchanged. */
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"],
.home-explore-reference-v8 .home-explore-v8-secondary-card{
  border:0 !important;
  box-shadow:none !important;
  background:transparent !important;
}

/* Remove frames around the token images inside Explore. */
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] > .home-explore-v8-media,
.home-explore-reference-v8 .home-explore-v8-secondary-card > .home-explore-v8-media{
  border:0 !important;
  box-shadow:none !important;
  background:#0a0a0a;
}

/* No divider line between the left image and its info section. */
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] > .home-explore-v8-copy{
  border-top:0 !important;
}
'''

if marker in css:
    print("PASS border cleanup CSS already present from v15.5 attempt")
else:
    css_path.write_text(css.rstrip() + "\n\n" + css_patch + "\n")
    print("PASS border cleanup CSS added")

css = css_path.read_text()

checks = {
    "marker exists": marker in css,
    "primary inner card border removed": '.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"],' in css and 'border:0 !important;' in css,
    "secondary inner card included": '.home-explore-reference-v8 .home-explore-v8-secondary-card{' in css,
    "primary media included": '.home-explore-v8-primary-card[data-explore-card-info="v15"] > .home-explore-v8-media,' in css,
    "secondary media included": '.home-explore-v8-secondary-card > .home-explore-v8-media{' in css,
    "copy divider removed": '.home-explore-v8-copy{' in css and 'border-top:0 !important;' in css,
}

for label, ok in checks.items():
    if not ok:
        raise SystemExit(f"ERROR: verification failed: {label}")
    print("PASS", label)

print("PASS verification complete")
PYCODE

echo
echo "== Project checks =="
npm run check

echo
echo "== Git diff =="
git diff --stat

git add src/styles.css

if git diff --cached --quiet; then
  echo "No new changes to commit (the failed v15.5 attempt already wrote the CSS)."
else
  git commit -m "Remove Explore inner card and image borders"
  git push
fi

echo
echo "DONE: Explore Border Cleanup v15.5.1 installed and verified."
echo "No server restart was performed."
echo "Restart Run/Console manually once, then reload the page."
