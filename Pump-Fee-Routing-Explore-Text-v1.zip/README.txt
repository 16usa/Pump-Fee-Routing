Pump Fee Routing — Explore text v1
Minimal Explore pass only.
Changes the Explore explanatory copy to match the reference wording while using the project's configured brand name.
Does NOT change search width, card dimensions, grid, spacing, filters, All/Pump/Pons Soon/Four Soon, or backend logic.
Runs npm check, commits, and pushes to origin/main. No automatic server restart.
