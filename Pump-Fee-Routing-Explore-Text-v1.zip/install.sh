#!/usr/bin/env bash
set -euo pipefail

if [ ! -f src/app.js ] || [ ! -f src/styles.css ]; then
  echo "Run this from the Pump-Fee-Routing project root."
  exit 1
fi

if [ -n "$(git status --porcelain -- src/app.js src/styles.css)" ]; then
  echo "STOP: src/app.js or src/styles.css has uncommitted changes."
  git status --short -- src/app.js src/styles.css
  exit 2
fi

python3 - <<'PY'
from pathlib import Path

app_path = Path("src/app.js")
app = app_path.read_text()

old = '''<p>pump.fun launches the tokens. The backend verifies permanent 100% creator-fee routing to the configured treasury, records claims, and tracks what has been sent and what is still owed.</p>'''

new = '''<p>pump.fun launches the tokens. ${esc(state.brand.name)} claims the creator fees on chain and pays them to an X account in dollars through X Money, with a public confirmation for every payout.</p>'''

if old not in app:
    raise SystemExit("Expected Explore description was not found. No files changed.")

app = app.replace(old, new, 1)
app_path.write_text(app)

print("Explore text patch installed.")
print("Layout, search width, token-card sizes, filters, and venue roadmap were left unchanged.")
PY

npm run check

git add src/app.js

if git diff --cached --quiet; then
  echo "No staged changes; nothing to commit."
else
  git commit -m "Match Explore copy"
fi

git push origin main

echo
echo "DONE: Explore text patch checked, committed, and pushed to GitHub."
echo "No server restart was performed."
