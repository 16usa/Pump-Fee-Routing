Pump-Fee-Routing — Launch Confirmation Retry v2

This is the corrected installer for the current main branch.

Why v1 failed:
The first installer searched for one large exact text block. The current src/app.js
had the same functions but the exact text anchor did not match, so it stopped before editing.

v2:
- Locates launchTokenOnPump() and routeFees() by stable function boundaries.
- Retries the same submitted token transaction signature.
- Prevents a pending confirmation from becoming a fresh token launch.
- Applies the same protection to the fee-routing transaction.
- Keeps the existing wallet-picker/loading fixes.
- Runs JS syntax check + project check before committing.
- Restores src/app.js automatically if validation fails.
- Commits and pushes to main.
- Does not restart the server.
