Pump Fee Routing — Launch Mobile Wallet Connect v1

Fixes the Launch page wallet connection flow, especially on iPhone Safari.

Problem found:
The current code only looked for an injected window.phantom.solana/window.solana provider.
iPhone Safari does not inject Phantom/Solflare, so the site showed:
"No Solana wallet found in this browser".

Fix:
- Detect Phantom, Solflare, Backpack/injected Solana providers.
- If a provider exists, connect normally.
- If iPhone/mobile browser has no injected provider, show a wallet chooser instead of an error.
- Open the same Launch page inside Phantom or Solflare via their mobile browse universal links.
- Carry text-form values into the wallet browser.
- Avoid falsely reporting "Wallet connected: null".
- Preserve the existing Pump launch + routing transaction flow.

Important iOS limitation:
A local image selected in Safari cannot be transferred into another app's browser context.
After Phantom/Solflare opens, re-select the token image once. Text values are restored.

Installer validates, commits, and pushes origin/main.
No automatic server restart.
