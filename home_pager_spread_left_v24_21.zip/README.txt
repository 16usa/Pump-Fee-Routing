Home Pager Spread Left v24.21

Goal:
- keep the right pager arrow visually at the same right edge;
- move the page number left;
- move the left arrow further left;
- roughly double the spacing between left arrow / number / right arrow.

Applied to:
- Top Tokens
- Top X Profiles
- Recent Payments
- Most Payments
- Off-ramp
- On-ramp

Method:
- widen the pager block;
- anchor it to the right;
- place the three pager items into three even columns.

No automatic server restart.

Install in the existing Replit Shell:

rm -rf /tmp/home_pager_spread_left_v24_21 && mkdir -p /tmp/home_pager_spread_left_v24_21 && unzip -o home_pager_spread_left_v24_21.zip -d /tmp/home_pager_spread_left_v24_21 && bash /tmp/home_pager_spread_left_v24_21/install.sh
