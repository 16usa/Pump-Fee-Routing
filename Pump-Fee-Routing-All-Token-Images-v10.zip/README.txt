Pump Fee Routing — All Token Images v10

This supersedes the Explore-only image patch.

What it changes:
- Uses the real token image everywhere a token is rendered:
  Home Explore preview, Top Tokens, Explore page, Money token routes,
  recent/most payment token icons, Token Detail, Profile Top Token,
  Profile token list, and standard token cards.
- Uses one centralized token image renderer instead of separate direct image URLs.
- Resolves images by mint through the app's /api/token-image/:mint endpoint.
- Falls back through Pump metadata, nested metadata JSON, stored image URL,
  IPFS gateways, then initials only if no usable image exists.
- Keeps X profile avatars separate.
- Does not redesign card geometry or other modules.
- Does not restart the server.

Install from the existing Replit workspace:

rm -rf /tmp/all-token-images-v10
mkdir -p /tmp/all-token-images-v10
unzip -o Pump-Fee-Routing-All-Token-Images-v10.zip -d /tmp/all-token-images-v10
bash /tmp/all-token-images-v10/install.sh

After it finishes, restart Run/Console manually once and reload the site.
