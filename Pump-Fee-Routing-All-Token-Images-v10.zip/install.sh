#!/usr/bin/env bash
set -euo pipefail

echo "== All Token Images v10 =="

for f in src/app.js src/styles.css server/api.js server/solana.js; do
  if [ ! -f "$f" ]; then
    echo "ERROR: $f not found. Run this from the existing project workspace."
    exit 1
  fi
done

python3 <<'PY'
from pathlib import Path

app_path = Path("src/app.js")
css_path = Path("src/styles.css")
api_path = Path("server/api.js")
sol_path = Path("server/solana.js")

app = app_path.read_text()
css = css_path.read_text()
api = api_path.read_text()
sol = sol_path.read_text()

# ------------------------------------------------------------
# 1. One token-image renderer for ALL token cards/views.
# ------------------------------------------------------------
avatar_anchor = """const avatar=(text,large=false,img='')=>img?`<div class="avatar ${large?'avatar-lg':''}"><img src="${esc(img)}" alt=""></div>`:`<div class="avatar ${large?'avatar-lg':''}" aria-hidden="true">${esc(initials(text))}</div>`;"""

helpers = r"""
/* all-token-images-v10 */
const tokenImageSource=(t)=>{
  const mint=String(t?.mint||t?.contract||'').trim();
  const direct=String(t?.image_url||'').trim();
  return mint?`/api/token-image/${encodeURIComponent(mint)}`:direct;
};
const tokenImageErrorAttrs=(t)=>{
  const mint=String(t?.mint||t?.contract||'').trim();
  const direct=String(t?.image_url||'').trim();
  if(mint&&direct){
    return ` data-token-direct="${esc(direct)}" onerror="if(!this.dataset.tokenRetried){this.dataset.tokenRetried='1';this.src=this.dataset.tokenDirect;return}this.style.display='none';this.nextElementSibling.style.display='grid'"`;
  }
  return ` onerror="this.style.display='none';this.nextElementSibling.style.display='grid'"`;
};
const tokenAvatar=(t,large=false)=>{
  const label=t?.symbol||t?.name||'T';
  const src=tokenImageSource(t);
  if(!src) return avatar(label,large);
  return `<div class="avatar ${large?'avatar-lg':''} token-avatar"><img src="${esc(src)}" alt="" loading="lazy" decoding="async"${tokenImageErrorAttrs(t)}><span class="token-avatar-fallback" style="display:none">${esc(initials(label))}</span></div>`;
};
const tokenMedia=(t,fallbackClass='token-image-fallback',fallbackContent='',imageClass='')=>{
  const label=t?.symbol||t?.name||'T';
  const content=fallbackContent||esc(initials(label));
  const src=tokenImageSource(t);
  if(!src) return `<div class="${fallbackClass}">${content}</div>`;
  return `<img${imageClass?` class="${imageClass}"`:''} src="${esc(src)}" alt="" loading="lazy" decoding="async"${tokenImageErrorAttrs(t)}><div class="${fallbackClass}" style="display:none">${content}</div>`;
};
"""

if "/* all-token-images-v10 */" not in app:
    if avatar_anchor not in app:
        raise SystemExit("ERROR: avatar anchor not found in src/app.js")
    app = app.replace(avatar_anchor, avatar_anchor + helpers, 1)

def replace_any(old, new, label):
    global app
    if old in app:
        app = app.replace(old, new)
        print("PASS", label)
        return
    if new in app:
        print("PASS", label, "(already installed)")
        return
    raise SystemExit(f"ERROR: app anchor not found: {label}")

# Standard token cards / money routes.
replace_any(
    "avatar(t.symbol||t.name,true,t.image_url)",
    "tokenAvatar(t,true)",
    "standard token cards"
)
replace_any(
    "token?avatar(token.symbol||token.name,true,token.image_url):avatar(mints[0]||'T',true)",
    "token?tokenAvatar(token,true):avatar(mints[0]||'T',true)",
    "money payment token"
)
replace_any(
    "avatar(t.symbol||t.name,true,t.image_url)",
    "tokenAvatar(t,true)",
    "money top token"
)

# Home hero media.
old = """${t?.image_url?`<img src="${esc(t.image_url)}" alt="">`:`<div class="home-hero-media-empty"><span>${esc(initials(t?.symbol||t?.name||'P'))}</span><small>${t?'Image unavailable':'No routed token yet'}</small></div>`}"""
new = """${t?tokenMedia(t,'home-hero-media-empty',`<span>${esc(initials(t?.symbol||t?.name||'P'))}</span><small>Image unavailable</small>`):`<div class="home-hero-media-empty"><span>P</span><small>No routed token yet</small></div>`}"""
replace_any(old, new, "home hero token image")

# Top-token home media.
old = """${t.image_url?`<img src="${esc(t.image_url)}" alt="">`:`<div class="home-top-token-fallback">${esc(initials(t.symbol||t.name||'T'))}</div>`}"""
new = """${tokenMedia(t,'home-top-token-fallback')}"""
replace_any(old, new, "home top token image")

# Home payment token.
replace_any(
    "token?avatar(token.symbol||token.name,true,token.image_url):`<span class=\"home-payment-placeholder\">${esc(initials(token?.symbol||firstMint||'T'))}</span>`",
    "token?tokenAvatar(token,true):`<span class=\"home-payment-placeholder\">${esc(initials(token?.symbol||firstMint||'T'))}</span>`",
    "home payment token image"
)

# Most payments token side.
replace_any(
    "lead?avatar(lead.symbol||lead.name,true,lead.image_url):avatar(name,true)",
    "lead?tokenAvatar(lead,true):avatar(name,true)",
    "most payments token image"
)

# Explore trending.
replace_any(
    "avatar(t.symbol||t.name,true,t.image_url)",
    "tokenAvatar(t,true)",
    "explore trending token image"
)

# Explore token cards.
old = """${t.image_url?`<img src="${esc(t.image_url)}" alt="">`:`<div class="explore-token-fallback">${esc(initials(t.symbol||t.name||'T'))}</div>`}"""
new = """${tokenMedia(t,'explore-token-fallback')}"""
replace_any(old, new, "explore token-card image")

# Token details and profile cards.
replace_any(
    "avatar(t.symbol||t.name,true,t.image_url)",
    "tokenAvatar(t,true)",
    "token detail/profile token image"
)
replace_any(
    "avatar(top.symbol||top.name,true,top.image_url)",
    "tokenAvatar(top,true)",
    "profile featured token image"
)

app_path.write_text(app)

# Minimal CSS only for the centralized circular token fallback.
css_marker = "/* all-token-images-v10 */"
css_add = r"""
/* all-token-images-v10 */
.token-avatar{position:relative;overflow:hidden}
.token-avatar>img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;border-radius:inherit}
.token-avatar-fallback{position:absolute;inset:0;width:100%;height:100%;place-items:center;background:radial-gradient(circle at 35% 25%,#555,#1b1b1b 58%,#0b0b0b);color:#fff}
"""
if css_marker not in css:
    css += "\n" + css_add
css_path.write_text(css)

# ------------------------------------------------------------
# 2. Robust server-side token image proxy.
#    This supersedes the previous Explore-only image patch.
# ------------------------------------------------------------
for marker in ("/* home-explore-token-image-v6 */", "/* home-explore-token-image-v9 */", "/* all-token-images-v10 */"):
    start = api.find(marker)
    if start >= 0:
        break
else:
    raise SystemExit("ERROR: token-image helper marker not found in server/api.js")

handle = "export async function handleApi(req,res,url){"
end = api.find(handle, start)
if end < 0:
    raise SystemExit("ERROR: handleApi anchor not found")

server_helpers = r"""/* all-token-images-v10 */
function tokenImageCandidates(raw){
  const value=String(raw||'').trim();
  if(!value) return [];
  const out=[];
  const add=(url)=>{
    const u=String(url||'').trim();
    if(u && /^https?:\/\//i.test(u) && !out.includes(u)) out.push(u);
  };

  if(/^ar:\/\//i.test(value)){
    add(`https://arweave.net/${value.replace(/^ar:\/\//i,'')}`);
    return out;
  }

  let ipfsPath='';
  if(/^ipfs:\/\//i.test(value)){
    ipfsPath=value.replace(/^ipfs:\/\//i,'').replace(/^ipfs\//i,'');
  }else{
    const m=value.match(/\/ipfs\/([^?#]+)/i);
    if(m) ipfsPath=m[1];
  }

  if(ipfsPath){
    ipfsPath=ipfsPath.replace(/^\/+/,'');
    add(value);
    add(`https://ipfs.io/ipfs/${ipfsPath}`);
    add(`https://gateway.pinata.cloud/ipfs/${ipfsPath}`);
    add(`https://dweb.link/ipfs/${ipfsPath}`);
    return out;
  }

  add(value);
  return out;
}

function imageValuesFromMetadata(meta){
  if(!meta || typeof meta!=='object') return [];
  const values=[
    meta.image_uri,meta.image,meta.imageUrl,meta.image_url,
    meta.metadata?.image_uri,meta.metadata?.image,meta.metadata?.imageUrl,meta.metadata?.image_url,
    meta.coin_metadata?.image_uri,meta.coin_metadata?.image,meta.coin_metadata?.imageUrl,meta.coin_metadata?.image_url
  ];
  return [...new Set(values.map(v=>String(v||'').trim()).filter(Boolean))];
}

function metadataUris(meta){
  if(!meta || typeof meta!=='object') return [];
  const values=[meta.uri,meta.metadata_uri,meta.metadataUri,meta.metadata?.uri,meta.coin_metadata?.uri];
  return [...new Set(values.map(v=>String(v||'').trim()).filter(Boolean))];
}

async function fetchMetadataJson(target){
  const direct=String(target||'').trim();
  const candidates=tokenImageCandidates(direct);
  if(/^https?:\/\//i.test(direct) && !candidates.includes(direct)) candidates.unshift(direct);
  for(const url of candidates.length?candidates:[direct]){
    if(!/^https?:\/\//i.test(url)) continue;
    try{
      const r=await fetch(url,{
        headers:{accept:'application/json,text/plain;q=0.9,*/*;q=0.5'},
        redirect:'follow',
        signal:AbortSignal.timeout(12000)
      });
      if(!r.ok) continue;
      const text=await r.text();
      if(text.length>2_000_000) continue;
      const data=JSON.parse(text);
      if(data && typeof data==='object') return data;
    }catch{}
  }
  return null;
}

async function resolvePumpTokenImages(mint){
  const candidates=[];
  const addRaw=(raw)=>{
    for(const url of tokenImageCandidates(raw)){
      if(!candidates.includes(url)) candidates.push(url);
    }
  };

  const stored=getToken(mint);
  addRaw(stored?.image_url||'');

  const urls=[...new Set([
    config.pumpMetadataUrlTemplate.replace('{mint}',encodeURIComponent(mint)),
    `https://frontend-api-v3.pump.fun/coins-v2/${encodeURIComponent(mint)}`,
    `https://frontend-api-v3.pump.fun/coins/${encodeURIComponent(mint)}`
  ])];

  for(const target of urls){
    try{
      const r=await fetch(target,{headers:{accept:'application/json'},redirect:'follow',signal:AbortSignal.timeout(12000)});
      if(!r.ok) continue;
      const meta=await r.json();

      for(const raw of imageValuesFromMetadata(meta)) addRaw(raw);
      for(const uri of metadataUris(meta)){
        const metadata=await fetchMetadataJson(uri);
        if(!metadata) continue;
        for(const raw of imageValuesFromMetadata(metadata)) addRaw(raw);
      }
    }catch{}
  }

  if(stored?.metadata_json){
    try{
      const meta=JSON.parse(stored.metadata_json);
      for(const raw of imageValuesFromMetadata(meta)) addRaw(raw);
      for(const uri of metadataUris(meta)){
        const metadata=await fetchMetadataJson(uri);
        if(!metadata) continue;
        for(const raw of imageValuesFromMetadata(metadata)) addRaw(raw);
      }
    }catch{}
  }

  return candidates;
}

async function proxyTokenImage(res,mint){
  const candidates=await resolvePumpTokenImages(mint);
  for(const target of candidates){
    try{
      const r=await fetch(target,{
        headers:{
          accept:'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
          'user-agent':'Mozilla/5.0'
        },
        redirect:'follow',
        signal:AbortSignal.timeout(15000)
      });
      if(!r.ok) continue;
      const type=String(r.headers.get('content-type')||'').split(';')[0].trim().toLowerCase();
      if(!type.startsWith('image/')) continue;
      const bytes=Buffer.from(await r.arrayBuffer());
      if(!bytes.length || bytes.length>8_000_000) continue;

      res.writeHead(200,{
        'content-type':type,
        'content-length':String(bytes.length),
        'cache-control':'public, max-age=900, stale-while-revalidate=3600',
        'x-content-type-options':'nosniff'
      });
      res.end(bytes);
      return true;
    }catch{}
  }
  return false;
}


"""

api = api[:start] + server_helpers + api[end:]

route_start = api.find("    if(req.method==='GET'&&url.pathname.startsWith('/api/token-image/')){")
route_end = api.find("\n    if(req.method==='GET'&&url.pathname==='/api/health')", route_start)
if route_start < 0 or route_end < 0:
    raise SystemExit("ERROR: /api/token-image route anchor not found")

new_route = """    if(req.method==='GET'&&url.pathname.startsWith('/api/token-image/')){
      const mint=decodeURIComponent(url.pathname.slice('/api/token-image/'.length)).trim();
      if(!/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(mint)) return json(res,400,{error:'Invalid mint'});
      const sent=await proxyTokenImage(res,mint);
      if(sent) return;
      return json(res,404,{error:'Token image not found'});
    }"""

api = api[:route_start] + new_route + api[route_end:]
api_path.write_text(api)

# Preserve more Pump image variants for all future indexed tokens.
old_expr = "image_url:meta.image_uri||meta.image||meta.metadata?.image||existing?.image_url||''"
new_expr = "image_url:meta.image_uri||meta.image||meta.image_url||meta.metadata?.image_uri||meta.metadata?.image||meta.metadata?.image_url||meta.coin_metadata?.image_uri||meta.coin_metadata?.image||meta.coin_metadata?.image_url||existing?.image_url||''"

if old_expr in sol:
    sol = sol.replace(old_expr, new_expr, 1)
elif new_expr not in sol:
    raise SystemExit("ERROR: image_url persistence anchor not found in server/solana.js")
sol_path.write_text(sol)

# ------------------------------------------------------------
# 3. Static verification: token cards should use centralized renderer.
# ------------------------------------------------------------
final_app = app_path.read_text()
required = [
    "/* all-token-images-v10 */",
    "tokenAvatar(token,true)",
    "tokenAvatar(lead,true)",
    "tokenAvatar(top,true)",
    "tokenMedia(t,'home-top-token-fallback')",
    "tokenMedia(t,'explore-token-fallback')",
    "/api/token-image/"
]
for item in required:
    if item not in final_app:
        raise SystemExit(f"ERROR: verification failed: {item}")

print("PASS centralized token-image renderer")
print("PASS token images applied across Home / Explore / Money / Token detail / Profile")
print("PASS server-side Pump/IPFS image proxy")
print("PASS image metadata persistence")
PY

echo
echo "== Project checks =="
npm run check

echo
echo "== Git diff summary =="
git diff --stat

git add src/app.js src/styles.css server/api.js server/solana.js

if git diff --cached --quiet; then
  echo "No new changes to commit (patch may already be installed)."
else
  git commit -m "Use real token images across all token cards"
  git push
fi

echo
echo "DONE: All Token Images v10 installed, checked, committed, and pushed."
echo "No server restart was performed."
echo "Restart Run/Console manually once, then reload the site."
