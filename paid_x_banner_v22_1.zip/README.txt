Paid X Banner v22.1

Fixes the missing header/cover image in Top X Profiles.

The frontend expected banner_url/profile_banner_url, but the backend only returned
handle, display_name and avatar_url. This patch adds real X banner retrieval,
storage and proxying, plus verification metadata.

Install in the existing Replit Shell:
rm -rf /tmp/paid_x_banner_v22_1 && mkdir -p /tmp/paid_x_banner_v22_1 && unzip -o paid_x_banner_v22_1.zip -d /tmp/paid_x_banner_v22_1 && bash /tmp/paid_x_banner_v22_1/install.sh

No automatic server restart is performed.
