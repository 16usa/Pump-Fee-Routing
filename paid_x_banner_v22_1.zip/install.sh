#!/usr/bin/env bash
set -euo pipefail

PATCH_NAME="paid_x_banner_v22_1"

for f in src/app.js server/api.js server/db.js server/queries.js; do
  if [ ! -f "$f" ]; then
    echo "ERROR: missing $f"
    echo "Run this from the existing Replit project root."
    exit 1
  fi
done

echo "==> Installing ${PATCH_NAME}"

mkdir -p ".patch-backups/${PATCH_NAME}"
cp src/app.js ".patch-backups/${PATCH_NAME}/app.js.before"
cp server/api.js ".patch-backups/${PATCH_NAME}/api.js.before"
cp server/db.js ".patch-backups/${PATCH_NAME}/db.js.before"
cp server/queries.js ".patch-backups/${PATCH_NAME}/queries.js.before"

python3 - <<'PY'
from pathlib import Path

app_path=Path("src/app.js")
api_path=Path("server/api.js")
db_path=Path("server/db.js")
queries_path=Path("server/queries.js")

app=app_path.read_text()
api=api_path.read_text()
db=db_path.read_text()
queries=queries_path.read_text()

# 1) DB
if "banner_url TEXT" not in db:
    old='''      bio TEXT,
      avatar_url TEXT,
      opted_out INTEGER NOT NULL DEFAULT 0,'''
    new='''      bio TEXT,
      avatar_url TEXT,
      banner_url TEXT,
      verified INTEGER NOT NULL DEFAULT 0,
      verified_type TEXT,
      opted_out INTEGER NOT NULL DEFAULT 0,'''
    if old not in db:
        raise SystemExit("ERROR: recipients table shape not found in server/db.js")
    db=db.replace(old,new,1)

migration_marker="/* x-profile-banner-columns-v22-1 */"
if migration_marker not in db:
    needle='''  `);
}

function upsertRecipient'''
    repl='''  `);

  /* x-profile-banner-columns-v22-1 */
  const recipientColumns=new Set(
    db.prepare('PRAGMA table_info(recipients)').all().map(row=>String(row.name||''))
  );
  if(!recipientColumns.has('banner_url')) db.exec('ALTER TABLE recipients ADD COLUMN banner_url TEXT');
  if(!recipientColumns.has('verified')) db.exec('ALTER TABLE recipients ADD COLUMN verified INTEGER NOT NULL DEFAULT 0');
  if(!recipientColumns.has('verified_type')) db.exec('ALTER TABLE recipients ADD COLUMN verified_type TEXT');
}

function upsertRecipient'''
    if needle not in db:
        raise SystemExit("ERROR: migrate() end not found in server/db.js")
    db=db.replace(needle,repl,1)

# 2) API
banner_marker="/* sitewide-x-banners-v22-1 */"
if banner_marker not in api:
    insert_before="\n\nexport async function handleApi(req,res,url){"
    if insert_before not in api:
        raise SystemExit("ERROR: handleApi insertion point not found in server/api.js")

    banner_code=r'''

/* sitewide-x-banners-v22-1 */
async function resolveXBanner(handle){
  const username=String(handle||'').replace(/^@/,'').trim();
  if(!/^[A-Za-z0-9_]{1,15}$/.test(username)) return null;

  const existing=db.prepare(
    'SELECT handle,banner_url,avatar_url FROM recipients WHERE handle=? COLLATE NOCASE'
  ).get(username);

  if(existing?.banner_url) return String(existing.banner_url);
  if(!config.xBearerToken) return null;

  try{
    const fields='id,name,username,profile_image_url,profile_banner_url,verified,verified_type';
    const r=await fetch(
      `https://api.x.com/2/users/by/username/${encodeURIComponent(username)}?user.fields=${encodeURIComponent(fields)}`,
      {
        headers:{authorization:`Bearer ${config.xBearerToken}`,accept:'application/json'},
        signal:AbortSignal.timeout(12000)
      }
    );
    if(!r.ok) return null;

    const payload=await r.json().catch(()=>({}));
    const u=payload?.data;
    if(!u) return null;

    const avatarUrl=largerXAvatar(u.profile_image_url||'');
    const bannerUrl=String(u.profile_banner_url||'').trim();

    if(existing){
      db.prepare(`UPDATE recipients
        SET x_user_id=COALESCE(NULLIF(?,''),x_user_id),
            display_name=COALESCE(NULLIF(?,''),display_name),
            avatar_url=COALESCE(NULLIF(?,''),avatar_url),
            banner_url=COALESCE(NULLIF(?,''),banner_url),
            verified=?,
            verified_type=?,
            updated_at=CURRENT_TIMESTAMP
        WHERE handle=? COLLATE NOCASE`)
        .run(
          String(u.id||''),
          String(u.name||u.username||''),
          avatarUrl,
          bannerUrl,
          u.verified?1:0,
          String(u.verified_type||''),
          username
        );
    }

    return bannerUrl||null;
  }catch{
    return null;
  }
}

async function proxyXBanner(res,handle){
  const target=await resolveXBanner(handle);
  if(!target) return false;

  try{
    const r=await fetch(target,{
      headers:{
        accept:'image/avif,image/webp,image/apng,image/*,*/*;q=0.8',
        'user-agent':'Mozilla/5.0'
      },
      redirect:'follow',
      signal:AbortSignal.timeout(12000)
    });
    if(!r.ok) return false;

    const type=String(r.headers.get('content-type')||'').split(';')[0].trim().toLowerCase();
    if(!type.startsWith('image/')) return false;

    const bytes=Buffer.from(await r.arrayBuffer());
    if(!bytes.length || bytes.length>8_000_000) return false;

    res.writeHead(200,{
      'content-type':type,
      'content-length':String(bytes.length),
      'cache-control':'public, max-age=3600, stale-while-revalidate=86400',
      'x-content-type-options':'nosniff'
    });
    res.end(bytes);
    return true;
  }catch{
    return false;
  }
}
'''
    api=api.replace(insert_before,banner_code+insert_before,1)

if "url.pathname.startsWith('/api/x-banner/')" not in api:
    avatar_route='''    if(req.method==='GET'&&url.pathname.startsWith('/api/x-avatar/')){
      const handle=decodeURIComponent(url.pathname.slice('/api/x-avatar/'.length)).replace(/^@/,'').trim();
      if(!/^[A-Za-z0-9_]{1,15}$/.test(handle)) return json(res,400,{error:'Invalid X username'});
      const sent=await proxyXAvatar(res,handle);
      if(sent) return;
      return json(res,404,{error:'X avatar not found'});
    }'''
    banner_route=avatar_route+'''
    if(req.method==='GET'&&url.pathname.startsWith('/api/x-banner/')){
      const handle=decodeURIComponent(url.pathname.slice('/api/x-banner/'.length)).replace(/^@/,'').trim();
      if(!/^[A-Za-z0-9_]{1,15}$/.test(handle)) return json(res,400,{error:'Invalid X username'});
      const sent=await proxyXBanner(res,handle);
      if(sent) return;
      return json(res,404,{error:'X banner not found'});
    }'''
    if avatar_route not in api:
        raise SystemExit("ERROR: X avatar route not found in server/api.js")
    api=api.replace(avatar_route,banner_route,1)

api=api.replace(
    "const fields='id,name,username,profile_image_url,verified,verified_type';",
    "const fields='id,name,username,profile_image_url,profile_banner_url,verified,verified_type';"
)

old_update='''      /* cache-x-profile-avatar-v13 */
      const cachedAvatar=largerXAvatar(u.profile_image_url||'');
      if(cachedAvatar){
        db.prepare(`UPDATE recipients
          SET x_user_id=COALESCE(NULLIF(?,''),x_user_id),
              display_name=COALESCE(NULLIF(?,''),display_name),
              avatar_url=?,
              updated_at=CURRENT_TIMESTAMP
          WHERE handle=? COLLATE NOCASE`)
          .run(String(u.id||''),String(u.name||u.username||''),cachedAvatar,username);
      }
      return json(res,200,{
        id:String(u.id||''),
        name:String(u.name||u.username||''),
        username:String(u.username||username),
        profileImageUrl:String(u.profile_image_url||''),
        verified:Boolean(u.verified),
        verifiedType:String(u.verified_type||'')
      });'''

new_update='''      /* cache-x-profile-avatar-v13 + x-profile-banner-v22-1 */
      const cachedAvatar=largerXAvatar(u.profile_image_url||'');
      const cachedBanner=String(u.profile_banner_url||'').trim();
      db.prepare(`UPDATE recipients
        SET x_user_id=COALESCE(NULLIF(?,''),x_user_id),
            display_name=COALESCE(NULLIF(?,''),display_name),
            avatar_url=COALESCE(NULLIF(?,''),avatar_url),
            banner_url=COALESCE(NULLIF(?,''),banner_url),
            verified=?,
            verified_type=?,
            updated_at=CURRENT_TIMESTAMP
        WHERE handle=? COLLATE NOCASE`)
        .run(
          String(u.id||''),
          String(u.name||u.username||''),
          cachedAvatar,
          cachedBanner,
          u.verified?1:0,
          String(u.verified_type||''),
          username
        );
      return json(res,200,{
        id:String(u.id||''),
        name:String(u.name||u.username||''),
        username:String(u.username||username),
        profileImageUrl:String(u.profile_image_url||''),
        profileBannerUrl:cachedBanner,
        verified:Boolean(u.verified),
        verifiedType:String(u.verified_type||'')
      });'''

if old_update in api:
    api=api.replace(old_update,new_update,1)
elif "profileBannerUrl:cachedBanner" not in api:
    raise SystemExit("ERROR: /api/x/profile cache block not found in server/api.js")

# 3) homeData
old_home="profiles:db.prepare(`SELECT r.handle,r.display_name,r.avatar_url,COUNT(DISTINCT t.mint) token_count,COALESCE(SUM(p.amount_usd),0) received FROM recipients r"
new_home="profiles:db.prepare(`SELECT r.handle,r.display_name,r.avatar_url,r.banner_url,r.verified,r.verified_type,COUNT(DISTINCT t.mint) token_count,COALESCE(SUM(p.amount_usd),0) received FROM recipients r"
if old_home in queries:
    queries=queries.replace(old_home,new_home,1)
elif "r.banner_url,r.verified,r.verified_type" not in queries:
    raise SystemExit("ERROR: homeData profile SELECT not found in server/queries.js")

# 4) frontend
old_cover='''  const coverMedia=cover
    ? `<img class="home-profile-cover-image" src="${esc(cover)}" alt="" loading="lazy" decoding="async" onerror="this.style.display='none';this.nextElementSibling.style.display='block'"><div class="home-profile-cover-fallback" style="display:none"><span>${esc(initials(name))}</span></div>`
    : `<div class="home-profile-cover-fallback"><span>${esc(initials(name))}</span></div>`;'''

new_cover='''  const coverSource=cover||(handle?`/api/x-banner/${encodeURIComponent(handle)}`:'');
  const coverMedia=coverSource
    ? `<img class="home-profile-cover-image" src="${esc(coverSource)}" alt="" loading="lazy" decoding="async" referrerpolicy="no-referrer" onerror="this.style.display='none';this.nextElementSibling.style.display='block'"><div class="home-profile-cover-fallback" style="display:none"><span>${esc(initials(name))}</span></div>`
    : `<div class="home-profile-cover-fallback"><span>${esc(initials(name))}</span></div>`;'''

if old_cover in app:
    app=app.replace(old_cover,new_cover,1)
elif "const coverSource=cover||(handle?`/api/x-banner/" not in app:
    raise SystemExit("ERROR: v22 profile cover block not found in src/app.js")

db_path.write_text(db)
api_path.write_text(api)
queries_path.write_text(queries)
app_path.write_text(app)

print("server/db.js: banner + verification columns ready")
print("server/api.js: X banner fetch/proxy ready")
print("server/queries.js: home profiles expose banner/verification")
print("src/app.js: Top X cards load real X banner")
PY

echo "==> Running checks"
npm run check

echo "==> Diff"
git diff -- src/app.js server/api.js server/db.js server/queries.js

git add src/app.js server/api.js server/db.js server/queries.js

if git diff --cached --quiet; then
  echo "==> No new changes to commit."
else
  git commit -m "Load real X profile banners in Top X cards"
  git push origin main
fi

echo
echo "PASS: ${PATCH_NAME} installed."
echo "No server restart was performed."
