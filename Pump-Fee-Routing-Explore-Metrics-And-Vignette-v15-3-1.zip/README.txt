Pump Fee Routing — Explore Metrics + Vignette v15.3.1

Fixes the installer SyntaxError from v15.3.

Changes:
- MC number matches Sent number size/style.
- MC and Sent labels match ticker-size text.
- Vignette runs around the whole image, not only the bottom.
- No automatic restart.

Install in existing Replit Shell:

rm -rf /tmp/explore-metrics-v15-3-1
mkdir -p /tmp/explore-metrics-v15-3-1
unzip -o Pump-Fee-Routing-Explore-Metrics-And-Vignette-v15-3-1.zip -d /tmp/explore-metrics-v15-3-1
bash /tmp/explore-metrics-v15-3-1/install.sh
