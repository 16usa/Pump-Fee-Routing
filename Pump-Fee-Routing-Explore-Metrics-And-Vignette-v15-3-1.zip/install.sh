#!/usr/bin/env bash
set -euo pipefail

echo "== Explore Metrics + Vignette v15.3.1 =="

for f in src/app.js src/styles.css; do
  if [ ! -f "$f" ]; then
    echo "ERROR: $f not found. Run this from the existing Replit project workspace."
    exit 1
  fi
done

python3 <<'PYCODE'
from pathlib import Path

app_path = Path("src/app.js")
css_path = Path("src/styles.css")

app = app_path.read_text()
css = css_path.read_text()

if 'data-explore-card-info="v15"' not in app:
    raise SystemExit("ERROR: Explore Card Info v15/v15.1 is not installed yet.")

old_block = """<div class=\"home-explore-v8-stats\">
                  <span>${fmtMc(token.mc ?? token.market_cap_usd)} MC</span>
                  <b><strong>${fmtMoney(token.sent || 0)}</strong><small>Sent</small></b>
                </div>"""

new_block = """<div class=\"home-explore-v8-stats\" data-explore-metrics=\"v15-3-1\">
                  <span>
                    <strong>${fmtMc(token.mc ?? token.market_cap_usd)}</strong>
                    <small>MC</small>
                  </span>
                  <b>
                    <strong>${fmtMoney(token.sent || 0)}</strong>
                    <small>Sent</small>
                  </b>
                </div>"""

if 'data-explore-metrics="v15-3-1"' in app:
    print("PASS metrics markup already installed")
elif old_block in app:
    app = app.replace(old_block, new_block, 1)
    app_path.write_text(app)
    print("PASS metrics markup updated")
else:
    raise SystemExit("ERROR: Explore metrics block not found. Nothing changed.")

marker = "/* explore-metrics-and-vignette-v15-3-1 */"
css_patch = """
/* explore-metrics-and-vignette-v15-3-1 */

/* MC number = Sent number. MC/Sent labels = ticker size. */
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info=\"v15\"] .home-explore-v8-stats[data-explore-metrics=\"v15-3-1\"]{
  display:flex;
  align-items:baseline;
  justify-content:space-between;
  gap:12px;
  min-width:0;
}

.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info=\"v15\"] .home-explore-v8-stats[data-explore-metrics=\"v15-3-1\"] > span,
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info=\"v15\"] .home-explore-v8-stats[data-explore-metrics=\"v15-3-1\"] > b{
  display:flex;
  align-items:baseline;
  gap:4px;
  min-width:0;
  color:#e8e8e8;
  font-size:12px;
  line-height:1.15;
  font-weight:650;
}

.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info=\"v15\"] .home-explore-v8-stats[data-explore-metrics=\"v15-3-1\"] > span{
  flex:1 1 auto;
  justify-content:flex-start;
}

.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info=\"v15\"] .home-explore-v8-stats[data-explore-metrics=\"v15-3-1\"] > b{
  flex:0 0 auto;
  justify-content:flex-end;
}

.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info=\"v15\"] .home-explore-v8-stats[data-explore-metrics=\"v15-3-1\"] strong{
  color:inherit;
  font:inherit;
}

.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info=\"v15\"] .home-explore-v8-stats[data-explore-metrics=\"v15-3-1\"] small{
  color:#6f6f6f;
  font-size:9px;
  line-height:1.15;
  font-weight:450;
  letter-spacing:0;
}

/* Soft vignette around the entire image, not only bottom. */
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info=\"v15\"] > .home-explore-v8-media{
  position:relative;
  isolation:isolate;
}

.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info=\"v15\"] > .home-explore-v8-media::after{
  content:\"\";
  position:absolute;
  inset:0;
  border-radius:inherit;
  pointer-events:none;
  z-index:2;
  background:
    radial-gradient(118% 96% at 50% 48%,
      rgba(0,0,0,0) 54%,
      rgba(0,0,0,.10) 72%,
      rgba(0,0,0,.26) 88%,
      rgba(0,0,0,.40) 100%),
    linear-gradient(180deg,
      rgba(0,0,0,.16) 0%,
      rgba(0,0,0,.02) 22%,
      rgba(0,0,0,.02) 68%,
      rgba(0,0,0,.46) 100%);
  box-shadow:
    inset 28px 0 34px -26px rgba(0,0,0,.20),
    inset -28px 0 34px -26px rgba(0,0,0,.20),
    inset 0 26px 36px -30px rgba(0,0,0,.26),
    inset 0 -58px 72px -34px rgba(0,0,0,.56);
}

.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info=\"v15\"] .home-top-token-age,
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info=\"v15\"] .home-explore-v8-recipient{
  z-index:4;
}

@media (max-width:640px){
  .home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info=\"v15\"] .home-explore-v8-stats[data-explore-metrics=\"v15-3-1\"] > span,
  .home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info=\"v15\"] .home-explore-v8-stats[data-explore-metrics=\"v15-3-1\"] > b{
    gap:3px;
    font-size:10px;
  }

  .home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info=\"v15\"] .home-explore-v8-stats[data-explore-metrics=\"v15-3-1\"] small{
    font-size:7px;
  }
}
"""

if marker in css:
    print("PASS CSS already installed")
else:
    css_path.write_text(css + chr(10) + css_patch + chr(10))
    print("PASS CSS patch added")

app = app_path.read_text()
css = css_path.read_text()

checks = {
    "metrics marker": 'data-explore-metrics="v15-3-1"' in app,
    "MC label": "<small>MC</small>" in app,
    "Sent label": "<small>Sent</small>" in app,
    "CSS marker": marker in css,
    "vignette": "> .home-explore-v8-media::after" in css,
}
for label, ok in checks.items():
    if not ok:
        raise SystemExit(f"ERROR: verification failed: {label}")
    print("PASS", label)
PYCODE

echo
echo "== Project checks =="
npm run check

echo
echo "== Git diff =="
git diff --stat

git add src/app.js src/styles.css

if git diff --cached --quiet; then
  echo "No new changes to commit."
else
  git commit -m "Match Explore metrics and image vignette"
  git push
fi

echo
echo "DONE: Explore Metrics + Vignette v15.3.1 installed, checked, committed, and pushed."
echo "No server restart was performed."
echo "Restart Run/Console manually once, then reload the page."
