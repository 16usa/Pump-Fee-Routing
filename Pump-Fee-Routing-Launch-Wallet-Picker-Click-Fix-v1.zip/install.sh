#!/usr/bin/env bash
set -euo pipefail

[ -f src/app.js ] || {
  echo "Missing src/app.js. Run this from the Pump-Fee-Routing project root."
  exit 1
}

if [ -n "$(git status --porcelain -- src/app.js)" ]; then
  echo "STOP: src/app.js has uncommitted changes."
  git status --short -- src/app.js
  exit 2
fi

python3 - <<'PY'
from pathlib import Path
import base64

p=Path("src/app.js")
s=p.read_text()

marker="launch-wallet-picker-click-fix-v1"
if marker in s:
    raise SystemExit("Launch Wallet Picker Click Fix v1 is already installed.")

old=base64.b64decode("ICBgOwogIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQobW9kYWwpOwp9CgpmdW5jdGlvbiByZXN0b3JlTGF1bmNoV2FsbGV0RHJhZnQoKXs=").decode()
new=base64.b64decode("ICBgOwoKICBtb2RhbC5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsZT0+ewogICAgY29uc3QgY2xvc2U9ZS50YXJnZXQuY2xvc2VzdCgnW2RhdGEtd2FsbGV0LWNsb3NlXScpOwogICAgaWYoY2xvc2UpewogICAgICBlLnByZXZlbnREZWZhdWx0KCk7CiAgICAgIGNsb3NlTGF1bmNoV2FsbGV0UGlja2VyKCk7CiAgICAgIHJldHVybjsKICAgIH0KCiAgICBjb25zdCB3YWxsZXRPcGVuPWUudGFyZ2V0LmNsb3Nlc3QoJ1tkYXRhLXdhbGxldC1vcGVuXScpOwogICAgaWYod2FsbGV0T3Blbil7CiAgICAgIGUucHJldmVudERlZmF1bHQoKTsKICAgICAgY29uc3QgdGFyZ2V0PXdhbGxldEJyb3dzZVVybCh3YWxsZXRPcGVuLmRhdGFzZXQud2FsbGV0T3Blbik7CiAgICAgIGlmKCF0YXJnZXQpcmV0dXJuOwogICAgICB3YWxsZXRPcGVuLmRpc2FibGVkPXRydWU7CiAgICAgIGxvY2F0aW9uLmhyZWY9dGFyZ2V0OwogICAgfQogIH0pOwoKICBkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKG1vZGFsKTsKfQoKZnVuY3Rpb24gcmVzdG9yZUxhdW5jaFdhbGxldERyYWZ0KCl7").decode()

if old not in s:
    raise SystemExit("Wallet picker anchor not found.")

s=s.replace(old,new,1)
s += "\n/* "+marker+" */\n"
p.write_text(s)

print("Launch Wallet Picker Click Fix v1 installed.")
PY

node --check src/app.js
npm run check

node <<'NODE'
const fs=require('fs');
const s=fs.readFileSync('src/app.js','utf8');

const checks=[
  ['picker local click listener', s.includes("modal.addEventListener('click',e=>{")],
  ['close handled locally', s.includes("const close=e.target.closest('[data-wallet-close]')")],
  ['wallet choice handled locally', s.includes("const walletOpen=e.target.closest('[data-wallet-open]')")],
  ['wallet browse URL used locally', s.includes("const target=walletBrowseUrl(walletOpen.dataset.walletOpen)")],
  ['modal still mounted on body', s.includes("document.body.appendChild(modal)")],
  ['loading hotfix preserved', s.includes("launch-mobile-wallet-loading-hotfix-v1")],
  ['patch marker', s.includes("launch-wallet-picker-click-fix-v1")]
];

let bad=0;
for(const [name,ok] of checks){
  console.log((ok?'PASS':'FAIL')+' '+name);
  if(!ok)bad++;
}
if(bad)process.exit(1);
NODE

git add src/app.js

if git diff --cached --quiet; then
  echo "No staged changes; nothing to commit."
else
  git commit -m "Fix mobile wallet picker buttons"
fi

git push origin main

echo
echo "DONE: Launch Wallet Picker Click Fix v1 checked, committed, and pushed."
echo "Cause fixed: the wallet picker is appended to document.body, but its old click handler existed only on #app."
echo "Phantom, Solflare, close X, and backdrop taps are now handled directly by the wallet picker."
echo "No server restart was performed."
echo "Restart Console/Run manually once, reload Launch, then test Phantom and Solflare."
