Pump Fee Routing — Launch Wallet Picker Click Fix v1

Problem:
The mobile wallet picker was appended to document.body, but click handling
for Phantom / Solflare / Close lived only on the #app element.
Because the modal is outside #app, those clicks never reached that handler.

Fix:
- Adds a click handler directly to the wallet picker.
- Phantom button opens the Phantom browse universal link.
- Solflare button opens the Solflare browse universal link.
- X button closes the picker.
- Backdrop tap closes the picker.
- Keeps the previous loading-loop hotfix and wallet draft logic unchanged.

Installer validates, commits, and pushes origin/main.
No automatic server restart.
