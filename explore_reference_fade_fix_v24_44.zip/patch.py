from pathlib import Path

css_path = Path("src/styles.css")
if not css_path.exists():
    raise SystemExit("ERROR: src/styles.css not found. Run from the existing Replit project root.")

css = css_path.read_text()
marker = "/* explore-reference-fade-fix-v24-44 */"

required = [
    ".home-explore-reference-v8",
    ".home-explore-v8-stage",
    ".home-explore-v8-footer",
    ".home-explore-v8-primary-slot",
    ".home-explore-v8-secondary-slot",
]
missing = [s for s in required if s not in css]
if missing:
    raise SystemExit("ERROR: Explore selectors not found: " + ", ".join(missing))

if marker not in css:
    css += r'''

/* explore-reference-fade-fix-v24-44
   Replace v24.43's heavy per-slot blur with one soft lower-stage fade,
   closer to the UsePaid reference. Keep Explore / Open + arrow crisp. */

/* Disable old per-slot overlays from v24.43. */
.home-explore-reference-v8 .home-explore-v8-primary-slot::before,
.home-explore-reference-v8 .home-explore-v8-primary-slot::after,
.home-explore-reference-v8 .home-explore-v8-secondary-slot::before,
.home-explore-reference-v8 .home-explore-v8-secondary-slot::after{
  content:none !important;
  display:none !important;
  background:none !important;
  -webkit-backdrop-filter:none !important;
  backdrop-filter:none !important;
  -webkit-mask-image:none !important;
  mask-image:none !important;
}

/* No top vignette. */
.home-explore-reference-v8 .home-explore-v8-stage::before{
  content:none !important;
  display:none !important;
}

/* Single progressive lower blur/fade across the preview interior. */
.home-explore-reference-v8 .home-explore-v8-stage::after{
  content:"" !important;
  display:block !important;
  position:absolute !important;
  left:0 !important;
  right:0 !important;
  top:auto !important;
  bottom:0 !important;
  height:31% !important;
  z-index:8 !important;
  pointer-events:none !important;

  background:linear-gradient(
    to top,
    rgba(10,10,10,.62) 0%,
    rgba(10,10,10,.34) 30%,
    rgba(10,10,10,.13) 62%,
    rgba(10,10,10,0) 100%
  ) !important;

  -webkit-backdrop-filter:blur(9px) saturate(.96) !important;
  backdrop-filter:blur(9px) saturate(.96) !important;

  -webkit-mask-image:linear-gradient(
    to top,
    #000 0%,
    rgba(0,0,0,.95) 26%,
    rgba(0,0,0,.64) 58%,
    rgba(0,0,0,.22) 82%,
    transparent 100%
  ) !important;
  mask-image:linear-gradient(
    to top,
    #000 0%,
    rgba(0,0,0,.95) 26%,
    rgba(0,0,0,.64) 58%,
    rgba(0,0,0,.22) 82%,
    transparent 100%
  ) !important;
  -webkit-mask-repeat:no-repeat !important;
  mask-repeat:no-repeat !important;
  -webkit-mask-size:100% 100% !important;
  mask-size:100% 100% !important;
}

/* Footer must remain in its original absolute position and above the blur. */
.home-explore-reference-v8 .home-explore-v8-footer{
  position:absolute !important;
  left:18px !important;
  right:18px !important;
  bottom:14px !important;
  z-index:20 !important;
  display:flex !important;
  align-items:center !important;
  justify-content:space-between !important;
  visibility:visible !important;
  opacity:1 !important;
  -webkit-filter:none !important;
  filter:none !important;
}

.home-explore-reference-v8 .home-explore-v8-footer strong,
.home-explore-reference-v8 .home-explore-v8-footer span{
  position:relative !important;
  z-index:21 !important;
  visibility:visible !important;
  opacity:1 !important;
  -webkit-filter:none !important;
  filter:none !important;
}

/* Preserve all preview content underneath the effect. */
.home-explore-reference-v8 .home-explore-v8-primary-slot,
.home-explore-reference-v8 .home-explore-v8-secondary-slot{
  visibility:visible !important;
  opacity:1 !important;
}

/* Keep the old bottom shade subtle so it does not black out card details. */
.home-explore-reference-v8 .home-explore-v8-bottom-shade{
  height:16% !important;
  z-index:7 !important;
  opacity:.42 !important;
  background:linear-gradient(
    to top,
    rgba(10,10,10,.58) 0%,
    rgba(10,10,10,.20) 50%,
    rgba(10,10,10,0) 100%
  ) !important;
}

@media(max-width:640px){
  .home-explore-reference-v8 .home-explore-v8-stage::after{
    height:33% !important;
    background:linear-gradient(
      to top,
      rgba(10,10,10,.64) 0%,
      rgba(10,10,10,.36) 31%,
      rgba(10,10,10,.13) 64%,
      rgba(10,10,10,0) 100%
    ) !important;
    -webkit-backdrop-filter:blur(9px) saturate(.96) !important;
    backdrop-filter:blur(9px) saturate(.96) !important;
  }

  .home-explore-reference-v8 .home-explore-v8-footer{
    position:absolute !important;
    left:14px !important;
    right:14px !important;
    bottom:11px !important;
    z-index:20 !important;
  }
}
'''
    css_path.write_text(css)
    print("PASS: v24.44 installed.")
    print("PASS: heavy v24.43 slot blur disabled.")
    print("PASS: footer Explore/Open + arrow restored above the effect.")
    print("PASS: lower fade is softer and narrower, closer to the reference.")
else:
    print("No changes needed; v24.44 already installed.")
