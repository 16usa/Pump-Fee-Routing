Explore Reference Fade Fix v24.44

Why v24.43 looked wrong:
- it blurred each slot separately over ~47% of its height
- that made the lower half too dark and too soft
- it also changed the footer to position:relative, which could move Explore/Open out of place

v24.44:
- disables the v24.43 per-slot overlays
- uses one softer bottom blur/fade across the preview interior
- keeps the effect narrow (31-33% high)
- restores Explore / Open + arrow to absolute positioning above the effect
- keeps the old bottom shade subtle
- does not change card geometry

No automatic restart.
