Top Tokens Money Mark Match Avatar v24.11

What this fixes:
- In Top Tokens, the left dollar circle inside the recipient chip was smaller than the avatar.
- This patch makes that left circle the same size as the avatar.
- It also increases the dollar glyph proportionally.

Targeted rules:
- .home-top-token-card[data-top-token-layout="v21"] .home-top-token-recipient>i
- mobile variant inside @media(max-width:640px)

Install from the existing Replit Shell:

rm -rf /tmp/top_tokens_money_mark_match_avatar_v24_11 && mkdir -p /tmp/top_tokens_money_mark_match_avatar_v24_11 && unzip -o top_tokens_money_mark_match_avatar_v24_11.zip -d /tmp/top_tokens_money_mark_match_avatar_v24_11 && bash /tmp/top_tokens_money_mark_match_avatar_v24_11/install.sh

No automatic restart.
