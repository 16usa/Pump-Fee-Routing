from pathlib import Path
import re

path = Path('src/styles.css')
if not path.exists():
    raise SystemExit('ERROR: src/styles.css not found. Run from project root.')

css = path.read_text()
orig = css

marker = '/* Recipient/profile pill = Explore recipient pill style. */'
start = css.find(marker)
if start < 0:
    raise SystemExit('ERROR: Top Tokens v21 recipient pill block marker not found')

tail = css[start:]

# Desktop: make the left dollar circle exactly the same size as the avatar.
desktop_pattern = re.compile(
    r'(\.home-top-token-card\[data-top-token-layout="v21"\] \.home-top-token-recipient>i\{\s*)'
    r'width:\s*\d+px;\s*'
    r'height:\s*\d+px;\s*'
    r'flex:0 0 \d+px;\s*'
    r'(display:grid;\s*place-items:center;\s*border-radius:50%;\s*background:#171717;\s*color:#d8d8d8;\s*)'
    r'font-size:\s*\d+px;(\s*line-height:1;\s*font-style:normal;\s*font-weight:750;\s*\})',
    re.S
)

def repl_desktop(m):
    return (
        m.group(1)
        + 'width:22px;\n  height:22px;\n  flex:0 0 22px;\n  '
        + m.group(2)
        + 'font-size:11px;'
        + m.group(3)
    )

tail, n1 = desktop_pattern.subn(repl_desktop, tail, count=1)
if n1 != 1:
    raise SystemExit('ERROR: Desktop Top Tokens money mark rule not found')

# Mobile: match mobile avatar size too.
mobile_pattern = re.compile(
    r'(@media\(max-width:640px\)\{.*?'
    r'\.home-top-token-card\[data-top-token-layout="v21"\] \.home-top-token-recipient>i\{\s*)'
    r'width:\s*\d+px;\s*'
    r'height:\s*\d+px;\s*'
    r'flex-basis:\s*\d+px;\s*'
    r'font-size:\s*\d+px;(\s*\})',
    re.S
)

def repl_mobile(m):
    return (
        m.group(1)
        + 'width:19px;\n    height:19px;\n    flex-basis:19px;\n    font-size:10px;'
        + m.group(2)
    )

tail, n2 = mobile_pattern.subn(repl_mobile, tail, count=1)
if n2 != 1:
    raise SystemExit('ERROR: Mobile Top Tokens money mark rule not found')

css = css[:start] + tail

final_marker = '/* top-tokens-money-mark-match-avatar-v24-11 */'
if final_marker not in css:
    css += '\n\n' + final_marker + r'''
.home-top-token-card[data-top-token-layout="v21"] .home-top-token-recipient>i.home-top-token-money-mark{
  width:22px !important;
  height:22px !important;
  flex:0 0 22px !important;
  font-size:11px !important;
}

@media(max-width:640px){
  .home-top-token-card[data-top-token-layout="v21"] .home-top-token-recipient>i.home-top-token-money-mark{
    width:19px !important;
    height:19px !important;
    flex-basis:19px !important;
    font-size:10px !important;
  }
}
'''

if css == orig:
    print('No changes needed; rules already match requested sizing.')
else:
    path.write_text(css)
    print('PASS: Top Tokens dollar circle now matches avatar size')
