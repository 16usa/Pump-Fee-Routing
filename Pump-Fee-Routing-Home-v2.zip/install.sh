#!/usr/bin/env bash
set -euo pipefail

if [ ! -f src/app.js ] || [ ! -f src/styles.css ]; then
  echo "Run this from the Pump-Fee-Routing project root."
  exit 1
fi

if [ -n "$(git status --porcelain)" ]; then
  echo "STOP: the workspace has uncommitted changes."
  echo "Commit/push them first so this patch does not mix unrelated edits."
  git status --short
  exit 2
fi

python3 - <<'PY'
from pathlib import Path

app_path = Path("src/app.js")
css_path = Path("src/styles.css")
app = app_path.read_text()
css = css_path.read_text()

def replace_between(text, start_marker, end_marker, replacement):
    start = text.find(start_marker)
    end = text.find(end_marker, start)
    if start < 0 or end < 0:
        raise SystemExit(f"Could not locate {start_marker} / {end_marker}")
    return text[:start] + replacement.rstrip() + "\n\n" + text[end:]

hero_fn = r'''function homeHeroCard(h,top){
  const t=top[0]||null;
  const p=(h.profiles||[])[0]||null;
  const handle=t?.profile||t?.recipient_handle||p?.handle||'';
  const display=p?.display_name||handle||'';
  const sent=Number(t?.sent||0);
  const owed=Number(t?.owed||0);
  return `<a class="home-hero-card" href="${t?`#/token/${encodeURIComponent(t.mint||t.contract)}`:'#/explore'}">
    <div class="home-hero-media">
      ${t?.image_url?`<img src="${esc(t.image_url)}" alt="">`:`<div class="home-hero-media-empty"><span>${esc(initials(t?.symbol||t?.name||'P'))}</span><small>${t?'Image unavailable':'No routed token yet'}</small></div>`}
      <div class="home-hero-media-badge">${platformBadge(t?.platform||'Pump')}</div>
      <div class="home-hero-media-route">${handle?`@${esc(handle)}`:'Treasury'}</div>
    </div>
    <div class="home-hero-card-body">
      <div class="home-hero-token-row">
        <div>
          <small>${handle?`@${esc(handle)}`:'Waiting for first route'}</small>
          <strong>${t?esc(t.name):'No routed token yet'}</strong>
          <span>${t?`${esc(t.symbol||'')} · ${fmtMc(t.mc??t.market_cap_usd)} MC`:'Permanent 100% creator-fee route required'}</span>
        </div>
        <b>${t?fmtMoney(sent):'$0.00'}</b>
      </div>
      <div class="home-hero-stats">
        <div><span>Sent</span><b>${fmtMoney(sent)}</b></div>
        <div><span>Owed</span><b>${fmtMoney(owed)}</b></div>
        <div><span>Recipient</span><b>${handle?`@${esc(handle)}`:'—'}</b></div>
      </div>
      <div class="home-hero-card-foot"><span>${display?esc(display):'Verified on-chain routing'}</span><em>${t?'View token →':'Explore →'}</em></div>
    </div>
  </a>`;
}'''

preview_fn = r'''function homePreviewDeck(h,top){
  const t=top[0]||null;
  const pay=(h.payments||[])[0]||null;
  const money=h.money||{};
  const profile=(h.profiles||[])[0]||null;
  const total=Number(money.totalPaid||0);
  return `<section class="home-preview-shell">
    <div class="wrap home-preview-stack">
      <a class="home-preview-card home-preview-token-card" href="#/explore">
        <div class="home-preview-label"><b>Explore</b><span>View all →</span></div>
        <div class="home-preview-token-row">
          ${t?avatar(t.symbol||t.name,true,t.image_url):'<div class="home-preview-placeholder">P</div>'}
          <div>
            <small>${t?`@${esc(t.profile||t.recipient_handle||'')}`:'Token routing'}</small>
            <strong>${t?esc(t.name):'No routed token yet'}</strong>
            <span>${t?`${fmtMc(t.mc??t.market_cap_usd)} MC · ${fmtMoney(t.sent)} Sent`:'Tokens appear here after on-chain verification'}</span>
          </div>
          <em>→</em>
        </div>
      </a>

      <a class="home-preview-card home-preview-payment-card" href="#/money">
        <div class="home-preview-label"><b>Payments</b><span>View all →</span></div>
        <div class="home-preview-payment">
          <small>${pay?'Latest confirmed payment':'Confirmed payouts'}</small>
          <strong>${pay?fmtMoney(pay.amount_usd??pay.amount??0):'$0.00'}</strong>
          <span>${pay?`sent to ${esc(pay.display_name||pay.recipient_handle||'recipient')}`:'No confirmed payments yet'}</span>
          <time>${pay?esc(ago(pay.sent_at||pay.created_at)):'—'}</time>
        </div>
      </a>

      <a class="home-preview-card home-preview-analytics-card" href="#/money">
        <div class="home-preview-label"><b>Analytics</b><span>View all →</span></div>
        <div class="home-preview-analytics">
          <small>Total paid</small>
          <strong>${fmtMoney(total)}</strong>
          <div class="home-mini-chart">${Array.from({length:22},(_,i)=>`<i style="height:${12+((i*23)%68)}%"></i>`).join('')}</div>
          <span>Confirmed ledger activity</span>
        </div>
      </a>

      <a class="home-preview-card home-preview-launch-card" href="#/launch">
        <div class="home-preview-label"><b>Launch</b><span>Open →</span></div>
        <div class="home-preview-launch">
          <small>Recipient X handle</small>
          <div class="home-preview-input">@${profile?esc(profile.handle):'recipient'}</div>
          <div class="home-preview-launch-meta">
            <span>Creator fees</span><b>100%</b>
            <span>Treasury route</span><b>Permanent</b>
          </div>
        </div>
      </a>

      <a class="home-preview-card home-preview-doc-card" href="#/docs">
        <div class="home-preview-label"><b>How it works</b><span>Read →</span></div>
        <div class="home-preview-doc-lines">
          <span><i>1</i><b>Launch token</b><small>pump.fun / supported venue</small></span>
          <span><i>2</i><b>Route creator fees</b><small>100% to treasury</small></span>
          <span><i>3</i><b>Pay recipient</b><small>public ledger confirmation</small></span>
        </div>
      </a>
    </div>
  </section>`;
}'''

app = replace_between(app, "function homeHeroCard(h,top){", "function homePreviewDeck(h,top){", hero_fn)
app = replace_between(app, "function homePreviewDeck(h,top){", "function homeMostPayments(h){", preview_fn)
app_path.write_text(app)

marker = "/* home-v2-header-hero-cards */"
if marker in css:
    raise SystemExit("Home v2 patch is already installed.")

css += r'''

/* home-v2-header-hero-cards */
.home-page .topbar{background:#000}
.home-page .home-hero{
  display:block;
  width:min(100% - 32px,760px);
  min-height:0;
  padding:58px 0 22px;
  text-align:center;
}
.home-page .home-hero .hero-copy{max-width:620px;margin:0 auto}
.home-page .home-hero .hero-copy h1{
  font-size:clamp(42px,7vw,68px);
  line-height:.93;
  letter-spacing:-.062em;
  text-align:center;
}
.home-page .home-hero .hero-copy>p{
  max-width:560px;
  margin:20px auto 24px;
  color:#858585;
  font-size:14px;
  line-height:1.55;
  text-align:center;
}
.home-page .home-hero .hero-buttons{justify-content:center;margin:0 0 42px}
.home-page .home-hero-card{
  display:block;
  width:min(100%,390px);
  margin:0 auto;
  padding:0;
  overflow:hidden;
  color:#fff;
  text-align:left;
  background:#101010;
  border:1px solid #242424;
  border-radius:16px;
  box-shadow:none;
}
.home-hero-media{
  height:190px;
  position:relative;
  display:grid;
  place-items:center;
  overflow:hidden;
  background:#070707;
  border-bottom:1px solid #202020;
}
.home-hero-media>img{width:100%;height:100%;object-fit:cover}
.home-hero-media-empty{
  width:100%;
  height:100%;
  display:grid;
  place-content:center;
  gap:7px;
  text-align:center;
  background:
    radial-gradient(circle at 50% 42%,#1b1b1b 0,#0b0b0b 45%,#070707 72%);
}
.home-hero-media-empty span{font-size:42px;font-weight:900;font-style:italic}
.home-hero-media-empty small{font-size:9px;color:#666}
.home-hero-media-badge{
  position:absolute;
  left:10px;
  bottom:9px;
  padding:5px 8px;
  border-radius:999px;
  background:rgba(0,0,0,.76);
  border:1px solid #343434;
  backdrop-filter:blur(8px);
}
.home-hero-media-route{
  position:absolute;
  right:10px;
  bottom:9px;
  max-width:48%;
  padding:5px 8px;
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
  border-radius:999px;
  background:rgba(0,0,0,.76);
  border:1px solid #343434;
  color:#cfcfcf;
  font-size:8px;
  backdrop-filter:blur(8px);
}
.home-hero-card-body{padding:12px}
.home-hero-token-row{display:flex;align-items:flex-start;justify-content:space-between;gap:12px}
.home-hero-token-row>div{display:grid;min-width:0}
.home-hero-token-row small,.home-hero-token-row span{font-size:8px;color:#686868}
.home-hero-token-row strong{font-size:13px;margin:3px 0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.home-hero-token-row>b{font-size:13px;white-space:nowrap}
.home-hero-stats{
  display:grid;
  grid-template-columns:repeat(3,1fr);
  gap:1px;
  margin-top:12px;
  overflow:hidden;
  border:1px solid #232323;
  border-radius:10px;
  background:#232323;
}
.home-hero-stats>div{display:grid;gap:3px;padding:9px;background:#111;min-width:0}
.home-hero-stats span{font-size:7px;color:#606060}
.home-hero-stats b{font-size:9px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.home-hero-card-foot{display:flex;justify-content:space-between;gap:10px;margin-top:11px;color:#5f5f5f;font-size:8px}
.home-hero-card-foot em{font-style:normal;color:#858585;white-space:nowrap}

.home-preview-shell{padding:12px 0 34px}
.home-preview-stack{
  width:min(100% - 32px,390px);
  display:grid;
  gap:9px;
}
.home-preview-card{
  width:100%;
  min-height:0;
  padding:12px;
  color:#fff;
  background:#141414;
  border:1px solid #242424;
  border-radius:13px;
}
.home-preview-label{margin:0 0 11px;font-size:9px}
.home-preview-label span{font-size:8px;color:#747474}
.home-preview-token-row{
  display:grid;
  grid-template-columns:38px 1fr 12px;
  gap:9px;
  align-items:center;
}
.home-preview-token-row .avatar,
.home-preview-placeholder{
  width:38px;height:38px;border-radius:9px;
}
.home-preview-placeholder{
  display:grid;place-items:center;
  background:#080808;border:1px solid #2a2a2a;
  font-size:15px;font-weight:800;font-style:italic;
}
.home-preview-token-row>div:nth-child(2){display:grid;min-width:0}
.home-preview-token-row small,.home-preview-token-row span{font-size:8px;color:#656565}
.home-preview-token-row strong{font-size:11px;margin:2px 0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.home-preview-token-row em{font-style:normal;color:#777}
.home-preview-payment{display:grid;grid-template-columns:1fr auto;align-items:end}
.home-preview-payment small,.home-preview-payment span{grid-column:1/2;font-size:8px;color:#656565}
.home-preview-payment strong{grid-column:1/2;font-size:24px;letter-spacing:-.045em;margin:4px 0}
.home-preview-payment time{grid-column:2/3;grid-row:1/4;align-self:end;font-size:8px;color:#666}
.home-preview-analytics{display:grid}
.home-preview-analytics small,.home-preview-analytics span{font-size:8px;color:#656565}
.home-preview-analytics strong{font-size:24px;letter-spacing:-.045em;margin:3px 0 8px}
.home-mini-chart{height:44px;margin:2px 0 8px;gap:2px}
.home-mini-chart i{background:#292929}
.home-preview-launch{display:grid}
.home-preview-launch>small{font-size:8px;color:#666;margin-bottom:6px}
.home-preview-input{
  padding:10px 12px;
  border:1px solid #333;
  border-radius:999px;
  background:#090909;
  color:#d3d3d3;
  font-size:10px;
}
.home-preview-launch-meta{
  display:grid;
  grid-template-columns:1fr auto;
  gap:6px 12px;
  margin-top:10px;
  padding:0 4px;
}
.home-preview-launch-meta span{font-size:8px;color:#626262}
.home-preview-launch-meta b{font-size:8px;font-weight:600}
.home-preview-doc-lines{display:grid;gap:8px}
.home-preview-doc-lines>span{
  display:grid;
  grid-template-columns:22px 1fr;
  gap:1px 8px;
  align-items:center;
}
.home-preview-doc-lines i{
  grid-row:1/3;
  width:22px;height:22px;
  display:grid;place-items:center;
  border:1px solid #303030;border-radius:50%;
  color:#777;font-style:normal;font-size:8px;
}
.home-preview-doc-lines b{font-size:9px}
.home-preview-doc-lines small{font-size:7px;color:#606060}

@media(max-width:640px){
  .topbar{height:52px}
  .topbar-inner{height:52px;width:calc(100% - 28px)}
  .launch-pill{padding:7px 15px;font-size:11px}
  .menu-btn{margin-left:2px}
  .home-page .home-hero{width:calc(100% - 32px);padding-top:42px}
  .home-page .home-hero .hero-copy h1{font-size:38px;line-height:.94}
  .home-page .home-hero .hero-copy>p{font-size:11px;line-height:1.55;margin:16px auto 20px}
  .home-page .home-hero .hero-buttons{gap:15px;margin-bottom:34px}
  .home-page .home-hero .btn-light{padding:10px 15px;font-size:11px}
  .home-page .home-hero .text-link{font-size:10px}
  .home-hero-media{height:178px}
  .home-preview-stack{width:calc(100% - 32px)}
}
'''
css_path.write_text(css)

print("Home v2 header/hero/cards patch installed.")
PY

npm run check

git add src/app.js src/styles.css

if git diff --cached --quiet; then
  echo "No staged changes; nothing to commit."
else
  git commit -m "Home v2 header hero cards"
fi

git push origin main

echo
echo "DONE: patch checked, committed, and pushed to GitHub."
echo "No server restart was performed."
echo "Refresh the browser to see the updated Home page."
