Pump Fee Routing — Home v2
Scope: Header + Hero + main token/payment/showcase cards only.
Backend, Solana, database, workers, and lower homepage sections are untouched.
Installer runs npm check, commits, and pushes to origin/main.
No automatic server restart.
