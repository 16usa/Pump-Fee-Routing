Pump Fee Routing — Explore Image Inset v15.2

Changes only the left image area in the Home Explore card.

- Adds top, left, and right inset around the image.
- Adds the inner image border/radius like the reference.
- Keeps the info section directly below the image.
- Keeps age and recipient overlays on the image.
- Does not change the right card or other modules.
- No automatic server restart.

Install in the existing Replit Shell:

rm -rf /tmp/explore-image-inset-v15-2
mkdir -p /tmp/explore-image-inset-v15-2
unzip -o Pump-Fee-Routing-Explore-Image-Inset-v15-2.zip -d /tmp/explore-image-inset-v15-2
bash /tmp/explore-image-inset-v15-2/install.sh
