#!/usr/bin/env bash
set -euo pipefail

echo "== Explore Image Inset v15.2 =="

for f in src/app.js src/styles.css; do
  if [ ! -f "$f" ]; then
    echo "ERROR: $f not found. Run this from the existing Replit project workspace."
    exit 1
  fi
done

python3 <<'PY'
from pathlib import Path

app_path = Path("src/app.js")
css_path = Path("src/styles.css")

app = app_path.read_text()
css = css_path.read_text()

if 'data-explore-card-info="v15"' not in app:
    raise SystemExit("ERROR: Explore Card Info v15/v15.1 is not installed yet. Install v15.1 first.")

marker = "/* explore-image-inset-v15-2 */"
css_patch = r"""
/* explore-image-inset-v15-2 */

/* Reference-style breathing room around the LEFT Explore image:
   top + left + right. */
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"]{
  padding:12px 12px 42px;
}

/* Image becomes an inset module inside the card. */
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] > .home-explore-v8-media{
  border:1px solid #2b2b2b;
  border-radius:14px;
  overflow:hidden;
  background:#0a0a0a;
}

/* Info stays directly below the image. */
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] > .home-explore-v8-copy{
  padding:9px 1px 10px;
  border-top:0;
  background:#0b0b0b;
}

/* Keep overlays relative to the inset image. */
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-top-token-age{
  top:7px;
  right:7px;
}
.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-recipient{
  left:8px;
  bottom:8px;
}

@media (max-width:640px){
  .home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"]{
    padding:9px 9px 36px;
  }
  .home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] > .home-explore-v8-media{
    border-radius:11px;
  }
  .home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] > .home-explore-v8-copy{
    padding:7px 1px 8px;
  }
  .home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-top-token-age{
    top:6px;
    right:6px;
  }
  .home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] .home-explore-v8-recipient{
    left:6px;
    bottom:6px;
  }
}
"""

if marker in css:
    print("PASS Explore image inset already installed")
else:
    css_path.write_text(css + "\n" + css_patch + "\n")
    print("PASS Explore image inset added")

c = css_path.read_text()
checks = {
    "v15 card structure exists": 'data-explore-card-info="v15"' in app,
    "inset marker exists": marker in c,
    "desktop inset exists": "padding:12px 12px 42px;" in c,
    "media border exists": "border:1px solid #2b2b2b;" in c,
    "media radius exists": "border-radius:14px;" in c,
}
for label, ok in checks.items():
    if not ok:
        raise SystemExit(f"ERROR: verification failed: {label}")
    print("PASS", label)
PY

echo
echo "== Project checks =="
npm run check

echo
echo "== Git diff =="
git diff --stat

git add src/styles.css

if git diff --cached --quiet; then
  echo "No new changes to commit (patch may already be installed)."
else
  git commit -m "Add inset spacing around Explore image"
  git push
fi

echo
echo "DONE: Explore Image Inset v15.2 installed, checked, committed, and pushed."
echo "No server restart was performed."
echo "Restart Run/Console manually once, then reload the page."
