Pump Fee Routing — Launch Demo Rotator Loop Fix v2

Fixes the page-freezing / page-not-loading issue introduced by the animated Launch demo card.

Root cause:
The MutationObserver watched the whole document. Every time the demo card rendered,
its own DOM mutation triggered the observer again. The observer called
startLaunchDemoRotation(), which immediately rendered the card again, producing
a self-triggering render loop that could lock the browser main thread.

Fix:
- Do not render again when the rotator timer is already active.
- Existing demo block only starts the rotator if it is not already running.
- Keeps all 10 scenes and the current design.

Installer checks, commits, and pushes origin/main.
No automatic server restart.
