#!/usr/bin/env bash
set -euo pipefail

[ -f src/app.js ] || {
  echo "Missing src/app.js. Run this from the Pump-Fee-Routing project root."
  exit 1
}

if [ -n "$(git status --porcelain -- src/app.js)" ]; then
  echo "STOP: src/app.js has uncommitted changes."
  git status --short -- src/app.js
  exit 2
fi

python3 - <<'PY'
from pathlib import Path
import base64

p=Path("src/app.js")
app=p.read_text()

marker="launch-demo-rotator-loop-fix-v2"
if marker in app:
    raise SystemExit("Launch Demo Rotator Loop Fix v2 is already installed.")

if "launch-demo-rotator-v1" not in app:
    raise SystemExit("Launch Demo Rotator v1 was not found.")

old_start=base64.b64decode("ZnVuY3Rpb24gc3RhcnRMYXVuY2hEZW1vUm90YXRpb24oKXsKICBjb25zdCBjYXJkPWRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJyNsYXVuY2hEZW1vUm90YXRvcicpOwogIGlmKCFjYXJkKXJldHVybjsKICByZW5kZXJMYXVuY2hEZW1vU2NlbmUodHJ1ZSk7CiAgY2FyZC5jbGFzc0xpc3QuYWRkKCdpcy1hY3RpdmUnKTsKICBpZihsYXVuY2hEZW1vVGltZXIpcmV0dXJuOwogIGxhdW5jaERlbW9UaW1lcj1zZXRJbnRlcnZhbCgoKT0+ewogICAgaWYoIWRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJyNsYXVuY2hEZW1vUm90YXRvcicpKXsKICAgICAgY2xlYXJJbnRlcnZhbChsYXVuY2hEZW1vVGltZXIpOwogICAgICBsYXVuY2hEZW1vVGltZXI9bnVsbDsKICAgICAgcmV0dXJuOwogICAgfQogICAgbGF1bmNoRGVtb1NjZW5lSW5kZXg9KGxhdW5jaERlbW9TY2VuZUluZGV4KzEpJWxhdW5jaERlbW9TY2VuZXMubGVuZ3RoOwogICAgcmVuZGVyTGF1bmNoRGVtb1NjZW5lKGZhbHNlKTsKICB9LDI2MDApOwp9").decode()
new_start=base64.b64decode("ZnVuY3Rpb24gc3RhcnRMYXVuY2hEZW1vUm90YXRpb24oKXsKICBjb25zdCBjYXJkPWRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJyNsYXVuY2hEZW1vUm90YXRvcicpOwogIGlmKCFjYXJkKXJldHVybjsKICBpZihsYXVuY2hEZW1vVGltZXIpcmV0dXJuOwogIHJlbmRlckxhdW5jaERlbW9TY2VuZSh0cnVlKTsKICBjYXJkLmNsYXNzTGlzdC5hZGQoJ2lzLWFjdGl2ZScpOwogIGxhdW5jaERlbW9UaW1lcj1zZXRJbnRlcnZhbCgoKT0+ewogICAgaWYoIWRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJyNsYXVuY2hEZW1vUm90YXRvcicpKXsKICAgICAgY2xlYXJJbnRlcnZhbChsYXVuY2hEZW1vVGltZXIpOwogICAgICBsYXVuY2hEZW1vVGltZXI9bnVsbDsKICAgICAgcmV0dXJuOwogICAgfQogICAgbGF1bmNoRGVtb1NjZW5lSW5kZXg9KGxhdW5jaERlbW9TY2VuZUluZGV4KzEpJWxhdW5jaERlbW9TY2VuZXMubGVuZ3RoOwogICAgcmVuZGVyTGF1bmNoRGVtb1NjZW5lKGZhbHNlKTsKICB9LDI2MDApOwp9").decode()
old_existing=base64.b64decode("ICBpZihkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcjbGF1bmNoRGVtb0Jsb2NrJykpewogICAgc3RhcnRMYXVuY2hEZW1vUm90YXRpb24oKTsKICAgIHJldHVybjsKICB9").decode()
new_existing=base64.b64decode("ICBpZihkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcjbGF1bmNoRGVtb0Jsb2NrJykpewogICAgaWYoIWxhdW5jaERlbW9UaW1lcilzdGFydExhdW5jaERlbW9Sb3RhdGlvbigpOwogICAgcmV0dXJuOwogIH0=").decode()

if old_start not in app:
    raise SystemExit("startLaunchDemoRotation anchor not found.")
if old_existing not in app:
    raise SystemExit("existing demo block anchor not found.")

app=app.replace(old_start,new_start,1)
app=app.replace(old_existing,new_existing,1)
app += "\n/* launch-demo-rotator-loop-fix-v2 */\n"

p.write_text(app)
print("Launch Demo Rotator Loop Fix v2 installed.")
PY

node --check src/app.js
npm run check

node <<'NODE'
const fs=require('fs');
const app=fs.readFileSync('src/app.js','utf8');

const startBegin=app.indexOf('function startLaunchDemoRotation(){');
const startEnd=app.indexOf('function stopLaunchDemoRotation(){');
const ensureBegin=app.indexOf('function ensureLaunchDemoBlock(){');
const ensureEnd=app.indexOf('const launchDemoObserver=');

const start=startBegin>=0 && startEnd>startBegin ? app.slice(startBegin,startEnd) : '';
const ensure=ensureBegin>=0 && ensureEnd>ensureBegin ? app.slice(ensureBegin,ensureEnd) : '';

const checks=[
  ['timer guard before first render', start.indexOf('if(launchDemoTimer)return;') >= 0 && start.indexOf('if(launchDemoTimer)return;') < start.indexOf('renderLaunchDemoScene(true);')],
  ['existing block does not force rerender', ensure.includes('if(!launchDemoTimer)startLaunchDemoRotation();')],
  ['loop fix marker', app.includes('launch-demo-rotator-loop-fix-v2')],
  ['rotator still has 10 scenes', app.includes('const launchDemoScenes=[5,10,20,50,100].flatMap')]
];

let bad=0;
for(const [name,ok] of checks){
  console.log((ok?'PASS':'FAIL')+' '+name);
  if(!ok)bad++;
}
if(bad)process.exit(1);
NODE

git add src/app.js

if git diff --cached --quiet; then
  echo "No staged changes; nothing to commit."
else
  git commit -m "Fix Launch demo observer render loop"
fi

git push origin main

echo
echo "DONE: Launch Demo Rotator Loop Fix v2 checked, committed, and pushed to GitHub."
echo "Root cause fixed: MutationObserver was repeatedly forcing the rotator to render itself."
echo "No server restart was performed."
echo "Restart Console/Run manually once to load the fix."
