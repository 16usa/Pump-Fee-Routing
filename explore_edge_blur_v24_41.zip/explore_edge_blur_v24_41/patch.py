from pathlib import Path

css_path = Path('src/styles.css')
if not css_path.exists():
    raise SystemExit('ERROR: src/styles.css not found. Run from the existing Replit project root.')

css = css_path.read_text()
marker = '/* explore-edge-blur-v24-41 */'

if '.home-explore-reference-v8' not in css or '.home-explore-v8-stage' not in css:
    raise SystemExit('ERROR: Explore preview selectors not found in src/styles.css')

if marker not in css:
    css += r'''

/* explore-edge-blur-v24-41
   Add a strong circular / perimeter blur vignette inside the Explore block.
   The blur is strongest at the borders, fades inward gradually, and the bottom
   edge starts stronger than the rest. Footer text stays above the effect. */
.home-explore-reference-v8 .home-explore-v8-stage{
  position:relative !important;
  overflow:hidden !important;
  isolation:isolate !important;
}

.home-explore-reference-v8 .home-explore-v8-stage::before,
.home-explore-reference-v8 .home-explore-v8-stage::after{
  content:"";
  position:absolute;
  pointer-events:none;
  border-radius:inherit;
}

.home-explore-reference-v8 .home-explore-v8-stage::before{
  inset:0 !important;
  z-index:6 !important;
  background:
    radial-gradient(140% 102% at 50% 44%, rgba(10,10,10,0) 41%, rgba(10,10,10,0.06) 52%, rgba(10,10,10,0.22) 65%, rgba(10,10,10,0.48) 78%, rgba(10,10,10,0.76) 100%),
    linear-gradient(to top, rgba(10,10,10,0.86) 0%, rgba(10,10,10,0.50) 14%, rgba(10,10,10,0.18) 26%, rgba(10,10,10,0) 42%),
    linear-gradient(to bottom, rgba(10,10,10,0.42) 0%, rgba(10,10,10,0.18) 12%, rgba(10,10,10,0) 26%),
    linear-gradient(to right, rgba(10,10,10,0.50) 0%, rgba(10,10,10,0.20) 11%, rgba(10,10,10,0) 22%),
    linear-gradient(to left, rgba(10,10,10,0.50) 0%, rgba(10,10,10,0.20) 11%, rgba(10,10,10,0) 22%) !important;
  -webkit-backdrop-filter: blur(14px) saturate(0.92) !important;
  backdrop-filter: blur(14px) saturate(0.92) !important;
}

.home-explore-reference-v8 .home-explore-v8-stage::after{
  left:0 !important;
  right:0 !important;
  bottom:0 !important;
  height:34% !important;
  z-index:7 !important;
  background:linear-gradient(to top, rgba(10,10,10,0.94) 0%, rgba(10,10,10,0.72) 22%, rgba(10,10,10,0.34) 54%, rgba(10,10,10,0.08) 82%, rgba(10,10,10,0) 100%) !important;
  -webkit-backdrop-filter: blur(18px) saturate(0.9) !important;
  backdrop-filter: blur(18px) saturate(0.9) !important;
}

.home-explore-reference-v8 .home-explore-v8-footer{
  z-index:9 !important;
}

@media(max-width:640px){
  .home-explore-reference-v8 .home-explore-v8-stage::before{
    background:
      radial-gradient(150% 108% at 50% 42%, rgba(10,10,10,0) 39%, rgba(10,10,10,0.08) 51%, rgba(10,10,10,0.26) 64%, rgba(10,10,10,0.54) 78%, rgba(10,10,10,0.82) 100%),
      linear-gradient(to top, rgba(10,10,10,0.92) 0%, rgba(10,10,10,0.58) 16%, rgba(10,10,10,0.20) 30%, rgba(10,10,10,0) 46%),
      linear-gradient(to bottom, rgba(10,10,10,0.46) 0%, rgba(10,10,10,0.20) 13%, rgba(10,10,10,0) 28%),
      linear-gradient(to right, rgba(10,10,10,0.56) 0%, rgba(10,10,10,0.24) 12%, rgba(10,10,10,0) 24%),
      linear-gradient(to left, rgba(10,10,10,0.56) 0%, rgba(10,10,10,0.24) 12%, rgba(10,10,10,0) 24%) !important;
    -webkit-backdrop-filter: blur(15px) saturate(0.92) !important;
    backdrop-filter: blur(15px) saturate(0.92) !important;
  }

  .home-explore-reference-v8 .home-explore-v8-stage::after{
    height:38% !important;
    background:linear-gradient(to top, rgba(10,10,10,0.97) 0%, rgba(10,10,10,0.78) 24%, rgba(10,10,10,0.40) 57%, rgba(10,10,10,0.10) 84%, rgba(10,10,10,0) 100%) !important;
    -webkit-backdrop-filter: blur(20px) saturate(0.88) !important;
    backdrop-filter: blur(20px) saturate(0.88) !important;
  }
}
'''
    css_path.write_text(css)
    print('PASS: Explore block now has a strong edge blur vignette with heavier bottom blur.')
else:
    print('No changes needed; patch already installed.')
