#!/usr/bin/env bash
set -euo pipefail
PATCH_NAME="explore_edge_blur_v24_41"
CSS="src/styles.css"

if [ ! -f "$CSS" ]; then
  echo "ERROR: missing src/styles.css"
  echo "Run this from the existing Replit project root."
  exit 1
fi

echo "==> Installing ${PATCH_NAME}"
mkdir -p ".patch-backups/${PATCH_NAME}"
cp "$CSS" ".patch-backups/${PATCH_NAME}/styles.css.before"

python3 "$(dirname "$0")/patch.py"

echo "==> Verifying patch"
grep -q 'explore-edge-blur-v24-41' "$CSS"

echo "==> Running project check"
npm run check

echo "==> Git diff"
git diff -- src/styles.css

git add src/styles.css
if git diff --cached --quiet; then
  echo "==> No new changes to commit."
else
  git commit -m "Add blur vignette to Explore preview block"
  git push origin main
fi

echo

echo "PASS: ${PATCH_NAME} installed."
echo "No server restart was performed."
