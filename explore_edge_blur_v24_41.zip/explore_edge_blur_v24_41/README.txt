Explore Edge Blur v24.41

Adds a strong blur/vignette inside the Explore preview block:
- strong blur from the block borders inward
- gradual fade toward the center
- stronger blur starting from the bottom edge
- footer labels remain above the effect

No automatic restart.
