Pump Fee Routing — Footer v1.1
Fixes the installer SyntaxError from Footer v1.
Scope: shared site footer only.
Runs npm check, commits, and pushes to origin/main. No automatic server restart.
