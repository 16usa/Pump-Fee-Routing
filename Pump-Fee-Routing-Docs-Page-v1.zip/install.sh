#!/usr/bin/env bash
set -euo pipefail

if [ ! -f src/app.js ] || [ ! -f src/styles.css ]; then
  echo "Run this from the Pump-Fee-Routing project root."
  exit 1
fi

if [ -n "$(git status --porcelain -- src/app.js src/styles.css)" ]; then
  echo "STOP: src/app.js or src/styles.css has uncommitted changes."
  git status --short -- src/app.js src/styles.css
  exit 2
fi

python3 - <<'PY'
from pathlib import Path

app_path = Path("src/app.js")
css_path = Path("src/styles.css")
app = app_path.read_text()
css = css_path.read_text()

marker = "/* docs-page-v1-reference */"
if marker in css:
    raise SystemExit("Docs page v1 is already installed.")

start = app.find("function docsPage(){")
end = app.find("function docSection(", start)
if start < 0 or end < 0:
    raise SystemExit("Could not locate docsPage()/docSection().")

replacement = r'''function docsVenueCard(name,status,chain,copy,kind=''){
  return `<div class="docs-venue ${kind}">
    <div><b>${esc(name)}</b><span>${esc(status)}</span></div>
    <small>${esc(chain)}</small>
    <p>${esc(copy)}</p>
  </div>`;
}

function docsFact(label,value){
  return `<div class="docs-fact"><span>${esc(label)}</span><b>${value}</b></div>`;
}

function docsPage(){
  const name=esc(state.brand.name);
  const recipientPct=fmtNum((state.brand.recipientShareBps||8000)/100);
  const protocolPct=fmtNum((state.brand.protocolShareBps||2000)/100);

  return `<main class="docs-page-v1">
    <article class="wrap docs-v1">
      <header class="docs-v1-hero">
        <p class="eyebrow">Docs</p>
        <h1>How ${name} works</h1>
        <p class="lead">${name} is a creator-fee routing service. A token points its creator fees at the configured treasury, the system verifies and claims eligible fees on chain, and the recipient allocation is tracked for payout.</p>
      </header>

      <nav class="docs-toc">
        <a href="#docs-1"><b>1</b>Overview</a>
        <a href="#docs-2"><b>2</b>Supported venues</a>
        <a href="#docs-3"><b>3</b>Directing fees</a>
        <a href="#docs-4"><b>4</b>Naming the recipient</a>
        <a href="#docs-5"><b>5</b>The ${recipientPct}/${protocolPct} split</a>
        <a href="#docs-6"><b>6</b>How claims work</a>
        <a href="#docs-7"><b>7</b>Getting your fees</a>
        <a href="#docs-8"><b>8</b>Payout setup</a>
        <a href="#docs-9"><b>9</b>Unclaimed payments</a>
        <a href="#docs-10"><b>10</b>Public confirmation</a>
        <a href="#docs-11"><b>11</b>Treasury and cross-chain</a>
        <a href="#docs-12"><b>12</b>$PAID and buyback</a>
        <a href="#docs-13"><b>13</b>Stopping payments</a>
        <a href="#docs-14"><b>14</b>If a token is not registering</a>
        <a href="#docs-15"><b>15</b>Glossary</a>
      </nav>

      <section class="docs-v1-section" id="docs-1">
        <h2><span>1</span>Overview</h2>
        <p>A deployer launches a token on a supported venue and permanently routes the creator-fee share to the project treasury. The token metadata identifies the X handle that should receive the recipient allocation.</p>
        <p>From there the system is mechanical: registration is discovered from public chain state, fees accrue, claims are recorded against transaction references, the recipient and protocol allocations are separated in the ledger, and completed payouts are published in the product.</p>
        <div class="docs-steps">
          <div><b>1</b><span>Token directs creator fees</span></div>
          <div><b>2</b><span>Description names a recipient</span></div>
          <div><b>3</b><span>Indexer verifies registration</span></div>
          <div><b>4</b><span>Fees are claimed and ledgered</span></div>
          <div><b>5</b><span>Recipient payout is confirmed</span></div>
        </div>
      </section>

      <section class="docs-v1-section" id="docs-2">
        <h2><span>2</span>Supported venues</h2>
        <p>The venue changes how the creator-fee destination is configured, but it does not change the accounting model after a token is registered.</p>
        <div class="docs-venue-grid">
          ${docsVenueCard('pump.fun','Live','Solana','Fee sharing is configured after token creation. The route must point entirely to the configured treasury and be made permanent.','live')}
          ${docsVenueCard('pons.family','Not live yet','Robinhood Chain','Reserved for a future launch rail. No Pons token is treated as payable until that integration is explicitly enabled.','soon')}
          ${docsVenueCard('four.meme','Exploratory','BNB Chain','Shown only as a possible future venue. It is not currently supported by this project.','future')}
        </div>
      </section>

      <section class="docs-v1-section" id="docs-3">
        <h2><span>3</span>Directing fees</h2>
        <p>For a token to become payable, the configured treasury must be the sole creator-fee shareholder at 10,000 basis points and the sharing authority must be permanent. A partial or still-editable route remains ineligible.</p>
        <div class="docs-facts">
          ${docsFact('When','After the token exists')}
          ${docsFact('What is verified','Fee-sharing config per mint')}
          ${docsFact('Required share','100%')}
          ${docsFact('Permanent','Authority revoked / locked')}
        </div>
      </section>

      <section class="docs-v1-section" id="docs-4">
        <h2><span>4</span>Naming the recipient</h2>
        <p>The most reliable way to name the beneficiary is a fixed line in the token description. It keeps the payout handle unambiguous even when the rest of the description mentions other accounts.</p>
        <pre class="docs-code">Fees to @yourhandle via ${name}</pre>
        <p>The parser may fall back to a linked or first detected handle when required, but the explicit recipient line is the preferred format.</p>
      </section>

      <section class="docs-v1-section" id="docs-5">
        <h2><span>5</span>The ${recipientPct}/${protocolPct} split</h2>
        <p>Each confirmed claim is divided at claim time. The recipient allocation and the protocol allocation become separate ledger entries tied to the same fee event.</p>
        <div class="docs-facts">
          ${docsFact('To the recipient',`${recipientPct}%`)}
          ${docsFact('Protocol cut',`${protocolPct}%`)}
          ${docsFact('Applied','Per confirmed claim')}
          ${docsFact('Extra project fee','None')}
        </div>
      </section>

      <section class="docs-v1-section" id="docs-6">
        <h2><span>6</span>How claims work</h2>
        <p>Creator fees accrue on chain and are claimed on a schedule rather than on every trade. A successful claim is keyed to its transaction reference so the same event cannot be accounted for twice.</p>
        <p>A failed chain transaction creates no recipient obligation. The fees remain on chain until a later successful claim can be verified.</p>
        <h3>Payout milestones</h3>
        <p>The current backend can evaluate cumulative payout milestones and queue the outstanding recipient balance when a threshold is crossed. Provider execution remains subject to the configured payout adapter and live-mode safeguards.</p>
      </section>

      <section class="docs-v1-section" id="docs-7">
        <h2><span>7</span>Getting your fees</h2>
        <div class="docs-steps compact">
          <div><b>1</b><span>A token names your handle</span></div>
          <div><b>2</b><span>Trading generates creator fees</span></div>
          <div><b>3</b><span>Eligible fees are claimed and credited</span></div>
          <div><b>4</b><span>A confirmed payout is recorded</span></div>
        </div>
        <p>The recipient does not need to connect a Solana wallet to be represented in the payout ledger. Receiving a payout also does not imply endorsement of the token that named the handle.</p>
      </section>

      <section class="docs-v1-section" id="docs-8">
        <h2><span>8</span>Payout setup</h2>
        <p>The product is designed around an X Money-style payout experience, while the backend uses an explicit payout adapter. Production sending requires an authorized provider configuration; the site does not manufacture or expose payment credentials.</p>
        <div class="docs-note">Current safe configuration can keep payouts in manual or read-only mode until the production rail is connected.</div>
      </section>

      <section class="docs-v1-section" id="docs-9">
        <h2><span>9</span>Unclaimed payments</h2>
        <p>Provider-returned or expired recipient payments should be recorded separately from the fixed protocol cut. That keeps reversals traceable and prevents returned recipient money from being silently blended into ordinary protocol revenue.</p>
      </section>

      <section class="docs-v1-section" id="docs-10">
        <h2><span>10</span>Public confirmation</h2>
        <p>Confirmed payouts can be displayed publicly with the amount, recipient, contributing token or tokens, status and provider reference. The public view never needs server secrets or signing material.</p>
      </section>

      <section class="docs-v1-section" id="docs-11">
        <h2><span>11</span>The treasury and cross-chain</h2>
        <p>Fees are earned on the chain where a token launched. If future venues live on other chains, any bridge belongs at the treasury layer. Recipient payouts and protocol accounting remain separate from that crossing.</p>
      </section>

      <section class="docs-v1-section" id="docs-12">
        <h2><span>12</span>$PAID and the buyback</h2>
        <p>The protocol allocation is intended to fund open-market $PAID purchases and burns after the token and production execution policy are live. Until then, the ledger records that allocation as pending buyback accounting.</p>
        <a class="docs-inline-link" href="#/paid">Read the $PAID mechanism →</a>
      </section>

      <section class="docs-v1-section" id="docs-13">
        <h2><span>13</span>Stopping payments</h2>
        <p>The project includes an X OAuth opt-out flow. Once a handle is verified and opted out, future payout eligibility can be blocked and the related token visibility/accounting rules can be applied consistently by the backend.</p>
        <a class="docs-inline-link" href="#/opt-out">Open opt-out →</a>
      </section>

      <section class="docs-v1-section" id="docs-14">
        <h2><span>14</span>If a token is not registering</h2>
        <div class="docs-checks">
          <div><b>Not the whole fee</b><span>The treasury must receive the complete creator-fee share.</span></div>
          <div><b>Not permanent yet</b><span>An editable sharing authority is not considered payable.</span></div>
          <div><b>Wrong treasury</b><span>The on-chain destination must match the configured treasury address.</span></div>
          <div><b>No recipient handle</b><span>Add the explicit recipient line or a supported linked handle.</span></div>
          <div><b>Too recent</b><span>The discovery worker may not have reached a brand-new token yet.</span></div>
        </div>
      </section>

      <section class="docs-v1-section" id="docs-15">
        <h2><span>15</span>Glossary</h2>
        <dl class="docs-glossary">
          <dt>Creator fees</dt><dd>Trading fees assigned by the launch venue to the token creator.</dd>
          <dt>Fee sharing</dt><dd>The pump.fun configuration used to direct creator fees to one or more wallets.</dd>
          <dt>Claim</dt><dd>A confirmed on-chain collection of accrued creator fees for a registered token.</dd>
          <dt>Recipient share</dt><dd>The portion of a confirmed claim credited to the named recipient.</dd>
          <dt>Protocol cut</dt><dd>The portion tracked for project execution and $PAID buyback accounting.</dd>
          <dt>Held balance</dt><dd>A recipient amount that remains in the ledger until the relevant payout condition is resolved.</dd>
          <dt>Treasury</dt><dd>The configured address to which eligible creator fees are permanently routed.</dd>
        </dl>
      </section>
    </article>

    ${moneyFooter()}
  </main>`;
}
'''

app = app[:start] + replacement + app[end:]
app_path.write_text(app)

css += r'''

/* docs-page-v1-reference */
.docs-page-v1{
  padding-top:56px;
  background:#000;
  color:#fff;
}
.docs-page-v1 .wrap{
  width:min(100% - 32px,720px);
}
.docs-v1{
  padding-bottom:16px;
}
.docs-v1-hero{
  padding:10px 0 48px;
}
.docs-v1-hero .eyebrow{
  margin:0 0 18px;
  color:#676767;
  font-size:13px;
}
.docs-v1-hero h1{
  margin:0;
  font-size:58px;
  line-height:.96;
  letter-spacing:-.055em;
  font-weight:560;
}
.docs-v1-hero .lead{
  max-width:680px;
  margin:24px 0 0;
  color:#8b8b8b;
  font-size:16px;
  line-height:1.56;
}
.docs-toc{
  display:grid;
  grid-template-columns:1fr 1fr;
  gap:0;
  margin-bottom:48px;
  border-top:1px solid #222;
  border-bottom:1px solid #222;
}
.docs-toc a{
  display:grid;
  grid-template-columns:28px 1fr;
  gap:10px;
  padding:12px 10px 12px 0;
  color:#7b7b7b;
  border-bottom:1px solid #171717;
  font-size:11px;
}
.docs-toc a:nth-last-child(-n+2){border-bottom:0}
.docs-toc b{
  color:#4f4f4f;
  font-size:9px;
}
.docs-v1-section{
  padding:38px 0;
  border-top:1px solid #202020;
}
.docs-v1-section>h2{
  display:grid;
  grid-template-columns:34px 1fr;
  gap:12px;
  align-items:start;
  margin:0 0 20px;
  font-size:29px;
  line-height:1.05;
  letter-spacing:-.035em;
  font-weight:550;
}
.docs-v1-section>h2>span{
  width:30px;
  height:30px;
  display:grid;
  place-items:center;
  border:1px solid #303030;
  border-radius:50%;
  color:#747474;
  font-size:9px;
  letter-spacing:0;
}
.docs-v1-section>p,
.docs-v1-section .docs-note{
  margin:0 0 17px;
  color:#898989;
  font-size:13px;
  line-height:1.6;
}
.docs-v1-section h3{
  margin:28px 0 11px;
  font-size:18px;
  font-weight:550;
}
.docs-steps{
  display:grid;
  gap:8px;
  margin-top:24px;
}
.docs-steps>div{
  min-height:54px;
  display:grid;
  grid-template-columns:30px 1fr;
  align-items:center;
  gap:11px;
  padding:9px 12px;
  border:1px solid #272727;
  border-radius:12px;
  background:#101010;
}
.docs-steps b{
  width:25px;
  height:25px;
  display:grid;
  place-items:center;
  border:1px solid #303030;
  border-radius:50%;
  color:#777;
  font-size:8px;
}
.docs-steps span{
  color:#d6d6d6;
  font-size:11px;
  font-weight:550;
}
.docs-venue-grid{
  display:grid;
  gap:9px;
  margin-top:24px;
}
.docs-venue{
  padding:16px;
  border:1px solid #292929;
  border-radius:14px;
  background:#101010;
}
.docs-venue>div{
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap:12px;
}
.docs-venue b{font-size:15px}
.docs-venue>div span{
  padding:5px 8px;
  border-radius:999px;
  background:#222;
  color:#898989;
  font-size:8px;
}
.docs-venue.live>div span{color:#d8d8d8}
.docs-venue small{
  display:block;
  margin-top:6px;
  color:#696969;
  font-size:9px;
}
.docs-venue p{
  margin:12px 0 0;
  color:#858585;
  font-size:11px;
  line-height:1.45;
}
.docs-facts{
  display:grid;
  grid-template-columns:1fr 1fr;
  gap:8px;
  margin-top:22px;
}
.docs-fact{
  min-height:80px;
  display:grid;
  align-content:space-between;
  gap:14px;
  padding:13px 14px;
  border:1px solid #292929;
  border-radius:12px;
  background:#101010;
}
.docs-fact span{
  color:#666;
  font-size:9px;
}
.docs-fact b{
  color:#fff;
  font-size:13px;
  font-weight:550;
}
.docs-code{
  margin:22px 0;
  padding:16px;
  overflow:auto;
  border:1px solid #292929;
  border-radius:12px;
  background:#0d0d0d;
  color:#f2f2f2;
  font-size:12px;
  white-space:pre-wrap;
}
.docs-note{
  padding:14px 16px;
  border-left:2px solid #4a4a4a;
  background:#0d0d0d;
}
.docs-inline-link{
  display:inline-block;
  margin-top:4px;
  color:#fff;
  font-size:12px;
  font-weight:600;
}
.docs-checks{
  display:grid;
  gap:0;
  border-top:1px solid #202020;
}
.docs-checks>div{
  display:grid;
  grid-template-columns:160px 1fr;
  gap:20px;
  padding:17px 0;
  border-bottom:1px solid #202020;
}
.docs-checks b{
  font-size:11px;
  font-weight:600;
}
.docs-checks span{
  color:#828282;
  font-size:11px;
  line-height:1.45;
}
.docs-glossary{
  display:grid;
  grid-template-columns:150px 1fr;
  gap:0 20px;
  margin:0;
}
.docs-glossary dt,
.docs-glossary dd{
  margin:0;
  padding:15px 0;
  border-bottom:1px solid #1d1d1d;
}
.docs-glossary dt{
  color:#d8d8d8;
  font-size:11px;
  font-weight:600;
}
.docs-glossary dd{
  color:#7f7f7f;
  font-size:11px;
  line-height:1.45;
}
.docs-page-v1 .money-footer{
  margin-top:58px;
}

@media(max-width:640px){
  .docs-page-v1{padding-top:42px}
  .docs-page-v1 .wrap{width:calc(100% - 32px)}
  .docs-v1-hero{padding:5px 0 38px}
  .docs-v1-hero .eyebrow{margin-bottom:14px;font-size:10px}
  .docs-v1-hero h1{font-size:42px}
  .docs-v1-hero .lead{margin-top:19px;font-size:12px}
  .docs-toc{
    grid-template-columns:1fr;
    margin-bottom:36px;
  }
  .docs-toc a{padding:10px 0;font-size:10px}
  .docs-toc a:nth-last-child(-n+2){border-bottom:1px solid #171717}
  .docs-toc a:last-child{border-bottom:0}
  .docs-v1-section{padding:30px 0}
  .docs-v1-section>h2{
    grid-template-columns:30px 1fr;
    gap:10px;
    margin-bottom:17px;
    font-size:22px;
  }
  .docs-v1-section>h2>span{width:27px;height:27px;font-size:8px}
  .docs-v1-section>p,
  .docs-v1-section .docs-note{font-size:10.5px;line-height:1.55}
  .docs-v1-section h3{font-size:15px}
  .docs-steps>div{min-height:48px;padding:8px 10px}
  .docs-steps span{font-size:10px}
  .docs-venue{padding:13px;border-radius:12px}
  .docs-venue b{font-size:13px}
  .docs-venue p{font-size:10px}
  .docs-facts{gap:7px;margin-top:18px}
  .docs-fact{min-height:70px;padding:11px}
  .docs-fact span{font-size:8px}
  .docs-fact b{font-size:11px}
  .docs-code{font-size:10px;padding:13px}
  .docs-checks>div{
    grid-template-columns:1fr;
    gap:6px;
    padding:14px 0;
  }
  .docs-checks b,.docs-checks span{font-size:10px}
  .docs-glossary{
    grid-template-columns:1fr;
    gap:0;
  }
  .docs-glossary dt{
    padding-bottom:5px;
    border-bottom:0;
    font-size:10px;
  }
  .docs-glossary dd{
    padding-top:0;
    font-size:10px;
  }
  .docs-page-v1 .money-footer{margin-top:46px}
}
'''
css_path.write_text(css)

print("Docs page v1 patch installed.")
PY

npm run check

git add src/app.js src/styles.css

if git diff --cached --quiet; then
  echo "No staged changes; nothing to commit."
else
  git commit -m "Rebuild Docs page from reference"
fi

git push origin main

echo
echo "DONE: Docs page v1 checked, committed, and pushed to GitHub."
echo "No server restart was performed."
echo "Restart Console/Run manually if the old Docs page is still being served."
