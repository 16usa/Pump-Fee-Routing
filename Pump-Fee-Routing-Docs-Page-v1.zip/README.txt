Pump Fee Routing — Docs Page v1
Rebuilds the Docs/How it works page as a 15-section long-form protocol guide based on the reference information architecture.
All prose is adapted for the current project's real backend semantics: Pump live, Pons/Four not live, generic/authorized payout adapter, read-only safeguards, and pending $PAID buyback accounting.
No backend, worker, Solana, database or payout execution logic is changed.
Runs npm check, commits, and pushes to origin/main. No automatic server restart.
