Top Tokens Name + Dollar Scale v24.7

Changes only the small recipient pill inside Top Tokens cards:
- increases the GG name size so it visually matches the larger chip better;
- increases the left dollar circle/mark proportionally;
- slightly increases the small avatar and chip sizing to keep everything balanced;
- keeps the avatar frame removed;
- no automatic server restart.

Install in the existing Replit Shell:

rm -rf /tmp/top_tokens_name_dollar_scale_v24_7 && mkdir -p /tmp/top_tokens_name_dollar_scale_v24_7 && unzip -o top_tokens_name_dollar_scale_v24_7.zip -d /tmp/top_tokens_name_dollar_scale_v24_7 && bash /tmp/top_tokens_name_dollar_scale_v24_7/install.sh
