Explore Cleanup Single Effect v24.46

What I checked in code:
- old Explore effect generations v24.41, v24.42, v24.43, v24.44, v24.45 are all still present in styles.css
- several of them redefine stage ::before / ::after, slot overlays, bottom shade, and right-image shading
- that makes the Explore block fragile and visually inconsistent

What this patch does:
- neutralizes all extra Explore effect layers
- restores the right image slot geometry
- hides old secondary/bottom shade layers
- leaves only ONE visual treatment:
  shared inner edge fade/blur around the preview area
- top edge is a bit stronger than before
- bottom edge is still stronger than top
- Explore / Open remain crisp above the effect

Install from your existing Replit project root:
rm -rf /tmp/explore_cleanup_single_effect_v24_46 && mkdir -p /tmp/explore_cleanup_single_effect_v24_46 && unzip -o explore_cleanup_single_effect_v24_46.zip -d /tmp/explore_cleanup_single_effect_v24_46 && bash /tmp/explore_cleanup_single_effect_v24_46/install.sh
