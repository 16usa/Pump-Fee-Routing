from pathlib import Path

css_path = Path('src/styles.css')
if not css_path.exists():
    raise SystemExit('ERROR: src/styles.css not found. Run this from the existing Replit project root.')

css = css_path.read_text()
marker = '/* explore-cleanup-single-effect-v24-46 */'
required = [
    '.home-explore-reference-v8',
    '.home-explore-v8-stage',
    '.home-explore-v8-primary-slot',
    '.home-explore-v8-secondary-slot',
    '.home-explore-v8-footer'
]
missing = [s for s in required if s not in css]
if missing:
    raise SystemExit('ERROR: required Explore selectors not found: ' + ', '.join(missing))

if marker in css:
    print('No changes needed; v24.46 already installed.')
    raise SystemExit(0)

css += r'''

/* explore-cleanup-single-effect-v24-46
   Cleanup all accumulated Explore visual effects and leave only ONE effect:
   a single shared inner edge fade/blur around the whole preview stage.
   - top edge is slightly stronger than before, but still weaker than bottom
   - bottom edge is the strongest
   - no extra per-slot shades / old blurs / duplicate overlays
   - Explore / Open remain crisp above the effect */

/* --- Restore stable stage geometry --- */
.home-explore-reference-v8 .home-explore-v8-stage{
  position:absolute !important;
  inset:0 !important;
  overflow:hidden !important;
  isolation:isolate !important;
}

.home-explore-reference-v8 .home-explore-v8-primary-slot,
.home-explore-reference-v8 .home-explore-v8-secondary-slot{
  visibility:visible !important;
  opacity:1 !important;
}

/* --- Remove every old extra effect from earlier patches --- */
.home-explore-reference-v8 .home-explore-v8-primary-slot::before,
.home-explore-reference-v8 .home-explore-v8-primary-slot::after,
.home-explore-reference-v8 .home-explore-v8-secondary-slot::before,
.home-explore-reference-v8 .home-explore-v8-secondary-slot::after{
  content:none !important;
  display:none !important;
  background:none !important;
  -webkit-backdrop-filter:none !important;
  backdrop-filter:none !important;
  -webkit-mask-image:none !important;
  mask-image:none !important;
  box-shadow:none !important;
}

.home-explore-reference-v8 .home-explore-v8-secondary-shade,
.home-explore-reference-v8 .home-explore-v8-bottom-shade{
  display:none !important;
  opacity:0 !important;
  background:none !important;
}

/* Restore the right image so earlier generic child rules cannot collapse it. */
.home-explore-reference-v8 .home-explore-v8-secondary-slot{
  display:block !important;
  overflow:visible !important;
  z-index:3 !important;
}

.home-explore-reference-v8 .home-explore-v8-secondary-slot > .home-explore-v8-secondary-card{
  position:absolute !important;
  inset:0 !important;
  width:100% !important;
  height:100% !important;
  min-width:0 !important;
  min-height:0 !important;
  display:block !important;
  visibility:visible !important;
  opacity:1 !important;
  overflow:hidden !important;
  z-index:3 !important;
}

.home-explore-reference-v8 .home-explore-v8-secondary-slot > .home-explore-v8-secondary-card > .home-explore-v8-media,
.home-explore-reference-v8 .home-explore-v8-secondary-slot .home-explore-v8-art.secondary{
  position:absolute !important;
  inset:0 !important;
  width:100% !important;
  height:100% !important;
  display:block !important;
  visibility:visible !important;
  opacity:1 !important;
}

.home-explore-reference-v8 .home-explore-v8-secondary-slot .home-explore-v8-art.secondary{
  object-fit:cover !important;
  object-position:52% center !important;
  z-index:1 !important;
  filter:grayscale(1) saturate(.18) contrast(1.06) brightness(.68) !important;
  transform:scale(1.05) !important;
}

/* --- THE ONLY visual effect we keep: one shared edge fade / blur around the stage --- */
/* Main all-around inner edge fade. Slightly stronger at the top than before,
   but still softer than the bottom. The center stays clear. */
.home-explore-reference-v8 .home-explore-v8-stage::before{
  content:"" !important;
  display:block !important;
  position:absolute !important;
  inset:0 !important;
  z-index:8 !important;
  pointer-events:none !important;
  background:
    radial-gradient(
      ellipse 77% 69% at 50% 46%,
      rgba(10,10,10,0) 0%,
      rgba(10,10,10,0) 50%,
      rgba(10,10,10,.08) 64%,
      rgba(10,10,10,.20) 78%,
      rgba(10,10,10,.36) 90%,
      rgba(10,10,10,.52) 100%
    ),
    linear-gradient(
      to bottom,
      rgba(10,10,10,.34) 0%,
      rgba(10,10,10,.20) 10%,
      rgba(10,10,10,.08) 19%,
      rgba(10,10,10,0) 30%
    ),
    linear-gradient(
      to right,
      rgba(10,10,10,.16) 0%,
      rgba(10,10,10,.06) 10%,
      rgba(10,10,10,0) 19%
    ),
    linear-gradient(
      to left,
      rgba(10,10,10,.16) 0%,
      rgba(10,10,10,.06) 10%,
      rgba(10,10,10,0) 19%
    ) !important;
  -webkit-backdrop-filter:blur(7px) saturate(.96) !important;
  backdrop-filter:blur(7px) saturate(.96) !important;
  -webkit-mask-image:radial-gradient(
    ellipse 77% 69% at 50% 46%,
    transparent 0%,
    transparent 49%,
    rgba(0,0,0,.18) 63%,
    rgba(0,0,0,.46) 78%,
    rgba(0,0,0,.78) 90%,
    #000 100%
  ) !important;
  mask-image:radial-gradient(
    ellipse 77% 69% at 50% 46%,
    transparent 0%,
    transparent 49%,
    rgba(0,0,0,.18) 63%,
    rgba(0,0,0,.46) 78%,
    rgba(0,0,0,.78) 90%,
    #000 100%
  ) !important;
  -webkit-mask-repeat:no-repeat !important;
  mask-repeat:no-repeat !important;
  -webkit-mask-size:100% 100% !important;
  mask-size:100% 100% !important;
}

/* Bottom reinforcement: same single effect, only stronger at the bottom. */
.home-explore-reference-v8 .home-explore-v8-stage::after{
  content:"" !important;
  display:block !important;
  position:absolute !important;
  left:0 !important;
  right:0 !important;
  bottom:0 !important;
  top:auto !important;
  height:39% !important;
  z-index:9 !important;
  pointer-events:none !important;
  background:linear-gradient(
    to top,
    rgba(10,10,10,.82) 0%,
    rgba(10,10,10,.58) 24%,
    rgba(10,10,10,.30) 52%,
    rgba(10,10,10,.11) 74%,
    rgba(10,10,10,0) 100%
  ) !important;
  -webkit-backdrop-filter:blur(11px) saturate(.94) !important;
  backdrop-filter:blur(11px) saturate(.94) !important;
  -webkit-mask-image:linear-gradient(
    to top,
    #000 0%,
    rgba(0,0,0,.96) 22%,
    rgba(0,0,0,.72) 52%,
    rgba(0,0,0,.30) 79%,
    transparent 100%
  ) !important;
  mask-image:linear-gradient(
    to top,
    #000 0%,
    rgba(0,0,0,.96) 22%,
    rgba(0,0,0,.72) 52%,
    rgba(0,0,0,.30) 79%,
    transparent 100%
  ) !important;
}

/* Footer above all effects and never blurred. */
.home-explore-reference-v8 .home-explore-v8-footer{
  position:absolute !important;
  left:18px !important;
  right:18px !important;
  bottom:14px !important;
  z-index:20 !important;
  display:flex !important;
  align-items:center !important;
  justify-content:space-between !important;
  visibility:visible !important;
  opacity:1 !important;
  -webkit-filter:none !important;
  filter:none !important;
}

.home-explore-reference-v8 .home-explore-v8-footer strong,
.home-explore-reference-v8 .home-explore-v8-footer span{
  position:relative !important;
  z-index:21 !important;
  visibility:visible !important;
  opacity:1 !important;
  -webkit-filter:none !important;
  filter:none !important;
}

@media(max-width:640px){
  .home-explore-reference-v8 .home-explore-v8-stage::before{
    background:
      radial-gradient(
        ellipse 81% 71% at 50% 44%,
        rgba(10,10,10,0) 0%,
        rgba(10,10,10,0) 49%,
        rgba(10,10,10,.08) 63%,
        rgba(10,10,10,.22) 78%,
        rgba(10,10,10,.38) 90%,
        rgba(10,10,10,.54) 100%
      ),
      linear-gradient(
        to bottom,
        rgba(10,10,10,.36) 0%,
        rgba(10,10,10,.22) 11%,
        rgba(10,10,10,.08) 20%,
        rgba(10,10,10,0) 31%
      ),
      linear-gradient(to right, rgba(10,10,10,.16) 0%, rgba(10,10,10,.06) 11%, rgba(10,10,10,0) 20%),
      linear-gradient(to left, rgba(10,10,10,.16) 0%, rgba(10,10,10,.06) 11%, rgba(10,10,10,0) 20%) !important;
  }

  .home-explore-reference-v8 .home-explore-v8-stage::after{
    height:41% !important;
    background:linear-gradient(
      to top,
      rgba(10,10,10,.84) 0%,
      rgba(10,10,10,.60) 25%,
      rgba(10,10,10,.31) 53%,
      rgba(10,10,10,.11) 75%,
      rgba(10,10,10,0) 100%
    ) !important;
  }

  .home-explore-reference-v8 .home-explore-v8-footer{
    left:14px !important;
    right:14px !important;
    bottom:11px !important;
  }
}
'''

css_path.write_text(css)
print('PASS: cleaned up all old Explore effect layers.')
print('PASS: only one shared stage edge fade/blur remains.')
print('PASS: top edge slightly stronger; bottom edge strongest.')
print('PASS: right image restored and footer kept crisp.')
