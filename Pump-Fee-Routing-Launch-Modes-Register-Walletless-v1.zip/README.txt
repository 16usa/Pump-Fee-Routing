Pump Fee Routing — Launch Modes Register + Walletless v1

Enables the three Launch page mode tabs:
- Launch
- Register
- Walletless

Register mode mirrors the reference information structure:
- X recipient field
- Payment note
- Contract address
- Pump fee-sharing instructions/address
- Check status
- Choose who gets paid
- Payment demo + token preview

Walletless mode mirrors the reference information structure:
1. Put recipient @handle in description
2. Set up 100% Pump fee sharing to the configured treasury
3. Payouts start automatically
- Payment demo
- Launch on Pump / Share creator rewards guidance card

The existing Launch form, token image flow, X lookup, animated payment demo logic,
and token preview logic are preserved.

Installer validates, commits, and pushes origin/main.
No automatic server restart.
