from pathlib import Path

path = Path('src/styles.css')
if not path.exists():
    raise SystemExit('ERROR: src/styles.css not found')

css = path.read_text()

old_desktop = '''.home-top-token-pager button,
.home-top-profiles-pager button,
.home-recent-payments-pager button,
.home-most-payments-pager button,
.home-off-pager button,
.home-on-pager button{
  font-size:11px !important;
  line-height:1 !important;
}'''

new_desktop = '''.home-top-token-pager button,
.home-top-profiles-pager button,
.home-recent-payments-pager button,
.home-most-payments-pager button,
.home-off-pager button,
.home-on-pager button{
  font-size:21px !important;
  line-height:1 !important;
}'''

old_mobile = '''.home-top-token-pager button,
  .home-top-profiles-pager button,
  .home-recent-payments-pager button,
  .home-most-payments-pager button,
  .home-off-pager button,
  .home-on-pager button{
    font-size:9px !important;
    line-height:1 !important;
  }'''

new_mobile = '''.home-top-token-pager button,
  .home-top-profiles-pager button,
  .home-recent-payments-pager button,
  .home-most-payments-pager button,
  .home-off-pager button,
  .home-on-pager button{
    font-size:17px !important;
    line-height:1 !important;
  }'''

if old_desktop not in css:
    raise SystemExit('ERROR: v24.16 desktop pager button block not found')
if old_mobile not in css:
    raise SystemExit('ERROR: v24.16 mobile pager button block not found')

css = css.replace(old_desktop, new_desktop, 1)
css = css.replace(old_mobile, new_mobile, 1)

marker = '/* home-pager-arrow-scale-fix-v24-17 */'
if marker not in css:
    css += '''

/* home-pager-arrow-scale-fix-v24-17
   Keep page number = FEES ROUTE TO size.
   Arrows preserve the old visual proportion to the number. */
.home-top-token-pager,
.home-top-profiles-pager,
.home-recent-payments-pager,
.home-most-payments-pager,
.home-off-pager,
.home-on-pager{
  font-size:11px !important;
}

.home-top-token-pager button,
.home-top-profiles-pager button,
.home-recent-payments-pager button,
.home-most-payments-pager button,
.home-off-pager button,
.home-on-pager button{
  font-size:21px !important;
  line-height:1 !important;
}

@media(max-width:640px){
  .home-top-token-pager,
  .home-top-profiles-pager,
  .home-recent-payments-pager,
  .home-most-payments-pager,
  .home-off-pager,
  .home-on-pager{
    font-size:9px !important;
  }

  .home-top-token-pager button,
  .home-top-profiles-pager button,
  .home-recent-payments-pager button,
  .home-most-payments-pager button,
  .home-off-pager button,
  .home-on-pager button{
    font-size:17px !important;
    line-height:1 !important;
  }
}
'''

path.write_text(css)
print('PASS: pager arrows now scale proportionally with the enlarged page number')
