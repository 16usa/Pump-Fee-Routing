Home Pager Arrow Scale Fix v24.17

Conflict found:
v24.16 correctly increased the page number from 8px to 9px on mobile,
but it also forced the arrow buttons down from their old 15px size to 9px.
That is why the arrows visually became smaller.

This patch keeps:
- page number: 11px desktop / 9px mobile
- arrows: 21px desktop / 17px mobile

So the arrows grow proportionally with the page number instead of shrinking.

Applies to:
- Top Tokens
- Top X Profiles
- Recent Payments
- Most Payments
- Off Ramp
- On Ramp

No automatic server restart.

Install in existing Replit Shell:

rm -rf /tmp/home_pager_arrow_scale_fix_v24_17 && mkdir -p /tmp/home_pager_arrow_scale_fix_v24_17 && unzip -o home_pager_arrow_scale_fix_v24_17.zip -d /tmp/home_pager_arrow_scale_fix_v24_17 && bash /tmp/home_pager_arrow_scale_fix_v24_17/install.sh
