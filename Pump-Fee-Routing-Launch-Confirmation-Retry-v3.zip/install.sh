#!/usr/bin/env bash
set -euo pipefail

[ -f src/app.js ] || {
  echo "Missing src/app.js. Run this from the Pump-Fee-Routing project root."
  exit 1
}

cp src/app.js /tmp/Pump-Fee-Routing-app-before-confirmation-retry-v3.js

python3 - <<'PY'
from pathlib import Path

p=Path("src/app.js")
s=p.read_text()

marker="launch-confirmation-retry-v3"
if marker in s:
    print("Launch Confirmation Retry v3 is already installed.")
    raise SystemExit(0)

# Replace the two launch transaction functions as one stable section.
fn_start=s.find("async function launchTokenOnPump(){")
fn_end=s.find("\napp.addEventListener('click',async e=>{", fn_start)
if fn_start < 0 or fn_end < 0:
    raise SystemExit("Could not locate launchTokenOnPump()/routeFees() section.")

replacement_functions="function isLaunchConfirmationPendingError(err){\n  return /transaction is not confirmed yet|mint account is not visible on-chain/i.test(String(err?.message||''));\n}\n\nasync function confirmCreatedLaunch(attempts=2){\n  if(!currentLaunch?.id||!currentLaunch?.mint||!currentLaunch?.createSignature)throw new Error('Pending token transaction is incomplete');\n  let lastError=null;\n  for(let attempt=1;attempt<=attempts;attempt++){\n    setLaunchStatus(`Token submitted: ${currentLaunch.mint.slice(0,6)}…${currentLaunch.mint.slice(-6)}. Waiting for confirmation${attempt>1?' (retry)':''}…`);\n    try{\n      const out=await api('/api/launch/created',{\n        method:'POST',\n        body:JSON.stringify({\n          intent_id:currentLaunch.id,\n          mint:currentLaunch.mint,\n          creator_pubkey:currentLaunch.creatorPubkey,\n          tx_signature:currentLaunch.createSignature\n        })\n      });\n      currentLaunch={...currentLaunch,createConfirmed:true,createPending:false};\n      return out;\n    }catch(err){\n      lastError=err;\n      if(!isLaunchConfirmationPendingError(err))throw err;\n      if(attempt<attempts)await new Promise(r=>setTimeout(r,1800));\n    }\n  }\n  currentLaunch={...currentLaunch,createPending:true};\n  return {ok:false,pending:true,reason:lastError?.message||'Transaction confirmation is still pending'};\n}\n\nasync function confirmRoutingLaunch(attempts=2){\n  if(!currentLaunch?.id||!currentLaunch?.mint||!currentLaunch?.routingSignature)throw new Error('Pending fee-routing transaction is incomplete');\n  let lastError=null;\n  for(let attempt=1;attempt<=attempts;attempt++){\n    setLaunchStatus(`Fee routing submitted. Waiting for confirmation${attempt>1?' (retry)':''}…`);\n    try{\n      const out=await api('/api/launch/confirm',{\n        method:'POST',\n        body:JSON.stringify({\n          intent_id:currentLaunch.id,\n          mint:currentLaunch.mint,\n          recipient_handle:currentLaunch.handle,\n          tx_signature:currentLaunch.routingSignature\n        })\n      });\n      if(out.ok)currentLaunch={...currentLaunch,routingConfirmed:true,routingPending:false};\n      return out;\n    }catch(err){\n      lastError=err;\n      if(!isLaunchConfirmationPendingError(err))throw err;\n      if(attempt<attempts)await new Promise(r=>setTimeout(r,1800));\n    }\n  }\n  currentLaunch={...currentLaunch,routingPending:true};\n  return {ok:false,pending:true,reason:lastError?.message||'Fee-routing confirmation is still pending'};\n}\n\nasync function finishCurrentLaunch(){\n  if(!currentLaunch?.mint||!currentLaunch?.createSignature)throw new Error('No submitted token transaction to finish');\n  const button=document.querySelector('#launchSubmitButton');\n\n  if(!currentLaunch.createConfirmed){\n    const created=await confirmCreatedLaunch();\n    if(created?.pending){\n      if(button){button.disabled=false;button.textContent='Retry confirmation';}\n      setLaunchStatus('Token transaction was submitted, but confirmation is still pending. Tap Retry confirmation — do not launch a second token.');\n      return created;\n    }\n  }\n\n  setLaunchStatus('Token confirmed. One more wallet approval will permanently route 100% of creator fees to the treasury.');\n  const routed=await routeFees();\n\n  if(routed?.pending){\n    if(button){button.disabled=false;button.textContent='Retry confirmation';}\n    setLaunchStatus('Fee-routing transaction was submitted, but confirmation is still pending. Tap Retry confirmation — it will check the same transaction.');\n    return routed;\n  }\n\n  if(routed?.ok){\n    if(button){button.disabled=true;button.textContent='Launched';}\n    const symbol=String(currentLaunch.symbol||document.querySelector('#launchTicker')?.value||'TOKEN').trim().toUpperCase();\n    setLaunchStatus(`Launch complete. ${symbol} is registered and live in Explore.`,true);\n    setTimeout(()=>{location.hash=`#/token/${encodeURIComponent(currentLaunch.mint)}`;},900);\n  }\n  return routed;\n}\n\nasync function launchTokenOnPump(){\n  if(!currentLaunch)throw new Error('Create the launch intent first');\n\n  if(currentLaunch?.mint&&currentLaunch?.createSignature)return finishCurrentLaunch();\n\n  if(!window.solanaWeb3?.VersionedTransaction||!window.solanaWeb3?.Keypair)throw new Error('Solana web3 browser bundle did not load');\n\n  let creator=currentLaunch?.creatorPubkey||currentWallet?.publicKey?.toString?.()||'';\n  if(!creator)creator=await connectWallet();\n\n  const name=document.querySelector('#launchName')?.value.trim()||'';\n  const symbol=document.querySelector('#launchTicker')?.value.trim().toUpperCase()||'';\n  const description=document.querySelector('#launchDescription')?.value.trim()||'';\n  const website=document.querySelector('#launchWebsite')?.value.trim()||'';\n  const twitter=document.querySelector('#launchX')?.value.trim()||'';\n  const telegram=document.querySelector('#launchTelegram')?.value.trim()||'';\n  const file=document.querySelector('#launchImage')?.files?.[0];\n\n  if(!name)throw new Error('Enter the token name');\n  if(!symbol)throw new Error('Enter the ticker');\n  if(name.length>32)throw new Error('Token name must be 32 characters or fewer');\n  if(symbol.length>13)throw new Error('Ticker must be 13 characters or fewer');\n\n  const devBuySol=Number(document.querySelector('#launchDevBuy')?.value||0);\n  if(!Number.isFinite(devBuySol)||devBuySol<0)throw new Error('Dev Buy must be a valid SOL amount');\n  const solLamports=Math.round(devBuySol*1_000_000_000);\n  if(!Number.isSafeInteger(solLamports))throw new Error('Dev Buy amount is too large');\n\n  setLaunchStatus('Uploading token metadata to IPFS…');\n  const imageBase64=await launchImageBase64(file);\n  const metadata=await api('/api/launch/metadata',{\n    method:'POST',\n    body:JSON.stringify({\n      intent_id:currentLaunch.id,\n      name,\n      symbol,\n      description,\n      website,\n      twitter,\n      telegram,\n      image_base64:imageBase64,\n      image_type:file.type,\n      image_name:file.name\n    })\n  });\n\n  let mintKeypair=null;\n  let mintPubkey='';\n  if(solLamports===0){\n    mintKeypair=window.solanaWeb3.Keypair.generate();\n    mintPubkey=mintKeypair.publicKey.toBase58();\n  }\n\n  setLaunchStatus(solLamports>0\n    ? `Building Pump launch + ${devBuySol} SOL initial buy…`\n    : 'Building Pump launch transaction…');\n\n  const built=await api('/api/launch/prepare-create',{\n    method:'POST',\n    body:JSON.stringify({\n      intent_id:currentLaunch.id,\n      user_pubkey:creator,\n      mint_pubkey:mintPubkey,\n      name,\n      symbol,\n      metadata_uri:metadata.metadataUri,\n      sol_lamports:String(solLamports)\n    })\n  });\n\n  const bytes=Uint8Array.from(atob(built.transactionBase64),c=>c.charCodeAt(0));\n  const tx=window.solanaWeb3.VersionedTransaction.deserialize(bytes);\n  if(built.requiresMintSignature){\n    if(!mintKeypair)throw new Error('Mint signer was not generated');\n    tx.sign([mintKeypair]);\n  }\n\n  setLaunchStatus(solLamports>0\n    ? `Approve token creation and ${devBuySol} SOL initial buy in your wallet…`\n    : 'Approve token creation in your wallet…');\n\n  let sig;\n  if(currentWallet.signAndSendTransaction){\n    const out=await currentWallet.signAndSendTransaction(tx);\n    sig=out.signature||out;\n  }else{\n    const signed=await currentWallet.signTransaction(tx);\n    sig=await currentWallet.sendTransaction(signed);\n  }\n\n  const mint=built.mint;\n  currentLaunch={\n    ...currentLaunch,\n    mint,\n    symbol,\n    creatorPubkey:creator,\n    createSignature:String(sig),\n    metadataUri:metadata.metadataUri,\n    createConfirmed:false,\n    createPending:true\n  };\n\n  return finishCurrentLaunch();\n}\n\nasync function routeFees(){\n  if(!currentLaunch)throw new Error('Create the launch intent first');\n  const mint=String(currentLaunch.mint||'').trim();\n  let creator=String(currentLaunch.creatorPubkey||currentWallet?.publicKey?.toString?.()||'').trim();\n\n  if(!creator)creator=await connectWallet();\n  if(!mint)throw new Error('Token mint is not available yet');\n  if(!currentWallet)await connectWallet();\n\n  if(currentLaunch.routingSignature)return confirmRoutingLaunch();\n\n  setLaunchStatus('Building fee-sharing transaction…');\n  const p=await api('/api/launch/prepare-routing',{\n    method:'POST',\n    body:JSON.stringify({intent_id:currentLaunch.id,mint,creator_pubkey:creator})\n  });\n\n  if(!window.solanaWeb3?.VersionedTransaction)throw new Error('Solana web3 browser bundle did not load');\n  const bytes=Uint8Array.from(atob(p.transactionBase64),c=>c.charCodeAt(0));\n  const tx=window.solanaWeb3.VersionedTransaction.deserialize(bytes);\n\n  setLaunchStatus('Approve the transaction in your wallet…');\n  let sig;\n  if(currentWallet.signAndSendTransaction){\n    const out=await currentWallet.signAndSendTransaction(tx);\n    sig=out.signature||out;\n  }else{\n    const signed=await currentWallet.signTransaction(tx);\n    sig=await currentWallet.sendTransaction(signed);\n  }\n\n  currentLaunch={...currentLaunch,routingSignature:String(sig),routingPending:true};\n  return confirmRoutingLaunch();\n}\n"
s=s[:fn_start]+replacement_functions+s[fn_end:]

# Replace the entire Launch form submit handler, avoiding fragile inner-text anchors.
submit_start=s.find("app.addEventListener('submit',async e=>{if(e.target.id==='launchForm')")
submit_end=s.find("\nwindow.addEventListener('hashchange',render);render();", submit_start)
if submit_start < 0 or submit_end < 0:
    raise SystemExit("Could not locate the complete Launch form submit handler.")

replacement_submit="app.addEventListener('submit',async e=>{if(e.target.id==='launchForm'){e.preventDefault();const button=document.querySelector('#launchSubmitButton');try{\n  if(!currentWallet){\n    if(button){button.disabled=true;button.textContent='Connecting wallet…';}\n    const creator=await connectWallet();\n    currentLaunch=null;\n    if(!creator){\n      if(button){button.disabled=false;button.textContent='Connect wallet';}\n      setLaunchStatus('');\n      return;\n    }\n    if(button){button.disabled=false;button.textContent='Launch token';}\n    setLaunchStatus(`Wallet connected: ${creator}`,true);\n    return;\n  }\n\n  if(currentLaunch?.mint&&currentLaunch?.createSignature){\n    if(button){button.disabled=true;button.textContent='Checking confirmation…';}\n    const resumed=await finishCurrentLaunch();\n    if(resumed?.pending&&button){button.disabled=false;button.textContent='Retry confirmation';}\n    return;\n  }\n\n  const handle=document.querySelector('#launchHandle').value.trim();\n  const creator=currentWallet.publicKey?.toString?.()||await connectWallet();\n  if(button){button.disabled=true;button.textContent='Preparing launch…';}\n\n  const out=await api('/api/launch/intents',{\n    method:'POST',\n    body:JSON.stringify({recipient_handle:handle,creator_pubkey:creator,mint:null})\n  });\n  currentLaunch={...out,handle:handle.replace(/^@/,''),creatorPubkey:creator};\n\n  if(!out.treasuryAddress)throw new Error('Set TREASURY_ADDRESS on the server before launching');\n\n  setLaunchStatus('Launch intent created. Preparing token transaction…');\n  if(button)button.textContent='Launching…';\n  const routed=await launchTokenOnPump();\n  if(!routed?.ok&&!routed?.pending&&button){button.disabled=false;button.textContent='Launch token';}\n}catch(err){\n  if(button){\n    button.disabled=false;\n    button.textContent=(currentLaunch?.mint&&currentLaunch?.createSignature)?'Retry confirmation':(currentWallet?'Launch token':'Connect wallet');\n  }\n  setLaunchStatus(err.message);\n}}});\n"
s=s[:submit_start]+replacement_submit+s[submit_end:]

s += "\n/* "+marker+" */\n"
p.write_text(s)
print("Launch Confirmation Retry v3 installed.")
PY

if ! node --check src/app.js; then
  cp /tmp/Pump-Fee-Routing-app-before-confirmation-retry-v3.js src/app.js
  echo "JS syntax check failed; src/app.js restored."
  exit 2
fi

if ! npm run check; then
  cp /tmp/Pump-Fee-Routing-app-before-confirmation-retry-v3.js src/app.js
  echo "Project check failed; src/app.js restored."
  exit 3
fi

node <<'NODE'
const fs=require('fs');
const s=fs.readFileSync('src/app.js','utf8');
const checks=[
  ['patch marker',s.includes('launch-confirmation-retry-v3')],
  ['create retry helper',s.includes('async function confirmCreatedLaunch(attempts=2)')],
  ['routing retry helper',s.includes('async function confirmRoutingLaunch(attempts=2)')],
  ['same submitted launch resumed',s.includes("currentLaunch?.mint&&currentLaunch?.createSignature")],
  ['retry confirmation button',s.includes("button.textContent='Retry confirmation'")],
  ['same routing signature reused',s.includes('if(currentLaunch.routingSignature)return confirmRoutingLaunch()')],
  ['wallet loading fix preserved',s.includes('launch-mobile-wallet-loading-hotfix-v1')],
  ['wallet click fix preserved',s.includes('launch-wallet-picker-click-fix-v1')]
];
let bad=0;
for(const [name,ok] of checks){
  console.log((ok?'PASS':'FAIL')+' '+name);
  if(!ok)bad++;
}
if(bad)process.exit(1);
NODE

git add src/app.js
if git diff --cached --quiet; then
  echo "No new changes to commit."
else
  git commit -m "Retry submitted launch confirmations safely"
  git push origin main
fi

echo
echo "DONE: Launch Confirmation Retry v3 installed, checked, committed, and pushed."
echo "No server restart was performed."
echo "Restart Console/Run manually once."
