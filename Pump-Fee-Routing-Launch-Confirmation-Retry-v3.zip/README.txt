Pump-Fee-Routing — Launch Confirmation Retry v3

v2 failed before modifying src/app.js because its installer still depended on a fragile
exact match inside the Launch form catch block.

v3 replaces:
1) the complete launchTokenOnPump()/routeFees() section by stable function boundaries;
2) the complete launch form submit handler by stable outer boundaries.

It then:
- checks JavaScript syntax;
- runs npm run check;
- restores src/app.js automatically if validation fails;
- commits and pushes main;
- never restarts the server.

Behavior:
- after a token transaction is signed, a delayed RPC confirmation re-checks the same signature;
- the UI shows Retry confirmation instead of creating another token;
- the fee-routing transaction has the same protection.
