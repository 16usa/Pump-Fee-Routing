#!/usr/bin/env bash
set -euo pipefail

[ -f src/styles.css ] || { echo "Missing src/styles.css. Run from the Pump-Fee-Routing project root."; exit 1; }

# Protect only the file this patch edits. Old ZIPs and .conversation are ignored.
if [ -n "$(git status --porcelain -- src/styles.css)" ]; then
  echo "STOP: src/styles.css has uncommitted changes."
  git status --short -- src/styles.css
  exit 2
fi

staged_unrelated="$(git diff --cached --name-only | grep -vE '^src/styles\.css$' || true)"
if [ -n "$staged_unrelated" ]; then
  echo "STOP: unrelated staged files are present:"
  echo "$staged_unrelated"
  exit 3
fi

python3 - <<'PY'

from pathlib import Path
import base64

p=Path('src/styles.css')
css=p.read_text()

marker='/* launch-terms-checkbox-v1'
if marker in css:
    raise SystemExit('Launch Terms Checkbox v1 is already installed.')

css += base64.b64decode('Ci8qIGxhdW5jaC10ZXJtcy1jaGVja2JveC12MSDigJQgY29tcGFjdCBVc2VQYWlkLXN0eWxlIGNoZWNrYm94ICovCi5sYXVuY2gtdGVybXMgaW5wdXRbdHlwZT0iY2hlY2tib3giXXsKICAtd2Via2l0LWFwcGVhcmFuY2U6bm9uZTsKICBhcHBlYXJhbmNlOm5vbmU7CiAgYm94LXNpemluZzpib3JkZXItYm94OwogIHdpZHRoOjE4cHg7CiAgaGVpZ2h0OjE4cHg7CiAgbWluLXdpZHRoOjE4cHg7CiAgbWFyZ2luOjA7CiAgYm9yZGVyOjFweCBzb2xpZCAjZjJmMmYyOwogIGJvcmRlci1yYWRpdXM6NXB4OwogIGJhY2tncm91bmQ6I2Y3ZjdmNzsKICBkaXNwbGF5OmdyaWQ7CiAgcGxhY2UtaXRlbXM6Y2VudGVyOwogIGN1cnNvcjpwb2ludGVyOwogIGJveC1zaGFkb3c6bm9uZTsKICBvdXRsaW5lOm5vbmU7Cn0KLmxhdW5jaC10ZXJtcyBpbnB1dFt0eXBlPSJjaGVja2JveCJdOjphZnRlcnsKICBjb250ZW50OiIiOwogIHdpZHRoOjVweDsKICBoZWlnaHQ6OXB4OwogIGJvcmRlcjpzb2xpZCAjMTExOwogIGJvcmRlci13aWR0aDowIDJweCAycHggMDsKICB0cmFuc2Zvcm06cm90YXRlKDQ1ZGVnKSBzY2FsZSgwKTsKICB0cmFuc2Zvcm0tb3JpZ2luOmNlbnRlcjsKfQoubGF1bmNoLXRlcm1zIGlucHV0W3R5cGU9ImNoZWNrYm94Il06Y2hlY2tlZDo6YWZ0ZXJ7CiAgdHJhbnNmb3JtOnJvdGF0ZSg0NWRlZykgc2NhbGUoMSk7Cn0KLmxhdW5jaC10ZXJtcyBpbnB1dFt0eXBlPSJjaGVja2JveCJdOmZvY3VzLXZpc2libGV7CiAgb3V0bGluZToxcHggc29saWQgIzc3NzsKICBvdXRsaW5lLW9mZnNldDozcHg7Cn0K').decode()
p.write_text(css)
print('Launch Terms Checkbox v1 installed.')

PY

npm run check

node <<'NODE'
const fs=require('fs');
const css=fs.readFileSync('src/styles.css','utf8');
const checks=[
  ['native blue checkbox disabled', css.includes('-webkit-appearance:none') && css.includes('appearance:none')],
  ['compact 18px size', css.includes('width:18px') && css.includes('height:18px')],
  ['white checkbox', css.includes('background:#f7f7f7')],
  ['rounded corners', css.includes('border-radius:5px')],
  ['custom dark check mark', css.includes('border:solid #111')],
  ['checked state', css.includes('input[type="checkbox"]:checked::after')],
];
let bad=0;
for(const [name,ok] of checks){
  console.log(`${ok?'PASS':'FAIL'} ${name}`);
  if(!ok) bad++;
}
if(bad) process.exit(1);
NODE

git add src/styles.css

if git diff --cached --quiet; then
  echo "No staged changes; nothing to commit."
else
  git commit -m "Polish Launch terms checkbox"
fi

git push origin main

echo
echo "DONE: Launch Terms Checkbox v1 checked, committed, and pushed to GitHub."
echo "Old ZIP files and .conversation entries were intentionally ignored."
echo "No server restart was performed."
echo "Restart Console/Run manually once to load the updated checkbox."
