Pump Fee Routing — Launch Terms Checkbox v1

Replaces the native blue iOS checkbox on the Launch Terms row with a compact white rounded checkbox like the reference.
Unchecked: white rounded square.
Checked: white rounded square with a dark check mark.
No other Launch layout or behavior is changed.

Installer checks src/styles.css, runs project checks, commits, and pushes origin/main.
No automatic server restart.
