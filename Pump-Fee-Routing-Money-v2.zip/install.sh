#!/usr/bin/env bash
set -euo pipefail

if [ ! -f src/app.js ] || [ ! -f src/styles.css ]; then
  echo "Run this from the Pump-Fee-Routing project root."
  exit 1
fi

if [ -n "$(git status --porcelain -- src/app.js src/styles.css)" ]; then
  echo "STOP: src/app.js or src/styles.css has uncommitted changes."
  git status --short -- src/app.js src/styles.css
  exit 2
fi

python3 - <<'PY'
from pathlib import Path

app_path = Path("src/app.js")
css_path = Path("src/styles.css")
app = app_path.read_text()
css = css_path.read_text()

marker = "/* money-v2-reference */"
if marker in css:
    raise SystemExit("Money v2 is already installed.")

sections_start = app.find("function moneySections(money){")
sections_end = app.find("function homeHeroCard(", sections_start)
if sections_start < 0 or sections_end < 0:
    raise SystemExit("Could not locate moneySections().")

helpers = r'''function moneyProfile(handle){
  const key=String(handle||'').replace(/^@/,'').toLowerCase();
  return (state.home?.profiles||[]).find(p=>String(p.handle||'').replace(/^@/,'').toLowerCase()===key)||null;
}

function moneyTokenByMint(mint){
  return (state.tokens||[]).find(t=>(t.mint||t.contract)===mint)||null;
}

function moneyRoundIcon(label,kind='dark'){
  return `<span class="money-round-icon ${kind}">${esc(label)}</span>`;
}

function moneyRecentCard(p,i){
  const amount=p.amount_usd??p.amount??0;
  const handle=p.recipient_handle||p.to||'recipient';
  const profile=moneyProfile(handle);
  const mints=String(p.mints||'').split(',').filter(Boolean);
  const token=moneyTokenByMint(mints[0]||'');
  const confirmed=['sent','claimed'].includes(p.status);
  return `<button class="money-payment-card expandable" data-expand="money-payment-${i}">
    <div class="money-payment-copy">
      <strong>${fmtMoney(amount)}</strong>
      <span>${confirmed?'sent':'scheduled'} to <b>${esc(p.display_name||handle)}</b>${confirmed?' <em>✓</em>':''}</span>
    </div>
    <span class="chev">⌄</span>
    <div class="money-payment-route">
      <div class="money-payment-avatar">
        ${token?avatar(token.symbol||token.name,true,token.image_url):avatar(mints[0]||'T',true)}
        <i>●</i>
      </div>
      <b class="money-dollar">$</b>
      <div class="money-payment-avatar">
        ${avatar(profile?.display_name||p.display_name||handle,true,profile?.avatar_url||p.avatar_url||'')}
        <i class="x">X</i>
      </div>
      <time>${esc(ago(p.sent_at||p.created_at))}</time>
    </div>
    <div class="details hidden">
      <div><span>Status</span><b>${esc(p.status||'queued')}</b></div>
      <div><span>Provider</span><b>${esc(p.provider||'')}</b></div>
      <div><span>Reference</span><b>${esc(p.provider_ref||p.id||'')}</b></div>
    </div>
  </button>`;
}

function moneyOffRampCard(x,i){
  const side=String(x.side||'sell').toLowerCase();
  const status=String(x.status||'queued');
  const provider=String(x.provider||'rail');
  const native=Number(x.volume_native||0);
  const usd=Number(x.received_usd||0);
  const swapped=/swap/i.test(status)||side==='swap';
  const sentUsd=usd>0 && !swapped;
  const amount=usd>0?fmtMoney(usd):`${fmtNum(native)} SOL`;
  const subtitle=swapped
    ? `swapped ${fmtNum(native)} SOL`
    : sentUsd?`USD sent to ${provider}`:`sent to ${provider}`;
  const left=swapped||!sentUsd?moneyRoundIcon('≋','sol'):moneyRoundIcon('🇺🇸','usd');
  const right=swapped?moneyRoundIcon('🇺🇸','usd'):moneyRoundIcon(provider.slice(0,1).toUpperCase(),'provider');
  const arrow=swapped?'⇄':'→';
  return `<button class="money-transfer-card expandable" data-expand="money-off-${i}">
    <div class="money-transfer-copy"><strong>${esc(amount)}</strong><span>${esc(subtitle)}</span></div>
    <div class="money-transfer-route">${left}<b>${arrow}</b>${right}</div>
    <div class="money-transfer-side"><span class="money-status">${esc(status)}</span><time>${esc(ago(x.filled_at||x.created_at))}</time></div>
    <span class="chev">⌄</span>
    <div class="tx-details hidden">
      <div><span>Provider</span><b>${esc(provider)}</b></div>
      <div><span>Pair</span><b>${esc(x.pair||'SOLUSD')}</b></div>
      <div><span>Reference</span><b>${esc(x.provider_ref||x.id||'')}</b></div>
    </div>
  </button>`;
}

function moneyTopTokenCard(t){
  const handle=t.recipient_handle||t.profile||'';
  const profile=moneyProfile(handle);
  return `<a class="money-top-token-card" href="#/token/${encodeURIComponent(t.mint||t.contract||'')}">
    <div class="money-top-route">
      <div class="money-payment-avatar">${avatar(t.symbol||t.name,true,t.image_url)}<i>●</i></div>
      <b class="money-dollar">$</b>
      <div class="money-payment-avatar">${avatar(profile?.display_name||handle||'X',true,profile?.avatar_url||'')}<i class="x">X</i></div>
    </div>
    <div class="money-top-values">
      <strong>${fmtMoney(t.sent||0)}</strong>
      <span>${fmtMoney(t.owed||0)} owed</span>
    </div>
  </a>`;
}

function moneyOnRampCard(x,i){
  const provider=String(x.provider||'Kraken');
  const usd=Number(x.received_usd||x.gross_usd||0);
  const native=Number(x.volume_native||0);
  const amount=usd>0?fmtMoney(usd):(native>0?`${fmtNum(native)} SOL`:'$0.00');
  return `<button class="money-on-card expandable" data-expand="money-on-${i}">
    <div class="money-on-copy"><strong>${esc(amount)}</strong><span>from <b>${esc(provider)}</b></span></div>
    ${moneyRoundIcon('$','payout')}
    <div class="money-on-side"><span class="money-status">Received</span><time>${esc(ago(x.filled_at||x.created_at))}</time></div>
    <span class="chev">⌄</span>
    <div class="tx-details hidden">
      <div><span>Provider</span><b>${esc(provider)}</b></div>
      <div><span>Pair</span><b>${esc(x.pair||'')}</b></div>
      <div><span>Reference</span><b>${esc(x.provider_ref||x.id||'')}</b></div>
    </div>
  </button>`;
}

function moneyBridgeSection(){
  return `<section class="wrap money-section">
    <div class="money-section-head money-bridge-head">
      <h2>Bridge <small><i>↗</i> Configured treasury rail</small></h2>
      <div class="money-pager"><button disabled>‹</button><span>1 / 1</span><button disabled>›</button></div>
    </div>
    <div class="money-empty-card">
      <div class="money-empty-route">${moneyRoundIcon('◇','bridge')}<b>→</b>${moneyRoundIcon('≋','sol')}</div>
      <strong>No bridge activity yet.</strong>
      <span>Bridge events will appear here when a bridge adapter is configured.</span>
    </div>
  </section>`;
}

function moneySections(money){
  const exchanges=money?.exchange||[];
  const offRamp=exchanges.filter(x=>!isOnRampOrder(x));
  const onRamp=exchanges.filter(isOnRampOrder);
  const topTokens=(state.tokens||[]).slice().sort((a,b)=>Number(b.sent||0)-Number(a.sent||0)).slice(0,6);
  const inTransit=onRamp.reduce((sum,x)=>sum+Number(x.received_usd||x.gross_usd||0),0);

  return `<section class="wrap money-section">
    <div class="money-section-head"><h2>Off-ramp</h2><div class="money-pager"><button disabled>‹</button><span>1</span><button disabled>›</button></div></div>
    <div class="money-filter-tabs"><button class="active">All</button><button disabled>Deposits</button><button disabled>Swaps</button><button disabled>ACH</button></div>
    <div class="money-list">${offRamp.length?offRamp.slice(0,6).map(moneyOffRampCard).join(''):'<div class="money-empty-card"><strong>No off-ramp activity yet.</strong><span>Exchange and payout-rail events will appear here.</span></div>'}</div>
  </section>

  ${moneyBridgeSection()}

  <section class="wrap money-section">
    <p class="money-delay">Updates are delayed. Showing top paid tokens from the confirmed ledger.</p>
    <div class="money-section-head">
      <h2>Top paid tokens</h2>
      <div class="money-pager"><button disabled>‹</button><span>1 / 1</span><button disabled>›</button></div>
    </div>
    <p class="money-explainer">Ranked by all-time amount sent. Owed amounts do not affect rank. Recipient shown is the token's current beneficiary.</p>
    <div class="money-list">${topTokens.length?topTokens.map(moneyTopTokenCard).join(''):'<div class="money-empty-card"><strong>No paid tokens yet.</strong><span>Tokens will be ranked here after confirmed payouts.</span></div>'}</div>
  </section>

  <section class="wrap money-section">
    <div class="money-section-head">
      <h2>On-ramp <small class="money-transit">${fmtMoney(inTransit)} <span>in transit</span></small></h2>
      <div class="money-pager"><button disabled>‹</button><span>1</span><button disabled>›</button></div>
    </div>
    <div class="money-list">${onRamp.length?onRamp.slice(0,6).map(moneyOnRampCard).join(''):'<div class="money-empty-card"><strong>No on-ramp activity yet.</strong><span>Confirmed funding events will appear here.</span></div>'}</div>
  </section>`;
}

function moneyFooter(){
  return `<footer class="money-footer">
    <div class="money-footer-inner">
      <div class="money-footer-brand">
        <b>${esc(state.brand.name)}</b>
        <span>© 2026 ${esc(state.brand.name)}</span>
        <em>𝕏</em>
        <small>Not affiliated with X Corp.</small>
      </div>
      <div class="money-footer-links"><b>Product</b><a href="#/explore">Explore</a><a href="#/money">Payments</a><a href="#/money">Analytics</a><a href="#/launch">Launch</a></div>
      <div class="money-footer-links"><b>Protocol</b><a href="#/capital-flow">Capital Flow</a><a href="#/paid">$PAID</a><a href="#/docs">Docs</a></div>
      <div class="money-footer-links"><b>Legal</b><a href="#/legal">Terms</a><a href="#/legal">Privacy</a><a href="#/legal">Disclosures</a><a href="#/opt-out">Opt out</a></div>
    </div>
  </footer>`;
}

'''

app = app[:sections_start] + helpers + app[sections_end:]

money_start = app.find("function moneyPage(){")
money_end = app.find("function docsPage(){", money_start)
if money_start < 0 or money_end < 0:
    raise SystemExit("Could not locate moneyPage().")

money_page = r'''function moneyPage(){
  const m=state.money||{recent:[],topPaid:[],exchange:[]};
  const updated=m.indexer?.completedAt||m.indexer?.startedAt||m.recent?.[0]?.created_at||null;
  return `<main class="money-page-v2">
    <section class="wrap money-summary-card">
      <p class="money-label">𝕏 Money</p>
      <strong class="money-summary-total">${fmtMoney(m.totalPaid||0)}</strong>
      <span class="money-summary-caption">Total paid out</span>

      <div class="money-summary-tabs">
        <button class="active">𝕏 Money</button>
        <button>Solana treasury</button>
      </div>

      <div class="money-summary-stat"><span>Currently owed</span><b>${fmtMoney(m.totalOwed||0)}</b></div>
      <div class="money-summary-stat"><span>Ledger updated</span><b>${updated?esc(ago(updated)):'—'}</b></div>
    </section>

    <section class="wrap money-section money-recent-section">
      <p class="money-delay">Updates are delayed. Showing recent payments from the confirmed ledger.</p>
      <div class="money-section-head">
        <h2>Recent payments</h2>
        <div class="money-pager"><button disabled>‹</button><span>1</span><button disabled>›</button></div>
      </div>
      <div class="money-list">${(m.recent||[]).slice(0,6).map(moneyRecentCard).join('')||'<div class="money-empty-card"><strong>No payouts recorded yet.</strong><span>Confirmed payments will appear here.</span></div>'}</div>
    </section>

    ${moneySections(m)}
    ${moneyFooter()}
  </main>`;
}'''

app = app[:money_start] + money_page + chr(10) + app[money_end:]
app_path.write_text(app)

css += r'''

/* money-v2-reference */
.money-page-v2{padding-top:56px;background:#000;color:#fff}
.money-page-v2 .wrap{width:min(100% - 32px,720px)}
.money-summary-card{min-height:430px;padding:52px 44px;border:1px solid #272727;border-radius:18px;background:#050505}
.money-label{margin:0 0 15px;color:#858585;font-size:17px;font-weight:650}
.money-summary-total{display:block;font-size:54px;line-height:.95;letter-spacing:-.045em;font-weight:500}
.money-summary-caption{display:block;margin-top:18px;color:#878787;font-size:18px;font-weight:600}
.money-summary-tabs{display:flex;align-items:center;gap:22px;margin-top:34px}
.money-summary-tabs button{border:0;padding:13px 21px;border-radius:999px;background:transparent;color:#818181;font-size:15px;font-weight:650}
.money-summary-tabs button.active{background:#fff;color:#000}
.money-summary-stat{display:grid;gap:7px;margin-top:34px}
.money-summary-stat span{color:#777;font-size:13px;font-weight:600}
.money-summary-stat b{font-size:15px;font-weight:650}
.money-section{padding-top:72px;padding-bottom:0}
.money-recent-section{padding-top:64px}
.money-delay{margin:0 0 22px;color:#818181;font-size:13px;line-height:1.45}
.money-section-head{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:22px}
.money-section-head h2{margin:0;font-size:28px;line-height:1;letter-spacing:-.035em;font-weight:500}
.money-section-head h2 small{margin-left:8px;color:#686868;font-size:12px;font-weight:600}
.money-pager{display:flex;align-items:center;gap:20px;color:#777;font-size:12px}
.money-pager button{border:0;background:transparent;color:#777;padding:0;font-size:24px}
.money-list{display:grid;gap:12px}
.money-payment-card,.money-transfer-card,.money-on-card{width:100%;min-height:126px;position:relative;display:grid;align-items:center;color:#fff;text-align:left;background:#181818;border:1px solid #323232;border-radius:18px}
.money-payment-card{grid-template-columns:1fr auto;padding:20px 22px}
.money-payment-copy{display:grid}
.money-payment-copy strong{font-size:36px;line-height:1;letter-spacing:-.035em;font-weight:500}
.money-payment-copy span{margin-top:8px;color:#a1a1a1;font-size:16px;font-weight:550}
.money-payment-copy span b{color:#fff}
.money-payment-copy em{color:#1da1f2;font-style:normal}
.money-payment-card>.chev{align-self:start;color:#777;font-size:17px}
.money-payment-route{grid-column:1/-1;display:grid;grid-template-columns:45px 28px 45px 1fr;align-items:center;gap:8px;margin-top:14px}
.money-payment-avatar{position:relative;width:45px;height:45px}
.money-payment-avatar .avatar{width:45px;height:45px;border:0;font-size:13px}
.money-payment-avatar i{position:absolute;right:-3px;bottom:-3px;width:18px;height:18px;display:grid;place-items:center;border:2px solid #181818;border-radius:5px;background:#050505;color:#62e897;font-size:7px;font-style:normal}
.money-payment-avatar i.x{color:#fff}
.money-dollar{display:grid;place-items:center;font-size:25px;font-weight:850}
.money-payment-route time{justify-self:end;align-self:end;color:#9a9a9a;font-size:12px}
.money-filter-tabs{display:flex;gap:20px;margin:-5px 0 22px}
.money-filter-tabs button{border:0;padding:9px 12px;border-radius:999px;background:transparent;color:#858585;font-size:13px;font-weight:600}
.money-filter-tabs button.active{background:#181818;color:#fff}
.money-transfer-card{grid-template-columns:minmax(0,1fr) auto auto 14px;gap:14px;padding:16px 22px}
.money-transfer-copy{min-width:0;display:grid}
.money-transfer-copy strong{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:30px;line-height:1;font-weight:500}
.money-transfer-copy span{margin-top:8px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#aaa;font-size:16px}
.money-transfer-route{display:flex;align-items:center;gap:10px}
.money-transfer-route>b{color:#666;font-size:19px}
.money-round-icon{width:46px;height:46px;display:grid;place-items:center;border-radius:50%;background:#030303;border:1px solid #222;font-size:18px;font-weight:800}
.money-round-icon.usd{font-size:24px}
.money-round-icon.sol{font-size:25px}
.money-round-icon.provider{color:#fff}
.money-round-icon.bridge{background:#b9ff00;color:#000}
.money-round-icon.payout{font-size:22px}
.money-transfer-side,.money-on-side{min-width:72px;display:grid;justify-items:end;gap:7px}
.money-status{max-width:90px;padding:6px 9px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;border-radius:999px;background:#303030;color:#d2d2d2;font-size:10px;font-weight:650;text-transform:capitalize}
.money-transfer-side time,.money-on-side time{color:#9a9a9a;font-size:11px}
.money-transfer-card>.chev,.money-on-card>.chev{color:#777;font-size:15px}
.money-bridge-head h2{display:flex;align-items:center;gap:9px}
.money-bridge-head h2 small{display:inline-flex;align-items:center;gap:6px;margin-left:0}
.money-bridge-head h2 small i{width:18px;height:18px;display:grid;place-items:center;border-radius:4px;background:#b9ff00;color:#000;font-size:9px;font-style:normal}
.money-empty-card{min-height:126px;display:grid;place-items:center;align-content:center;gap:8px;padding:22px;border:1px dashed #292929;border-radius:18px;color:#696969;text-align:center}
.money-empty-card strong{font-size:13px;color:#848484}
.money-empty-card span{font-size:11px}
.money-empty-route{display:flex;align-items:center;gap:12px;margin-bottom:4px}
.money-empty-route>b{color:#666;font-size:18px}
.money-explainer{max-width:650px;margin:-6px 0 22px;color:#858585;font-size:12px;line-height:1.42}
.money-top-token-card{min-height:112px;display:grid;grid-template-columns:auto 1fr;align-items:center;gap:16px;padding:18px 22px;color:#fff;background:#181818;border:1px solid #323232;border-radius:18px}
.money-top-route{display:flex;align-items:center;gap:10px}
.money-top-values{min-width:0;display:grid;justify-items:end}
.money-top-values strong{font-size:25px;line-height:1;font-weight:550}
.money-top-values span{margin-top:7px;color:#8b8b8b;font-size:12px;font-weight:600}
.money-transit{display:inline-flex;align-items:baseline;gap:5px;padding:8px 12px;border:1px solid #2c2c2c;border-radius:999px;background:#151515;color:#fff!important}
.money-transit span{color:#777;font-size:11px}
.money-on-card{grid-template-columns:minmax(0,1fr) 48px auto 14px;gap:14px;padding:18px 22px}
.money-on-copy{min-width:0;display:grid}
.money-on-copy strong{font-size:30px;line-height:1;font-weight:500}
.money-on-copy span{margin-top:8px;color:#aaa;font-size:16px}
.money-on-copy span b{color:#fff}
.money-footer{margin-top:76px;border-top:1px solid #191919}
.money-footer-inner{width:min(100% - 32px,720px);margin:0 auto;padding:66px 0 86px;display:grid;grid-template-columns:1.6fr 1fr 1fr;gap:34px}
.money-footer-brand{grid-row:span 2;display:grid;align-content:start;justify-items:start;gap:18px}
.money-footer-brand>b{font-size:18px}
.money-footer-brand>span{color:#666;font-size:12px}
.money-footer-brand>em{margin-top:10px;color:#4d4d4d;font-size:27px;font-style:normal}
.money-footer-brand>small{color:#3f3f3f;font-size:10px}
.money-footer-links{display:grid;align-content:start;gap:15px}
.money-footer-links b{font-size:13px}
.money-footer-links a{width:max-content;color:#4f4f4f;font-size:12px}
.money-footer-links:last-child{grid-column:2}
.money-page-v2 .details,.money-page-v2 .tx-details{grid-column:1/-1;margin-top:12px;padding-top:12px;border-top:1px solid #303030}

@media(max-width:640px){
  .money-page-v2{padding-top:44px}
  .money-page-v2 .wrap{width:calc(100% - 32px)}
  .money-summary-card{min-height:0;padding:30px 24px;border-radius:16px}
  .money-label{font-size:13px;margin-bottom:12px}
  .money-summary-total{font-size:43px}
  .money-summary-caption{margin-top:12px;font-size:14px}
  .money-summary-tabs{gap:10px;margin-top:27px}
  .money-summary-tabs button{padding:10px 14px;font-size:11px}
  .money-summary-stat{margin-top:26px}
  .money-summary-stat span{font-size:10px}
  .money-summary-stat b{font-size:12px}
  .money-section{padding-top:54px}
  .money-recent-section{padding-top:52px}
  .money-delay{font-size:10px;margin-bottom:18px}
  .money-section-head{margin-bottom:17px}
  .money-section-head h2{font-size:22px}
  .money-pager{gap:14px;font-size:9px}
  .money-pager button{font-size:18px}
  .money-list{gap:10px}
  .money-payment-card{min-height:112px;padding:16px 17px;border-radius:15px}
  .money-payment-copy strong{font-size:30px}
  .money-payment-copy span{font-size:13px}
  .money-payment-route{grid-template-columns:39px 24px 39px 1fr;gap:7px;margin-top:12px}
  .money-payment-avatar,.money-payment-avatar .avatar{width:39px;height:39px}
  .money-dollar{font-size:21px}
  .money-payment-route time{font-size:10px}
  .money-filter-tabs{gap:12px;margin-bottom:17px}
  .money-filter-tabs button{padding:7px 9px;font-size:10px}
  .money-transfer-card{min-height:96px;grid-template-columns:minmax(0,1fr) auto auto 10px;gap:8px;padding:13px 16px;border-radius:15px}
  .money-transfer-copy strong{font-size:23px}
  .money-transfer-copy span{font-size:12px;max-width:120px}
  .money-transfer-route{gap:6px}
  .money-round-icon{width:36px;height:36px;font-size:14px}
  .money-round-icon.usd{font-size:19px}
  .money-round-icon.sol{font-size:20px}
  .money-transfer-side,.money-on-side{min-width:56px}
  .money-status{padding:5px 7px;font-size:8px}
  .money-transfer-side time,.money-on-side time{font-size:9px}
  .money-bridge-head h2{display:block}
  .money-bridge-head h2 small{margin-top:7px}
  .money-empty-card{min-height:112px;border-radius:15px}
  .money-explainer{font-size:10px;margin-bottom:18px}
  .money-top-token-card{min-height:94px;gap:10px;padding:14px 16px;border-radius:15px}
  .money-top-route{gap:6px}
  .money-top-values strong{font-size:20px}
  .money-top-values span{font-size:9px}
  .money-transit{padding:6px 9px}
  .money-transit span{font-size:8px}
  .money-on-card{min-height:96px;grid-template-columns:minmax(0,1fr) 38px auto 10px;gap:8px;padding:14px 16px;border-radius:15px}
  .money-on-copy strong{font-size:23px}
  .money-on-copy span{font-size:12px}
  .money-footer{margin-top:58px}
  .money-footer-inner{width:calc(100% - 32px);padding:50px 0 70px;grid-template-columns:1fr 1fr;gap:34px 28px}
  .money-footer-brand{grid-column:1/-1;grid-row:auto;gap:13px}
  .money-footer-brand>b{font-size:14px}
  .money-footer-brand>span{font-size:10px}
  .money-footer-brand>em{font-size:23px}
  .money-footer-brand>small{font-size:9px}
  .money-footer-links b{font-size:10px}
  .money-footer-links a{font-size:10px}
  .money-footer-links:last-child{grid-column:1}
}
'''
css_path.write_text(css)

print("Money v2 reference patch installed.")
PY

npm run check

git add src/app.js src/styles.css

if git diff --cached --quiet; then
  echo "No staged changes; nothing to commit."
else
  git commit -m "Rebuild Money page from reference"
fi

git push origin main

echo
echo "DONE: Money v2 checked, committed, and pushed to GitHub."
echo "No server restart was performed."
echo "Refresh #/money after the running server serves the updated files."
