Pump Fee Routing — Money v2
Full Money-page rebuild using the supplied reference screenshots as the design source.
Includes summary card, recent payments, off-ramp, bridge, top paid tokens, on-ramp, and a Money-specific footer.
Uses only real project ledger/token/exchange data. Bridge remains an honest empty state until a bridge adapter exists.
No backend, Solana, payout-worker, discovery-worker, or database mutation logic is changed.
Runs npm check, commits, and pushes to origin/main. No automatic server restart.
