Pump Fee Routing — Launch Page v1
Rebuilds the Launch page in the reference style while preserving the existing launch-intent, wallet-connect, fee-routing and registration backend.
Adds token-preparation fields and a preview. Direct Pump token creation is not faked; the flow links to the official Pump create page, then routes/registers the resulting mint.
Pons and Walletless remain disabled until real integrations exist.
Runs npm check, commits, and pushes to origin/main. No automatic server restart.
