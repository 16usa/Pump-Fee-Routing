Pump Fee Routing — Token Detail v1
Rebuilds each #/token/<mint> page using only the real token API fields already available in the project.
Includes token identity, X recipient, Sent/Owed/Earned/Market Cap, verified fee route, live chain state, About, Claims, and Payments.
Pump tokens link to their Pump page. Empty chain/claim/payment states remain honest and no fixture values are added.
No backend, database, Solana worker, payout or claim execution logic is changed.
Runs npm check, commits, and pushes to origin/main. No automatic server restart.
