
from pathlib import Path
import re

path=Path("src/app.js")
s=path.read_text()

old = '<button class="launch-pill" data-action="open-launch">Launch</button>'
new = '<a class="launch-pill" href="#/launch">Launch</a>'
if new not in s:
    if old not in s:
        raise SystemExit("ERROR: header Launch button target not found")
    s=s.replace(old,new,1)
    print("Header Launch now opens #/launch directly")

old = '<button class="btn-light" data-action="open-launch">Launch a token</button>'
new = '<a class="btn-light" href="#/launch">Launch a token</a>'
if new not in s:
    if old not in s:
        raise SystemExit("ERROR: hero Launch button target not found")
    s=s.replace(old,new,1)
    print("Home Launch a token now opens #/launch directly")

modal_pattern = re.compile(
    r'function launchModal\(\)\{return `<div class="modal-bg hidden" id="launchModal">.*?</div></div>`;\}\n',
    re.S
)
if "function launchModal()" in s:
    s,n=modal_pattern.subn("",s,count=1)
    if n!=1:
        raise SystemExit("ERROR: launchModal() function found but could not remove safely")
    print("Launch choice modal removed")

s=s.replace("header()+loadingPage()+launchModal()","header()+loadingPage()")
s=s.replace("header()+page+launchModal()","header()+page")
s=s.replace("header()+errorPage(e)+launchModal()","header()+errorPage(e)")

s=s.replace("if(action==='open-launch')document.querySelector('#launchModal')?.classList.remove('hidden');","")
s=s.replace("if(action==='close-launch')document.querySelector('#launchModal')?.classList.add('hidden');","")

s=s.replace('data-action="open-launch"','data-action="go-launch"')

if "launchModal()" in s or 'id="launchModal"' in s:
    raise SystemExit("ERROR: launch modal references remain after patch")

path.write_text(s)
print("PASS: modal removed and Launch routes directly to #/launch")
