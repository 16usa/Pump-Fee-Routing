Direct Launch Page v24

Removes the intermediate "Route creator fees" popup completely.

After this patch:
- Header Launch -> immediately opens #/launch
- Home "Launch a token" -> immediately opens #/launch
- Existing go-launch buttons continue opening #/launch
- The old popup is no longer rendered
- No automatic server restart

Install in the existing Replit Shell:

rm -rf /tmp/direct_launch_page_v24 && mkdir -p /tmp/direct_launch_page_v24 && unzip -o direct_launch_page_v24.zip -d /tmp/direct_launch_page_v24 && bash /tmp/direct_launch_page_v24/install.sh
