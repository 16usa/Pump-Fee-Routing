#!/usr/bin/env bash
set -euo pipefail

PATCH_NAME="direct_launch_page_v24"
APP="src/app.js"

if [ ! -f "$APP" ]; then
  echo "ERROR: missing $APP"
  echo "Run this from the existing Replit project root."
  exit 1
fi

echo "==> Installing ${PATCH_NAME}"

mkdir -p ".patch-backups/${PATCH_NAME}"
cp "$APP" ".patch-backups/${PATCH_NAME}/app.js.before"

python3 "$(dirname "$0")/patch.py"

echo "==> Running project check"
npm run check

echo "==> Git diff"
git diff -- src/app.js

git add src/app.js

if git diff --cached --quiet; then
  echo "==> No new changes to commit."
else
  git commit -m "Open Launch page directly"
  git push origin main
fi

echo
echo "PASS: ${PATCH_NAME} installed."
echo "No server restart was performed."
