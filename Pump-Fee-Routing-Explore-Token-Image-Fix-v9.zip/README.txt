Pump Fee Routing — Explore Token Image Fix v9

Scope:
- Fixes ONLY token image loading used by the Home > Explore preview.
- Does not change Explore geometry, Payments, Analytics, Launch, or Docs layout.
- Proxies the token image through the app so Safari does not depend on a fragile external redirect.
- Tries stored token image, Pump API image fields, nested metadata image fields,
  metadata JSON URIs, and multiple IPFS gateways.
- Future token indexing also stores nested image_uri/image_url fields.
- Does NOT restart the server.

Install from the existing Replit workspace:

rm -rf /tmp/explore-token-image-v9
mkdir -p /tmp/explore-token-image-v9
unzip -o Pump-Fee-Routing-Explore-Token-Image-Fix-v9.zip -d /tmp/explore-token-image-v9
bash /tmp/explore-token-image-v9/install.sh

Then restart Run/Console manually and reload the page.
