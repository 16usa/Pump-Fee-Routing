#!/usr/bin/env bash
set -euo pipefail

echo "== Explore Token Image Fix v9 =="

for f in src/app.js server/api.js server/solana.js; do
  if [ ! -f "$f" ]; then
    echo "ERROR: $f not found. Run this from the existing project workspace."
    exit 1
  fi
done

python3 <<'PY'
from pathlib import Path

api_path = Path("server/api.js")
sol_path = Path("server/solana.js")

api = api_path.read_text()
sol = sol_path.read_text()

marker = "/* home-explore-token-image-v6 */"
handle = "export async function handleApi(req,res,url){"

if marker not in api:
    marker = "/* home-explore-token-image-v9 */"

start = api.find(marker)
end = api.find(handle, start)
if start < 0 or end < 0:
    raise SystemExit("ERROR: token-image helper block anchor not found in server/api.js")

new_helpers = r"""/* home-explore-token-image-v9 */
function tokenImageCandidates(raw){
  const value=String(raw||'').trim();
  if(!value) return [];

  const out=[];
  const add=(url)=>{
    const u=String(url||'').trim();
    if(u && /^https?:\/\//i.test(u) && !out.includes(u)) out.push(u);
  };

  if(/^ar:\/\//i.test(value)){
    add(`https://arweave.net/${value.replace(/^ar:\/\//i,'')}`);
    return out;
  }

  let ipfsPath='';
  if(/^ipfs:\/\//i.test(value)){
    ipfsPath=value.replace(/^ipfs:\/\//i,'').replace(/^ipfs\//i,'');
  }else{
    const m=value.match(/\/ipfs\/([^?#]+)/i);
    if(m) ipfsPath=m[1];
  }

  if(ipfsPath){
    ipfsPath=ipfsPath.replace(/^\/+/,'');
    add(value);
    add(`https://ipfs.io/ipfs/${ipfsPath}`);
    add(`https://gateway.pinata.cloud/ipfs/${ipfsPath}`);
    add(`https://dweb.link/ipfs/${ipfsPath}`);
    return out;
  }

  add(value);
  return out;
}

function imageValuesFromMetadata(meta){
  if(!meta || typeof meta!=='object') return [];
  const values=[
    meta.image_uri,
    meta.image,
    meta.imageUrl,
    meta.image_url,
    meta.metadata?.image_uri,
    meta.metadata?.image,
    meta.metadata?.imageUrl,
    meta.metadata?.image_url,
    meta.coin_metadata?.image_uri,
    meta.coin_metadata?.image,
    meta.coin_metadata?.imageUrl,
    meta.coin_metadata?.image_url
  ];
  return [...new Set(values.map(v=>String(v||'').trim()).filter(Boolean))];
}

function metadataUris(meta){
  if(!meta || typeof meta!=='object') return [];
  const values=[
    meta.uri,
    meta.metadata_uri,
    meta.metadataUri,
    meta.metadata?.uri,
    meta.coin_metadata?.uri
  ];
  return [...new Set(values.map(v=>String(v||'').trim()).filter(Boolean))];
}

async function fetchMetadataJson(target){
  const direct=String(target||'').trim();
  const candidates=tokenImageCandidates(direct);
  if(/^https?:\/\//i.test(direct) && !candidates.includes(direct)) candidates.unshift(direct);

  for(const url of candidates.length?candidates:[direct]){
    if(!/^https?:\/\//i.test(url)) continue;
    try{
      const r=await fetch(url,{
        headers:{accept:'application/json,text/plain;q=0.9,*/*;q=0.5'},
        redirect:'follow',
        signal:AbortSignal.timeout(12000)
      });
      if(!r.ok) continue;
      const text=await r.text();
      if(text.length>2_000_000) continue;
      const data=JSON.parse(text);
      if(data && typeof data==='object') return data;
    }catch{}
  }
  return null;
}

async function resolvePumpTokenImages(mint){
  const candidates=[];
  const addRaw=(raw)=>{
    for(const url of tokenImageCandidates(raw)){
      if(!candidates.includes(url)) candidates.push(url);
    }
  };

  const stored=getToken(mint);
  addRaw(stored?.image_url||'');

  const urls=[...new Set([
    config.pumpMetadataUrlTemplate.replace('{mint}',encodeURIComponent(mint)),
    `https://frontend-api-v3.pump.fun/coins-v2/${encodeURIComponent(mint)}`,
    `https://frontend-api-v3.pump.fun/coins/${encodeURIComponent(mint)}`
  ])];

  for(const target of urls){
    try{
      const r=await fetch(target,{
        headers:{accept:'application/json'},
        redirect:'follow',
        signal:AbortSignal.timeout(12000)
      });
      if(!r.ok) continue;
      const meta=await r.json();

      for(const raw of imageValuesFromMetadata(meta)) addRaw(raw);

      for(const uri of metadataUris(meta)){
        const metadata=await fetchMetadataJson(uri);
        if(!metadata) continue;
        for(const raw of imageValuesFromMetadata(metadata)) addRaw(raw);
      }
    }catch{}
  }

  if(stored?.metadata_json){
    try{
      const meta=JSON.parse(stored.metadata_json);
      for(const raw of imageValuesFromMetadata(meta)) addRaw(raw);
      for(const uri of metadataUris(meta)){
        const metadata=await fetchMetadataJson(uri);
        if(!metadata) continue;
        for(const raw of imageValuesFromMetadata(metadata)) addRaw(raw);
      }
    }catch{}
  }

  return candidates;
}

async function proxyTokenImage(res,mint){
  const candidates=await resolvePumpTokenImages(mint);

  for(const target of candidates){
    try{
      const r=await fetch(target,{
        headers:{
          accept:'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
          'user-agent':'Mozilla/5.0'
        },
        redirect:'follow',
        signal:AbortSignal.timeout(15000)
      });
      if(!r.ok) continue;

      const type=String(r.headers.get('content-type')||'').split(';')[0].trim().toLowerCase();
      if(!type.startsWith('image/')) continue;

      const bytes=Buffer.from(await r.arrayBuffer());
      if(!bytes.length || bytes.length>8_000_000) continue;

      res.writeHead(200,{
        'content-type':type,
        'content-length':String(bytes.length),
        'cache-control':'public, max-age=900, stale-while-revalidate=3600',
        'x-content-type-options':'nosniff'
      });
      res.end(bytes);
      return true;
    }catch{}
  }

  return false;
}


"""

api = api[:start] + new_helpers + api[end:]

route_start = api.find("    if(req.method==='GET'&&url.pathname.startsWith('/api/token-image/')){")
route_end = api.find("\n    if(req.method==='GET'&&url.pathname==='/api/health')", route_start)
if route_start < 0 or route_end < 0:
    raise SystemExit("ERROR: /api/token-image route anchor not found")

new_route = """    if(req.method==='GET'&&url.pathname.startsWith('/api/token-image/')){
      const mint=decodeURIComponent(url.pathname.slice('/api/token-image/'.length)).trim();
      if(!/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(mint)) return json(res,400,{error:'Invalid mint'});
      const sent=await proxyTokenImage(res,mint);
      if(sent) return;
      return json(res,404,{error:'Token image not found'});
    }"""

api = api[:route_start] + new_route + api[route_end:]
api_path.write_text(api)

old_expr = "image_url:meta.image_uri||meta.image||meta.metadata?.image||existing?.image_url||''"
new_expr = "image_url:meta.image_uri||meta.image||meta.image_url||meta.metadata?.image_uri||meta.metadata?.image||meta.metadata?.image_url||meta.coin_metadata?.image_uri||meta.coin_metadata?.image||meta.coin_metadata?.image_url||existing?.image_url||''"

if old_expr in sol:
    sol = sol.replace(old_expr, new_expr, 1)
elif new_expr not in sol:
    raise SystemExit("ERROR: image_url persistence anchor not found in server/solana.js")

sol_path.write_text(sol)

print("PASS token-image proxy installed")
print("PASS Pump metadata image fallbacks installed")
print("PASS future indexed tokens persist nested image_uri/image_url")
PY

echo
echo "== Project checks =="
npm run check

echo
echo "== Git status =="
git status --short

git add server/api.js server/solana.js

if git diff --cached --quiet; then
  echo "No new changes to commit (patch may already be installed)."
else
  git commit -m "Fix Explore token image loading"
  git push
fi

echo
echo "DONE: Explore Token Image Fix v9 installed, checked, committed, and pushed."
echo "No server restart was performed."
echo "Restart Run/Console manually once, then reload the page."
