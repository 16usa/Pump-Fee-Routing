#!/usr/bin/env bash
set -euo pipefail

if [ ! -f src/app.js ] || [ ! -f src/styles.css ]; then
  echo "Run this from the Pump-Fee-Routing project root."
  exit 1
fi

if [ -n "$(git status --porcelain -- src/app.js src/styles.css)" ]; then
  echo "STOP: src/app.js or src/styles.css has uncommitted changes."
  git status --short -- src/app.js src/styles.css
  exit 2
fi

python3 - <<'PY'
from pathlib import Path

app_path = Path("src/app.js")
css_path = Path("src/styles.css")
app = app_path.read_text()
css = css_path.read_text()

marker = "/* home-off-ramp-v1 */"
if marker in css:
    raise SystemExit("Off-ramp v1 is already installed.")

start = app.find("function homeOffRamp(h){")
end = app.find("function homeOnRamp(){", start)
if start < 0 or end < 0:
    raise SystemExit("Could not locate homeOffRamp()/homeOnRamp().")

replacement = r'''function homeOffRampIcon(kind){
  if(kind==='usd') return '<span class="home-off-icon home-off-usd">🇺🇸</span>';
  if(kind==='x') return '<span class="home-off-icon home-off-x">$</span>';
  if(kind==='provider') return '<span class="home-off-icon home-off-provider">●</span>';
  return '<span class="home-off-icon home-off-sol">≋</span>';
}

function homeOffRampCard(x,i){
  const received=Number(x.received_usd||0);
  const native=Number(x.volume_native||0);
  const pair=String(x.pair||'SOLUSD').toUpperCase();
  const side=String(x.side||'sell').toLowerCase();
  const status=String(x.status||'queued');
  const provider=String(x.provider||'provider');
  const amount=received>0?fmtMoney(received):`${fmtNum(native)} SOL`;
  const isSwap=side==='sell'||side==='swap'||/swap/i.test(status);
  const leftKind=received>0?'usd':'sol';
  const rightKind=isSwap?(received>0?'x':'usd'):'provider';
  const subtitle=isSwap
    ? (received>0?`USD sent to payout rail`:`swapped ${fmtNum(native)} SOL`)
    : `${received>0?'USD':'SOL'} sent to ${provider}`;
  return `<button class="home-off-card expandable" data-expand="home-off-${i}">
    <div class="home-off-main">
      <div class="home-off-copy">
        <strong>${esc(amount)}</strong>
        <span>${esc(subtitle)}</span>
      </div>
      <div class="home-off-route">
        ${homeOffRampIcon(leftKind)}
        <span class="home-off-arrow">${isSwap?'⇄':'→'}</span>
        ${homeOffRampIcon(rightKind)}
      </div>
      <div class="home-off-meta">
        <span class="home-off-status ${esc(status.toLowerCase().replace(/[^a-z0-9]+/g,'-'))}">${esc(status)}</span>
        <time>${esc(ago(x.filled_at||x.created_at))}</time>
      </div>
      <span class="chev">⌄</span>
    </div>
    <div class="tx-details hidden">
      <div><span>Provider</span><b>${esc(provider)}</b></div>
      <div><span>Pair</span><b>${esc(pair)}</b></div>
      <div><span>Side</span><b>${esc(side)}</b></div>
      <div><span>Reference</span><b>${esc(x.provider_ref||x.id||'')}</b></div>
    </div>
  </button>`;
}

function homeOffRamp(h){
  const exchanges=(h.money?.exchange||[]).slice(0,6);
  return `<section class="wrap section home-off-ramp">
    <div class="home-off-head">
      <h2>Off-ramp</h2>
      <div class="home-off-pager"><button disabled>‹</button><span>1</span><button disabled>›</button></div>
    </div>
    <div class="home-off-tabs">
      <button class="active">All</button>
      <button disabled>Deposits</button>
      <button disabled>Swaps</button>
      <button disabled>ACH</button>
    </div>
    <div class="home-off-list">
      ${exchanges.length
        ? exchanges.map(homeOffRampCard).join('')
        : `<div class="home-off-empty">
            <div class="home-off-empty-route">${homeOffRampIcon('sol')}<span>→</span>${homeOffRampIcon('provider')}</div>
            <strong>No off-ramp activity yet.</strong>
            <span>Confirmed exchange and payout-rail events will appear here.</span>
          </div>`}
    </div>
  </section>`;
}

'''

app = app[:start] + replacement + app[end:]
app_path.write_text(app)

css += r'''

/* home-off-ramp-v1 */
.home-off-ramp{padding-top:42px!important}
.home-off-head{
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap:12px;
  margin-bottom:10px;
}
.home-off-head h2{
  margin:0;
  font-size:18px;
  line-height:1;
  letter-spacing:-.03em;
  font-weight:650;
}
.home-off-pager{
  display:flex;
  align-items:center;
  gap:11px;
  color:#686868;
  font-size:8px;
}
.home-off-pager button{
  border:0;
  background:transparent;
  color:#666;
  padding:0;
  font-size:15px;
}
.home-off-tabs{
  display:flex;
  align-items:center;
  gap:10px;
  margin-bottom:14px;
}
.home-off-tabs button{
  border:0;
  background:transparent;
  color:#767676;
  padding:7px 9px;
  border-radius:999px;
  font-size:9px;
}
.home-off-tabs button.active{
  color:#fff;
  background:#191919;
}
.home-off-tabs button:disabled{opacity:.62}
.home-off-list{display:grid;gap:8px}
.home-off-card{
  width:100%;
  padding:12px;
  color:#fff;
  text-align:left;
  background:#191919;
  border:1px solid #303030;
  border-radius:14px;
}
.home-off-main{
  display:grid;
  grid-template-columns:minmax(0,1fr) auto auto 12px;
  align-items:center;
  gap:10px;
}
.home-off-copy{
  min-width:0;
  display:grid;
}
.home-off-copy strong{
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
  font-size:20px;
  line-height:1;
  letter-spacing:-.035em;
  font-weight:580;
}
.home-off-copy span{
  margin-top:5px;
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
  color:#9a9a9a;
  font-size:9px;
}
.home-off-route{
  display:flex;
  align-items:center;
  gap:6px;
}
.home-off-icon{
  width:34px;
  height:34px;
  display:grid;
  place-items:center;
  flex:0 0 auto;
  border-radius:50%;
  background:#050505;
  border:1px solid #272727;
  font-size:14px;
}
.home-off-usd{background:#101010;font-size:17px}
.home-off-x{font-size:15px;font-weight:800}
.home-off-provider{color:#8b68ff;font-size:12px}
.home-off-sol{font-size:18px;font-weight:800}
.home-off-arrow{color:#626262;font-size:13px}
.home-off-meta{
  min-width:58px;
  display:grid;
  justify-items:end;
  gap:6px;
}
.home-off-status{
  max-width:90px;
  padding:4px 7px;
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
  border-radius:999px;
  color:#c7a45c;
  background:#302817;
  font-size:7px;
  text-transform:capitalize;
}
.home-off-status.swapped,
.home-off-status.received,
.home-off-status.completed,
.home-off-status.sent{color:#c8c8c8;background:#303030}
.home-off-meta time{color:#828282;font-size:8px}
.home-off-main>.chev{color:#737373;font-size:11px}
.home-off-card .tx-details{
  margin-top:11px;
  padding-top:10px;
  border-top:1px solid #303030;
}
.home-off-empty{
  min-height:145px;
  display:grid;
  place-items:center;
  align-content:center;
  gap:7px;
  padding:20px;
  border:1px dashed #272727;
  border-radius:14px;
  color:#646464;
  text-align:center;
}
.home-off-empty-route{
  display:flex;
  align-items:center;
  gap:9px;
  margin-bottom:5px;
}
.home-off-empty-route>span{color:#5c5c5c}
.home-off-empty strong{font-size:9px;color:#777}
.home-off-empty>span{font-size:7px;color:#555}

@media(max-width:640px){
  .home-off-ramp{padding-top:38px!important}
  .home-off-head h2{font-size:16px}
  .home-off-card{padding:11px;border-radius:13px}
  .home-off-main{
    grid-template-columns:minmax(0,1fr) auto auto 10px;
    gap:7px;
  }
  .home-off-copy strong{font-size:18px}
  .home-off-copy span{font-size:8px;max-width:118px}
  .home-off-icon{width:31px;height:31px}
  .home-off-route{gap:4px}
  .home-off-meta{min-width:50px}
  .home-off-status{padding:4px 6px;font-size:6.5px}
}
'''
css_path.write_text(css)

print("Off-ramp v1 patch installed.")
PY

npm run check

git add src/app.js src/styles.css

if git diff --cached --quiet; then
  echo "No staged changes; nothing to commit."
else
  git commit -m "Match home off-ramp"
fi

git push origin main

echo
echo "DONE: Off-ramp patch checked, committed, and pushed to GitHub."
echo "No server restart was performed."
echo "Refresh the browser to see the updated Off-ramp section."
