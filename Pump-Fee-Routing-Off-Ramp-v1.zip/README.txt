Pump Fee Routing — Off-ramp v1
Scope: Home Off-ramp section only.
Matches the reference hierarchy with tabs, amount, route icons, status pill, time, chevron and expandable details.
Uses only real exchange-order data; no demo rows are inserted.
Runs npm check, commits, and pushes to origin/main. No automatic server restart.
