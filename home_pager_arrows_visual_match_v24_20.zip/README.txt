Home Pager Arrows Visual Match v24.20

The page number was already the requested Docs/Open size, but the Unicode ‹ ›
glyphs render visually smaller than a numeral at the same CSS font-size.

This patch keeps:
- page number: 13px desktop / 12px mobile

And changes arrows to:
- 20px desktop
- 18px mobile

This makes their visible height match the page number more closely.

Applies to:
- Top Tokens
- Top X Profiles
- Recent Payments
- Most Payments
- Off Ramp
- On Ramp

No automatic server restart.

Install in existing Replit Shell:

rm -rf /tmp/home_pager_arrows_visual_match_v24_20 && mkdir -p /tmp/home_pager_arrows_visual_match_v24_20 && unzip -o home_pager_arrows_visual_match_v24_20.zip -d /tmp/home_pager_arrows_visual_match_v24_20 && bash /tmp/home_pager_arrows_visual_match_v24_20/install.sh
