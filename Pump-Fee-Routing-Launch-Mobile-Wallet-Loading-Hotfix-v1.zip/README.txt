Pump Fee Routing — Launch Mobile Wallet Loading Hotfix v1

Fixes a regression introduced by Launch Mobile Wallet Connect v1.

Cause:
The new wallet MutationObserver watched the entire document subtree.
syncLaunchWalletUi() wrote button.textContent inside that observed subtree.
On Safari this can retrigger the observer repeatedly, starving the UI/event loop
and leaving the page on the generic "Syncing ledger..." loading screen.

Fix:
- Observe only direct page replacements inside #app.
- Do not rewrite Connect wallet / Launch token text when it is already correct.
- Preserve all mobile wallet connection functionality from the previous patch.
- No server restart is performed by installer.
