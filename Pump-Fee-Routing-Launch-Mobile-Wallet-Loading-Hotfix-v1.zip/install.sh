#!/usr/bin/env bash
set -euo pipefail

[ -f src/app.js ] || {
  echo "Missing src/app.js. Run this from the Pump-Fee-Routing project root."
  exit 1
}

if [ -n "$(git status --porcelain -- src/app.js)" ]; then
  echo "STOP: src/app.js has uncommitted changes."
  git status --short -- src/app.js
  exit 2
fi

python3 - <<'PY'
from pathlib import Path
import base64

p=Path("src/app.js")
s=p.read_text()

old_sync=base64.b64decode("ZnVuY3Rpb24gc3luY0xhdW5jaFdhbGxldFVpKCl7CiAgY29uc3QgcHJvdmlkZXI9c29sYW5hV2FsbGV0UHJvdmlkZXIoKTsKICBpZihwcm92aWRlciAmJiBwcm92aWRlci5wdWJsaWNLZXkpewogICAgY3VycmVudFdhbGxldD1wcm92aWRlcjsKICAgIGNvbnN0IGJ1dHRvbj1kb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcjbGF1bmNoU3VibWl0QnV0dG9uJyk7CiAgICBpZihidXR0b24gJiYgIWJ1dHRvbi5kaXNhYmxlZClidXR0b24udGV4dENvbnRlbnQ9J0xhdW5jaCB0b2tlbic7CiAgfWVsc2UgaWYobW9iaWxlQnJvd3NlcldpdGhvdXRXYWxsZXQoKSl7CiAgICBjb25zdCBidXR0b249ZG9jdW1lbnQucXVlcnlTZWxlY3RvcignI2xhdW5jaFN1Ym1pdEJ1dHRvbicpOwogICAgaWYoYnV0dG9uICYmICFidXR0b24uZGlzYWJsZWQpYnV0dG9uLnRleHRDb250ZW50PSdDb25uZWN0IHdhbGxldCc7CiAgfQp9").decode()
new_sync=base64.b64decode("ZnVuY3Rpb24gc3luY0xhdW5jaFdhbGxldFVpKCl7CiAgY29uc3QgcHJvdmlkZXI9c29sYW5hV2FsbGV0UHJvdmlkZXIoKTsKICBpZihwcm92aWRlciAmJiBwcm92aWRlci5wdWJsaWNLZXkpewogICAgY3VycmVudFdhbGxldD1wcm92aWRlcjsKICAgIGNvbnN0IGJ1dHRvbj1kb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcjbGF1bmNoU3VibWl0QnV0dG9uJyk7CiAgICBpZihidXR0b24gJiYgIWJ1dHRvbi5kaXNhYmxlZCAmJiBidXR0b24udGV4dENvbnRlbnQhPT0nTGF1bmNoIHRva2VuJylidXR0b24udGV4dENvbnRlbnQ9J0xhdW5jaCB0b2tlbic7CiAgfWVsc2UgaWYobW9iaWxlQnJvd3NlcldpdGhvdXRXYWxsZXQoKSl7CiAgICBjb25zdCBidXR0b249ZG9jdW1lbnQucXVlcnlTZWxlY3RvcignI2xhdW5jaFN1Ym1pdEJ1dHRvbicpOwogICAgaWYoYnV0dG9uICYmICFidXR0b24uZGlzYWJsZWQgJiYgYnV0dG9uLnRleHRDb250ZW50IT09J0Nvbm5lY3Qgd2FsbGV0JylidXR0b24udGV4dENvbnRlbnQ9J0Nvbm5lY3Qgd2FsbGV0JzsKICB9Cn0=").decode()
old_observer=base64.b64decode("aWYoZG9jdW1lbnQuYm9keSlsYXVuY2hXYWxsZXRSZXN0b3JlT2JzZXJ2ZXIub2JzZXJ2ZShkb2N1bWVudC5ib2R5LHtjaGlsZExpc3Q6dHJ1ZSxzdWJ0cmVlOnRydWV9KTs=").decode()
new_observer=base64.b64decode("aWYoYXBwKWxhdW5jaFdhbGxldFJlc3RvcmVPYnNlcnZlci5vYnNlcnZlKGFwcCx7Y2hpbGRMaXN0OnRydWV9KTs=").decode()

if "launch-mobile-wallet-connect-v1" not in s:
    raise SystemExit("The mobile wallet patch is not installed; hotfix target not found.")

if "launch-mobile-wallet-loading-hotfix-v1" in s:
    raise SystemExit("Launch Mobile Wallet Loading Hotfix v1 is already installed.")

if old_sync not in s:
    raise SystemExit("syncLaunchWalletUi anchor not found.")
if old_observer not in s:
    raise SystemExit("wallet MutationObserver anchor not found.")

s=s.replace(old_sync,new_sync,1)
s=s.replace(old_observer,new_observer,1)
s += "\n/* launch-mobile-wallet-loading-hotfix-v1 */\n"
p.write_text(s)

print("Launch Mobile Wallet Loading Hotfix v1 installed.")
PY

node --check src/app.js
npm run check

node <<'NODE'
const fs=require('fs');
const s=fs.readFileSync('src/app.js','utf8');
const checks=[
  ['wallet observer limited to #app direct children', s.includes("launchWalletRestoreObserver.observe(app,{childList:true})")],
  ['old body subtree observer removed', !s.includes("launchWalletRestoreObserver.observe(document.body,{childList:true,subtree:true})")],
  ['Launch token text write guarded', s.includes("button.textContent!=='Launch token'")],
  ['Connect wallet text write guarded', s.includes("button.textContent!=='Connect wallet'")],
  ['hotfix marker', s.includes('launch-mobile-wallet-loading-hotfix-v1')]
];
let bad=0;
for(const [name,ok] of checks){
  console.log((ok?'PASS':'FAIL')+' '+name);
  if(!ok)bad++;
}
if(bad)process.exit(1);
NODE

git add src/app.js
git commit -m "Fix wallet observer loading loop"
git push origin main

echo
echo "DONE: Launch Mobile Wallet Loading Hotfix v1 checked, committed, and pushed."
echo "Cause fixed: wallet MutationObserver was watching the entire document subtree and could retrigger itself when it changed the Connect wallet button text."
echo "It now watches only direct #app page replacements and skips no-op button text writes."
echo "No server restart was performed."
echo "Restart Console/Run manually once, then reload the page."
