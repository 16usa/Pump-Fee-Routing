Paid Top X Profiles v22

Target:
- Replit project: Pump Fee Routing
- Repository: 16usa/Pump-Fee-Routing
- Branch: main

Changes:
- Top X Profiles cards use Paid Profile-style internal layout.
- Name + blue verified badge when profile data says verified.
- @handle below the name.
- Paid Profile pill.
- Tokens and Received in the same bottom row.
- Supports banner/cover URL fields when available; otherwise uses the current dark fallback artwork.
- Existing X avatar resolver is preserved.
- No automatic server restart.

Install from the existing Replit Shell:
rm -rf /tmp/paid_top_x_profiles_v22 && mkdir -p /tmp/paid_top_x_profiles_v22 && unzip -o paid_top_x_profiles_v22.zip -d /tmp/paid_top_x_profiles_v22 && bash /tmp/paid_top_x_profiles_v22/install.sh
