#!/usr/bin/env bash
set -euo pipefail

PATCH_NAME="paid_top_x_profiles_v22"
APP="src/app.js"
CSS="src/styles.css"

echo "==> Installing ${PATCH_NAME}"

if [ ! -f "$APP" ] || [ ! -f "$CSS" ]; then
  echo "ERROR: Run this from the existing Replit project root."
  echo "Expected: $APP and $CSS"
  exit 1
fi

mkdir -p ".patch-backups/${PATCH_NAME}"
cp "$APP" ".patch-backups/${PATCH_NAME}/app.js.before"
cp "$CSS" ".patch-backups/${PATCH_NAME}/styles.css.before"

python3 - <<'PY'
from pathlib import Path
import re

app_path = Path("src/app.js")
css_path = Path("src/styles.css")

app = app_path.read_text()
css = css_path.read_text()

new_profile_fn = r'''function homeProfileCard(p,index=0){
  const name=p.display_name||p.handle||'Profile';
  const handle=String(p.handle||'').replace(/^@/,'');
  const tokens=Number(p.token_count||0);
  const received=Number(p.received||0);
  const verified=
    p.verified===true||
    p.is_verified===true||
    p.blue_verified===true||
    p.is_blue_verified===true||
    ['blue','business','government'].includes(String(p.verified_type||'').toLowerCase());
  const cover=String(
    p.banner_url||
    p.profile_banner_url||
    p.cover_url||
    p.header_url||
    ''
  ).trim();

  const verifiedBadge=verified
    ? `<span class="home-profile-verified" title="Verified" aria-label="Verified">
        <svg viewBox="0 0 22 22" aria-hidden="true">
          <path d="M20.4 11c0 1.02-.72 1.88-1.7 2.08.18 1-.3 2.02-1.2 2.52-.35.2-.74.29-1.12.27-.05.96-.72 1.82-1.66 2.12-.38.12-.78.13-1.15.04-.43.86-1.32 1.43-2.32 1.43s-1.89-.57-2.32-1.43c-.37.09-.77.08-1.15-.04-.94-.3-1.61-1.16-1.66-2.12-.38.02-.77-.07-1.12-.27-.9-.5-1.38-1.52-1.2-2.52A2.12 2.12 0 0 1 1.6 11c0-1.02.72-1.88 1.7-2.08-.18-1 .3-2.02 1.2-2.52.35-.2.74-.29 1.12-.27.05-.96.72-1.82 1.66-2.12.38-.12.78-.13 1.15-.04C8.86 3.11 9.75 2.54 10.75 2.54s1.89.57 2.32 1.43c.37-.09.77-.08 1.15.04.94.3 1.61 1.16 1.66 2.12.38-.02.77.07 1.12.27.9.5 1.38 1.52 1.2 2.52.98.2 1.7 1.06 1.7 2.08Z"/>
          <path class="check" d="m7.2 11.2 2.2 2.2 5.3-5.4"/>
        </svg>
      </span>`
    : '';

  const coverMedia=cover
    ? `<img class="home-profile-cover-image" src="${esc(cover)}" alt="" loading="lazy" decoding="async" onerror="this.style.display='none';this.nextElementSibling.style.display='block'"><div class="home-profile-cover-fallback" style="display:none"><span>${esc(initials(name))}</span></div>`
    : `<div class="home-profile-cover-fallback"><span>${esc(initials(name))}</span></div>`;

  return `<a class="home-profile-feature" data-profile-layout="v22" href="#/profile/${encodeURIComponent(handle)}">
    <div class="home-profile-cover home-profile-cover-${index%4}">
      ${coverMedia}
      <div class="home-profile-avatar">${recipientAvatar(handle,name,true,p.avatar_url||'')}</div>
    </div>

    <div class="home-profile-feature-body">
      <div class="home-profile-identity">
        <div class="home-profile-display-row">
          <strong>${esc(name)}</strong>
          ${verifiedBadge}
        </div>
        <span class="home-profile-handle">@${esc(handle)}</span>
      </div>

      <div class="home-profile-paid-badge">
        <i class="home-profile-paid-icon">$</i>
        <span>Paid Profile</span>
      </div>

      <div class="home-profile-feature-stats">
        <div class="home-profile-stat">
          <b>${fmtNum(tokens)}</b>
          <small>Tokens</small>
        </div>
        <div class="home-profile-stat">
          <b>${fmtMoney(received)}</b>
          <small>Received</small>
        </div>
      </div>
    </div>
  </a>`;
}

'''

pattern = re.compile(r'function homeProfileCard\(p,index=0\)\{.*?\n\}\n\n(?=function homeTopProfiles)', re.S)
matches = pattern.findall(app)

if len(matches) != 1:
    if 'data-profile-layout="v22"' in app:
        print("app.js: v22 markup already installed")
    else:
        raise SystemExit(f"ERROR: expected exactly one homeProfileCard() block, found {len(matches)}")
else:
    app = pattern.sub(new_profile_fn, app, count=1)
    app_path.write_text(app)
    print("app.js: Top X profile card markup updated")

marker = "/* top-x-profile-paid-layout-v22 */"
if marker not in css:
    css += r'''

/* top-x-profile-paid-layout-v22
   Internal Top X Profiles card layout matched to the Paid Profile reference. */
.home-profile-feature[data-profile-layout="v22"]{
  position:relative;
  display:block;
  min-width:0;
  overflow:hidden;
  color:#f5f5f5;
  background:#171717;
  border:1px solid #2c2c2c;
  border-radius:18px;
  text-decoration:none;
  box-shadow:none;
}

.home-profile-feature[data-profile-layout="v22"] .home-profile-cover{
  position:relative;
  height:154px;
  overflow:visible;
  border-bottom:0;
  background:#111;
}

.home-profile-feature[data-profile-layout="v22"] .home-profile-cover-image{
  position:absolute;
  inset:0;
  width:100%;
  height:100%;
  display:block;
  object-fit:cover;
  object-position:center;
}

.home-profile-feature[data-profile-layout="v22"] .home-profile-cover-fallback{
  position:absolute;
  inset:0;
  overflow:hidden;
  background:
    radial-gradient(circle at 18% 110%,rgba(255,255,255,.04),transparent 42%),
    linear-gradient(128deg,#101010 0%,#191919 56%,#101010 100%);
}

.home-profile-feature[data-profile-layout="v22"] .home-profile-cover-fallback span{
  position:absolute;
  right:18px;
  top:12px;
  color:rgba(255,255,255,.045);
  font-size:92px;
  line-height:.95;
  font-weight:780;
  letter-spacing:-.08em;
}

.home-profile-feature[data-profile-layout="v22"] .home-profile-avatar{
  position:absolute;
  z-index:4;
  left:20px;
  bottom:-35px;
}

.home-profile-feature[data-profile-layout="v22"] .home-profile-avatar .avatar{
  width:72px;
  height:72px;
  border:4px solid #171717;
  border-radius:50%;
  background:#111;
  box-shadow:0 0 0 1px rgba(255,255,255,.08);
  font-size:20px;
}

.home-profile-feature[data-profile-layout="v22"] .home-profile-avatar .avatar img{
  width:100%;
  height:100%;
  object-fit:cover;
  border-radius:inherit;
}

.home-profile-feature[data-profile-layout="v22"] .home-profile-feature-body{
  padding:45px 20px 18px;
}

.home-profile-feature[data-profile-layout="v22"] .home-profile-identity{
  min-width:0;
}

.home-profile-feature[data-profile-layout="v22"] .home-profile-display-row{
  min-width:0;
  display:flex;
  align-items:center;
  gap:6px;
}

.home-profile-feature[data-profile-layout="v22"] .home-profile-display-row>strong{
  min-width:0;
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
  color:#f7f7f7;
  font-size:21px;
  line-height:1.06;
  font-weight:720;
  letter-spacing:-.025em;
}

.home-profile-feature[data-profile-layout="v22"] .home-profile-verified{
  width:19px;
  height:19px;
  display:block;
  flex:0 0 19px;
}

.home-profile-feature[data-profile-layout="v22"] .home-profile-verified svg{
  width:100%;
  height:100%;
  display:block;
  fill:#1d9bf0;
}

.home-profile-feature[data-profile-layout="v22"] .home-profile-verified .check{
  fill:none;
  stroke:#fff;
  stroke-width:2.15;
  stroke-linecap:round;
  stroke-linejoin:round;
}

.home-profile-feature[data-profile-layout="v22"] .home-profile-handle{
  display:block;
  margin-top:3px;
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
  color:#717171;
  font-size:14px;
  line-height:1.1;
  font-weight:430;
}

.home-profile-feature[data-profile-layout="v22"] .home-profile-paid-badge{
  width:max-content;
  max-width:100%;
  height:25px;
  margin-top:8px;
  padding:0 8px;
  display:flex;
  align-items:center;
  gap:6px;
  border-radius:6px;
  background:#242424;
  color:#868686;
  font-size:12px;
  line-height:1;
  font-weight:480;
}

.home-profile-feature[data-profile-layout="v22"] .home-profile-paid-icon{
  width:16px;
  height:16px;
  display:grid;
  place-items:center;
  flex:0 0 16px;
  border:1.5px solid currentColor;
  border-radius:5px;
  color:#858585;
  font-size:10px;
  line-height:1;
  font-style:normal;
  font-weight:760;
}

.home-profile-feature[data-profile-layout="v22"] .home-profile-feature-stats{
  display:flex;
  align-items:baseline;
  justify-content:flex-start;
  flex-wrap:wrap;
  gap:9px 23px;
  margin-top:10px;
  padding:0;
  border:0;
}

.home-profile-feature[data-profile-layout="v22"] .home-profile-stat{
  min-width:0;
  display:flex;
  align-items:baseline;
  gap:6px;
}

.home-profile-feature[data-profile-layout="v22"] .home-profile-stat b{
  margin:0;
  color:#f5f5f5;
  font-size:18px;
  line-height:1;
  font-weight:690;
  letter-spacing:-.025em;
  white-space:nowrap;
}

.home-profile-feature[data-profile-layout="v22"] .home-profile-stat small{
  color:#747474;
  font-size:13px;
  line-height:1;
  font-weight:420;
  white-space:nowrap;
}

.home-profile-feature[data-profile-layout="v22"] .home-profile-cover-mark,
.home-profile-feature[data-profile-layout="v22"] .home-profile-open,
.home-profile-feature[data-profile-layout="v22"] .home-profile-feature-name{
  display:none!important;
}

@media(max-width:640px){
  .home-profile-feature[data-profile-layout="v22"]{
    border-radius:17px;
  }

  .home-profile-feature[data-profile-layout="v22"] .home-profile-cover{
    height:126px;
  }

  .home-profile-feature[data-profile-layout="v22"] .home-profile-cover-fallback span{
    right:14px;
    top:10px;
    font-size:78px;
  }

  .home-profile-feature[data-profile-layout="v22"] .home-profile-avatar{
    left:14px;
    bottom:-31px;
  }

  .home-profile-feature[data-profile-layout="v22"] .home-profile-avatar .avatar{
    width:64px;
    height:64px;
    border-width:3px;
    font-size:18px;
  }

  .home-profile-feature[data-profile-layout="v22"] .home-profile-feature-body{
    padding:40px 14px 15px;
  }

  .home-profile-feature[data-profile-layout="v22"] .home-profile-display-row{
    gap:5px;
  }

  .home-profile-feature[data-profile-layout="v22"] .home-profile-display-row>strong{
    font-size:18px;
  }

  .home-profile-feature[data-profile-layout="v22"] .home-profile-verified{
    width:17px;
    height:17px;
    flex-basis:17px;
  }

  .home-profile-feature[data-profile-layout="v22"] .home-profile-handle{
    margin-top:3px;
    font-size:12px;
  }

  .home-profile-feature[data-profile-layout="v22"] .home-profile-paid-badge{
    height:23px;
    margin-top:7px;
    padding:0 7px;
    gap:5px;
    font-size:11px;
  }

  .home-profile-feature[data-profile-layout="v22"] .home-profile-paid-icon{
    width:15px;
    height:15px;
    flex-basis:15px;
    font-size:9px;
  }

  .home-profile-feature[data-profile-layout="v22"] .home-profile-feature-stats{
    gap:8px 18px;
    margin-top:9px;
  }

  .home-profile-feature[data-profile-layout="v22"] .home-profile-stat{
    gap:5px;
  }

  .home-profile-feature[data-profile-layout="v22"] .home-profile-stat b{
    font-size:16px;
  }

  .home-profile-feature[data-profile-layout="v22"] .home-profile-stat small{
    font-size:12px;
  }
}
'''
    css_path.write_text(css)
    print("styles.css: v22 profile card styles appended")
else:
    print("styles.css: v22 styles already installed")
PY

echo "==> Running project check"
npm run check

echo "==> Git diff"
git diff -- src/app.js src/styles.css

git add src/app.js src/styles.css

if git diff --cached --quiet; then
  echo "==> No new changes to commit (patch is already installed)."
else
  git commit -m "Match Top X paid profile cards to reference"
  git push origin main
fi

echo
echo "PASS: ${PATCH_NAME} installed."
echo "No server restart was performed."
