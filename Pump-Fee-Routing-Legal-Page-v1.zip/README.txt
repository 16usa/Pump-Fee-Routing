Pump Fee Routing — Legal Page v1
Rebuilds #/legal into one Terms / Privacy / Disclosures page matching the current product design.
The legal copy is a product draft and explicitly retains a production-review warning.
No backend, payout, Solana, database or worker logic is changed.
Runs npm check, commits and pushes to origin/main. No automatic restart.
