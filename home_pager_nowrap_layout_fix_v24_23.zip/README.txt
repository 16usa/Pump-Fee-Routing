Home Pager No-Wrap Layout Fix v24.23

Problem:
After changing counters to "1 / 1", the v24.21 pager grid still used three equal columns.
The center column was too narrow on iPhone, so "1 / 1" wrapped onto two lines.

Fix:
- center column is now max-content;
- "1 / 1", "1 / 2", etc. are forced to stay on one line;
- right arrow remains anchored at the same right edge;
- wide spacing between left arrow / counter / right arrow is preserved;
- pager block is widened slightly to fit the longer counter.

Applies to:
Top Tokens, Top X Profiles, Recent Payments, Most Payments, Off-ramp, On-ramp.

No automatic server restart.

Install in the existing Replit Shell:

rm -rf /tmp/home_pager_nowrap_layout_fix_v24_23 && mkdir -p /tmp/home_pager_nowrap_layout_fix_v24_23 && unzip -o home_pager_nowrap_layout_fix_v24_23.zip -d /tmp/home_pager_nowrap_layout_fix_v24_23 && bash /tmp/home_pager_nowrap_layout_fix_v24_23/install.sh
