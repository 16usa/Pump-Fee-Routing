X OAuth Sign-in Session v24.56

Why the current screen fails:
- server/xoauth.js requires X_CLIENT_ID and a callback URL
- your server currently returns: "X OAuth is not configured"
- the previous callback also immediately opted the user out after login, which is not a normal sign-in flow

This patch changes the flow to:
1. Sign in with X
2. Server verifies the X account
3. Server creates a short-lived HttpOnly signed session cookie
4. The page shows the signed-in X account
5. The user must explicitly press "Confirm opt out"
6. Only then is the opt-out applied

It also:
- derives the callback URL from the current Replit HTTPS host when X_REDIRECT_URI is blank
- adds /api/auth/x/status
- adds /api/auth/x/session
- adds /api/auth/x/opt-out
- adds /api/auth/x/logout
- fixes the wrong X_BEARER_TOKEN example value
- does not store X access tokens in the browser or cookie
- does not restart the server

REQUIRED REPLIT SECRETS:
X_CLIENT_ID=<from your X Developer App>
X_SESSION_SECRET=<random 32+ byte secret>

IF YOUR X APP PROVIDES/REQUIRES IT:
X_CLIENT_SECRET=<from your X Developer App>

OPTIONAL:
X_REDIRECT_URI=https://YOUR-DOMAIN/api/auth/x/callback
If blank, the server derives it from the current request host.

IMPORTANT:
The exact callback URL used by your site must also be added to the X Developer App callback/redirect allowlist.

Generate a session secret in Replit Shell:
openssl rand -hex 32
Then copy the output into Replit Secrets as X_SESSION_SECRET.

X_BEARER_TOKEN is separate from OAuth login. It is only for server-side public profile lookup.
