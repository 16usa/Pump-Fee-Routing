from pathlib import Path
import re

ROOT = Path('.')
paths = {
    'config': ROOT / 'server/config.js',
    'db': ROOT / 'server/db.js',
    'xoauth': ROOT / 'server/xoauth.js',
    'api': ROOT / 'server/api.js',
    'app': ROOT / 'src/app.js',
    'css': ROOT / 'src/styles.css',
    'env': ROOT / '.env.example',
}
for key, p in paths.items():
    if not p.exists():
        raise SystemExit(f'ERROR: missing {p}. Run from the existing Replit project root.')

# server/config.js
p = paths['config']
s = p.read_text()
if 'xSessionSecret:' not in s:
    old = """  xClientId: process.env.X_CLIENT_ID || '',
  xClientSecret: process.env.X_CLIENT_SECRET || '',
  xRedirectUri: process.env.X_REDIRECT_URI || '',
  xBearerToken: process.env.X_BEARER_TOKEN || process.env.TWITTER_BEARER_TOKEN || '',
"""
    new = """  xClientId: process.env.X_CLIENT_ID || '',
  xClientSecret: process.env.X_CLIENT_SECRET || '',
  xRedirectUri: process.env.X_REDIRECT_URI || '',
  xSessionSecret: process.env.X_SESSION_SECRET || '',
  xBearerToken: process.env.X_BEARER_TOKEN || process.env.TWITTER_BEARER_TOKEN || '',
"""
    if old not in s:
        raise SystemExit('ERROR: X OAuth config block not found in server/config.js')
    s = s.replace(old, new, 1)
    p.write_text(s)

# server/db.js
p = paths['db']
s = p.read_text()
old_table = """    CREATE TABLE IF NOT EXISTS oauth_states (
      state TEXT PRIMARY KEY,
      code_verifier TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
"""
new_table = """    CREATE TABLE IF NOT EXISTS oauth_states (
      state TEXT PRIMARY KEY,
      code_verifier TEXT NOT NULL,
      redirect_uri TEXT,
      created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
"""
if old_table in s:
    s = s.replace(old_table, new_table, 1)
if 'const oauthStateColumns=' not in s:
    anchor = """  /* x-profile-banner-columns-v22-1 */
  const recipientColumns=new Set(
"""
    insert = """  const oauthStateColumns=new Set(
    db.prepare('PRAGMA table_info(oauth_states)').all().map(row=>String(row.name||''))
  );
  if(!oauthStateColumns.has('redirect_uri')) db.exec('ALTER TABLE oauth_states ADD COLUMN redirect_uri TEXT');

  /* x-profile-banner-columns-v22-1 */
  const recipientColumns=new Set(
"""
    if anchor not in s:
        raise SystemExit('ERROR: db migration anchor not found')
    s = s.replace(anchor, insert, 1)
p.write_text(s)

# server/xoauth.js
paths['xoauth'].write_text(r"""import crypto from 'node:crypto';
import { config } from './config.js';
import { db } from './db.js';

const b64url = b => Buffer.from(b).toString('base64url');
const parseB64Json = value => JSON.parse(Buffer.from(value,'base64url').toString('utf8'));

function sessionSecret(){
  return String(
    config.xSessionSecret ||
    config.xClientSecret ||
    config.webhookSecret ||
    config.adminToken ||
    ''
  ).trim();
}

export function xOAuthConfigured(){
  return Boolean(config.xClientId);
}

export function startXOAuth({redirectUri}={}){
  const callback=String(redirectUri||config.xRedirectUri||'').trim();
  if(!config.xClientId) throw Object.assign(new Error('X OAuth client ID is not configured'),{statusCode:503});
  if(!callback) throw Object.assign(new Error('X OAuth callback URL is not configured'),{statusCode:503});

  db.prepare(`DELETE FROM oauth_states WHERE created_at < datetime('now','-20 minutes')`).run();

  const state=b64url(crypto.randomBytes(24));
  const verifier=b64url(crypto.randomBytes(48));
  const challenge=b64url(crypto.createHash('sha256').update(verifier).digest());

  db.prepare(`INSERT INTO oauth_states(state,code_verifier,redirect_uri) VALUES(?,?,?)`)
    .run(state,verifier,callback);

  const u=new URL('https://x.com/i/oauth2/authorize');
  u.searchParams.set('response_type','code');
  u.searchParams.set('client_id',config.xClientId);
  u.searchParams.set('redirect_uri',callback);
  u.searchParams.set('scope','users.read');
  u.searchParams.set('state',state);
  u.searchParams.set('code_challenge',challenge);
  u.searchParams.set('code_challenge_method','S256');
  return u.toString();
}

export async function finishXOAuth({code,state}){
  if(!code) throw Object.assign(new Error('X did not return an authorization code'),{statusCode:400});
  if(!state) throw Object.assign(new Error('Missing OAuth state'),{statusCode:400});

  const row=db.prepare('SELECT * FROM oauth_states WHERE state=?').get(state);
  if(!row) throw Object.assign(new Error('Invalid or expired OAuth state'),{statusCode:400});
  db.prepare('DELETE FROM oauth_states WHERE state=?').run(state);

  const redirectUri=String(row.redirect_uri||config.xRedirectUri||'').trim();
  if(!redirectUri) throw Object.assign(new Error('OAuth callback URL is missing'),{statusCode:500});

  const form=new URLSearchParams({
    code,
    grant_type:'authorization_code',
    client_id:config.xClientId,
    redirect_uri:redirectUri,
    code_verifier:row.code_verifier
  });

  const headers={'content-type':'application/x-www-form-urlencoded'};
  if(config.xClientSecret){
    headers.authorization='Basic '+Buffer.from(`${config.xClientId}:${config.xClientSecret}`).toString('base64');
  }

  const tr=await fetch('https://api.x.com/2/oauth2/token',{method:'POST',headers,body:form});
  const tj=await tr.json().catch(()=>({}));
  if(!tr.ok){
    throw Object.assign(
      new Error(tj.error_description||tj.error||`X token exchange failed (${tr.status})`),
      {statusCode:502}
    );
  }

  const me=await fetch(
    'https://api.x.com/2/users/me?user.fields=name,username,profile_image_url',
    {headers:{authorization:`Bearer ${tj.access_token}`,accept:'application/json'}}
  );
  const mj=await me.json().catch(()=>({}));
  if(!me.ok){
    throw Object.assign(new Error(mj.detail||mj.title||`X users/me failed (${me.status})`),{statusCode:502});
  }
  return mj.data;
}

export function createXSession(user){
  const secret=sessionSecret();
  if(!secret){
    throw Object.assign(
      new Error('X session secret is not configured. Set X_SESSION_SECRET in Replit Secrets.'),
      {statusCode:503}
    );
  }
  const now=Math.floor(Date.now()/1000);
  const payload=b64url(JSON.stringify({
    id:String(user?.id||''),
    username:String(user?.username||''),
    name:String(user?.name||user?.username||''),
    profile_image_url:String(user?.profile_image_url||''),
    iat:now,
    exp:now+1800
  }));
  const sig=crypto.createHmac('sha256',secret).update(payload).digest('base64url');
  return `${payload}.${sig}`;
}

export function readXSession(token){
  const secret=sessionSecret();
  if(!secret || !token) return null;
  const [payload,sig]=String(token).split('.');
  if(!payload||!sig) return null;

  const expected=crypto.createHmac('sha256',secret).update(payload).digest('base64url');
  const aa=Buffer.from(sig),bb=Buffer.from(expected);
  if(aa.length!==bb.length || !crypto.timingSafeEqual(aa,bb)) return null;

  try{
    const data=parseB64Json(payload);
    if(!data?.username || Number(data.exp||0)<Math.floor(Date.now()/1000)) return null;
    return data;
  }catch{
    return null;
  }
}
""")

# server/api.js
p = paths['api']
s = p.read_text()
old_import = "import { startXOAuth, finishXOAuth } from './xoauth.js';"
new_import = "import { startXOAuth, finishXOAuth, createXSession, readXSession, xOAuthConfigured } from './xoauth.js';"
if old_import in s:
    s = s.replace(old_import, new_import, 1)
elif new_import not in s:
    raise SystemExit('ERROR: X OAuth import not found in server/api.js')

helper_anchor = "function requireUserSignedLaunch(){ if(!config.userSignedLaunchEnabled)throw Object.assign(new Error('User-signed launch is disabled'),{statusCode:423}); }\n"
if 'function requestOrigin(req)' not in s:
    helpers = helper_anchor + r"""
function requestOrigin(req){
  const forwardedProto=String(req.headers['x-forwarded-proto']||'').split(',')[0].trim();
  const forwardedHost=String(req.headers['x-forwarded-host']||'').split(',')[0].trim();
  const proto=forwardedProto || (req.socket?.encrypted?'https':'http');
  const host=forwardedHost || String(req.headers.host||'localhost');
  return `${proto}://${host}`;
}
function xCallbackUri(req){
  return config.xRedirectUri || `${requestOrigin(req)}/api/auth/x/callback`;
}
function cookieValue(req,name){
  const raw=String(req.headers.cookie||'');
  for(const part of raw.split(';')){
    const i=part.indexOf('=');
    if(i<0)continue;
    const key=part.slice(0,i).trim();
    if(key===name)return decodeURIComponent(part.slice(i+1).trim());
  }
  return '';
}
function xSessionCookie(req,value,maxAge=1800){
  const secure=requestOrigin(req).startsWith('https://')?'; Secure':'';
  return `x_session=${encodeURIComponent(value)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}${secure}`;
}
function xSessionUser(req){
  return readXSession(cookieValue(req,'x_session'));
}
"""
    if helper_anchor not in s:
        raise SystemExit('ERROR: API helper anchor not found')
    s = s.replace(helper_anchor, helpers, 1)

old_routes = """    if(req.method==='GET'&&url.pathname==='/api/auth/x/start'){ const dest=startXOAuth(); res.writeHead(302,{location:dest}); return res.end(); }
    if(req.method==='GET'&&url.pathname==='/api/auth/x/callback'){ const user=await finishXOAuth({code:url.searchParams.get('code'),state:url.searchParams.get('state')}); if(!user?.username)throw new Error('X did not return a username'); const result=optOutHandle(user.username); res.writeHead(302,{location:`/#/opt-out?done=${encodeURIComponent(result.handle)}`}); return res.end(); }
"""
new_routes = """    if(req.method==='GET'&&url.pathname==='/api/auth/x/status'){
      return json(res,200,{
        configured:xOAuthConfigured(),
        callbackUrl:xCallbackUri(req),
        hasClientSecret:Boolean(config.xClientSecret),
        hasSessionSecret:Boolean(config.xSessionSecret||config.xClientSecret||config.webhookSecret||config.adminToken)
      });
    }
    if(req.method==='GET'&&url.pathname==='/api/auth/x/start'){
      try{
        const dest=startXOAuth({redirectUri:xCallbackUri(req)});
        res.writeHead(302,{location:dest,'cache-control':'no-store'});
        return res.end();
      }catch(e){
        res.writeHead(302,{location:`/#/opt-out?oauth_error=${encodeURIComponent(e.message||'X OAuth is not configured')}`,'cache-control':'no-store'});
        return res.end();
      }
    }
    if(req.method==='GET'&&url.pathname==='/api/auth/x/callback'){
      const denied=url.searchParams.get('error');
      if(denied){
        res.writeHead(302,{location:`/#/opt-out?oauth_error=${encodeURIComponent(url.searchParams.get('error_description')||denied)}`,'cache-control':'no-store'});
        return res.end();
      }
      const user=await finishXOAuth({code:url.searchParams.get('code'),state:url.searchParams.get('state')});
      if(!user?.username)throw Object.assign(new Error('X did not return a username'),{statusCode:502});
      const token=createXSession(user);
      res.writeHead(302,{
        location:'/#/opt-out?auth=1',
        'set-cookie':xSessionCookie(req,token,1800),
        'cache-control':'no-store'
      });
      return res.end();
    }
    if(req.method==='GET'&&url.pathname==='/api/auth/x/session'){
      const user=xSessionUser(req);
      return json(res,200,{authenticated:Boolean(user),user:user?{
        id:user.id,username:user.username,name:user.name,profile_image_url:user.profile_image_url
      }:null});
    }
    if(req.method==='POST'&&url.pathname==='/api/auth/x/opt-out'){
      const user=xSessionUser(req);
      if(!user)throw Object.assign(new Error('Sign in with X first'),{statusCode:401});
      const result=optOutHandle(user.username);
      res.setHeader('set-cookie',xSessionCookie(req,'',0));
      return json(res,200,{ok:true,handle:result.handle});
    }
    if(req.method==='POST'&&url.pathname==='/api/auth/x/logout'){
      res.setHeader('set-cookie',xSessionCookie(req,'',0));
      return json(res,200,{ok:true});
    }
"""
if old_routes in s:
    s = s.replace(old_routes, new_routes, 1)
elif '/api/auth/x/session' not in s:
    raise SystemExit('ERROR: current X OAuth API routes not found')
p.write_text(s)

# src/app.js
p = paths['app']
s = p.read_text()
old_render = "else if(path==='opt-out')page=optOutPage();"
if old_render in s:
    s = s.replace(old_render, "else if(path==='opt-out')page=await optOutPage();", 1)

start = s.find('function optOutPage(){')
end = s.find('\nfunction tokenDetailClaimCard', start)
if start < 0 or end < 0:
    raise SystemExit('ERROR: optOutPage block not found')

new_optout = r'''async function optOutPage(){
  const raw=(location.hash||'').split('?')[1]||'';
  const qs=new URLSearchParams(raw);
  const done=qs.get('done')||'';
  const oauthError=qs.get('oauth_error')||'';

  let auth={authenticated:false,user:null};
  let oauthStatus={configured:false,callbackUrl:'',hasClientSecret:false,hasSessionSecret:false};
  if(!done){
    try{auth=await api('/api/auth/x/session');}catch{}
    try{oauthStatus=await api('/api/auth/x/status');}catch{}
  }
  const user=auth?.authenticated?auth.user:null;

  return `<main class="optout-page-v1">
    <section class="wrap optout-hero">
      <h1>Opt out of ${esc(state.brand.name)}</h1>
      <p>Sign in with X to stop payments to your account and keep tokens that name you off this site.</p>
    </section>

    <section class="wrap optout-card">
      <p class="eyebrow">Opt out</p>
      <h2>Turn off everything tied to your handle</h2>
      <p class="optout-lead">${esc(state.brand.name)} pays creator-fee distributions to the X account a token names. If that is you and you do not want it, opting out disables the recipient flow for your handle.</p>

      <div class="optout-effects">
        <div><b>1</b><section><h3>Payments stop</h3><p>We will not send future X Money-style payouts to your account.</p></section></div>
        <div><b>2</b><section><h3>Tokens naming you are hidden</h3><p>They are removed from Explore, Payments, search and your public profile views.</p></section></div>
        <div><b>3</b><section><h3>Unpaid fees move to protocol accounting</h3><p>Future unpaid recipient accounting can be diverted to the protocol allocation and pending $PAID buyback ledger.</p></section></div>
        <div><b>4</b><section><h3>Launches here cannot pick you</h3><p>The launch flow rejects a recipient handle that has opted out.</p></section></div>
      </div>

      <div class="optout-limit">
        <h3>What we cannot stop</h3>
        <p>Anyone can still create a token on third-party launch venues using your handle or name. We do not control those venues. We can stop listing it here and stop paying your handle from it.</p>
      </div>

      <p class="optout-auth-note">Signing in verifies that the request comes from the X account owner. Opt-out happens only after a separate confirmation.</p>
    </section>

    <section class="wrap optout-status-card">
      ${done ? `
        <div class="optout-success">
          <div class="optout-success-icon">✓</div>
          <div>
            <span>Opted out</span>
            <h2>@${esc(done)}</h2>
            <p>Payments and launch selection for this handle are now disabled by the backend.</p>
          </div>
        </div>
        <div class="optout-check-grid">
          <div><span>Your X account</span><b>@${esc(done)}</b></div>
          <div><span>X Money payments</span><b>Stopped</b></div>
          <div><span>Tokens shown here</span><b>Hidden</b></div>
          <div><span>Selectable at launch</span><b>No</b></div>
        </div>
      ` : user ? `
        <div class="optout-checking optout-authenticated">
          <span>Signed in</span>
          <h2>${esc(user.name||user.username)}</h2>
          <p class="optout-auth-handle">@${esc(user.username)}</p>
          <div class="optout-check-grid">
            <div><span>X account</span><b>Verified</b></div>
            <div><span>X Money payments</span><b>Ready to stop</b></div>
            <div><span>Tokens shown here</span><b>Ready to hide</b></div>
            <div><span>Unpaid fees</span><b>Confirm required</b></div>
          </div>
        </div>

        <div class="optout-auth-actions">
          <button class="btn-light full center-button optout-x-button" type="button" data-action="confirm-opt-out">Confirm opt out</button>
          <button class="optout-secondary-button" type="button" data-action="x-logout">Sign out</button>
        </div>
      ` : `
        <div class="optout-checking">
          <span>Checking</span>
          <h2>Your X account</h2>
          <div class="optout-check-grid">
            <div><span>X Money payments</span><b>—</b></div>
            <div><span>Tokens shown here</span><b>—</b></div>
            <div><span>Selectable at launch</span><b>—</b></div>
            <div><span>Unpaid fees</span><b>—</b></div>
          </div>
        </div>

        <a class="btn-light full center-button optout-x-button" href="/api/auth/x/start">Sign in with X</a>
        ${oauthError?`<div class="status-box optout-env-note optout-oauth-error">${esc(oauthError)}</div>`:''}
        ${!oauthStatus.configured?`<div class="status-box optout-env-note">X OAuth needs an X Developer App client ID before sign-in can start.</div>`:''}
      `}

      <div class="optout-progress">
        <div class="${done||user?'done':'active'}"><b>1</b><span>Sign in with X</span></div>
        <div class="${done?'done':user?'active':''}"><b>2</b><span>Confirm</span></div>
        <div class="${done?'done':''}"><b>3</b><span>Opted out</span></div>
      </div>
    </section>

    ${moneyFooter()}
  </main>`;
}
'''
s = s[:start] + new_optout + s[end:]

action_anchor = "const a=e.target.closest('[data-action]');if(a){const action=a.dataset.action;"
if "action==='confirm-opt-out'" not in s:
    addition = action_anchor + "if(action==='confirm-opt-out'){e.preventDefault();a.disabled=true;a.textContent='Confirming…';const result=await api('/api/auth/x/opt-out',{method:'POST',body:'{}'});location.hash=`#/opt-out?done=${encodeURIComponent(result.handle)}`;return;}if(action==='x-logout'){e.preventDefault();await api('/api/auth/x/logout',{method:'POST',body:'{}'});location.hash='#/opt-out';await render();return;}"
    if action_anchor not in s:
        raise SystemExit('ERROR: app click-action anchor not found')
    s = s.replace(action_anchor, addition, 1)
p.write_text(s)

# src/styles.css
p = paths['css']
s = p.read_text()
if '/* x-oauth-signin-session-v24-56 */' not in s:
    s += r'''

/* x-oauth-signin-session-v24-56 */
.optout-auth-handle{
  margin:4px 0 18px;
  color:var(--muted,#8b8b8b);
}
.optout-auth-actions{
  display:grid;
  gap:10px;
}
.optout-secondary-button{
  width:100%;
  min-height:48px;
  border:1px solid var(--line,#272727);
  border-radius:999px;
  background:#0A0A0A;
  color:#fff;
  font:inherit;
  font-weight:700;
  cursor:pointer;
}
.optout-oauth-error{
  border-color:#5a2b2b !important;
}
'''
    p.write_text(s)

# .env.example
p = paths['env']
s = p.read_text()
if 'X_SESSION_SECRET=' not in s:
    old = """X_CLIENT_ID=
X_CLIENT_SECRET=
X_REDIRECT_URI=
X_BEARER_TOKEN=http://localhost:3000/api/auth/x/callback
"""
    new = """X_CLIENT_ID=
X_CLIENT_SECRET=
# Optional: if blank, the server derives the callback from the current HTTPS host.
# If you set this, it must exactly match the callback URL registered in your X Developer App.
X_REDIRECT_URI=
# Random 32+ byte secret used only to sign short-lived login cookies.
X_SESSION_SECRET=
# Optional and separate from OAuth login; used for server-side public X profile lookups.
X_BEARER_TOKEN=
"""
    if old not in s:
        raise SystemExit('ERROR: X env block not found in .env.example')
    s = s.replace(old, new, 1)
    p.write_text(s)

print('PASS: X OAuth sign-in now creates a short-lived signed session.')
print('PASS: OAuth callback no longer opts the user out automatically.')
print('PASS: Opt-out now requires an explicit Confirm button after X sign-in.')
print('PASS: Callback URL can be derived from the current Replit HTTPS host.')
print('PASS: .env.example X_BEARER_TOKEN placeholder bug fixed.')
