#!/usr/bin/env bash
set -euo pipefail

PATCH_NAME="x_oauth_signin_session_v24_56"
FILES=(server/config.js server/db.js server/xoauth.js server/api.js src/app.js src/styles.css .env.example)

for f in "${FILES[@]}"; do
  if [ ! -f "$f" ]; then
    echo "ERROR: missing $f"
    echo "Run this from the existing Replit project root."
    exit 1
  fi
done

echo "==> Installing ${PATCH_NAME}"
BACKUP=".patch-backups/${PATCH_NAME}"
mkdir -p "$BACKUP/server" "$BACKUP/src"
cp server/config.js "$BACKUP/server/config.js.before"
cp server/db.js "$BACKUP/server/db.js.before"
cp server/xoauth.js "$BACKUP/server/xoauth.js.before"
cp server/api.js "$BACKUP/server/api.js.before"
cp src/app.js "$BACKUP/src/app.js.before"
cp src/styles.css "$BACKUP/src/styles.css.before"
cp .env.example "$BACKUP/.env.example.before"

python3 "$(dirname "$0")/patch.py"

echo "==> Syntax checks"
node --check server/config.js
node --check server/db.js
node --check server/xoauth.js
node --check server/api.js
node --check src/app.js

echo "==> Project check"
npm run check

echo "==> Verifying OAuth routes"
grep -q "/api/auth/x/session" server/api.js
grep -q "/api/auth/x/opt-out" server/api.js
grep -q "X_SESSION_SECRET" server/config.js
grep -q "Confirm opt out" src/app.js

echo "==> Git diff"
git diff --stat -- "${FILES[@]}"

git add "${FILES[@]}"
if git diff --cached --quiet; then
  echo "==> No new changes to commit."
else
  git commit -m "Make X OAuth sign-in session explicit and safe"
  git push origin main
fi

echo
echo "PASS: ${PATCH_NAME} installed."
echo "No server restart was performed."
echo
echo "NEXT: add X_CLIENT_ID and X_SESSION_SECRET in Replit Secrets."
echo "If your X app has a client secret, add X_CLIENT_SECRET too."
echo "Register this exact callback in the X Developer App:"
echo "  https://YOUR-REPLIT-HOST/api/auth/x/callback"
