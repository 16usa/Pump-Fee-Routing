X OAuth State Fix v24.57

Problem confirmed:
X authorization succeeds and returns to the app, but callback fails with:
  Invalid or expired OAuth state

Why:
The old flow stores state + PKCE verifier only in local SQLite and expects the
callback to land on the same runtime/data copy. Replit preview host aliases,
runtime replacement, or process lifecycle can break that assumption.

Fix:
- OAuth transaction is encrypted/authenticated into the state parameter using AES-256-GCM derived from X_SESSION_SECRET.
- PKCE verifier is not exposed in plaintext.
- Callback no longer depends on a local oauth_states row for new sign-ins.
- Existing SQLite state remains as fallback for already-started flows.
- Scope becomes: tweet.read users.read.
- No other auth/session/opt-out behavior changes.
- No automatic server restart.

After install:
1. Restart the Replit app manually.
2. Return to the site's Opt out page.
3. Press Sign in with X again.
4. Do NOT reuse an old X authorization/callback tab.
