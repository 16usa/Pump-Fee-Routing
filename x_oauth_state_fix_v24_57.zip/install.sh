#!/usr/bin/env bash
set -euo pipefail

PATCH_NAME="x_oauth_state_fix_v24_57"
FILE="server/xoauth.js"

if [ ! -f "$FILE" ]; then
  echo "ERROR: missing $FILE"
  echo "Run this from the existing Replit project root."
  exit 1
fi

echo "==> Installing ${PATCH_NAME}"
mkdir -p ".patch-backups/${PATCH_NAME}/server"
cp "$FILE" ".patch-backups/${PATCH_NAME}/server/xoauth.js.before"

python3 "$(dirname "$0")/patch.py"

echo "==> Verifying patch"
grep -q 'x-oauth-state-fix-v24-57' "$FILE"
grep -q 'aes-256-gcm' "$FILE"
grep -q 'tweet.read users.read' "$FILE"

echo "==> Syntax check"
node --check "$FILE"

echo "==> Project check"
npm run check

echo "==> Git diff"
git diff --stat -- "$FILE"

git add "$FILE"
if git diff --cached --quiet; then
  echo "==> No new changes to commit."
else
  git commit -m "Make X OAuth state portable across Replit restarts"
  git push origin main
fi

echo
echo "PASS: ${PATCH_NAME} installed."
echo "No server restart was performed."
echo "After installing, restart manually and start a NEW Sign in with X flow."
