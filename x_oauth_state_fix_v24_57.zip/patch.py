from pathlib import Path

xoauth_path = Path('server/xoauth.js')
if not xoauth_path.exists():
    raise SystemExit('ERROR: server/xoauth.js not found. Run this from the existing Replit project root.')

src = xoauth_path.read_text()
marker = '/* x-oauth-state-fix-v24-57 */'

if marker in src:
    print('No changes needed; v24.57 already installed.')
    raise SystemExit(0)

old_helpers = """const b64url = b => Buffer.from(b).toString('base64url');
const parseB64Json = value => JSON.parse(Buffer.from(value,'base64url').toString('utf8'));

function sessionSecret(){
"""
new_helpers = """const b64url = b => Buffer.from(b).toString('base64url');
const fromB64url = value => Buffer.from(String(value||''),'base64url');
const parseB64Json = value => JSON.parse(Buffer.from(value,'base64url').toString('utf8'));

/* x-oauth-state-fix-v24-57
   Keep PKCE state/verifier portable across Replit restarts/host aliases by
   sealing the OAuth transaction into an authenticated, encrypted state token.
   No browser-readable verifier and no dependency on one SQLite/process copy. */
function sessionSecret(){
"""
if old_helpers not in src:
    raise SystemExit('ERROR: xoauth helper anchor not found')
src = src.replace(old_helpers, new_helpers, 1)

old_after_secret = """  ).trim();
}

export function xOAuthConfigured(){
"""
new_after_secret = """  ).trim();
}

function oauthStateKey(){
  const secret=sessionSecret();
  if(!secret){
    throw Object.assign(
      new Error('X session secret is not configured. Set X_SESSION_SECRET in Replit Secrets.'),
      {statusCode:503}
    );
  }
  return crypto.createHash('sha256').update(secret).digest();
}

function sealOAuthState(payload){
  const iv=crypto.randomBytes(12);
  const cipher=crypto.createCipheriv('aes-256-gcm',oauthStateKey(),iv);
  const plaintext=Buffer.from(JSON.stringify(payload),'utf8');
  const encrypted=Buffer.concat([cipher.update(plaintext),cipher.final()]);
  const tag=cipher.getAuthTag();
  return `v1.${b64url(iv)}.${b64url(tag)}.${b64url(encrypted)}`;
}

function openOAuthState(token){
  const parts=String(token||'').split('.');
  if(parts.length!==4 || parts[0]!=='v1') return null;
  try{
    const iv=fromB64url(parts[1]);
    const tag=fromB64url(parts[2]);
    const encrypted=fromB64url(parts[3]);
    const decipher=crypto.createDecipheriv('aes-256-gcm',oauthStateKey(),iv);
    decipher.setAuthTag(tag);
    const plaintext=Buffer.concat([decipher.update(encrypted),decipher.final()]);
    const data=JSON.parse(plaintext.toString('utf8'));
    if(!data?.codeVerifier || !data?.redirectUri) return null;
    if(Number(data.expiresAt||0)<Date.now()) return null;
    return data;
  }catch{
    return null;
  }
}

export function xOAuthConfigured(){
"""
if old_after_secret not in src:
    raise SystemExit('ERROR: sessionSecret closing anchor not found')
src = src.replace(old_after_secret, new_after_secret, 1)

old_start = """  db.prepare(`DELETE FROM oauth_states WHERE created_at < datetime('now','-20 minutes')`).run();

  const state=b64url(crypto.randomBytes(24));
  const verifier=b64url(crypto.randomBytes(48));
  const challenge=b64url(crypto.createHash('sha256').update(verifier).digest());

  db.prepare(`INSERT INTO oauth_states(state,code_verifier,redirect_uri) VALUES(?,?,?)`)
    .run(state,verifier,callback);

  const u=new URL('https://x.com/i/oauth2/authorize');
  u.searchParams.set('response_type','code');
  u.searchParams.set('client_id',config.xClientId);
  u.searchParams.set('redirect_uri',callback);
  u.searchParams.set('scope','users.read');
"""
new_start = """  db.prepare(`DELETE FROM oauth_states WHERE created_at < datetime('now','-20 minutes')`).run();

  const verifier=b64url(crypto.randomBytes(48));
  const challenge=b64url(crypto.createHash('sha256').update(verifier).digest());
  const state=sealOAuthState({
    codeVerifier:verifier,
    redirectUri:callback,
    expiresAt:Date.now()+(15*60*1000),
    nonce:b64url(crypto.randomBytes(16))
  });

  const u=new URL('https://x.com/i/oauth2/authorize');
  u.searchParams.set('response_type','code');
  u.searchParams.set('client_id',config.xClientId);
  u.searchParams.set('redirect_uri',callback);
  u.searchParams.set('scope','tweet.read users.read');
"""
if old_start not in src:
    raise SystemExit('ERROR: current startXOAuth block not found')
src = src.replace(old_start, new_start, 1)

old_finish = """  const row=db.prepare('SELECT * FROM oauth_states WHERE state=?').get(state);
  if(!row) throw Object.assign(new Error('Invalid or expired OAuth state'),{statusCode:400});
  db.prepare('DELETE FROM oauth_states WHERE state=?').run(state);

  const redirectUri=String(row.redirect_uri||config.xRedirectUri||'').trim();
  if(!redirectUri) throw Object.assign(new Error('OAuth callback URL is missing'),{statusCode:500});

  const form=new URLSearchParams({
    code,
    grant_type:'authorization_code',
    client_id:config.xClientId,
    redirect_uri:redirectUri,
    code_verifier:row.code_verifier
  });
"""
new_finish = """  let transaction=openOAuthState(state);

  /* Backward-compatible fallback for an authorization flow started before this patch. */
  if(!transaction){
    const row=db.prepare('SELECT * FROM oauth_states WHERE state=?').get(state);
    if(row){
      db.prepare('DELETE FROM oauth_states WHERE state=?').run(state);
      transaction={
        codeVerifier:row.code_verifier,
        redirectUri:String(row.redirect_uri||config.xRedirectUri||'').trim()
      };
    }
  }

  if(!transaction){
    throw Object.assign(
      new Error('Invalid or expired OAuth state. Start sign-in again from the site.'),
      {statusCode:400}
    );
  }

  const redirectUri=String(transaction.redirectUri||config.xRedirectUri||'').trim();
  if(!redirectUri) throw Object.assign(new Error('OAuth callback URL is missing'),{statusCode:500});

  const form=new URLSearchParams({
    code,
    grant_type:'authorization_code',
    client_id:config.xClientId,
    redirect_uri:redirectUri,
    code_verifier:transaction.codeVerifier
  });
"""
if old_finish not in src:
    raise SystemExit('ERROR: current finishXOAuth block not found')
src = src.replace(old_finish, new_finish, 1)

xoauth_path.write_text(src)
print('PASS: X OAuth state is now encrypted/stateless across Replit process or host changes.')
print('PASS: PKCE verifier is recovered from sealed state, not dependent on SQLite.')
print('PASS: OAuth scope updated to tweet.read users.read.')
