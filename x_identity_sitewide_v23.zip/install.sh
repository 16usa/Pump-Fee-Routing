#!/usr/bin/env bash
set -euo pipefail

PATCH_NAME="x_identity_sitewide_v23"
FILES=(src/app.js src/styles.css server/api.js server/db.js server/queries.js)

for f in "${FILES[@]}"; do
  if [ ! -f "$f" ]; then
    echo "ERROR: missing $f"
    echo "Run this from the existing Replit project root."
    exit 1
  fi
done

echo "==> Installing ${PATCH_NAME}"

mkdir -p ".patch-backups/${PATCH_NAME}"
for f in "${FILES[@]}"; do
  cp "$f" ".patch-backups/${PATCH_NAME}/$(basename "$f").before"
done

python3 "$(dirname "$0")/patch.py"

echo "==> Running project checks"
npm run check

echo "==> Git diff"
git diff --stat
git diff -- src/app.js src/styles.css server/api.js server/db.js server/queries.js

git add src/app.js src/styles.css server/api.js server/db.js server/queries.js

if git diff --cached --quiet; then
  echo "==> No new changes to commit."
else
  git commit -m "Unify X names and verified badges sitewide"
  git push origin main
fi

echo
echo "PASS: ${PATCH_NAME} installed."
echo "No server restart was performed."
