
from pathlib import Path
import re

app_path=Path("src/app.js")
css_path=Path("src/styles.css")
api_path=Path("server/api.js")
db_path=Path("server/db.js")
queries_path=Path("server/queries.js")

app=app_path.read_text()
css=css_path.read_text()
api=api_path.read_text()
db=db_path.read_text()
queries=queries_path.read_text()

# --- DB: preserve real X names and expose recipient identity on token rows.
if "lower(excluded.display_name)=lower(excluded.handle)" not in db:
    old = """  db.prepare(`INSERT INTO recipients(handle, display_name) VALUES(?, ?)
    ON CONFLICT(handle) DO UPDATE SET display_name=COALESCE(excluded.display_name, recipients.display_name), updated_at=CURRENT_TIMESTAMP`).run(h, displayName);"""
    new = """  db.prepare(`INSERT INTO recipients(handle, display_name) VALUES(?, ?)
    ON CONFLICT(handle) DO UPDATE SET
      display_name=CASE
        WHEN excluded.display_name IS NULL OR lower(excluded.display_name)=lower(excluded.handle)
          THEN COALESCE(NULLIF(recipients.display_name,''),excluded.display_name)
        ELSE excluded.display_name
      END,
      updated_at=CURRENT_TIMESTAMP`).run(h, displayName);"""
    if old not in db:
        raise SystemExit("ERROR: upsertRecipient target not found")
    db=db.replace(old,new,1)

if "recipient_display_name" not in db:
    old = """    SELECT t.*,
      COALESCE((SELECT SUM(c.recipient_usd)"""
    new = """    SELECT t.*,
      r.display_name AS recipient_display_name,
      r.avatar_url AS recipient_avatar_url,
      r.verified AS recipient_verified,
      r.verified_type AS recipient_verified_type,
      r.banner_url AS recipient_banner_url,
      COALESCE((SELECT SUM(c.recipient_usd)"""
    if old not in db:
        raise SystemExit("ERROR: tokenFinancialsWhere SELECT target not found")
    db=db.replace(old,new,1)

    old = """    FROM tokens t
    WHERE ${whereSql}"""
    new = """    FROM tokens t
    LEFT JOIN recipients r ON r.handle=t.recipient_handle
    WHERE ${whereSql}"""
    if old not in db:
        raise SystemExit("ERROR: tokenFinancialsWhere FROM target not found")
    db=db.replace(old,new,1)

# --- Queries: include recipient X identity fields everywhere needed.
if "recipient_display_name:t.recipient_display_name" not in queries:
    old = """  image_url:t.image_url || '', description:t.description || '', recipient_handle:t.recipient_handle,
  profile:t.recipient_handle, mc:Number(t.market_cap_usd||0), market_cap_usd:Number(t.market_cap_usd||0),"""
    new = """  image_url:t.image_url || '', description:t.description || '', recipient_handle:t.recipient_handle,
  recipient_display_name:t.recipient_display_name || '',
  recipient_avatar_url:t.recipient_avatar_url || '',
  recipient_verified:Number(t.recipient_verified||0),
  recipient_verified_type:t.recipient_verified_type || '',
  recipient_banner_url:t.recipient_banner_url || '',
  profile:t.recipient_handle, mc:Number(t.market_cap_usd||0), market_cap_usd:Number(t.market_cap_usd||0),"""
    if old not in queries:
        raise SystemExit("ERROR: mapToken target not found")
    queries=queries.replace(old,new,1)

queries=queries.replace(
    "SELECT p.*,r.display_name,r.avatar_url, GROUP_CONCAT(pi.mint) mints",
    "SELECT p.*,r.display_name,r.avatar_url,r.verified,r.verified_type, GROUP_CONCAT(pi.mint) mints"
)
queries=queries.replace(
    "SELECT r.handle,r.display_name,r.avatar_url,COALESCE(SUM(p.amount_usd),0) received",
    "SELECT r.handle,r.display_name,r.avatar_url,r.verified,r.verified_type,COALESCE(SUM(p.amount_usd),0) received"
)
queries=queries.replace(
    "SELECT p.*,pi.amount_usd item_amount_usd FROM payout_items pi JOIN payouts p ON p.id=pi.payout_id WHERE pi.mint=?",
    "SELECT p.*,pi.amount_usd item_amount_usd,r.display_name,r.avatar_url,r.verified,r.verified_type FROM payout_items pi JOIN payouts p ON p.id=pi.payout_id LEFT JOIN recipients r ON r.handle=p.recipient_handle WHERE pi.mint=?"
)

# --- API: batch X identity lookup.
if "/* x-identities-batch-v23 */" not in api:
    insertion = "\n\nexport async function handleApi(req,res,url){"
    if insertion not in api:
        raise SystemExit("ERROR: handleApi insertion point not found")
    batch = r"""
/* x-identities-batch-v23 */
async function resolveXIdentities(handles){
  const usernames=[...new Set((handles||[])
    .map(x=>String(x||'').replace(/^@/,'').trim())
    .filter(x=>/^[A-Za-z0-9_]{1,15}$/.test(x))
  )].slice(0,100);

  if(!usernames.length) return [];

  if(config.xBearerToken){
    try{
      const fields='id,name,username,profile_image_url,profile_banner_url,verified,verified_type';
      const r=await fetch(
        `https://api.x.com/2/users/by?usernames=${encodeURIComponent(usernames.join(','))}&user.fields=${encodeURIComponent(fields)}`,
        {
          headers:{authorization:`Bearer ${config.xBearerToken}`,accept:'application/json'},
          signal:AbortSignal.timeout(15000)
        }
      );

      if(r.ok){
        const payload=await r.json().catch(()=>({}));
        for(const u of (payload?.data||[])){
          const username=String(u?.username||'').replace(/^@/,'').trim();
          if(!username) continue;
          const avatarUrl=largerXAvatar(u?.profile_image_url||'');
          const bannerUrl=String(u?.profile_banner_url||'').trim();

          db.prepare(`INSERT INTO recipients(
            handle,x_user_id,display_name,avatar_url,banner_url,verified,verified_type
          ) VALUES(?,?,?,?,?,?,?)
          ON CONFLICT(handle) DO UPDATE SET
            x_user_id=COALESCE(NULLIF(excluded.x_user_id,''),recipients.x_user_id),
            display_name=COALESCE(NULLIF(excluded.display_name,''),recipients.display_name),
            avatar_url=COALESCE(NULLIF(excluded.avatar_url,''),recipients.avatar_url),
            banner_url=COALESCE(NULLIF(excluded.banner_url,''),recipients.banner_url),
            verified=excluded.verified,
            verified_type=excluded.verified_type,
            updated_at=CURRENT_TIMESTAMP`)
            .run(
              username,
              String(u?.id||''),
              String(u?.name||username),
              avatarUrl,
              bannerUrl,
              u?.verified?1:0,
              String(u?.verified_type||'')
            );
        }
      }
    }catch{}
  }

  const get=db.prepare(`SELECT handle,display_name,avatar_url,banner_url,verified,verified_type
    FROM recipients WHERE handle=? COLLATE NOCASE`);

  return usernames.map(username=>{
    const row=get.get(username)||{};
    return {
      username:String(row.handle||username),
      name:String(row.display_name||username),
      profileImageUrl:String(row.avatar_url||''),
      profileBannerUrl:String(row.banner_url||''),
      verified:Boolean(row.verified),
      verifiedType:String(row.verified_type||'')
    };
  });
}
"""
    api=api.replace(insertion,"\n\n"+batch+insertion,1)

if "url.pathname==='/api/x/identities'" not in api:
    target = """    if(req.method==='GET'&&url.pathname==='/api/x/profile'){"""
    route = """    if(req.method==='GET'&&url.pathname==='/api/x/identities'){
      const usernames=String(url.searchParams.get('usernames')||'')
        .split(',')
        .map(x=>x.trim())
        .filter(Boolean)
        .slice(0,100);
      return json(res,200,{identities:await resolveXIdentities(usernames)});
    }
"""
    if target not in api:
        raise SystemExit("ERROR: x/profile route target not found")
    api=api.replace(target,route+target,1)

# --- Frontend helper for one canonical X display name + one canonical badge.
if "/* sitewide-x-identity-ui-v23 */" not in app:
    target="\nconst logo=()=>"
    if target not in app:
        raise SystemExit("ERROR: helper insertion target not found")
    helpers = r"""
/* sitewide-x-identity-ui-v23 */
function xIsVerified(value,type=''){
  const kind=String(type||'').toLowerCase();
  return value===true||
    Number(value)===1||
    String(value||'').toLowerCase()==='true'||
    ['blue','business','government'].includes(kind);
}

function xVerifiedBadge(value,type='',extraClass=''){
  if(!xIsVerified(value,type))return '';
  const cls=['x-verified-badge',extraClass].filter(Boolean).join(' ');
  return `<span class="${cls}" title="Verified" aria-label="Verified">
    <svg viewBox="0 0 20 20" aria-hidden="true">
      <circle class="badge-bg" cx="10" cy="10" r="9"/>
      <path class="check" d="M6.3 10.2 8.7 12.6 13.9 7.4"/>
    </svg>
  </span>`;
}

function xIdentity(handle,source={}){
  const clean=String(
    handle||
    source?.recipient_handle||
    source?.profile||
    source?.handle||
    source?.username||
    ''
  ).replace(/^@/,'').trim();

  const stored=typeof moneyProfile==='function'?moneyProfile(clean):null;
  const isToken=!!(source?.mint||source?.contract||source?.symbol);

  const name=String(
    source?.recipient_display_name||
    (!isToken?source?.display_name:'')||
    stored?.display_name||
    clean||
    'Recipient'
  );

  const avatarUrl=String(
    source?.recipient_avatar_url||
    source?.avatar_url||
    stored?.avatar_url||
    ''
  );

  const verifiedValue=
    source?.recipient_verified ??
    source?.verified ??
    stored?.verified ??
    0;

  const verifiedType=String(
    source?.recipient_verified_type||
    source?.verified_type||
    stored?.verified_type||
    ''
  );

  return {
    handle:clean,
    name,
    avatarUrl,
    verified:xIsVerified(verifiedValue,verifiedType),
    verifiedType
  };
}
"""
    app=app.replace(target,"\n"+helpers+target,1)

# tokenCard
if "/* x-identity-token-card-v23 */" not in app:
    new = r"""/* x-identity-token-card-v23 */
function tokenCard(t,compact=false){
  const handle=t.profile||t.recipient_handle||'';
  const identity=xIdentity(handle,t);
  return `<a class="token-card ${compact?'compact':''}" href="#/token/${encodeURIComponent(t.mint||t.contract)}"><div class="token-img">${tokenAvatar(t,true)}</div><div class="token-meta"><div class="meta-line">${platformBadge(t.platform||'Pump')}<span class="muted x-recipient-name">${esc(identity.name)}${xVerifiedBadge(identity.verified,identity.verifiedType,'x-verified-compact')}</span><span class="muted">${esc(t.age||ago(t.created_at))}</span></div><div class="token-name"><strong>${esc(t.name)}</strong><span>${esc(t.symbol)}</span></div><div class="token-numbers"><span>${fmtMc(t.mc??t.market_cap_usd)} <small>MC</small></span><span>${fmtNum(t.sent)} <small>Sent</small></span>${compact?'':`<span>${fmtNum(t.owed)} <small>Owed</small></span>`}</div>${compact?'':`<div class="contract">${esc((t.mint||'').slice(0,6))}…${esc((t.mint||'').slice(-6))}</div>`}</div></a>`;
}
"""
    app,n=re.subn(r'function tokenCard\(t,compact=false\)\{.*?(?=function paymentCard)',new,app,count=1,flags=re.S)
    if n!=1: raise SystemExit("ERROR: tokenCard target not found")

# paymentCard
if "/* x-identity-payment-card-v23 */" not in app:
    new = r"""/* x-identity-payment-card-v23 */
function paymentCard(p,i){
  const amount=p.amount_usd??p.amount??0;
  const handle=p.recipient_handle||p.to||'recipient';
  const identity=xIdentity(handle,p);
  const mints=String(p.mints||'').split(',').filter(Boolean);
  const sent=['sent','claimed'].includes(p.status);
  return `<button class="payment-card expandable" data-expand="payment-${i}"><div class="row"><div><strong>${fmtMoney(amount)}</strong><span>${sent?'sent':'scheduled'} to <b class="x-recipient-name">${esc(identity.name)}${xVerifiedBadge(identity.verified,identity.verifiedType,'x-verified-compact')}</b></span></div><span class="chev">⌄</span></div><div class="mini-tokens">${mints.slice(0,5).map((x,j)=>`${j?'<span class="arrow">→</span>':''}<span class="mini-icon">${esc(x[0]||'T')}</span>`).join('')}<time>${esc(ago(p.sent_at||p.created_at))}</time></div><div class="details hidden"><div><span>Status</span><b>${esc(p.status||'queued')}</b></div><div><span>Provider</span><b>${esc(p.provider||'')}</b></div><div><span>Reference</span><b>${esc(p.provider_ref||p.id||'')}</b></div>${p.public_confirmation_url?`<div><span>Confirmation</span><b>${esc(p.public_confirmation_url)}</b></div>`:''}</div></button>`;
}
"""
    app,n=re.subn(r'function paymentCard\(p,i\)\{.*?(?=function txCard)',new,app,count=1,flags=re.S)
    if n!=1: raise SystemExit("ERROR: paymentCard target not found")

def replace_fn(name,next_name,marker,new):
    global app
    if marker in app:
        return
    pat=rf'function {re.escape(name)}\([^)]*\)\{{.*?\n\}}\n\n(?=function {re.escape(next_name)}\()'
    app2,n=re.subn(pat,new+"\n\n",app,count=1,flags=re.S)
    if n!=1: raise SystemExit(f"ERROR: {name} target not found")
    app=app2

replace_fn("moneyRecentCard","moneyOffRampCard","x-identity-money-recent-v23",r"""/* x-identity-money-recent-v23 */
function moneyRecentCard(p,i){
  const amount=p.amount_usd??p.amount??0;
  const handle=p.recipient_handle||p.to||'recipient';
  const identity=xIdentity(handle,p);
  const mints=String(p.mints||'').split(',').filter(Boolean);
  const token=moneyTokenByMint(mints[0]||'');
  const confirmed=['sent','claimed'].includes(p.status);
  return `<button class="money-payment-card expandable" data-expand="money-payment-${i}">
    <div class="money-payment-copy">
      <strong>${fmtMoney(amount)}</strong>
      <span>${confirmed?'sent':'scheduled'} to <b class="x-recipient-name">${esc(identity.name)}${xVerifiedBadge(identity.verified,identity.verifiedType,'x-verified-compact')}</b></span>
    </div>
    <span class="chev">⌄</span>
    <div class="money-payment-route">
      <div class="money-payment-avatar">${token?tokenAvatar(token,true):avatar(mints[0]||'T',true)}<i>●</i></div>
      <b class="money-dollar">$</b>
      <div class="money-payment-avatar">${recipientAvatar(handle,identity.name,true,identity.avatarUrl)}<i class="x">X</i></div>
      <time>${esc(ago(p.sent_at||p.created_at))}</time>
    </div>
    <div class="details hidden">
      <div><span>Status</span><b>${esc(p.status||'queued')}</b></div>
      <div><span>Provider</span><b>${esc(p.provider||'')}</b></div>
      <div><span>Reference</span><b>${esc(p.provider_ref||p.id||'')}</b></div>
    </div>
  </button>`;
}""")

replace_fn("moneyTopTokenCard","moneyOnRampCard","x-identity-money-top-token-v23",r"""/* x-identity-money-top-token-v23 */
function moneyTopTokenCard(t){
  const handle=t.recipient_handle||t.profile||'';
  const identity=xIdentity(handle,t);
  return `<a class="money-top-token-card" href="#/token/${encodeURIComponent(t.mint||t.contract||'')}">
    <div class="money-top-route">
      <div class="money-payment-avatar">${tokenAvatar(t,true)}<i>●</i></div>
      <b class="money-dollar">$</b>
      <div class="money-payment-avatar">${recipientAvatar(handle,identity.name,true,identity.avatarUrl)}<i class="x">X</i></div>
    </div>
    <div class="money-top-values"><strong>${fmtMoney(t.sent||0)}</strong><span>${fmtMoney(t.owed||0)} owed</span></div>
  </a>`;
}""")

replace_fn("homeTopTokenCard","homeTopTokens","x-identity-home-top-token-v23",r"""/* x-identity-home-top-token-v23 */
function homeTopTokenCard(t){
  const handle=t.profile||t.recipient_handle||'';
  const identity=xIdentity(handle,t);
  const mint=t.mint||t.contract||'';
  const ageText=t.age||ago(t.created_at);
  const mc=t.mc??t.market_cap_usd;
  return `<a class="home-top-token-card" data-top-token-layout="v21" href="#/token/${encodeURIComponent(mint)}">
    <div class="home-top-token-media">
      ${tokenMedia(t,'home-top-token-fallback')}
      <div class="home-top-token-platform" data-top-token-pump-logo="v21-1" aria-label="${esc(t.platform||'Pump')}">
        ${String(t.platform||'Pump').toLowerCase().includes('pump')
          ? `<span class="home-top-token-pump-logo" aria-hidden="true"><svg viewBox="0 0 24 24" role="presentation" focusable="false"><g transform="rotate(-42 12 12)"><rect x="7" y="3" width="10" height="18" rx="5" fill="#f2f2f2"/><path d="M7 12h10v4a5 5 0 0 1-5 5 5 5 0 0 1-5-5v-4Z" fill="#63d7a4"/></g></svg></span>`
          : platformBadge(t.platform||'Pump')}
      </div>
      <div class="home-top-token-age">${esc(ageText||'')}</div>
      <div class="home-top-token-recipient">
        <i class="home-top-token-money-mark">$</i>
        ${handle?recipientAvatar(handle,identity.name,false,identity.avatarUrl):avatar(t.symbol||'T')}
        <b class="x-recipient-name">${handle?`${esc(identity.name)}${xVerifiedBadge(identity.verified,identity.verifiedType,'x-verified-compact')}`:'Recipient'}</b>
      </div>
    </div>
    <div class="home-top-token-body">
      <div class="home-top-token-title"><strong>${esc(t.name)}</strong><span>${esc(t.symbol||'')}</span></div>
      <div class="home-top-token-market"><strong>${fmtMc(mc)}</strong><span>MC</span></div>
    </div>
  </a>`;
}""")

# Top X card gets the same global badge.
if "xVerifiedBadge(verified,p.verified_type,'home-profile-verified')" not in app:
    app,n=re.subn(
        r"""  const verifiedBadge=verified\n    \? `<span class="home-profile-verified".*?      </span>`\n    : '';""",
        "  const verifiedBadge=xVerifiedBadge(verified,p.verified_type,'home-profile-verified');",
        app,count=1,flags=re.S
    )
    if n!=1: raise SystemExit("ERROR: Top X badge target not found")

replace_fn("homeRecentPaymentCard","homeRecentPayments","x-identity-home-recent-payment-v23",r"""/* x-identity-home-recent-payment-v23 */
function homeRecentPaymentCard(p,i,tokens){
  const amount=p.amount_usd??p.amount??0;
  const handle=p.recipient_handle||p.to||'recipient';
  const identity=xIdentity(handle,p);
  const mints=String(p.mints||'').split(',').filter(Boolean);
  const firstMint=mints[0]||'';
  const token=(tokens||[]).find(t=>(t.mint||t.contract)===firstMint)||null;
  const confirmed=['sent','claimed'].includes(p.status);
  return `<button class="home-payment-card expandable" data-expand="home-payment-${i}">
    <div class="home-payment-top"><div><strong>${fmtMoney(amount)}</strong><span>${confirmed?'sent':'scheduled'} to <b class="x-recipient-name">${esc(identity.name)}${xVerifiedBadge(identity.verified,identity.verifiedType,'x-verified-compact')}</b></span></div><span class="chev">⌄</span></div>
    <div class="home-payment-route">
      <div class="home-payment-party home-payment-token">${token?tokenAvatar(token,true):`<span class="home-payment-placeholder">${esc(initials(token?.symbol||firstMint||'T'))}</span>`}<i class="home-payment-badge">●</i></div>
      <span class="home-payment-dollar">$</span>
      <div class="home-payment-party home-payment-recipient">${recipientAvatar(handle,identity.name,true,identity.avatarUrl)}<i class="home-payment-x">X</i></div>
      <time>${esc(ago(p.sent_at||p.created_at))}</time>
    </div>
    <div class="details hidden"><div><span>Status</span><b>${esc(p.status||'queued')}</b></div><div><span>Provider</span><b>${esc(p.provider||'')}</b></div><div><span>Reference</span><b>${esc(p.provider_ref||p.id||'')}</b></div>${p.public_confirmation_url?`<div><span>Confirmation</span><b>${esc(p.public_confirmation_url)}</b></div>`:''}</div>
  </button>`;
}""")

replace_fn("exploreTokenCard","exploreTrending","x-identity-explore-token-v23",r"""/* x-identity-explore-token-v23 */
function exploreTokenCard(t){
  const mint=t.mint||t.contract||'';
  const handle=t.profile||t.recipient_handle||'';
  const identity=xIdentity(handle,t);
  return `<a class="explore-token-card" href="#/token/${encodeURIComponent(mint)}">
    <div class="explore-token-image">${tokenMedia(t,'explore-token-fallback')}</div>
    <div class="explore-token-info">
      <div class="explore-token-meta">
        ${platformBadge(t.platform||'Pump')}
        <span class="explore-token-profile x-recipient-name">${handle?`${esc(identity.name)}${xVerifiedBadge(identity.verified,identity.verifiedType,'x-verified-compact')}`:'Recipient'}</span>
        <span class="explore-token-age">${esc(t.age||ago(t.created_at))}</span>
      </div>
      <div class="explore-token-name"><strong>${esc(t.name)}</strong><span>${esc(t.symbol||'')}</span></div>
      <div class="explore-token-stats"><div><b>${fmtMc(t.mc??t.market_cap_usd)}</b><small>MC</small></div><div><b>${fmtNum(t.sent||0)}</b><small>Sent</small></div><div><b>${fmtNum(t.owed||0)}</b><small>Owed</small></div></div>
      <div class="explore-token-contract">${mint?`${esc(mint.slice(0,6))}...${esc(mint.slice(-6))}`:'-'}</div>
    </div>
  </a>`;
}""")

replace_fn("tokenDetailPaymentCard","tokenDetailEmpty","x-identity-token-payment-v23",r"""/* x-identity-token-payment-v23 */
function tokenDetailPaymentCard(p,i,handle){
  const amount=Number(p.item_amount_usd??p.amount_usd??0);
  const identity=xIdentity(handle||p.recipient_handle,p);
  return `<button class="token-detail-event expandable" data-expand="token-payment-${i}">
    <div class="token-event-main"><div><span>Payment to <b class="x-recipient-name">${esc(identity.name)}${xVerifiedBadge(identity.verified,identity.verifiedType,'x-verified-compact')}</b></span><strong>${fmtMoney(amount)}</strong></div><div class="token-event-value"><span class="token-status-pill">${esc(p.status||'queued')}</span><time>${esc(ago(p.sent_at||p.created_at))}</time></div></div>
    <div class="token-event-meta"><span>${esc(p.provider||'payout rail')}</span><span>${p.public_confirmation_url?'Public confirmation':'Ledger record'}</span></div>
    <div class="details hidden"><div><span>Provider reference</span><b class="token-detail-truncate">${esc(p.provider_ref||p.id||'—')}</b></div><div><span>Created</span><b>${esc(p.created_at||'—')}</b></div></div>
  </button>`;
}""")

# Token detail recipient card.
if "const recipientIdentity=xIdentity(t.recipient_handle" not in app:
    old="""  const recipient=moneyProfile(t.recipient_handle)||{};
  const chain=t.chain||null;"""
    new="""  const recipient=moneyProfile(t.recipient_handle)||{};
  const recipientIdentity=xIdentity(t.recipient_handle,{...t,...recipient});
  const chain=t.chain||null;"""
    if old not in app: raise SystemExit("ERROR: tokenPage identity target not found")
    app=app.replace(old,new,1)

old="""        <a class="token-detail-recipient" href="#/profile/${encodeURIComponent(t.recipient_handle||'')}">
          ${recipientAvatar(t.recipient_handle||'',recipient.display_name||t.recipient_handle||'X',true,recipient.avatar_url||'')}
          <div><span>X Money sent to</span><b>@${esc(t.recipient_handle||'—')}</b></div>
          <i>→</i>
        </a>"""
new="""        <a class="token-detail-recipient" href="#/profile/${encodeURIComponent(t.recipient_handle||'')}">
          ${recipientAvatar(t.recipient_handle||'',recipientIdentity.name,true,recipientIdentity.avatarUrl)}
          <div><span>X Money sent to</span><b class="x-recipient-name">${esc(recipientIdentity.name)}${xVerifiedBadge(recipientIdentity.verified,recipientIdentity.verifiedType,'x-verified-compact')}</b></div>
          <i>→</i>
        </a>"""
if new not in app:
    if old not in app: raise SystemExit("ERROR: token detail recipient markup not found")
    app=app.replace(old,new,1)

# Profile page title.
old="""          <h1>${esc(display)}</h1>
          <span>@${esc(cleanHandle)}</span>"""
new="""          <h1 class="x-recipient-name">${esc(display)}${xVerifiedBadge(r.verified,r.verified_type)}</h1>
          <span>@${esc(cleanHandle)}</span>"""
if new not in app:
    if old not in app: raise SystemExit("ERROR: profile h1 target not found")
    app=app.replace(old,new,1)

# Home preview payment.
old="""    const recipientVisual=handle
      ? recipientAvatar(handle,to,false,profile?.avatar_url||'')
      : avatar(to,false,'');
    const verified=(p.verified||profile?.verified)?'<em class="home-v2-payment-verified">✓</em>':'';"""
new="""    const identity=xIdentity(handle,{...p,...(profile||{})});
    const recipientVisual=handle
      ? recipientAvatar(handle,identity.name,false,identity.avatarUrl)
      : avatar(identity.name,false,'');
    const verified=xVerifiedBadge(identity.verified,identity.verifiedType,'x-verified-compact');"""
if new not in app:
    if old not in app: raise SystemExit("ERROR: preview payment target not found")
    app=app.replace(old,new,1)

app=app.replace(
    """<span>sent to <b>${esc(to)}</b>${verified}</span>""",
    """<span>sent to <b class="x-recipient-name">${esc(identity.name)}${verified}</b></span>""",1
)

# Home preview Explore recipient badge.
old="""          const renderRecipient = (token) => {
            const profile = findProfile(token);
            const handle = String(token?.profile || token?.recipient_handle || token?.recipient_handles || '').replace(/^@/, '').trim();
            const label = profile?.display_name || handle || 'Recipient';
            const avatarUrl = String(profile?.avatar_url || '').trim();
            return `<div class="home-explore-v8-recipient"><i>$</i>${recipientAvatar(handle,label,false,avatarUrl)}<b>${esc(label)}</b></div>`;
          };"""
new="""          const renderRecipient = (token) => {
            const profile = findProfile(token);
            const handle = String(token?.profile || token?.recipient_handle || token?.recipient_handles || '').replace(/^@/, '').trim();
            const identity=xIdentity(handle,{...token,...(profile||{})});
            return `<div class="home-explore-v8-recipient"><i>$</i>${recipientAvatar(handle,identity.name,false,identity.avatarUrl)}<b class="x-recipient-name">${esc(identity.name)}${xVerifiedBadge(identity.verified,identity.verifiedType,'x-verified-compact')}</b></div>`;
          };"""
if new not in app:
    if old not in app: raise SystemExit("ERROR: preview Explore recipient target not found")
    app=app.replace(old,new,1)

# Home Launch preview same badge.
app=app.replace(
    """<strong>${esc(leadName)}${leadProfile?.verified?'<em>✓</em>':''}</strong>""",
    """<strong class="x-recipient-name">${esc(leadName)}${xVerifiedBadge(leadProfile?.verified,leadProfile?.verified_type,'x-verified-compact')}</strong>"""
)

# Launch live lookup and preview.
old="""  if(profile.verified){
    const badge=document.createElement('span');
    badge.className='launch-x-verified';
    badge.textContent='✓';
    badge.title=profile.verifiedType?`Verified: ${profile.verifiedType}`:'Verified';
    top.appendChild(badge);
  }"""
new="""  if(xIsVerified(profile.verified,profile.verifiedType)){
    top.insertAdjacentHTML('beforeend',xVerifiedBadge(profile.verified,profile.verifiedType,'launch-x-verified'));
  }"""
if new not in app:
    if old not in app: raise SystemExit("ERROR: launch lookup badge target not found")
    app=app.replace(old,new,1)

old="""  if(profile.verified){
    const verified=document.createElement('span');
    verified.className='launch-preview-profile-verified';
    verified.textContent='✓';
    verified.title=profile.verifiedType?`Verified: ${profile.verifiedType}`:'Verified';
    wrap.appendChild(verified);
  }"""
new="""  if(xIsVerified(profile.verified,profile.verifiedType)){
    wrap.insertAdjacentHTML('beforeend',xVerifiedBadge(profile.verified,profile.verifiedType,'launch-preview-profile-verified'));
  }"""
if new not in app:
    if old not in app: raise SystemExit("ERROR: launch preview badge target not found")
    app=app.replace(old,new,1)

app=app.replace(
    """function launchDemoVerified(show){
  return show ? '<span class="launch-demo-verified" aria-hidden="true">✓</span>' : '';
}""",
    """function launchDemoVerified(show){
  return xVerifiedBadge(show,'','launch-demo-verified');
}"""
)

# Sitewide batch hydration replaces old top-4 hydration.
if "/* sitewide-x-live-identity-v23 */" not in app:
    pat=re.compile(r'/\* home-top-x-live-identity-v22-2 \*/.*?(?=async function refreshTokens\(\))',re.S)
    new=r"""/* sitewide-x-live-identity-v23 */
function identityHandle(row){
  return String(row?.handle||row?.recipient_handle||row?.profile||row?.to||'').replace(/^@/,'').trim();
}

function applyLiveXIdentity(row,identity){
  if(!row||!identity)return row;
  const isToken=!!(row.mint||row.contract||row.symbol);
  const base={
    ...row,
    recipient_display_name:identity.name||row.recipient_display_name||'',
    recipient_avatar_url:identity.profileImageUrl||row.recipient_avatar_url||'',
    recipient_verified:identity.verified?1:0,
    recipient_verified_type:identity.verifiedType||row.recipient_verified_type||''
  };
  if(isToken)return base;
  return {
    ...base,
    display_name:identity.name||row.display_name||identity.username,
    avatar_url:identity.profileImageUrl||row.avatar_url||'',
    banner_url:identity.profileBannerUrl||row.banner_url||'',
    verified:identity.verified?1:0,
    verified_type:identity.verifiedType||row.verified_type||''
  };
}

function applyIdentityList(rows,map){
  return (rows||[]).map(row=>{
    const handle=identityHandle(row).toLowerCase();
    return handle&&map.has(handle)?applyLiveXIdentity(row,map.get(handle)):row;
  });
}

async function hydrateSiteXData(rawHome,rawMoney,rawTokens){
  const home=rawHome||{};
  const money=rawMoney||{};
  const tokenPayload=rawTokens||{tokens:[]};

  const sources=[
    ...(home.profiles||[]),
    ...(home.tokens||[]),
    ...(home.payments||[]),
    ...(home.money?.recent||[]),
    ...(home.money?.topPaid||[]),
    ...(money.recent||[]),
    ...(money.topPaid||[]),
    ...(tokenPayload.tokens||[])
  ];

  const handles=[...new Set(
    sources.map(identityHandle)
      .filter(x=>/^[A-Za-z0-9_]{1,15}$/.test(x))
      .map(x=>x.toLowerCase())
  )].slice(0,100);

  if(!handles.length)return {home,money,tokenPayload};

  let identities=[];
  try{
    const out=await api(`/api/x/identities?usernames=${encodeURIComponent(handles.join(','))}`);
    identities=Array.isArray(out?.identities)?out.identities:[];
  }catch{}

  const map=new Map(
    identities
      .filter(Boolean)
      .map(x=>[String(x.username||'').toLowerCase(),x])
      .filter(([key])=>key)
  );

  return {
    home:{
      ...home,
      profiles:applyIdentityList(home.profiles,map),
      tokens:applyIdentityList(home.tokens,map),
      payments:applyIdentityList(home.payments,map),
      money:home.money?{
        ...home.money,
        recent:applyIdentityList(home.money.recent,map),
        topPaid:applyIdentityList(home.money.topPaid,map)
      }:home.money
    },
    money:{
      ...money,
      recent:applyIdentityList(money.recent,map),
      topPaid:applyIdentityList(money.topPaid,map)
    },
    tokenPayload:{
      ...tokenPayload,
      tokens:applyIdentityList(tokenPayload.tokens,map)
    }
  };
}

async function loadBase(){
  const [cfg,rawHome,rawMoney,rawTokens]=await Promise.all([
    api('/api/config'),
    api('/api/home'),
    api('/api/money'),
    api('/api/tokens?limit=100')
  ]);

  const hydrated=await hydrateSiteXData(rawHome,rawMoney,rawTokens);

  state.brand={
    ...state.brand,
    ...cfg,
    heroLine1:'Route token fees',
    heroLine2:'through X Money',
    description:'Point a token’s creator fees at any X handle and route the recipient share in dollars through your configured payout rail.'
  };
  state.home=hydrated.home;
  state.money=hydrated.money;
  state.tokens=hydrated.tokenPayload.tokens||[];
  document.title=state.brand.name;
}
"""
    app,n=pat.subn(new+"\n",app,count=1)
    if n!=1: raise SystemExit("ERROR: old identity hydration block not found")

# Global badge CSS.
if "/* sitewide-x-verified-badge-v23 */" not in css:
    css += r"""

/* sitewide-x-verified-badge-v23 */
.x-recipient-name{min-width:0}

.x-verified-badge{
  width:16px;
  height:16px;
  display:inline-flex;
  align-items:center;
  justify-content:center;
  flex:0 0 16px;
  margin-left:6px;
  vertical-align:-2px;
  line-height:1;
}

.x-verified-badge svg{
  width:100%;
  height:100%;
  display:block;
  overflow:visible;
}

.x-verified-badge .badge-bg{fill:#1d9bf0}
.x-verified-badge .check{
  fill:none;
  stroke:#fff;
  stroke-width:2.1;
  stroke-linecap:round;
  stroke-linejoin:round;
}

.x-verified-badge.x-verified-compact{
  width:13px;
  height:13px;
  flex-basis:13px;
  margin-left:4px;
  vertical-align:-2px;
}

.home-profile-feature[data-profile-layout="v22"] .home-profile-verified{margin-left:0}
.launch-x-verified,.launch-preview-profile-verified,.launch-demo-verified{margin-left:5px}

@media(max-width:640px){
  .x-verified-badge{
    width:15px;
    height:15px;
    flex-basis:15px;
    margin-left:5px;
  }
  .x-verified-badge.x-verified-compact{
    width:12px;
    height:12px;
    flex-basis:12px;
    margin-left:4px;
  }
  .home-profile-feature[data-profile-layout="v22"] .home-profile-verified{margin-left:0}
}
"""

for needle in [
    "sitewide-x-identity-ui-v23",
    "sitewide-x-live-identity-v23",
    "x-identity-home-top-token-v23",
    "x-identity-explore-token-v23",
    "x-identity-token-payment-v23",
    "url.pathname==='/api/x/identities'"
]:
    if needle not in (app+api):
        raise SystemExit(f"ERROR: sanity check failed: {needle}")

app_path.write_text(app)
css_path.write_text(css)
api_path.write_text(api)
db_path.write_text(db)
queries_path.write_text(queries)

print("PASS: sitewide X identity changes prepared")
