X Identity Sitewide v23

This patch makes X account identity consistent across the whole site:

- Primary account label = the X display name (example: GG), not @reptilonx.
- @username remains only as secondary information where it makes sense, such as the profile page.
- The exact same blue verified badge from Top X Profiles is reused beside verified X display names everywhere.
- Updates Top Tokens, Explore cards, payment cards, token details, profile title, Home previews, and Launch account previews.
- Adds a batch X identity lookup so display names / avatar / verification are refreshed consistently.
- Enriches token/payment data with recipient identity.
- Prevents a real X display name from being overwritten by the raw handle during future token registration.
- No automatic server restart.

Install in the existing Replit Shell:

rm -rf /tmp/x_identity_sitewide_v23 && mkdir -p /tmp/x_identity_sitewide_v23 && unzip -o x_identity_sitewide_v23.zip -d /tmp/x_identity_sitewide_v23 && bash /tmp/x_identity_sitewide_v23/install.sh
