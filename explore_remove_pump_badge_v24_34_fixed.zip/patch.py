from pathlib import Path

css_path = Path("src/styles.css")
if not css_path.exists():
    raise SystemExit("ERROR: src/styles.css not found. Run from the existing Replit project root.")

css = css_path.read_text()
marker = "/* explore-remove-pump-badge-v24-34-fixed */"

# Robust project check: do not depend on the exact old comment text.
if ".home-explore-top-token-card" not in css or "data-explore-projection" not in css:
    raise SystemExit("ERROR: Explore projected Top Token card selectors not found in src/styles.css")

if marker not in css:
    css += r'''

/* explore-remove-pump-badge-v24-34-fixed */
.home-explore-reference-v8
.home-explore-top-token-card[data-explore-projection]
.home-top-token-platform{
  display:none !important;
}
'''
    css_path.write_text(css)
    print("PASS: Removed the round Pump badge from the top-left of the Explore projected card.")
else:
    print("No changes needed; patch already installed.")
