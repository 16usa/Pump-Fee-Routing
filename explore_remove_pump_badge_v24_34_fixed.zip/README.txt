Explore Remove Pump Badge v24.34 FIXED

Fixes the failed previous v24.34 installer.

Reason for previous failure:
- the installer looked for one exact old CSS comment string;
- the current project has the same v24.32 styles, but the comment formatting differs.

This fixed patch:
- detects the actual Explore projected-card selectors instead;
- removes only the round Pump badge at the top-left of the Explore preview card;
- does not change Top Tokens cards elsewhere;
- does not restart the server.

Install in the existing Replit Shell:

rm -rf /tmp/explore_remove_pump_badge_v24_34_fixed && mkdir -p /tmp/explore_remove_pump_badge_v24_34_fixed && unzip -o explore_remove_pump_badge_v24_34_fixed.zip -d /tmp/explore_remove_pump_badge_v24_34_fixed && bash /tmp/explore_remove_pump_badge_v24_34_fixed/install.sh
