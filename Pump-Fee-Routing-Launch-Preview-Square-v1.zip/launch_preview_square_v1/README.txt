Pump-Fee-Routing-Launch-Preview-Square-v1

What it changes
- Makes the Launch preview image area square (1:1)
- Keeps the image cropped cleanly with object-fit: cover
- Preserves the existing information layout below the image
- Commits and pushes to origin/main automatically

Install from the project root:
  bash /tmp/launch-preview-square-v1/install.sh
