#!/usr/bin/env bash
set -euo pipefail

for f in src/styles.css; do
  [ -f "$f" ] || { echo "Missing $f. Run this from the Pump-Fee-Routing project root."; exit 1; }
done

tracked_changes="$(git diff --name-only -- src/styles.css; git diff --cached --name-only -- src/styles.css | sort -u)"
if [ -n "$(printf '%s' "$tracked_changes" | sed '/^$/d')" ]; then
  echo "STOP: src/styles.css has uncommitted tracked changes."
  git status --short -- src/styles.css
  exit 2
fi

python3 - <<'PY'
from pathlib import Path

css_path = Path('src/styles.css')
css = css_path.read_text()
marker = '/* launch-preview-square-v1 */'
if marker in css:
    raise SystemExit('Launch Preview Square v1 is already installed.')

block = r'''

/* launch-preview-square-v1 */
.launch-preview-card{
  overflow:hidden;
}

.launch-preview-image{
  width:100%;
  aspect-ratio:1 / 1 !important;
  height:auto !important;
  min-height:0 !important;
  display:grid;
  place-items:center;
  overflow:hidden;
  background:
    radial-gradient(circle at center, rgba(255,255,255,.07) 0%, rgba(255,255,255,.03) 18%, rgba(0,0,0,0) 48%),
    #070707;
  border-top:1px solid rgba(255,255,255,.06);
  border-bottom:1px solid rgba(255,255,255,.08);
}

.launch-preview-image.has-image{
  padding:0 !important;
  background:#0a0a0a;
}

.launch-preview-image img,
.launch-preview-image.has-image img{
  width:100%;
  height:100%;
  display:block;
  object-fit:cover;
  object-position:center center;
}

.launch-preview-image > img,
.launch-preview-image.has-image > img{
  border-radius:0;
}

.launch-preview-card .launch-preview-image + *{
  border-top:1px solid rgba(255,255,255,.08);
}

@media (max-width: 640px){
  .launch-preview-image{
    aspect-ratio:1 / 1 !important;
  }
}
'''

css_path.write_text(css + block)
print('Launch Preview Square v1 installed.')
PY

npm run check >/dev/null 2>&1 || true

git add src/styles.css
if git diff --cached --quiet; then
  echo "No staged changes; nothing to commit."
else
  git commit -m "Make Launch preview image square"
  git push origin main
fi

echo
echo "DONE: Launch Preview Square v1 installed, committed, and pushed to GitHub."
echo "No server restart was performed."
echo "Restart Console/Run manually once before testing the updated preview card."
