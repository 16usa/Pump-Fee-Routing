#!/usr/bin/env bash
set -euo pipefail

echo "== Top Token Explore Badges v21.1 =="

for f in src/app.js src/styles.css; do
  if [ ! -f "$f" ]; then
    echo "ERROR: $f not found. Run this from the existing Replit project workspace."
    exit 1
  fi
done

python3 <<'PYCODE'
from pathlib import Path

app_path = Path("src/app.js")
css_path = Path("src/styles.css")

app = app_path.read_text()
css = css_path.read_text()

if 'data-top-token-layout="v21"' not in app:
    raise SystemExit("ERROR: Top Token Card Layout v21 is not installed yet.")

marker = "/* top-token-explore-badges-v21-1 */"

# Match the recipient pill markup to Explore: $ icon + avatar + bold label.
start = app.find("function homeTopTokenCard(t){")
end = app.find("\n\nfunction homeTopTokens(top){", start)
if start < 0 or end < 0:
    raise SystemExit("ERROR: homeTopTokenCard() block not found.")

segment = app[start:end]
segment = segment.replace(
    '<span>${handle?esc(handle.replace(/^@/,\'\')):\'Recipient\'}</span>',
    '<b>${handle?esc(handle.replace(/^@/,\'\')):\'Recipient\'}</b>'
)
app = app[:start] + segment + app[end:]
app_path.write_text(app)

if marker not in css:
    patch = r'''
/* top-token-explore-badges-v21-1 */

/*
  ONLY two overlays in Top Tokens are changed:
  1) time badge -> same visual style as Explore
  2) recipient/profile pill -> same visual style as Explore
*/

/* Time badge = Explore home-top-token-age style. */
.home-top-token-card[data-top-token-layout="v21"] .home-top-token-age{
  position:absolute;
  top:7px;
  right:7px;
  z-index:6;
  min-height:0;
  display:block;
  padding:4px 6px;
  border:1px solid rgba(255,255,255,.12);
  border-radius:999px;
  background:rgba(0,0,0,.72);
  color:#b9b9b9;
  backdrop-filter:blur(7px);
  -webkit-backdrop-filter:blur(7px);
  box-shadow:none;
  font-size:7px;
  line-height:normal;
  font-weight:400;
}

/* Recipient/profile pill = Explore recipient pill style. */
.home-top-token-card[data-top-token-layout="v21"] .home-top-token-recipient{
  position:absolute;
  left:8px;
  right:auto;
  bottom:8px;
  z-index:6;
  width:max-content;
  max-width:84%;
  min-height:33px;
  display:flex;
  align-items:center;
  gap:7px;
  padding:5px 11px 5px 7px;
  overflow:hidden;
  border:1px solid rgba(255,255,255,.16);
  border-radius:999px;
  background:rgba(4,4,4,.93);
  box-shadow:0 4px 16px rgba(0,0,0,.28);
  backdrop-filter:none;
  -webkit-backdrop-filter:none;
  white-space:nowrap;
}

.home-top-token-card[data-top-token-layout="v21"] .home-top-token-recipient>i{
  width:21px;
  height:21px;
  flex:0 0 21px;
  display:grid;
  place-items:center;
  border-radius:50%;
  background:#171717;
  color:#d8d8d8;
  font-size:10px;
  line-height:1;
  font-style:normal;
  font-weight:750;
}

.home-top-token-card[data-top-token-layout="v21"] .home-top-token-recipient .avatar{
  width:22px;
  height:22px;
  flex:0 0 22px;
  margin-left:-10px;
  border:1px solid #292929;
  font-size:8px;
}

.home-top-token-card[data-top-token-layout="v21"] .home-top-token-recipient>b{
  min-width:0;
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
  color:#f1f1f1;
  font-size:11px;
  line-height:1;
  font-weight:650;
}

/* Hide the old span style if cached/legacy markup appears. */
.home-top-token-card[data-top-token-layout="v21"] .home-top-token-recipient>span{
  min-width:0;
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
  color:#f1f1f1;
  font-size:11px;
  line-height:1;
  font-weight:650;
}

@media(max-width:640px){
  .home-top-token-card[data-top-token-layout="v21"] .home-top-token-age{
    top:6px;
    right:6px;
    padding:4px 6px;
    font-size:7px;
  }

  .home-top-token-card[data-top-token-layout="v21"] .home-top-token-recipient{
    left:6px;
    bottom:6px;
    min-height:28px;
    gap:5px;
    padding:4px 8px 4px 5px;
  }

  .home-top-token-card[data-top-token-layout="v21"] .home-top-token-recipient>i{
    width:18px;
    height:18px;
    flex-basis:18px;
    font-size:9px;
  }

  .home-top-token-card[data-top-token-layout="v21"] .home-top-token-recipient .avatar{
    width:19px;
    height:19px;
    flex-basis:19px;
    margin-left:-8px;
    font-size:7px;
  }

  .home-top-token-card[data-top-token-layout="v21"] .home-top-token-recipient>b,
  .home-top-token-card[data-top-token-layout="v21"] .home-top-token-recipient>span{
    font-size:9px;
  }
}
'''
    css_path.write_text(css.rstrip() + "\n\n" + patch + "\n")
    print("PASS Explore badge styles appended")
else:
    print("PASS v21.1 already installed")

app2 = app_path.read_text()
css2 = css_path.read_text()
segment2 = app2[app2.find("function homeTopTokenCard"):app2.find("function homeTopTokens")]
checks = {
    "v21 card exists": 'data-top-token-layout="v21"' in segment2,
    "recipient uses bold label": "<b>${handle?esc(handle.replace(/^@/,'')):'Recipient'}</b>" in segment2,
    "v21.1 CSS marker": marker in css2,
    "time badge override": '.home-top-token-age{' in css2[css2.rfind(marker):],
    "recipient pill override": '.home-top-token-recipient{' in css2[css2.rfind(marker):],
}
for label, ok in checks.items():
    if not ok:
        raise SystemExit(f"ERROR: verification failed: {label}")
    print("PASS", label)
PYCODE

echo
echo "== Project checks =="
npm run check

echo
echo "== Git diff =="
git diff --stat

git add src/app.js src/styles.css

if git diff --cached --quiet; then
  echo "No new changes to commit."
else
  git commit -m "Match Top Tokens badges to Explore"
  git push
fi

echo
echo "DONE: Top Token Explore Badges v21.1 installed, checked, committed, and pushed."
echo "No server restart was performed."
echo "Restart Run/Console manually once, then reload the page."
