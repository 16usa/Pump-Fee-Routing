Pump Fee Routing — Top Token Explore Badges v21.1

Scope: ONLY the two overlay badges inside Top Tokens cards.

Changed:
- time badge now matches Explore
- recipient/profile pill now matches Explore
- same border, dark background, radius, shadow, avatar overlap, spacing, text scale
- mobile sizes also follow Explore

Not changed:
- photo size/position
- token title
- ticker
- MC row
- Top Tokens heading
- filters
- pagination
- grid
- any other section

Requires Top Token Card Layout v21.

Install:
rm -rf /tmp/top-token-explore-badges-v21-1
mkdir -p /tmp/top-token-explore-badges-v21-1
unzip -o Pump-Fee-Routing-Top-Token-Explore-Badges-v21-1.zip -d /tmp/top-token-explore-badges-v21-1
bash /tmp/top-token-explore-badges-v21-1/install.sh
