Pump Fee Routing — Launch Preview UsePaid v1

Changes only the Launch preview area:
- moves the preview card into the main Launch card
- removes the separate PREVIEW header strip
- keeps the token image square
- gives the image inset margins and rounded corners
- adds a compact image badge when an image is selected
- compacts name/ticker/MC/Sent/recipient rows
- compacts the 80% / 20% bottom split
- preserves the existing data and preview bindings

Installer checks, commits, and pushes origin/main.
No automatic server restart.
