Pump Fee Routing — Launch X Lookup v1

Only adds real X-account lookup under the existing Launch recipient field.
The rest of the Launch design/layout is intentionally unchanged.

Requires Replit Secret: X_BEARER_TOKEN
The bearer token stays on the server.

Installer runs syntax checks, npm run check, commit, and push origin/main.
No automatic server restart.
