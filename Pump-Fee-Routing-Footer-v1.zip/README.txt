Pump Fee Routing — Footer v1
Scope: shared site footer only.
Refines spacing, typography and mobile two-column link layout while preserving all current routes.
Runs npm check, commits, and pushes to origin/main. No automatic server restart.
