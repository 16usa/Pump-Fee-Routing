#!/usr/bin/env bash
set -euo pipefail

if [ ! -f src/app.js ] || [ ! -f src/styles.css ]; then
  echo "Run this from the Pump-Fee-Routing project root."
  exit 1
fi

if [ -n "$(git status --porcelain -- src/app.js src/styles.css)" ]; then
  echo "STOP: src/app.js or src/styles.css has uncommitted changes."
  git status --short -- src/app.js src/styles.css
  exit 2
fi

python3 - <<'PY'
from pathlib import Path

app_path = Path("src/app.js")
css_path = Path("src/styles.css")
app = app_path.read_text()
css = css_path.read_text()

marker = "/* home-footer-v1 */"
if marker in css:
    raise SystemExit("Footer v1 is already installed.")

start = app.find("function footer(){")
end = app.find("function tokenCard(", start)
if start < 0 or end < 0:
    raise SystemExit("Could not locate footer()/tokenCard().")

footer_fn = r'''function footer(){return `<footer class="site-footer">
  <div class="footer-inner">
    <div class="footer-brand">
      ${logo()}
      <p>Independent creator-fee routing protocol.</p>
      <span>© 2026 ${esc(state.brand.name)}</span>
    </div>

    <div class="footer-links">
      <b>Product</b>
      <a href="#/explore">Explore</a>
      <a href="#/money">Money</a>
      <a href="#/launch">Launch</a>
    </div>

    <div class="footer-links">
      <b>Protocol</b>
      <a href="#/capital-flow">Capital flow</a>
      <a href="#/paid">Protocol cut</a>
      <a href="#/docs">How it works</a>
    </div>

    <div class="footer-links">
      <b>Legal</b>
      <a href="#/legal">Terms</a>
      <a href="#/opt-out">Opt out</a>
    </div>
  </div>
  <div class="footer-bottom">
    <span>Built on Solana</span>
    <span>Creator fees → treasury → recipient</span>
  </div>
</footer>`;}'''

app = app[:start] + footer_fn + "
" + app[end:]
app_path.write_text(app)

css += r'''

/* home-footer-v1 */
.site-footer{
  margin-top:34px;
  padding:0;
  border-top:1px solid #171717;
  background:#000;
}
.site-footer .footer-inner{
  width:min(100% - 32px,1080px);
  margin:0 auto;
  padding:48px 0 42px;
  display:grid;
  grid-template-columns:2fr repeat(3,minmax(0,1fr));
  gap:34px;
}
.site-footer .footer-brand{
  display:grid;
  align-content:start;
  justify-items:start;
}
.site-footer .footer-brand .brand{
  margin-bottom:20px;
}
.site-footer .footer-brand p{
  max-width:250px;
  margin:0 0 14px;
  color:#555;
  font-size:9px;
  line-height:1.5;
}
.site-footer .footer-brand span{
  color:#4e4e4e;
  font-size:8px;
}
.site-footer .footer-links{
  display:grid;
  align-content:start;
  gap:10px;
}
.site-footer .footer-links b{
  margin-bottom:3px;
  color:#e5e5e5;
  font-size:9px;
  font-weight:650;
}
.site-footer .footer-links a{
  width:max-content;
  color:#626262;
  font-size:9px;
  transition:color .15s ease;
}
.site-footer .footer-links a:hover{color:#fff}
.site-footer .footer-bottom{
  width:min(100% - 32px,1080px);
  min-height:42px;
  margin:0 auto;
  padding:12px 0 18px;
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap:16px;
  border-top:1px solid #111;
  color:#393939;
  font-size:7px;
}
@media(max-width:640px){
  .site-footer{margin-top:28px}
  .site-footer .footer-inner{
    width:calc(100% - 32px);
    padding:40px 0 34px;
    grid-template-columns:1fr 1fr;
    gap:30px 34px;
  }
  .site-footer .footer-brand{
    grid-column:1 / -1;
    padding-bottom:4px;
  }
  .site-footer .footer-brand .brand{margin-bottom:17px}
  .site-footer .footer-brand p{
    max-width:260px;
    margin-bottom:12px;
    font-size:8px;
  }
  .site-footer .footer-brand span{font-size:7px}
  .site-footer .footer-links{
    gap:9px;
  }
  .site-footer .footer-links b{font-size:8px}
  .site-footer .footer-links a{font-size:8px}
  .site-footer .footer-links:last-child{
    grid-column:1 / 2;
  }
  .site-footer .footer-bottom{
    width:calc(100% - 32px);
    min-height:0;
    padding:12px 0 18px;
    display:grid;
    gap:5px;
    font-size:6.5px;
  }
}
'''
css_path.write_text(css)

print("Footer v1 patch installed.")
PY

npm run check

git add src/app.js src/styles.css

if git diff --cached --quiet; then
  echo "No staged changes; nothing to commit."
else
  git commit -m "Match home footer"
fi

git push origin main

echo
echo "DONE: Footer patch checked, committed, and pushed to GitHub."
echo "No server restart was performed."
echo "Refresh the browser to see the updated footer."
