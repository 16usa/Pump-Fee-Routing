Pump Fee Routing — Explore Label Cleanup v11

Changes only the Home Explore preview block:

1. The bottom-left "Explore" text now uses the same color, size,
   weight, line-height and general text treatment as "Open →".
2. Removes the small "Pump" badge from the token image.
3. Does not change the token image, card geometry, Payments,
   Analytics, or other modules.
4. Does not restart the server.
5. Runs project checks, commits, and pushes.

Install from the existing Replit workspace:

rm -rf /tmp/explore-label-v11
mkdir -p /tmp/explore-label-v11
unzip -o Pump-Fee-Routing-Explore-Label-Cleanup-v11.zip -d /tmp/explore-label-v11
bash /tmp/explore-label-v11/install.sh

Then restart Run/Console manually once.
