#!/usr/bin/env bash
set -euo pipefail

echo "== Explore Label Cleanup v11 =="

for f in src/app.js src/styles.css; do
  if [ ! -f "$f" ]; then
    echo "ERROR: $f not found. Run this from the existing Replit project workspace."
    exit 1
  fi
done

python3 <<'PY'
from pathlib import Path

app_path = Path("src/app.js")
css_path = Path("src/styles.css")

app = app_path.read_text()
css = css_path.read_text()

# 1) Remove ONLY the Pump badge from the primary image inside the HOME Explore preview.
old_badge = """                <div class="home-explore-v8-venue">${platformBadge(token.platform || 'Pump')}</div>
"""
if old_badge in app:
    app = app.replace(old_badge, "", 1)
    print("PASS removed Pump badge from Home Explore preview image")
elif "home-explore-v8-venue" not in app:
    print("PASS Pump badge already removed")
else:
    raise SystemExit("ERROR: Explore Pump badge anchor changed; nothing modified.")

# 2) Make the bottom-left "Explore" label exactly inherit the same typography
#    as the bottom-right "Open →" label.
marker = "/* home-explore-footer-match-v11 */"
css_add = r"""
/* home-explore-footer-match-v11 */
.home-explore-reference-v8 .home-explore-v8-footer strong,
.home-explore-reference-v8 .home-explore-v8-footer span{
  color:#777;
  font-size:12px;
  line-height:1;
  font-weight:450;
  letter-spacing:0;
  white-space:nowrap;
}
@media (max-width:640px){
  .home-explore-reference-v8 .home-explore-v8-footer strong,
  .home-explore-reference-v8 .home-explore-v8-footer span{
    font-size:11px;
  }
}
"""
if marker not in css:
    css += "\n" + css_add
    print("PASS Explore label matched to Open typography")
else:
    print("PASS typography patch already installed")

app_path.write_text(app)
css_path.write_text(css)

# Verification.
app2 = app_path.read_text()
css2 = css_path.read_text()

if '<div class="home-explore-v8-venue">${platformBadge(token.platform' in app2:
    raise SystemExit("ERROR: Pump badge still present in Home Explore preview.")
if marker not in css2:
    raise SystemExit("ERROR: typography marker missing.")

print("PASS verification complete")
PY

echo
echo "== Project checks =="
npm run check

echo
echo "== Git diff =="
git diff --stat

git add src/app.js src/styles.css

if git diff --cached --quiet; then
  echo "No new changes to commit (patch may already be installed)."
else
  git commit -m "Match Explore label and remove preview Pump badge"
  git push
fi

echo
echo "DONE: Explore Label Cleanup v11 installed, checked, committed, and pushed."
echo "No server restart was performed."
echo "Restart Run/Console manually once, then reload the page."
