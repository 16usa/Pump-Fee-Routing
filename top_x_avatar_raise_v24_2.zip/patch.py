
from pathlib import Path

path=Path("src/styles.css")
css=path.read_text()

marker="/* top-x-avatar-raise-v24-2 */"
if marker not in css:
    css += r'''
/* top-x-avatar-raise-v24-2
   Raise the Top X avatar and the profile content by the same amount again. */
.home-profile-feature[data-profile-layout="v22"] .home-profile-avatar{
  bottom:-19px;
}

.home-profile-feature[data-profile-layout="v22"] .home-profile-feature-body{
  padding-top:27px;
}

@media(max-width:640px){
  .home-profile-feature[data-profile-layout="v22"] .home-profile-avatar{
    bottom:-17px;
  }

  .home-profile-feature[data-profile-layout="v22"] .home-profile-feature-body{
    padding-top:24px;
  }
}
'''
    path.write_text(css)
    print("src/styles.css: avatar and content raised again")
else:
    print("src/styles.css: patch already installed")

print("PASS: CSS patch prepared")
