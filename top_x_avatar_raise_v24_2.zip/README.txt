Top X Avatar Raise v24.2

Raises the Top X profile avatar by roughly the same amount again.
The name, @username, Paid Profile badge and stats move upward with it.
Avatar size stays the same as v24.1.

Install in the existing Replit Shell:

rm -rf /tmp/top_x_avatar_raise_v24_2 && mkdir -p /tmp/top_x_avatar_raise_v24_2 && unzip -o top_x_avatar_raise_v24_2.zip -d /tmp/top_x_avatar_raise_v24_2 && bash /tmp/top_x_avatar_raise_v24_2/install.sh

No automatic server restart.
