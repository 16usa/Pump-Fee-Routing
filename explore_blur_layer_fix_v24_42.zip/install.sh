#!/usr/bin/env bash
set -euo pipefail

PATCH_NAME="explore_blur_layer_fix_v24_42"
CSS="src/styles.css"

if [ ! -f "$CSS" ]; then
  echo "ERROR: missing src/styles.css"
  echo "Run this from the existing Replit project root."
  exit 1
fi

echo "==> Installing ${PATCH_NAME}"
mkdir -p ".patch-backups/${PATCH_NAME}"
cp "$CSS" ".patch-backups/${PATCH_NAME}/styles.css.before"

python3 "$(dirname "$0")/patch.py"

echo "==> Verifying conflict overrides"
grep -q 'explore-blur-layer-fix-v24-42' "$CSS"
grep -q 'mask-image:radial-gradient' "$CSS"
grep -q 'z-index:10 !important' "$CSS"

echo "==> Running project check"
npm run check

echo "==> Diff summary"
git diff --stat -- src/styles.css

git add src/styles.css
if git diff --cached --quiet; then
  echo "==> No new changes to commit."
else
  git commit -m "Fix Explore blur layering"
  git push origin main
fi

echo
echo "PASS: ${PATCH_NAME} installed."
echo "No server restart was performed."
