Explore Blur Layer Fix v24.42

Before building this patch I checked the current Explore code and the patch sequence.

Conflict found:
- v24.32 has .home-explore-v8-stage::after { display:none !important; }
- v24.41 reused ::after but did not override display, so its intended bottom blur layer could remain hidden.
- v24.41 also put backdrop-filter on the full-size ::before pseudo-element without a mask.
  On iPhone Safari this can blur/darken the whole Explore composition and make the inner content appear blank.
- Explore/Open already live as a separate footer layer, so they should stay above the effect.

v24.42:
- explicitly overrides both pseudo-elements
- adds a radial mask so the center remains visible
- keeps a stronger bottom blur
- explicitly sets ::after back to display:block
- puts Explore/Open above all blur layers
- does not change card geometry or footer font sizing

No automatic server restart.
