from pathlib import Path

css_path = Path("src/styles.css")
if not css_path.exists():
    raise SystemExit("ERROR: src/styles.css not found. Run from the existing Replit project root.")

css = css_path.read_text()
marker = "/* explore-blur-layer-fix-v24-42 */"

if ".home-explore-v8-stage" not in css or ".home-explore-v8-footer" not in css:
    raise SystemExit("ERROR: Explore stage/footer selectors not found in src/styles.css")

if marker not in css:
    css += r'''

/* explore-blur-layer-fix-v24-42
   Fix v24.41: keep the vignette only over the inner Explore composition.
   The center stays visible, edges blur gradually, bottom is stronger,
   and Explore / Open remain crisp above the effect. */
.home-explore-reference-v8 .home-explore-v8-stage{
  position:absolute !important;
  inset:0 !important;
  overflow:hidden !important;
  isolation:isolate !important;
}

/* Main circular/perimeter blur. Mask keeps the center transparent so the
   underlying token cards remain visible instead of being blanked out. */
.home-explore-reference-v8 .home-explore-v8-stage::before{
  content:"" !important;
  display:block !important;
  position:absolute !important;
  inset:0 !important;
  z-index:5 !important;
  pointer-events:none !important;
  border-radius:inherit !important;

  background:rgba(10,10,10,.16) !important;
  -webkit-backdrop-filter:blur(12px) saturate(.94) !important;
  backdrop-filter:blur(12px) saturate(.94) !important;

  -webkit-mask-image:radial-gradient(
    ellipse 76% 62% at 50% 43%,
    transparent 0%,
    transparent 43%,
    rgba(0,0,0,.16) 54%,
    rgba(0,0,0,.46) 67%,
    rgba(0,0,0,.78) 82%,
    #000 100%
  ) !important;
  mask-image:radial-gradient(
    ellipse 76% 62% at 50% 43%,
    transparent 0%,
    transparent 43%,
    rgba(0,0,0,.16) 54%,
    rgba(0,0,0,.46) 67%,
    rgba(0,0,0,.78) 82%,
    #000 100%
  ) !important;
  -webkit-mask-repeat:no-repeat !important;
  mask-repeat:no-repeat !important;
  -webkit-mask-size:100% 100% !important;
  mask-size:100% 100% !important;
}

/* Stronger bottom blur. Explicit display:block overrides the old v24.32
   display:none rule on ::after. It still sits BELOW the footer text. */
.home-explore-reference-v8 .home-explore-v8-stage::after{
  content:"" !important;
  display:block !important;
  position:absolute !important;
  left:0 !important;
  right:0 !important;
  top:auto !important;
  bottom:0 !important;
  height:42% !important;
  z-index:7 !important;
  pointer-events:none !important;

  background:linear-gradient(
    to top,
    rgba(10,10,10,.60) 0%,
    rgba(10,10,10,.38) 28%,
    rgba(10,10,10,.16) 58%,
    rgba(10,10,10,0) 100%
  ) !important;
  -webkit-backdrop-filter:blur(17px) saturate(.90) !important;
  backdrop-filter:blur(17px) saturate(.90) !important;

  -webkit-mask-image:linear-gradient(
    to top,
    #000 0%,
    rgba(0,0,0,.92) 28%,
    rgba(0,0,0,.58) 58%,
    rgba(0,0,0,.18) 82%,
    transparent 100%
  ) !important;
  mask-image:linear-gradient(
    to top,
    #000 0%,
    rgba(0,0,0,.92) 28%,
    rgba(0,0,0,.58) 58%,
    rgba(0,0,0,.18) 82%,
    transparent 100%
  ) !important;
}

/* Existing shade remains below the stronger bottom blur. */
.home-explore-reference-v8 .home-explore-v8-bottom-shade{
  z-index:6 !important;
}

/* Footer stays completely crisp above all blur layers. */
.home-explore-reference-v8 .home-explore-v8-footer{
  z-index:10 !important;
  -webkit-filter:none !important;
  filter:none !important;
}
.home-explore-reference-v8 .home-explore-v8-footer strong,
.home-explore-reference-v8 .home-explore-v8-footer span{
  position:relative !important;
  z-index:11 !important;
  -webkit-filter:none !important;
  filter:none !important;
}

/* Keep the actual content layers explicitly visible. */
.home-explore-reference-v8 .home-explore-v8-primary-slot,
.home-explore-reference-v8 .home-explore-v8-secondary-slot{
  visibility:visible !important;
  opacity:1 !important;
}

@media(max-width:640px){
  .home-explore-reference-v8 .home-explore-v8-stage::before{
    background:rgba(10,10,10,.14) !important;
    -webkit-backdrop-filter:blur(11px) saturate(.94) !important;
    backdrop-filter:blur(11px) saturate(.94) !important;

    -webkit-mask-image:radial-gradient(
      ellipse 80% 64% at 50% 41%,
      transparent 0%,
      transparent 42%,
      rgba(0,0,0,.14) 53%,
      rgba(0,0,0,.44) 67%,
      rgba(0,0,0,.80) 83%,
      #000 100%
    ) !important;
    mask-image:radial-gradient(
      ellipse 80% 64% at 50% 41%,
      transparent 0%,
      transparent 42%,
      rgba(0,0,0,.14) 53%,
      rgba(0,0,0,.44) 67%,
      rgba(0,0,0,.80) 83%,
      #000 100%
    ) !important;
  }

  .home-explore-reference-v8 .home-explore-v8-stage::after{
    height:44% !important;
    background:linear-gradient(
      to top,
      rgba(10,10,10,.64) 0%,
      rgba(10,10,10,.40) 30%,
      rgba(10,10,10,.16) 60%,
      rgba(10,10,10,0) 100%
    ) !important;
    -webkit-backdrop-filter:blur(16px) saturate(.90) !important;
    backdrop-filter:blur(16px) saturate(.90) !important;
  }

  .home-explore-reference-v8 .home-explore-v8-footer{
    z-index:10 !important;
  }
}
'''
    css_path.write_text(css)
    print("PASS: v24.41 full-stage blur conflict neutralized.")
    print("PASS: edge vignette is masked, center content stays visible.")
    print("PASS: bottom blur is stronger and Explore/Open stay above it.")
else:
    print("No changes needed; v24.42 already installed.")
