Pump-Fee-Routing — Home Reference Match v2

This patch refines only the Home page against the live UsePaid reference.

Key changes:
- Hero is centered like the reference.
- Explore preview becomes two moving token rails driven by the project's real token data.
- Payments preview becomes a compact payout list.
- Analytics preview matches the Fees / 1D / 30D / All time composition.
- Launch preview shows a recipient/profile rail and payout summary.
- Docs preview mirrors the compact technical sharing-config card.
- Existing Top Tokens, Top X Profiles, Recent payments, Most Payments, Off-ramp, On-ramp remain untouched.
- No fake tokens/payments are inserted. Empty sections remain empty until real data exists.
- Launch, wallet, fee-routing, claims, payout and indexer logic are not modified.
- Runs syntax/project checks and restores edited files automatically on failure.
- Commits and pushes to main.
- Does not restart the server.
