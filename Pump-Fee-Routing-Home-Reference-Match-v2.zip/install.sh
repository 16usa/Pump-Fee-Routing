#!/usr/bin/env bash
set -euo pipefail

[ -f src/app.js ] || { echo "Missing src/app.js"; exit 1; }
[ -f src/styles.css ] || { echo "Missing src/styles.css"; exit 1; }

cp src/app.js /tmp/Pump-Fee-Routing-app-before-home-reference-v2.js
cp src/styles.css /tmp/Pump-Fee-Routing-styles-before-home-reference-v2.css

restore() {
  cp /tmp/Pump-Fee-Routing-app-before-home-reference-v2.js src/app.js
  cp /tmp/Pump-Fee-Routing-styles-before-home-reference-v2.css src/styles.css
}

python3 - <<'PY'
from pathlib import Path

app=Path("src/app.js")
s=app.read_text()

start=s.find("function homePreviewDeck(h,top){")
end=s.find("\nfunction homeTopTokenCard", start)
if start < 0 or end < 0:
    raise SystemExit("Could not locate homePreviewDeck() boundaries.")

preview='function homePreviewDeck(h,top){\n  const tokens=(top||[]).filter(Boolean).slice(0,8);\n  const profiles=(h.profiles||[]).filter(Boolean).slice(0,3);\n  const payments=(h.payments||[]).filter(Boolean).slice(0,5);\n  const money=h.money||{};\n  const total=Number(money.totalPaid||0);\n\n  const railTokens=tokens.length?tokens:[null];\n  const repeated=Array.from({length:Math.max(8,railTokens.length*3)},(_,i)=>railTokens[i%railTokens.length]);\n\n  const exploreMini=(t,i)=>{\n    const name=t?.name||\'Waiting for token\';\n    const symbol=t?.symbol||\'\';\n    const handle=t?.profile||t?.recipient_handle||\'\';\n    const media=t?.image_url\n      ? `<img src="${esc(t.image_url)}" alt="" onerror="this.style.display=\'none\';this.nextElementSibling.style.display=\'grid\'"><span class="home-v2-token-fallback" style="display:none">${esc(initials(symbol||name||\'P\'))}</span>`\n      : `<span class="home-v2-token-fallback">${esc(initials(symbol||name||\'P\'))}</span>`;\n    return `<div class="home-v2-token-mini">\n      <div class="home-v2-token-media">${media}</div>\n      <div class="home-v2-token-copy">\n        <small>${handle?`@${esc(handle)}`:\'Pump\'}${t?.created_at?` · ${esc(ago(t.created_at))}`:\'\'}</small>\n        <strong>${esc(name)}</strong>\n        <span>${esc(symbol)}${t?` · ${fmtMc(t.mc??t.market_cap_usd)} MC`:\'\'}</span>\n      </div>\n      <b>${t?`${fmtNum(t.sent||0)} Sent`:\'—\'}</b>\n    </div>`;\n  };\n\n  const paymentMini=(p)=>{\n    if(!p) return \'\';\n    const amount=p.amount_usd??p.amount??0;\n    const to=p.display_name||p.recipient_handle||p.to||\'recipient\';\n    return `<div class="home-v2-payment-mini">\n      <strong>${fmtMoney(amount)}</strong>\n      <span>sent to <b>${esc(to)}</b></span>\n      <time>${esc(ago(p.sent_at||p.created_at))}</time>\n    </div>`;\n  };\n\n  const leadProfile=profiles[0]||null;\n  const leadName=leadProfile?.display_name||leadProfile?.handle||\'Recipient\';\n  const leadHandle=leadProfile?.handle||\'recipient\';\n\n  return `<section class="home-preview-shell home-ref-previews home-reference-v2-previews">\n    <div class="wrap home-preview-stack">\n\n      <a class="home-preview-card home-ref-card home-v2-explore-card" href="#/explore">\n        <div class="home-preview-label"><b>Explore</b><span>Open →</span></div>\n        <div class="home-v2-token-rail">\n          <div class="home-v2-token-track">${repeated.map(exploreMini).join(\'\')}</div>\n        </div>\n        <div class="home-v2-token-rail home-v2-token-rail-reverse">\n          <div class="home-v2-token-track">${repeated.slice().reverse().map(exploreMini).join(\'\')}</div>\n        </div>\n      </a>\n\n      <a class="home-preview-card home-ref-card home-v2-payments-card" href="#/money">\n        <div class="home-preview-label"><b>Payments</b><span>Open →</span></div>\n        ${payments.length\n          ? `<div class="home-v2-payments-list">${payments.map(paymentMini).join(\'\')}</div>`\n          : `<div class="home-v2-empty-row"><i></i><b>$</b><i></i><span>No payouts recorded yet.</span></div>`}\n      </a>\n\n      <a class="home-preview-card home-ref-card home-v2-analytics-card" href="#/money">\n        <div class="home-preview-label"><b>Analytics</b><span>Open →</span></div>\n        <div class="home-v2-analytics-tabs"><b>Fees</b><span>1D</span><span>30D</span><span>All time</span></div>\n        <div class="home-v2-analytics-period">1D</div>\n        <strong class="home-v2-analytics-total">${fmtMoney(total)}</strong>\n        <div class="home-v2-chart">${Array.from({length:32},(_,i)=>`<i style="height:${18+((i*37)%76)}%"></i>`).join(\'\')}</div>\n      </a>\n\n      <a class="home-preview-card home-ref-card home-v2-launch-card" href="#/launch">\n        <div class="home-preview-label"><b>Launch</b><span>Open →</span></div>\n        <div class="home-v2-launch-label">Fees route to</div>\n        <div class="home-v2-profile-strip">\n          ${profiles.length?profiles.map((p,i)=>{\n            const n=p.display_name||p.handle;\n            return `<span class="${i===0?\'active\':\'\'}">${avatar(n,false,p.avatar_url||\'\')}<b>${esc(n)}</b><small>@${esc(p.handle||\'\')}</small></span>`;\n          }).join(\'\'):`<span class="active">${avatar(leadName,false,\'\')}<b>${esc(leadName)}</b><small>@${esc(leadHandle)}</small></span>`}\n        </div>\n        <div class="home-v2-paying">\n          <div>${avatar(leadName,true,leadProfile?.avatar_url||\'\')}</div>\n          <span><small>Paying out</small><b>${esc(leadName)}</b><em>@${esc(leadHandle)}</em></span>\n          <strong>${payments[0]?fmtMoney(payments[0].amount_usd??payments[0].amount??0):\'$0.00\'}</strong>\n        </div>\n        <div class="home-v2-sent-via">Sent via X Money</div>\n      </a>\n\n      <a class="home-preview-card home-ref-card home-v2-docs-card" href="#/docs">\n        <div class="home-preview-label"><b>Docs</b><span>Open →</span></div>\n        <small class="home-v2-docs-eyebrow">Sharing config</small>\n        <strong class="home-v2-docs-title">Attribution is per-mint</strong>\n        <p>One config account per token mint. The treasury appears in its shareholders array, so a single wallet gets clean per-token attribution.</p>\n        <div class="home-v2-docs-fields">\n          <span><small>Off</small><small>Len</small><small>Field</small></span>\n          <b><i>0</i><i>8</i><em>discriminator</em></b>\n          <b><i>11</i><i>32</i><em>token mint</em></b>\n          <b><i>43</i><i>32</i><em>admin</em></b>\n          <b><i>75</i><i>1</i><em>revoke flag</em></b>\n        </div>\n        <div class="home-v2-docs-bottom">\n          <span><small>Detection</small><b>On-chain</b></span>\n          <span><small>Claiming</small><b>Creator fees</b></span>\n        </div>\n      </a>\n\n    </div>\n  </section>`;\n}'
s=s[:start]+preview+s[end:]
app.write_text(s)

styles=Path("src/styles.css")
css=styles.read_text()
patch="\n/* home-reference-match-v2\n   Refines Home against the live UsePaid reference:\n   centered hero + real-data marquee Explore + Payments/Analytics/Launch/Docs previews.\n   Visual-only. */\n.home-reference-v1 .home-hero{\n  width:min(100% - 32px,1080px);\n  padding:76px 0 34px;\n}\n.home-reference-v1 .home-hero .hero-copy{\n  width:min(100%,690px);\n  margin:0 auto;\n  text-align:center;\n}\n.home-reference-v1 .home-hero .hero-copy h1,\n.home-reference-v1 .home-hero .hero-copy>p{\n  text-align:center;\n}\n.home-reference-v1 .home-hero .hero-copy>p{\n  margin-left:auto;\n  margin-right:auto;\n}\n.home-reference-v1 .home-hero .hero-buttons{\n  justify-content:center;\n}\n\n.home-reference-v2-previews .home-preview-stack{\n  display:grid;\n  grid-template-columns:1fr;\n  gap:12px;\n}\n.home-reference-v2-previews .home-preview-card.home-ref-card{\n  min-height:0;\n  padding:14px;\n  border-radius:16px;\n}\n.home-reference-v2-previews .home-preview-label{\n  margin-bottom:11px;\n}\n\n/* Explore preview: two moving token rails like the reference */\n.home-v2-explore-card{overflow:hidden!important}\n.home-v2-token-rail{\n  width:100%;\n  overflow:hidden;\n  padding:2px 0 7px;\n  mask-image:linear-gradient(90deg,transparent 0,#000 4%,#000 96%,transparent 100%);\n  -webkit-mask-image:linear-gradient(90deg,transparent 0,#000 4%,#000 96%,transparent 100%);\n}\n.home-v2-token-track{\n  width:max-content;\n  display:flex;\n  gap:8px;\n  animation:homeV2Rail 44s linear infinite;\n}\n.home-v2-token-rail-reverse .home-v2-token-track{\n  animation-direction:reverse;\n  animation-duration:50s;\n}\n@keyframes homeV2Rail{\n  from{transform:translateX(0)}\n  to{transform:translateX(-33.333%)}\n}\n.home-v2-token-mini{\n  width:220px;\n  min-height:70px;\n  display:grid;\n  grid-template-columns:54px minmax(0,1fr) auto;\n  align-items:center;\n  gap:9px;\n  padding:7px;\n  border:1px solid #292929;\n  border-radius:12px;\n  background:#0d0d0d;\n}\n.home-v2-token-media{\n  width:54px;height:54px;position:relative;overflow:hidden;\n  border-radius:9px;background:#171717;\n}\n.home-v2-token-media img,\n.home-v2-token-fallback{\n  width:100%;height:100%;object-fit:cover;\n}\n.home-v2-token-fallback{\n  display:grid;place-items:center;color:#777;\n  background:radial-gradient(circle at 50% 40%,#333 0,#161616 56%,#0c0c0c 100%);\n  font-size:18px;font-weight:700;\n}\n.home-v2-token-copy{min-width:0;display:grid;gap:2px}\n.home-v2-token-copy small{color:#676767;font-size:7px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n.home-v2-token-copy strong{font-size:10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n.home-v2-token-copy span{color:#7b7b7b;font-size:7px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}\n.home-v2-token-mini>b{align-self:end;color:#d8d8d8;font-size:8px;white-space:nowrap}\n\n/* Payments preview */\n.home-v2-payments-list{display:grid;gap:0}\n.home-v2-payment-mini{\n  min-height:48px;\n  display:grid;\n  grid-template-columns:auto 1fr auto;\n  align-items:center;\n  gap:8px;\n  border-top:1px solid #262626;\n}\n.home-v2-payment-mini:first-child{border-top:0}\n.home-v2-payment-mini strong{font-size:13px}\n.home-v2-payment-mini span{color:#777;font-size:9px}\n.home-v2-payment-mini span b{color:#cfcfcf}\n.home-v2-payment-mini time{color:#666;font-size:8px}\n.home-v2-empty-row{\n  min-height:100px;\n  display:flex;align-items:center;justify-content:center;gap:8px;\n  color:#666;font-size:9px;\n}\n.home-v2-empty-row i{\n  width:34px;height:34px;border:1px solid #292929;border-radius:50%;background:#101010;\n}\n.home-v2-empty-row>b{font-size:18px;color:#707070}\n\n/* Analytics preview */\n.home-v2-analytics-tabs{display:flex;align-items:center;gap:13px;color:#747474;font-size:8px}\n.home-v2-analytics-tabs b{color:#fff;font-size:9px}\n.home-v2-analytics-period{margin-top:12px;color:#777;font-size:8px}\n.home-v2-analytics-total{\n  display:block;margin:2px 0 10px;\n  font-size:34px;line-height:1;letter-spacing:-.05em;\n}\n.home-v2-chart{\n  height:88px;\n  display:flex;align-items:flex-end;gap:3px;\n  padding-top:7px;border-top:1px solid #202020;\n}\n.home-v2-chart i{min-width:2px;flex:1;background:#3a3a3a;border-radius:2px 2px 0 0}\n\n/* Launch preview */\n.home-v2-launch-label{color:#777;font-size:8px;margin-bottom:7px}\n.home-v2-profile-strip{\n  display:flex;gap:7px;overflow:hidden;padding-bottom:10px;\n}\n.home-v2-profile-strip>span{\n  flex:0 0 auto;\n  display:grid;\n  grid-template-columns:26px auto;\n  grid-template-rows:auto auto;\n  align-items:center;\n  column-gap:6px;\n  min-width:110px;\n  padding:7px 9px;\n  border:1px solid #292929;border-radius:999px;\n  background:#0f0f0f;\n}\n.home-v2-profile-strip>span.active{border-color:#4a4a4a}\n.home-v2-profile-strip .avatar{grid-row:1/3;width:26px;height:26px}\n.home-v2-profile-strip b{font-size:8px}\n.home-v2-profile-strip small{color:#696969;font-size:6.5px}\n.home-v2-paying{\n  display:grid;\n  grid-template-columns:40px minmax(0,1fr) auto;\n  align-items:center;gap:9px;\n  padding:10px;border:1px solid #2a2a2a;border-radius:12px;background:#0b0b0b;\n}\n.home-v2-paying .avatar{width:38px;height:38px}\n.home-v2-paying>span{display:grid;min-width:0}\n.home-v2-paying small,.home-v2-paying em{color:#717171;font-size:7px;font-style:normal}\n.home-v2-paying b{font-size:10px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}\n.home-v2-paying>strong{font-size:14px}\n.home-v2-sent-via{padding-top:7px;color:#6c6c6c;font-size:7px;text-align:right}\n\n/* Docs preview */\n.home-v2-docs-eyebrow{display:block;color:#6f6f6f;font-size:7px}\n.home-v2-docs-title{display:block;margin-top:2px;font-size:15px}\n.home-v2-docs-card>p{margin:7px 0 10px;color:#777;font-size:8px;line-height:1.45}\n.home-v2-docs-fields{\n  display:grid;\n  grid-template-columns:30px 1fr;\n  gap:2px 6px;\n  padding:7px;border:1px solid #252525;border-radius:9px;background:#0d0d0d;\n}\n.home-v2-docs-fields>span{display:grid;grid-template-columns:1fr 1fr 2fr;grid-column:1/-1;color:#666}\n.home-v2-docs-fields>span small:last-child{text-align:left}\n.home-v2-docs-fields>b{\n  grid-column:1/-1;\n  display:grid;grid-template-columns:30px 30px 1fr;gap:4px;\n  color:#8a8a8a;font-size:6.5px;font-weight:500;\n}\n.home-v2-docs-fields i{font-style:normal;color:#5f5f5f}\n.home-v2-docs-fields em{font-style:normal}\n.home-v2-docs-bottom{display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-top:7px}\n.home-v2-docs-bottom>span{\n  display:grid;gap:2px;padding:7px;border:1px solid #252525;border-radius:8px;background:#0d0d0d;\n}\n.home-v2-docs-bottom small{color:#666;font-size:6px}\n.home-v2-docs-bottom b{font-size:7px;font-weight:600}\n\n/* Keep failed remote images from showing the browser's broken-image glyph. */\n.home-reference-v1 img{font-size:0}\n\n@media(max-width:640px){\n  .home-reference-v1 .home-hero{\n    width:calc(100% - 32px);\n    padding:48px 0 26px;\n  }\n  .home-reference-v1 .home-hero .hero-copy{margin:0 auto;text-align:center}\n  .home-reference-v1 .home-hero .hero-copy h1{\n    max-width:340px;\n    margin:0 auto;\n    font-size:39px;\n    line-height:.92;\n    text-align:center;\n  }\n  .home-reference-v1 .home-hero .hero-copy>p{\n    max-width:355px;\n    margin:17px auto 20px;\n    font-size:10px;\n    line-height:1.55;\n    text-align:center;\n  }\n  .home-reference-v1 .home-hero .hero-buttons{justify-content:center}\n\n  .home-reference-v2-previews .home-preview-stack{\n    width:calc(100% - 24px);\n    gap:8px;\n  }\n  .home-reference-v2-previews .home-preview-card.home-ref-card{\n    padding:10px;\n    border-radius:12px;\n  }\n  .home-v2-token-mini{\n    width:174px;\n    min-height:58px;\n    grid-template-columns:44px minmax(0,1fr) auto;\n    gap:7px;padding:6px;border-radius:9px;\n  }\n  .home-v2-token-media{width:44px;height:44px;border-radius:7px}\n  .home-v2-token-copy strong{font-size:8px}\n  .home-v2-token-copy small,.home-v2-token-copy span{font-size:6px}\n  .home-v2-token-mini>b{font-size:6.5px}\n  .home-v2-payment-mini{min-height:38px}\n  .home-v2-payment-mini strong{font-size:10px}\n  .home-v2-payment-mini span{font-size:7px}\n  .home-v2-payment-mini time{font-size:6px}\n  .home-v2-empty-row{min-height:78px;font-size:7px}\n  .home-v2-empty-row i{width:27px;height:27px}\n  .home-v2-analytics-total{font-size:28px}\n  .home-v2-chart{height:70px}\n  .home-v2-paying{grid-template-columns:32px minmax(0,1fr) auto;padding:8px}\n  .home-v2-paying .avatar{width:30px;height:30px}\n  .home-v2-paying>strong{font-size:11px}\n}\n"
marker="home-reference-match-v2"
if marker not in css:
    css += "\n\n"+patch+"\n"
styles.write_text(css)

print("Home Reference Match v2 installed.")
PY

if ! node --check src/app.js; then
  restore
  echo "JS syntax check failed; restored."
  exit 2
fi

if ! npm run check; then
  restore
  echo "Project check failed; restored."
  exit 3
fi

node <<'NODE'
const fs=require('fs');
const app=fs.readFileSync('src/app.js','utf8');
const css=fs.readFileSync('src/styles.css','utf8');
const checks=[
 ['v2 preview function',app.includes('home-v2-token-rail')],
 ['payments preview',app.includes('home-v2-payments-list')],
 ['analytics preview',app.includes('home-v2-analytics-total')],
 ['launch profile strip',app.includes('home-v2-profile-strip')],
 ['docs technical preview',app.includes('home-v2-docs-fields')],
 ['v2 css marker',css.includes('home-reference-match-v2')],
 ['launch page preserved',app.includes('function launchPage')||app.includes('launch-page')],
 ['wallet code preserved',app.includes('Connect wallet')]
];
let bad=0;
for(const [name,ok] of checks){
  console.log((ok?'PASS':'FAIL')+' '+name);
  if(!ok) bad++;
}
if(bad) process.exit(1);
NODE

git add src/app.js src/styles.css
if git diff --cached --quiet; then
  echo "No new changes to commit."
else
  git commit -m "Refine home reference previews"
  git push origin main
fi

echo
echo "DONE: Home Reference Match v2 installed, checked, committed, and pushed."
echo "Home UI only. No launch/wallet/routing/indexer/payout logic changed."
echo "No server restart was performed."
echo "Restart Console/Run manually once."
