Pump-Fee-Routing — Home Explore Reference Match v3

What this fixes from the latest screenshots:
- The Home Explore composition now follows the reference more closely:
  * left image occupies the upper-left part instead of the whole card height
  * second image begins lower on the right
  * bottom gradient and Explore / Open overlay match the reference structure
  * faint token information remains behind the lower fade, as in the reference
  * recipient pill replaces the Pump/@handle-only chip
- The two images remain completely static.
- Adds a backend-only image resolver for this Explore preview. It reads the token's real Pump metadata and redirects IPFS images through Pump's image delivery URL, which is more reliable on mobile Safari.
- No fake/sample token images are inserted.
- If there is only one real token, the same real token can occupy both positions until more tokens exist.
- No Payments/Analytics/Launch/Docs UI changes.
- No wallet, transaction, routing, claim, payout, or indexer logic changes.
- No automatic server restart.
