from pathlib import Path

path = Path("src/styles.css")
if not path.exists():
    raise SystemExit("ERROR: src/styles.css not found. Run from the existing Replit project root.")

css = path.read_text()
marker = "/* top-tokens-tabs-match-pager-v24-25 */"

if marker not in css:
    css += '''

/* top-tokens-tabs-match-pager-v24-25
   Match Pump / Pons / All typography to the pager number size. */
.home-top-tokens .home-top-token-tabs button{
  font-size:13px !important;
  line-height:1 !important;
}

@media(max-width:640px){
  .home-top-tokens .home-top-token-tabs button{
    font-size:12px !important;
    line-height:1 !important;
  }
}
'''
    path.write_text(css)
    print("PASS: Pump / Pons / All now match pager number size")
else:
    print("Patch already installed")
