Top Tokens Tabs Match Pager v24.25

Changes only the Top Tokens filter row:
- Pump
- Pons
- All

Their text/glyph size now matches the pager number:
- 13px desktop
- 12px mobile

No automatic server restart.

Install in the existing Replit Shell:

rm -rf /tmp/top_tokens_tabs_match_pager_v24_25 && mkdir -p /tmp/top_tokens_tabs_match_pager_v24_25 && unzip -o top_tokens_tabs_match_pager_v24_25.zip -d /tmp/top_tokens_tabs_match_pager_v24_25 && bash /tmp/top_tokens_tabs_match_pager_v24_25/install.sh
