
from pathlib import Path

path=Path("src/styles.css")
css=path.read_text()

marker="/* top-x-avatar-lower-v24-4 */"
if marker not in css:
    css += r'''
/* top-x-avatar-lower-v24-4
   Undo only the last upward move from v24.3.
   Keep the outer translucent ring removed. */
.home-profile-feature[data-profile-layout="v22"] .home-profile-avatar{
  bottom:-19px;
}

.home-profile-feature[data-profile-layout="v22"] .home-profile-feature-body{
  padding-top:27px;
}

@media(max-width:640px){
  .home-profile-feature[data-profile-layout="v22"] .home-profile-avatar{
    bottom:-17px;
  }

  .home-profile-feature[data-profile-layout="v22"] .home-profile-feature-body{
    padding-top:24px;
  }
}
'''
    path.write_text(css)
    print("src/styles.css: last vertical raise reverted; ring removal kept")
else:
    print("src/styles.css: patch already installed")

print("PASS: CSS patch prepared")
