Top X Avatar Lower v24.4

This undoes ONLY the last vertical raise from v24.3.

Result:
- avatar goes back to the v24.2 height;
- GG / @username / Paid Profile / stats go back down with it;
- avatar size stays unchanged;
- the outer translucent second ring stays removed;
- no automatic server restart.

Install in the existing Replit Shell:

rm -rf /tmp/top_x_avatar_lower_v24_4 && mkdir -p /tmp/top_x_avatar_lower_v24_4 && unzip -o top_x_avatar_lower_v24_4.zip -d /tmp/top_x_avatar_lower_v24_4 && bash /tmp/top_x_avatar_lower_v24_4/install.sh
