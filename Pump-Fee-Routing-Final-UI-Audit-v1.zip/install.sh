#!/usr/bin/env bash
set -euo pipefail

if [ ! -f src/app.js ] || [ ! -f src/styles.css ]; then
  echo "Run this from the Pump-Fee-Routing project root."
  exit 1
fi

if [ -n "$(git status --porcelain -- src/app.js src/styles.css)" ]; then
  echo "STOP: src/app.js or src/styles.css has uncommitted changes."
  git status --short -- src/app.js src/styles.css
  exit 2
fi

python3 - <<'PY'
from pathlib import Path

app_path = Path("src/app.js")
css_path = Path("src/styles.css")
app = app_path.read_text()
css = css_path.read_text()

marker = "/* final-ui-audit-v1 */"
if marker in css:
    raise SystemExit("Final UI audit v1 is already installed.")

old_venues = '''      <div class="explore-venue-tabs">
        <button class="${state.explore.venue==='pump'?'active':''}" data-venue="pump">● Pump</button>
        <button class="${state.explore.venue==='pons'?'active':''}" data-venue="pons">■ Pons</button>
      </div>'''
new_venues = '''      <div class="explore-venue-tabs">
        <button class="${!state.explore.venue?'active':''}" data-venue="">All</button>
        <button class="${state.explore.venue==='pump'?'active':''}" data-venue="pump">● Pump</button>
        <button disabled>■ Pons <small>Soon</small></button>
        <button disabled>Four <small>Soon</small></button>
      </div>'''
if old_venues not in app:
    raise SystemExit("Expected Explore venue block was not found.")
app = app.replace(old_venues, new_venues, 1)

docs_items = [
    ('<a href="#docs-1"><b>1</b>Overview</a>', '<button type="button" data-scroll-to="docs-1"><b>1</b>Overview</button>'),
    ('<a href="#docs-2"><b>2</b>Supported venues</a>', '<button type="button" data-scroll-to="docs-2"><b>2</b>Supported venues</button>'),
    ('<a href="#docs-3"><b>3</b>Directing fees</a>', '<button type="button" data-scroll-to="docs-3"><b>3</b>Directing fees</button>'),
    ('<a href="#docs-4"><b>4</b>Naming the recipient</a>', '<button type="button" data-scroll-to="docs-4"><b>4</b>Naming the recipient</button>'),
    ('<a href="#docs-5"><b>5</b>The ${recipientPct}/${protocolPct} split</a>', '<button type="button" data-scroll-to="docs-5"><b>5</b>The ${recipientPct}/${protocolPct} split</button>'),
    ('<a href="#docs-6"><b>6</b>How claims work</a>', '<button type="button" data-scroll-to="docs-6"><b>6</b>How claims work</button>'),
    ('<a href="#docs-7"><b>7</b>Getting your fees</a>', '<button type="button" data-scroll-to="docs-7"><b>7</b>Getting your fees</button>'),
    ('<a href="#docs-8"><b>8</b>Payout setup</a>', '<button type="button" data-scroll-to="docs-8"><b>8</b>Payout setup</button>'),
    ('<a href="#docs-9"><b>9</b>Unclaimed payments</a>', '<button type="button" data-scroll-to="docs-9"><b>9</b>Unclaimed payments</button>'),
    ('<a href="#docs-10"><b>10</b>Public confirmation</a>', '<button type="button" data-scroll-to="docs-10"><b>10</b>Public confirmation</button>'),
    ('<a href="#docs-11"><b>11</b>Treasury and cross-chain</a>', '<button type="button" data-scroll-to="docs-11"><b>11</b>Treasury and cross-chain</button>'),
    ('<a href="#docs-12"><b>12</b>$PAID and buyback</a>', '<button type="button" data-scroll-to="docs-12"><b>12</b>$PAID and buyback</button>'),
    ('<a href="#docs-13"><b>13</b>Stopping payments</a>', '<button type="button" data-scroll-to="docs-13"><b>13</b>Stopping payments</button>'),
    ('<a href="#docs-14"><b>14</b>If a token is not registering</a>', '<button type="button" data-scroll-to="docs-14"><b>14</b>If a token is not registering</button>'),
    ('<a href="#docs-15"><b>15</b>Glossary</a>', '<button type="button" data-scroll-to="docs-15"><b>15</b>Glossary</button>'),
]
for old, new in docs_items:
    if old not in app:
        raise SystemExit(f"Docs TOC item not found: {old[:50]}")
    app = app.replace(old, new, 1)

old_legal = '''    <section class="wrap legal-tabs">
      <a href="#legal-terms" class="active">Terms</a>
      <a href="#legal-privacy">Privacy</a>
      <a href="#legal-disclosures">Disclosures</a>
    </section>'''
new_legal = '''    <section class="wrap legal-tabs">
      <button type="button" class="active" data-scroll-to="legal-terms">Terms</button>
      <button type="button" data-scroll-to="legal-privacy">Privacy</button>
      <button type="button" data-scroll-to="legal-disclosures">Disclosures</button>
    </section>'''
if old_legal not in app:
    raise SystemExit("Expected Legal tabs were not found.")
app = app.replace(old_legal, new_legal, 1)

click_anchor = "app.addEventListener('click',async e=>{\n  try{\n"
click_insert = '''app.addEventListener('click',async e=>{
  try{
    const scrollControl=e.target.closest('[data-scroll-to]');
    if(scrollControl){
      e.preventDefault();
      const target=document.getElementById(scrollControl.dataset.scrollTo);
      if(target)target.scrollIntoView({behavior:'smooth',block:'start'});
      if(scrollControl.closest('.legal-tabs')){
        scrollControl.closest('.legal-tabs').querySelectorAll('[data-scroll-to]').forEach(x=>x.classList.toggle('active',x===scrollControl));
      }
      return;
    }
'''
if click_anchor not in app:
    raise SystemExit("Main click handler anchor was not found.")
app = app.replace(click_anchor, click_insert, 1)

app_path.write_text(app)

css += r'''

/* final-ui-audit-v1 */
.explore-venue-tabs button:disabled{
  opacity:.38;
  cursor:default;
}
.explore-venue-tabs button small{
  margin-left:3px;
  color:#555;
  font-size:.72em;
  font-weight:600;
}

.docs-toc button{
  appearance:none;
  width:100%;
  display:grid;
  grid-template-columns:28px 1fr;
  gap:10px;
  padding:12px 10px 12px 0;
  border:0;
  border-bottom:1px solid #171717;
  background:transparent;
  color:#7b7b7b;
  font:inherit;
  font-size:11px;
  text-align:left;
  cursor:pointer;
}
.docs-toc button:nth-last-child(-n+2){border-bottom:0}
.docs-toc button b{
  color:#4f4f4f;
  font-size:9px;
}
.docs-v1-section{scroll-margin-top:92px}

.legal-tabs button{
  appearance:none;
  border:0;
  padding:9px 13px;
  border-radius:999px;
  background:#111;
  color:#707070;
  font:inherit;
  font-size:10px;
  font-weight:650;
  cursor:pointer;
}
.legal-tabs button.active{
  background:#fff;
  color:#000;
}
.legal-block{scroll-margin-top:118px}

@media(max-width:640px){
  .docs-toc button{
    padding:10px 0;
    font-size:10px;
  }
  .docs-toc button:nth-last-child(-n+2){border-bottom:1px solid #171717}
  .docs-toc button:last-child{border-bottom:0}
  .legal-tabs button{
    flex:0 0 auto;
    font-size:9px;
  }
  .docs-v1-section{scroll-margin-top:78px}
  .legal-block{scroll-margin-top:104px}
}
'''
css_path.write_text(css)

print("Final UI/navigation audit patch installed.")
PY

node <<'NODE'
const fs=require('fs');
const src=fs.readFileSync('src/app.js','utf8');

const bare=[...src.matchAll(/href="(#[^"]*)"/g)]
  .map(x=>x[1])
  .filter(x=>!x.startsWith('#/'));

if(bare.length){
  console.error('UI audit failed: bare hash links remain:', [...new Set(bare)]);
  process.exit(1);
}

const actions=[...new Set([...src.matchAll(/data-action="([^"]+)"/g)].map(x=>x[1]))];
const handled=[...new Set([...src.matchAll(/action==='([^']+)'/g)].map(x=>x[1]))];
const missing=actions.filter(x=>!handled.includes(x));

if(missing.length){
  console.error('UI audit failed: unhandled data-action values:', missing);
  process.exit(1);
}

if(!src.includes('data-scroll-to="docs-1"') || !src.includes('data-scroll-to="legal-terms"')){
  console.error('UI audit failed: in-page scroll controls missing.');
  process.exit(1);
}

if(!src.includes('>All</button>') || !src.includes('Pons <small>Soon</small>') || !src.includes('Four <small>Soon</small>')){
  console.error('UI audit failed: Explore venue roadmap controls missing.');
  process.exit(1);
}

console.log('UI audit: PASS');
console.log(`Actions checked: ${actions.length}; bare hash links: 0`);
NODE

npm run check

git add src/app.js src/styles.css

if git diff --cached --quiet; then
  echo "No staged changes; nothing to commit."
else
  git commit -m "Final UI navigation audit"
fi

git push origin main

echo
echo "DONE: Final UI audit checked, committed, and pushed to GitHub."
echo "No server restart was performed."
echo "Restart Console/Run manually once to load this frontend pass."
