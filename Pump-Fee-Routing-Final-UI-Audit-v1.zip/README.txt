Pump Fee Routing — Final UI Audit v1

Focused final pass across the existing public SPA without adding preview/demo pages.

Fixes:
- Docs table-of-contents no longer breaks the hash router.
- Legal Terms/Privacy/Disclosures tabs no longer break the hash router.
- Explore venue roadmap restored to All / Pump / Pons Soon / Four Soon.
- Adds section scroll offsets for sticky header/tabs.
- Adds a static audit for bare hash links and unhandled data-action controls.

Does not change backend, SQLite, discovery, claims, payouts, Solana, or live-data logic.
Runs UI audit -> npm run check -> commit -> push origin/main.
No automatic server restart.
