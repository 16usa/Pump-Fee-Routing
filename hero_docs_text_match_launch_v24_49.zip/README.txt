Hero Docs Text Match Launch v24.49

Checked against current GitHub main.

Change:
- keeps the dark Read the docs pill exactly as it is
- changes only its mobile text size from 10px to 11px
- desktop remains 13px
- this visually matches the white Launch a token CTA text size
- no server restart
