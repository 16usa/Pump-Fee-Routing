from pathlib import Path

css_path = Path("src/styles.css")
if not css_path.exists():
    raise SystemExit("ERROR: src/styles.css not found. Run this from the existing Replit project root.")

css = css_path.read_text()
marker = "/* hero-docs-text-match-launch-v24-49 */"

if "hero-docs-black-pill-v24-48" not in css:
    raise SystemExit("ERROR: v24.48 docs pill styles not found in src/styles.css")

if marker not in css:
    css += r'''

/* hero-docs-text-match-launch-v24-49
   Match the dark Read the docs button text size to the white Launch a token CTA. */
@media(max-width:640px){
  .home-reference-v1 .home-hero .text-link{
    font-size:11px !important;
  }
}
'''
    css_path.write_text(css)
    print("PASS: Read the docs mobile text size now matches the white CTA visually.")
else:
    print("No changes needed; v24.49 already installed.")
