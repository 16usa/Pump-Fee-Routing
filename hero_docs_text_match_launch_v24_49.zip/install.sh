#!/usr/bin/env bash
set -euo pipefail

PATCH_NAME="hero_docs_text_match_launch_v24_49"
CSS="src/styles.css"

if [ ! -f "$CSS" ]; then
  echo "ERROR: missing src/styles.css"
  echo "Run this from the existing Replit project root."
  exit 1
fi

echo "==> Installing ${PATCH_NAME}"
mkdir -p ".patch-backups/${PATCH_NAME}"
cp "$CSS" ".patch-backups/${PATCH_NAME}/styles.css.before"

python3 "$(dirname "$0")/patch.py"

echo "==> Verifying patch"
grep -q 'hero-docs-text-match-launch-v24-49' "$CSS"
grep -q 'font-size:11px !important' "$CSS"

echo "==> Running project check"
npm run check

echo "==> Git diff"
git diff --stat -- "$CSS"

git add "$CSS"
if git diff --cached --quiet; then
  echo "==> No new changes to commit."
else
  git commit -m "Match docs CTA text size to launch CTA"
  git push origin main
fi

echo
echo "PASS: ${PATCH_NAME} installed."
echo "No server restart was performed."
