Pump Fee Routing — Home polish v1
Second-pass polish from the supplied reference screenshots.
Changes: consistent mobile gutters/section spacing, corrected On-ramp hierarchy, removes the extra footer bottom strip.
No backend, Solana, SQLite, worker, payout, or discovery logic changes.
Runs npm check, commits, and pushes to origin/main. No automatic server restart.
