#!/usr/bin/env bash
set -euo pipefail

if [ ! -f src/app.js ] || [ ! -f src/styles.css ]; then
  echo "Run this from the Pump-Fee-Routing project root."
  exit 1
fi

if [ -n "$(git status --porcelain -- src/app.js src/styles.css)" ]; then
  echo "STOP: src/app.js or src/styles.css has uncommitted changes."
  git status --short -- src/app.js src/styles.css
  exit 2
fi

python3 - <<'PY'
from pathlib import Path

app_path = Path("src/app.js")
css_path = Path("src/styles.css")
app = app_path.read_text()
css = css_path.read_text()

marker = "/* home-polish-v1 */"
if marker in css:
    raise SystemExit("Home polish v1 is already installed.")

# --- Correct On-ramp hierarchy to match the supplied reference ---
start = app.find("function isOnRampOrder(x){")
end = app.find("function homePage(){", start)
if start < 0 or end < 0:
    raise SystemExit("Could not locate current On-ramp functions.")

on_ramp = r'''function isOnRampOrder(x){
  const side=String(x?.side||'').toLowerCase();
  return ['buy','deposit','onramp','on-ramp','transfer_in','transfer-in','withdrawal','withdraw'].some(v=>side.includes(v));
}

function homeOnRampCard(x,i){
  const provider=String(x.provider||'Kraken');
  const usd=Number(x.received_usd||x.gross_usd||0);
  const native=Number(x.volume_native||0);
  const pair=String(x.pair||'SOLUSD').toUpperCase();
  const status=String(x.status||'received');
  const amount=usd>0?fmtMoney(usd):(native>0?`${fmtNum(native)} SOL`:'$0.00');
  return `<button class="home-on-card expandable" data-expand="home-on-${i}">
    <div class="home-on-main">
      <div class="home-on-copy">
        <strong>${esc(amount)}</strong>
        <span>from <b>${esc(provider)}</b></span>
      </div>
      <span class="home-on-money">$</span>
      <div class="home-on-meta">
        <span class="home-on-status">${esc(status)}</span>
        <time>${esc(ago(x.filled_at||x.created_at))}</time>
      </div>
      <span class="chev">⌄</span>
    </div>
    <div class="tx-details hidden">
      <div><span>Provider</span><b>${esc(provider)}</b></div>
      <div><span>Pair</span><b>${esc(pair)}</b></div>
      <div><span>Side</span><b>${esc(x.side||'')}</b></div>
      <div><span>Reference</span><b>${esc(x.provider_ref||x.id||'')}</b></div>
    </div>
  </button>`;
}

function homeOnRamp(h){
  const orders=(h.money?.exchange||[]).filter(isOnRampOrder).slice(0,6);
  const inTransit=orders.reduce((sum,x)=>sum+Number(x.received_usd||x.gross_usd||0),0);
  return `<section class="wrap section home-on-ramp">
    <div class="home-on-head">
      <h2>On-ramp</h2>
      <div class="home-on-transit"><b>${fmtMoney(inTransit)}</b><span>in transit</span></div>
      <div class="home-on-pager"><button disabled>‹</button><span>1</span><button disabled>›</button></div>
    </div>
    <div class="home-on-list">
      ${orders.length
        ? orders.map(homeOnRampCard).join('')
        : `<div class="home-on-empty">
            <div class="home-on-empty-route"><i>$</i></div>
            <strong>No on-ramp activity yet.</strong>
            <span>Confirmed funding events will appear here.</span>
          </div>`}
    </div>
  </section>`;
}

'''
app = app[:start] + on_ramp + app[end:]

# --- Remove the extra footer-bottom copy that is not in the supplied reference ---
old_footer_tail = '''  </div>
  <div class="footer-bottom">
    <span>Built on Solana</span>
    <span>Creator fees → treasury → recipient</span>
  </div>
</footer>`;}'''
new_footer_tail = '''  </div>
</footer>`;}'''
if old_footer_tail not in app:
    raise SystemExit("Could not locate current footer bottom block.")
app = app.replace(old_footer_tail, new_footer_tail, 1)

app_path.write_text(app)

css += r'''

/* home-polish-v1 */

/* Match the mobile reference's consistent 16px side gutter on Home. */
@media(max-width:640px){
  .home-page .wrap{
    width:calc(100% - 32px);
  }
  .home-page .section{
    padding-top:30px;
    padding-bottom:30px;
  }
  .home-top-tokens,
  .home-top-profiles,
  .home-recent-payments,
  .home-most-payments,
  .home-off-ramp,
  .home-on-ramp{
    padding-top:30px!important;
  }

  .home-top-tokens-head>h2,
  .home-top-profiles-head h2,
  .home-recent-payments-head h2,
  .home-most-payments-head h2,
  .home-off-head h2,
  .home-on-head h2{
    font-size:17px;
  }
}

/* On-ramp: reference uses one central money rail icon, no category tabs. */
.home-on-head{
  grid-template-columns:auto 1fr auto;
  align-items:center;
  margin-bottom:14px;
}
.home-on-transit{
  width:max-content;
  justify-self:start;
  display:flex;
  align-items:baseline;
  gap:5px;
  padding:6px 9px;
  border:1px solid #2d2d2d;
  border-radius:999px;
  background:#151515;
}
.home-on-transit b{
  color:#f1f1f1;
  font-size:10px;
  font-weight:650;
}
.home-on-transit span{
  color:#696969;
  font-size:7px;
}
.home-on-main{
  grid-template-columns:minmax(0,1fr) 38px auto 12px;
}
.home-on-copy span b{color:#fff;font-weight:650}
.home-on-money{
  width:38px;
  height:38px;
  display:grid;
  place-items:center;
  border-radius:50%;
  background:#050505;
  border:1px solid #292929;
  color:#fff;
  font-size:18px;
  font-weight:850;
}
.home-on-status{
  color:#c9c9c9;
  background:#303030;
}
.home-on-empty-route{
  margin-bottom:5px;
}
.home-on-empty-route i{
  width:38px;
  height:38px;
  font-size:17px;
  font-weight:850;
}
.home-on-tabs,
.home-on-route,
.home-on-provider,
.home-on-sol,
.home-on-arrow,
.home-on-total{
  display:none!important;
}

/* Keep footer as the clean four-part reference footer; no invented bottom strip. */
.site-footer .footer-bottom{
  display:none!important;
}
.site-footer .footer-inner{
  padding-bottom:48px;
}

@media(max-width:640px){
  .home-on-head{
    grid-template-columns:auto 1fr auto;
    gap:9px;
  }
  .home-on-transit{
    padding:5px 8px;
  }
  .home-on-transit b{font-size:9px}
  .home-on-main{
    grid-template-columns:minmax(0,1fr) 34px auto 10px;
    gap:7px;
  }
  .home-on-money{
    width:34px;
    height:34px;
    font-size:16px;
  }
  .site-footer .footer-inner{
    padding-bottom:38px;
  }
}
'''
css_path.write_text(css)

print("Home polish v1 patch installed.")
PY

npm run check

git add src/app.js src/styles.css

if git diff --cached --quiet; then
  echo "No staged changes; nothing to commit."
else
  git commit -m "Polish home against reference"
fi

git push origin main

echo
echo "DONE: Home polish checked, committed, and pushed to GitHub."
echo "No server restart was performed."
echo "Refresh the browser to see the polished Home page."
