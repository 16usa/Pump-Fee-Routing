Explore Footer Match Preview v24.40

Fixes the style conflict where Explore / Open were being overridden smaller
by the later Explore magazine styles.

Reference:
- Payments / Analytics / Launch / Docs preview footer labels

Result:
- desktop: 13px
- mobile: 12px
- same color #888
- same weight 430
- same line-height

No automatic restart.
