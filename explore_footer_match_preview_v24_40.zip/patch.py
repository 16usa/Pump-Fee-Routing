from pathlib import Path

css_path = Path("src/styles.css")
if not css_path.exists():
    raise SystemExit("ERROR: src/styles.css not found. Run from the existing Replit project root.")

css = css_path.read_text()
marker = "/* explore-footer-match-lower-preview-v24-40 */"

if ".home-explore-v8-footer" not in css:
    raise SystemExit("ERROR: Explore footer styles not found in src/styles.css")

if marker not in css:
    css += r'''

/* explore-footer-match-lower-preview-v24-40
   Make Explore / Open match the footer typography used by
   Payments / Analytics / Launch / Docs preview cards. */
.home-explore-reference-v8 .home-explore-v8-footer strong,
.home-explore-reference-v8 .home-explore-v8-footer span{
  color:#888 !important;
  font-size:13px !important;
  line-height:1 !important;
  font-weight:430 !important;
  letter-spacing:0 !important;
  white-space:nowrap !important;
}

@media(max-width:640px){
  .home-explore-reference-v8 .home-explore-v8-footer strong,
  .home-explore-reference-v8 .home-explore-v8-footer span{
    color:#888 !important;
    font-size:12px !important;
    line-height:1 !important;
    font-weight:430 !important;
  }
}
'''
    css_path.write_text(css)
    print("PASS: Explore/Open now match the lower preview footer text size.")
else:
    print("No changes needed; v24.40 already installed.")
