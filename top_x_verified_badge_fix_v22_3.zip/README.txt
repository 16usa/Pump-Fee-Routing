Top X Verified Badge Fix v22.3

Fixes the blue verified badge in Top X Profiles so it matches the reference much more closely:
- smaller, round X-style blue badge
- cleaner white checkmark
- better baseline alignment next to the display name
- no oversized / distorted badge look

Install in the existing Replit Shell:
rm -rf /tmp/top_x_verified_badge_fix_v22_3 && mkdir -p /tmp/top_x_verified_badge_fix_v22_3 && unzip -o top_x_verified_badge_fix_v22_3.zip -d /tmp/top_x_verified_badge_fix_v22_3 && bash /tmp/top_x_verified_badge_fix_v22_3/install.sh

No automatic server restart is performed.
