#!/usr/bin/env bash
set -euo pipefail

PATCH_NAME="top_x_verified_badge_fix_v22_3"
APP="src/app.js"
CSS="src/styles.css"

if [ ! -f "$APP" ] || [ ! -f "$CSS" ]; then
  echo "ERROR: missing $APP or $CSS"
  echo "Run this from the existing Replit project root."
  exit 1
fi

echo "==> Installing ${PATCH_NAME}"
mkdir -p ".patch-backups/${PATCH_NAME}"
cp "$APP" ".patch-backups/${PATCH_NAME}/app.js.before"
cp "$CSS" ".patch-backups/${PATCH_NAME}/styles.css.before"

python3 - <<'PY2'
from pathlib import Path

app_path=Path('src/app.js')
css_path=Path('src/styles.css')
app=app_path.read_text()
css=css_path.read_text()

start = """  const verifiedBadge=verified
    ? `<span class="home-profile-verified" title="Verified" aria-label="Verified">
        <svg viewBox="0 0 22 22" aria-hidden="true">"""
end = """      </span>`
    : '';"""
new_block = """  const verifiedBadge=verified
    ? `<span class="home-profile-verified" title="Verified" aria-label="Verified">
        <svg viewBox="0 0 20 20" aria-hidden="true">
          <circle class="badge-bg" cx="10" cy="10" r="9"/>
          <path class="check" d="M6.3 10.2 8.7 12.6 13.9 7.4"/>
        </svg>
      </span>`
    : '';"""

if 'viewBox="0 0 20 20"' not in app:
    a=app.find(start)
    if a==-1:
        raise SystemExit('ERROR: verified badge block start not found in src/app.js')
    b=app.find(end,a)
    if b==-1:
        raise SystemExit('ERROR: verified badge block end not found in src/app.js')
    b += len(end)
    app=app[:a]+new_block+app[b:]
    app_path.write_text(app)
    print('src/app.js: verified badge markup updated')
else:
    print('src/app.js: verified badge markup already updated')

marker='/* top-x-verified-badge-fix-v22-3 */'
if marker not in css:
    css += """

/* top-x-verified-badge-fix-v22-3 */
.home-profile-feature[data-profile-layout="v22"] .home-profile-display-row{
  align-items:center;
  gap:7px;
}

.home-profile-feature[data-profile-layout="v22"] .home-profile-display-row>strong{
  line-height:1.02;
}

.home-profile-feature[data-profile-layout="v22"] .home-profile-verified{
  width:16px;
  height:16px;
  display:inline-flex;
  align-items:center;
  justify-content:center;
  flex:0 0 16px;
  transform:translateY(1px);
}

.home-profile-feature[data-profile-layout="v22"] .home-profile-verified svg{
  width:100%;
  height:100%;
  display:block;
}

.home-profile-feature[data-profile-layout="v22"] .home-profile-verified .badge-bg{
  fill:#1d9bf0;
}

.home-profile-feature[data-profile-layout="v22"] .home-profile-verified .check{
  fill:none;
  stroke:#ffffff;
  stroke-width:2.1;
  stroke-linecap:round;
  stroke-linejoin:round;
}

@media(max-width:640px){
  .home-profile-feature[data-profile-layout="v22"] .home-profile-display-row{
    gap:6px;
  }

  .home-profile-feature[data-profile-layout="v22"] .home-profile-verified{
    width:15px;
    height:15px;
    flex-basis:15px;
  }
}
"""
    css_path.write_text(css)
    print('src/styles.css: verified badge style overrides appended')
else:
    print('src/styles.css: verified badge style overrides already installed')
PY2

echo "==> Running project check"
npm run check

echo "==> Git diff"
git diff -- src/app.js src/styles.css

git add src/app.js src/styles.css

if git diff --cached --quiet; then
  echo "==> No new changes to commit."
else
  git commit -m "Refine Top X verified badge to match reference"
  git push origin main
fi

echo
echo "PASS: ${PATCH_NAME} installed."
echo "No server restart was performed."
