#!/usr/bin/env bash
set -euo pipefail

echo "== Launch Reference Match v18 =="

for f in src/app.js src/styles.css; do
  if [ ! -f "$f" ]; then
    echo "ERROR: $f not found. Run this from the existing Replit project workspace."
    exit 1
  fi
done

python3 <<'PYCODE'
from pathlib import Path

app_path = Path('src/app.js')
css_path = Path('src/styles.css')
app = app_path.read_text()
css = css_path.read_text()

app_marker = 'data-launch-reference="v18"'
css_marker = '/* launch-reference-match-v18 */'

if app_marker not in app:
    start = app.find('<a class="home-preview-card home-ref-card home-v2-launch-card" href="#/launch">')
    if start < 0:
        raise SystemExit('ERROR: current Launch preview block not found.')
    end = app.find("\n\n      <a class=\"home-preview-card home-ref-card home-v2-docs-card\" href=\"#/docs\">", start)
    if end < 0:
        raise SystemExit('ERROR: could not locate end of Launch preview block.')

    new_block = '''<a class="home-preview-card home-ref-card home-v2-launch-card" data-launch-reference="v18" href="#/launch">
        <div class="home-v2-launch-stage">
          <div class="home-v2-launch-eyebrow">FEES ROUTE TO</div>
          <div class="home-v2-launch-search">
            <i aria-hidden="true"></i>
            <strong>@${esc(leadHandle)}</strong>
          </div>
          <div class="home-v2-launch-result">
            <div class="home-v2-launch-result-avatar">${leadProfile?recipientAvatar(leadHandle,leadName,true,leadProfile?.avatar_url||''):avatar(leadName,true,'')}</div>
            <div class="home-v2-launch-result-copy">
              <strong>${esc(leadName)}${leadProfile?.verified?'<em>✓</em>':''}</strong>
              <span>@${esc(leadHandle)}</span>
            </div>
          </div>
          <div class="home-v2-launch-bottom-shade" aria-hidden="true"></div>
          <div class="home-v2-launch-footer"><strong>Launch</strong><span>Open →</span></div>
        </div>
      </a>'''

    app = app[:start] + new_block + app[end:]
    app_path.write_text(app)
    print('PASS Launch preview markup updated')
else:
    print('PASS Launch v18 markup already installed')

if css_marker not in css:
    css_patch = r'''
/* launch-reference-match-v18 */
.home-reference-v2-previews .home-preview-card.home-v2-launch-card[data-launch-reference="v18"]{
  position:relative;
  display:block;
  min-height:246px;
  padding:12px;
  overflow:hidden;
  border:1px solid #303030;
  border-radius:20px;
  background:#171717;
  box-shadow:none;
  isolation:isolate;
}
.home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-stage{
  position:relative;
  min-height:220px;
  padding:12px 14px 44px;
}
.home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-eyebrow{
  color:#777;
  font-size:11px;
  line-height:1;
  font-weight:520;
  letter-spacing:.13em;
}
.home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-search{
  min-height:56px;
  margin-top:13px;
  display:flex;
  align-items:center;
  gap:12px;
  padding:0 18px;
  border:3px solid #f0f0f0;
  border-radius:999px;
  background:#080808;
}
.home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-search>i{
  position:relative;
  width:15px;
  height:15px;
  flex:0 0 15px;
  border:1.6px solid #7c838d;
  border-radius:50%;
}
.home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-search>i:after{
  content:'';
  position:absolute;
  right:-5px;
  bottom:-3px;
  width:6px;
  height:1.6px;
  border-radius:2px;
  background:#7c838d;
  transform:rotate(45deg);
  transform-origin:left center;
}
.home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-search>strong{
  min-width:0;
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
  color:#f2f2f2;
  font-size:16px;
  line-height:1;
  font-weight:420;
}
.home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-result{
  min-height:62px;
  margin-top:10px;
  display:flex;
  align-items:center;
  gap:11px;
  padding:9px 12px;
  border:0;
  border-radius:12px;
  background:#242424;
}
.home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-result-avatar,
.home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-result-avatar .avatar{
  width:43px;
  height:43px;
  flex:0 0 43px;
}
.home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-result-copy{
  min-width:0;
  display:grid;
  gap:4px;
}
.home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-result-copy>strong{
  min-width:0;
  display:flex;
  align-items:center;
  gap:5px;
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
  color:#f1f1f1;
  font-size:16px;
  line-height:1;
  font-weight:620;
}
.home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-result-copy>strong em{
  display:inline-grid;
  place-items:center;
  width:14px;
  height:14px;
  flex:0 0 14px;
  border-radius:50%;
  background:#1597e5;
  color:#fff;
  font-size:9px;
  font-style:normal;
  line-height:1;
}
.home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-result-copy>span{
  color:#8a8a8a;
  font-size:11px;
  line-height:1;
}
.home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-bottom-shade{
  position:absolute;
  left:-12px;
  right:-12px;
  bottom:-12px;
  z-index:2;
  height:75px;
  pointer-events:none;
  background:linear-gradient(180deg,rgba(23,23,23,0) 0%,rgba(23,23,23,.52) 55%,#171717 100%);
}
.home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-footer{
  position:absolute;
  left:6px;
  right:6px;
  bottom:3px;
  z-index:3;
  display:flex;
  align-items:center;
  justify-content:space-between;
  pointer-events:none;
}
.home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-footer strong,
.home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-footer span{
  color:#c8c8c8;
  font-size:12px;
  line-height:1;
  font-weight:420;
  letter-spacing:0;
  white-space:nowrap;
}
@media(max-width:640px){
  .home-reference-v2-previews .home-preview-card.home-v2-launch-card[data-launch-reference="v18"]{
    min-height:218px;
    padding:9px;
    border-radius:16px;
  }
  .home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-stage{
    min-height:198px;
    padding:11px 10px 38px;
  }
  .home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-eyebrow{
    font-size:9px;
    letter-spacing:.14em;
  }
  .home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-search{
    min-height:45px;
    margin-top:11px;
    gap:10px;
    padding:0 14px;
    border-width:2.5px;
  }
  .home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-search>strong{
    font-size:13px;
  }
  .home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-result{
    min-height:54px;
    margin-top:8px;
    gap:9px;
    padding:8px 10px;
    border-radius:10px;
  }
  .home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-result-avatar,
  .home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-result-avatar .avatar{
    width:36px;
    height:36px;
    flex-basis:36px;
  }
  .home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-result-copy>strong{
    font-size:13px;
  }
  .home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-result-copy>span{
    font-size:9px;
  }
  .home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-bottom-shade{
    left:-9px;
    right:-9px;
    bottom:-9px;
    height:68px;
  }
  .home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-footer{
    left:4px;
    right:4px;
    bottom:2px;
  }
  .home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-footer strong,
  .home-v2-launch-card[data-launch-reference="v18"] .home-v2-launch-footer span{
    font-size:11px;
  }
}
'''
    css_path.write_text(css.rstrip() + '\n\n' + css_patch + '\n')
    print('PASS Launch reference CSS added')
else:
    print('PASS Launch v18 CSS already installed')

app = app_path.read_text()
css = css_path.read_text()
checks = {
    'launch marker': app_marker in app,
    'route label': 'home-v2-launch-eyebrow' in app,
    'search field': 'home-v2-launch-search' in app,
    'profile result': 'home-v2-launch-result' in app,
    'footer': 'home-v2-launch-footer' in app,
    'css marker': css_marker in css,
}
for label, ok in checks.items():
    if not ok:
        raise SystemExit(f'ERROR: verification failed: {label}')
    print('PASS', label)
PYCODE

echo
echo "== Project checks =="
npm run check

echo
echo "== Git diff =="
git diff --stat

git add src/app.js src/styles.css

if git diff --cached --quiet; then
  echo "No new changes to commit."
else
  git commit -m "Match Launch preview to reference layout"
  git push
fi

echo
echo "DONE: Launch Reference Match v18 installed, checked, committed, and pushed."
echo "No server restart was performed."
echo "Restart Run/Console manually once, then reload the page."
