Pump Fee Routing — Launch Reference Match v18

Changes only the HOME Launch preview block to match the supplied UsePaid reference:
- removes the old top Launch/Open label row
- shows FEES ROUTE TO at the top
- adds the large rounded search field with the current X handle
- shows one profile result row with the real avatar/name/handle
- removes the old payout amount / Sent via X Money preview from this card
- moves Launch / Open → to the bottom footer
- does not restart the server automatically

Install in the existing Replit workspace:

rm -rf /tmp/launch-reference-match-v18
mkdir -p /tmp/launch-reference-match-v18
unzip -o Pump-Fee-Routing-Launch-Reference-Match-v18.zip -d /tmp/launch-reference-match-v18
bash /tmp/launch-reference-match-v18/install.sh
