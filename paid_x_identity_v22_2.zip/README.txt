Paid X Identity v22.2

Fix:
- Top X card now uses the current X display name (for example GG), not the old stored handle/name.
- Blue/business/government verified badges render correctly.
- Fixes SQLite verified values returned as 0/1.
- The first 4 Top X profiles are refreshed from the existing /api/x/profile endpoint before Home renders.
- Keeps the real X banner support from v22.1.
- No automatic server restart.

Install in existing Replit Shell:
rm -rf /tmp/paid_x_identity_v22_2 && mkdir -p /tmp/paid_x_identity_v22_2 && unzip -o paid_x_identity_v22_2.zip -d /tmp/paid_x_identity_v22_2 && bash /tmp/paid_x_identity_v22_2/install.sh
