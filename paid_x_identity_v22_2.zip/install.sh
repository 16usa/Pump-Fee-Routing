#!/usr/bin/env bash
set -euo pipefail

PATCH_NAME="paid_x_identity_v22_2"
APP="src/app.js"

if [ ! -f "$APP" ]; then
  echo "ERROR: missing $APP"
  echo "Run this from the existing Replit project root."
  exit 1
fi

echo "==> Installing ${PATCH_NAME}"

mkdir -p ".patch-backups/${PATCH_NAME}"
cp "$APP" ".patch-backups/${PATCH_NAME}/app.js.before"

python3 - <<'PY'
from pathlib import Path

path=Path("src/app.js")
s=path.read_text()

old_verified="""  const verified=
    p.verified===true||
    p.is_verified===true||
    p.blue_verified===true||
    p.is_blue_verified===true||
    ['blue','business','government'].includes(String(p.verified_type||'').toLowerCase());"""

new_verified="""  const verified=
    p.verified===true||
    Number(p.verified)===1||
    String(p.verified||'').toLowerCase()==='true'||
    p.is_verified===true||
    Number(p.is_verified)===1||
    p.blue_verified===true||
    p.is_blue_verified===true||
    ['blue','business','government'].includes(String(p.verified_type||'').toLowerCase());"""

if old_verified in s:
    s=s.replace(old_verified,new_verified,1)
elif "Number(p.verified)===1" not in s:
    raise SystemExit("ERROR: homeProfileCard verified block not found")

old_load="""async function loadBase(){const [cfg,home,money,tokens]=await Promise.all([api('/api/config'),api('/api/home'),api('/api/money'),api('/api/tokens?limit=100')]);state.brand={...state.brand,...cfg,heroLine1:'Route token fees',heroLine2:'through X Money',description:'Point a token’s creator fees at any X handle and route the recipient share in dollars through your configured payout rail.'};state.home=home;state.money=money;state.tokens=tokens.tokens||[];document.title=state.brand.name;}"""

new_load="""/* home-top-x-live-identity-v22-2 */
async function hydrateHomeXProfiles(home){
  const profiles=Array.isArray(home?.profiles)?home.profiles:[];
  if(!profiles.length)return home;

  const hydrated=await Promise.all(profiles.map(async(p,index)=>{
    if(index>=4)return p;
    const handle=String(p?.handle||'').replace(/^@/,'').trim();
    if(!/^[A-Za-z0-9_]{1,15}$/.test(handle))return p;

    try{
      const x=await api(`/api/x/profile?username=${encodeURIComponent(handle)}`);
      const verifiedType=String(x?.verifiedType||'').toLowerCase();
      const verified=Boolean(x?.verified)||
        ['blue','business','government'].includes(verifiedType);

      return {
        ...p,
        display_name:String(x?.name||p?.display_name||handle),
        avatar_url:String(x?.profileImageUrl||p?.avatar_url||''),
        banner_url:String(x?.profileBannerUrl||p?.banner_url||''),
        verified:verified?1:0,
        verified_type:String(x?.verifiedType||p?.verified_type||'')
      };
    }catch{
      return p;
    }
  }));

  return {...home,profiles:hydrated};
}

async function loadBase(){
  const [cfg,rawHome,money,tokens]=await Promise.all([
    api('/api/config'),
    api('/api/home'),
    api('/api/money'),
    api('/api/tokens?limit=100')
  ]);

  const home=await hydrateHomeXProfiles(rawHome);

  state.brand={
    ...state.brand,
    ...cfg,
    heroLine1:'Route token fees',
    heroLine2:'through X Money',
    description:'Point a token’s creator fees at any X handle and route the recipient share in dollars through your configured payout rail.'
  };
  state.home=home;
  state.money=money;
  state.tokens=tokens.tokens||[];
  document.title=state.brand.name;
}"""

if old_load in s:
    s=s.replace(old_load,new_load,1)
elif "home-top-x-live-identity-v22-2" not in s:
    raise SystemExit("ERROR: loadBase() block not found")

path.write_text(s)
print("src/app.js: live X display name + verification hydration installed")
PY

echo "==> Running project check"
npm run check

echo "==> Git diff"
git diff -- src/app.js

git add src/app.js

if git diff --cached --quiet; then
  echo "==> No new changes to commit."
else
  git commit -m "Use live X names and verification in Top X cards"
  git push origin main
fi

echo
echo "PASS: ${PATCH_NAME} installed."
echo "No server restart was performed."
