Pump Fee Routing — Explore Style Conflict Cleanup v15.8

Detected conflicts:
- v15.5 removed card borders/background/shadows
- v15.6 restored them
- v15.7 removed part of them again
- v15 and v15.2 still contained old divider/image-border declarations

This patch:
- removes obsolete v15.5/v15.6/v15.7 override chain
- normalizes earlier v15/v15.2 declarations
- adds ONE final canonical Explore border block
- keeps the main outer Explore container
- removes the line below the left image
- removes the left card right divider
- keeps the media/image areas borderless
- keeps the right image/tile frame borderless
- does not restart the server

Install in the existing Replit Shell:

rm -rf /tmp/explore-style-conflict-cleanup-v15-8
mkdir -p /tmp/explore-style-conflict-cleanup-v15-8
unzip -o Pump-Fee-Routing-Explore-Style-Conflict-Cleanup-v15-8.zip -d /tmp/explore-style-conflict-cleanup-v15-8
bash /tmp/explore-style-conflict-cleanup-v15-8/install.sh
