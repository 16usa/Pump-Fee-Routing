#!/usr/bin/env bash
set -euo pipefail

echo "== Explore Style Conflict Cleanup v15.8 =="

for f in src/app.js src/styles.css; do
  if [ ! -f "$f" ]; then
    echo "ERROR: $f not found. Run this from the existing Replit project workspace."
    exit 1
  fi
done

python3 <<'PYCODE'
from pathlib import Path

css_path = Path("src/styles.css")
app_path = Path("src/app.js")
css = css_path.read_text()
app = app_path.read_text()

required = [
    '/* explore-card-info-v15 */',
    '/* explore-image-inset-v15-2 */',
    '/* explore-metrics-and-vignette-v15-3-1 */',
]
for marker in required:
    if marker not in css:
        raise SystemExit(f"ERROR: required marker missing: {marker}")

if 'data-explore-card-info="v15"' not in app:
    raise SystemExit('ERROR: Explore v15 card markup not found in src/app.js')

# Normalize the older card-info rule so it no longer requests the divider.
card_start = css.index('/* explore-card-info-v15 */')
inset_start = css.index('/* explore-image-inset-v15-2 */')
card_section = css[card_start:inset_start]
card_section = card_section.replace('border-top:1px solid #272727;', 'border-top:0;')
css = css[:card_start] + card_section + css[inset_start:]

# Normalize v15.2: the image itself is intentionally borderless now.
inset_start = css.index('/* explore-image-inset-v15-2 */')
metrics_start = css.index('/* explore-metrics-and-vignette-v15-3-1 */')
inset_section = css[inset_start:metrics_start]
inset_section = inset_section.replace('border:1px solid #2b2b2b;', 'border:0;')
css = css[:inset_start] + inset_section + css[metrics_start:]

# Remove the mutually overriding border patches v15.5/v15.6/v15.7.
legacy_start_marker = '/* explore-border-cleanup-v15-5 */'
if legacy_start_marker in css:
    legacy_start = css.index(legacy_start_marker)
    css = css[:legacy_start].rstrip() + '\n\n'
    print('PASS removed legacy conflicting v15.5/v15.6/v15.7 cascade')
else:
    print('PASS legacy conflict tail already removed')

final_marker = '/* explore-style-final-v15-8 */'
final_css = r'''
/* explore-style-final-v15-8 */

/* FINAL Explore border state.
   Outer Explore container stays unchanged.
   Left image: no frame.
   Line below left image: removed.
   Left card right divider: removed.
   Right image/tile frame: removed.
   No duplicate border overrides below this block. */

.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"]{
  background:#0b0b0b;
  border:0;
  border-radius:0 15px 15px 0;
  box-shadow:0 8px 22px rgba(0,0,0,.22);
}

.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] > .home-explore-v8-media{
  border:0;
  outline:0;
  box-shadow:none;
}

.home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"] > .home-explore-v8-copy{
  border-top:0;
  box-shadow:none;
}

.home-explore-reference-v8 .home-explore-v8-secondary-card{
  background:#0b0b0b;
  border:0;
  outline:0;
  border-radius:15px 0 0 0;
  box-shadow:none;
}

.home-explore-reference-v8 .home-explore-v8-secondary-card > .home-explore-v8-media{
  border:0;
  outline:0;
  box-shadow:none;
}

@media (max-width:640px){
  .home-explore-reference-v8 .home-explore-v8-primary-card[data-explore-card-info="v15"]{
    border-radius:0 12px 12px 0;
  }
  .home-explore-reference-v8 .home-explore-v8-secondary-card{
    border-radius:12px 0 0 0;
  }
}
'''

if final_marker not in css:
    css = css.rstrip() + '\n\n' + final_css + '\n'

css_path.write_text(css)

updated = css_path.read_text()
checks = {
    'v15.5 removed': '/* explore-border-cleanup-v15-5 */' not in updated,
    'v15.6 removed': '/* explore-border-scope-fix-v15-6 */' not in updated,
    'v15.7 removed': '/* explore-image-frame-cleanup-v15-7 */' not in updated,
    'final v15.8 exists': final_marker in updated,
    'outer geometry preserved': 'home-preview-card.home-ref-explore-card.home-explore-reference-v8' in updated,
}
for label, ok in checks.items():
    if not ok:
        raise SystemExit(f'ERROR: verification failed: {label}')
    print('PASS', label)

print('PASS Explore styles consolidated: one final border rule set')
PYCODE

echo
echo "== Project checks =="
npm run check

echo
echo "== Git diff =="
git diff --stat

git add src/styles.css

if git diff --cached --quiet; then
  echo "No new changes to commit."
else
  git commit -m "Consolidate Explore styles and remove border conflicts"
  git push
fi

echo
echo "DONE: Explore Style Conflict Cleanup v15.8 installed, checked, committed, and pushed."
echo "No server restart was performed."
echo "Restart Run/Console manually once, then reload the page."
