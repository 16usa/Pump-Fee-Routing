Pump-Fee-Routing — Home Explore Modules v4

This patch changes ONLY the Home Explore preview.

Key change:
The two visual pieces inside Explore are now actual mini UI modules assembled from HTML/CSS and live token/profile data, like the Launch preview card. They are not flat screenshots.

Each module can contain:
- real token image when available
- Pump/platform badge
- recipient avatar/name pill
- token name and ticker
- market-cap text
- sent amount
- fallback initial/gradient when a real image is unavailable

Composition:
- primary module upper-left
- secondary module partially visible lower-right
- static, no movement
- bottom fade with Explore / Open →
- reference-like overlap/cropping

The existing backend /api/token-image resolver from v3 is reused.
Payments, Analytics, Launch, Docs and transaction/wallet logic are not changed.
No automatic server restart.
