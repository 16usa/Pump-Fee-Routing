#!/usr/bin/env bash
set -euo pipefail

for f in src/app.js src/styles.css; do
  [ -f "$f" ] || { echo "Missing $f. Run this from the Pump-Fee-Routing project root."; exit 1; }
done

# Protect only the files this patch edits. Untracked ZIPs and .conversation changes are ignored.
if [ -n "$(git status --porcelain -- src/app.js src/styles.css)" ]; then
  echo "STOP: Launch source files have uncommitted changes."
  git status --short -- src/app.js src/styles.css
  exit 2
fi

# Do not accidentally include unrelated files that may already be staged.
staged_unrelated="$(git diff --cached --name-only | grep -vE '^(src/app\.js|src/styles\.css)$' || true)"
if [ -n "$staged_unrelated" ]; then
  echo "STOP: unrelated staged files are present:"
  echo "$staged_unrelated"
  exit 3
fi

python3 - <<'PY'

from pathlib import Path
import base64

def dec(x): return base64.b64decode(x).decode()

def replace_once(text, old64, new64, label):
    old,new=dec(old64),dec(new64)
    if old not in text:
        raise SystemExit(f"{label} anchor not found")
    return text.replace(old,new,1)

app_path=Path('src/app.js')
css_path=Path('src/styles.css')
app=app_path.read_text()
css=css_path.read_text()

if 'launch-form-polish-v1' in css:
    raise SystemExit('Launch Form Polish v1 is already installed.')

app=replace_once(app,'ICAgICAgICAgIDxkaXYgY2xhc3M9ImxhdW5jaC1maWVsZCI+CiAgICAgICAgICAgIDxsYWJlbD5Tb2NpYWwgbGlua3MgPHNtYWxsPihvcHRpb25hbCk8L3NtYWxsPjwvbGFiZWw+CiAgICAgICAgICAgIDxwIGNsYXNzPSJsYXVuY2gtaGVscCI+WW91IGNhbiB1c2UgdGhlIHJlZ2lzdGVyZWQgdG9rZW4gcGFnZSBhcyB0aGUgd2Vic2l0ZSBsaW5rLjwvcD4KICAgICAgICAgICAgPGlucHV0IGlkPSJsYXVuY2hXZWJzaXRlIiB0eXBlPSJ1cmwiIGlucHV0bW9kZT0idXJsIiBhdXRvY29tcGxldGU9InVybCIgYXV0b2NhcGl0YWxpemU9Im5vbmUiIHNwZWxsY2hlY2s9ImZhbHNlIiBwbGFjZWhvbGRlcj0iaHR0cHM6Ly95b3Vyc2l0ZS5jb20iPgogICAgICAgICAgICA8ZGl2IGNsYXNzPSJsYXVuY2gtdHdvIj48aW5wdXQgaWQ9ImxhdW5jaFRlbGVncmFtIiBwbGFjZWhvbGRlcj0iVGVsZWdyYW0iPjxpbnB1dCBpZD0ibGF1bmNoWCIgcGxhY2Vob2xkZXI9IlgiPjwvZGl2PgogICAgICAgICAgPC9kaXY+','ICAgICAgICAgIDxkZXRhaWxzIGNsYXNzPSJsYXVuY2gtc29jaWFsLWRldGFpbHMiIG9wZW4+CiAgICAgICAgICAgIDxzdW1tYXJ5PlNvY2lhbCBsaW5rcyA8c21hbGw+KG9wdGlvbmFsKTwvc21hbGw+PHNwYW4gY2xhc3M9ImxhdW5jaC1zb2NpYWwtY2hldnJvbiIgYXJpYS1oaWRkZW49InRydWUiPuKMgzwvc3Bhbj48L3N1bW1hcnk+CiAgICAgICAgICAgIDxkaXYgY2xhc3M9ImxhdW5jaC1zb2NpYWwtYm9keSI+CiAgICAgICAgICAgICAgPHAgY2xhc3M9ImxhdW5jaC1oZWxwIj5Zb3UgY2FuIHVzZSB0aGUgcmVnaXN0ZXJlZCB0b2tlbiBwYWdlIGFzIHRoZSB3ZWJzaXRlIGxpbmsuPC9wPgogICAgICAgICAgICAgIDxpbnB1dCBpZD0ibGF1bmNoV2Vic2l0ZSIgdHlwZT0idXJsIiBpbnB1dG1vZGU9InVybCIgYXV0b2NvbXBsZXRlPSJ1cmwiIGF1dG9jYXBpdGFsaXplPSJub25lIiBzcGVsbGNoZWNrPSJmYWxzZSIgcGxhY2Vob2xkZXI9Imh0dHBzOi8veW91cnNpdGUuY29tIj4KICAgICAgICAgICAgICA8ZGl2IGNsYXNzPSJsYXVuY2gtdHdvIj48aW5wdXQgaWQ9ImxhdW5jaFRlbGVncmFtIiBwbGFjZWhvbGRlcj0iVGVsZWdyYW0iPjxpbnB1dCBpZD0ibGF1bmNoWCIgcGxhY2Vob2xkZXI9IlgiPjwvZGl2PgogICAgICAgICAgICA8L2Rpdj4KICAgICAgICAgIDwvZGV0YWlscz4=','Social links block')
app=replace_once(app,'ICAgICAgICAgIDxkaXYgY2xhc3M9ImxhdW5jaC1maWVsZCI+CiAgICAgICAgICAgIDxsYWJlbCBmb3I9ImxhdW5jaFBheW1lbnROb3RlIj5QYXltZW50IG5vdGU8L2xhYmVsPgogICAgICAgICAgICA8aW5wdXQgaWQ9ImxhdW5jaFBheW1lbnROb3RlIiBtYXhsZW5ndGg9IjI1MCIgdmFsdWU9IkNyZWF0b3IgZmVlcyB2aWEgJHtlc2Moc3RhdGUuYnJhbmQubmFtZSl9Ij4KICAgICAgICAgICAgPHAgY2xhc3M9ImxhdW5jaC1oZWxwIj5NZW1vIGF0dGFjaGVkIHRvIHRoZSByZWNpcGllbnQgcGF5b3V0IHJlY29yZC48L3A+CiAgICAgICAgICA8L2Rpdj4=','ICAgICAgICAgIDxkaXYgY2xhc3M9ImxhdW5jaC1maWVsZCBsYXVuY2gtcGF5bWVudC1ub3RlLWZpZWxkIj4KICAgICAgICAgICAgPGxhYmVsIGZvcj0ibGF1bmNoUGF5bWVudE5vdGUiPlBheW1lbnQgbm90ZTwvbGFiZWw+CiAgICAgICAgICAgIDx0ZXh0YXJlYSBpZD0ibGF1bmNoUGF5bWVudE5vdGUiIG1heGxlbmd0aD0iMjUwIiByb3dzPSIzIj5DcmVhdG9yIGZlZXMgdmlhICR7ZXNjKHN0YXRlLmJyYW5kLm5hbWUpfTwvdGV4dGFyZWE+CiAgICAgICAgICAgIDxwIGNsYXNzPSJsYXVuY2gtaGVscCI+PHNwYW4gaWQ9ImxhdW5jaFBheW1lbnROb3RlQ291bnQiPiR7YENyZWF0b3IgZmVlcyB2aWEgJHtzdGF0ZS5icmFuZC5uYW1lfWAubGVuZ3RofTwvc3Bhbj4vMjUwIMK3IHRoZSBtZXNzYWdlIHRoZSByZWNpcGllbnQgc2VlcyB3aXRoIGV2ZXJ5IHBheW91dDwvcD4KICAgICAgICAgIDwvZGl2Pg==','Payment note block')
app=replace_once(app,'ICAgICAgICAgIDxkaXYgaWQ9ImxhdW5jaFN0YXR1cyIgY2xhc3M9InN0YXR1cy1ib3giPjwvZGl2Pg==','ICAgICAgICAgIDxkaXYgaWQ9ImxhdW5jaFN0YXR1cyIgY2xhc3M9InN0YXR1cy1ib3ggaGlkZGVuIiBhcmlhLWxpdmU9InBvbGl0ZSI+PC9kaXY+','Launch status box')
app=replace_once(app,'ZnVuY3Rpb24gc2V0TGF1bmNoU3RhdHVzKHRleHQsZ29vZD1mYWxzZSl7Y29uc3QgZWw9ZG9jdW1lbnQucXVlcnlTZWxlY3RvcignI2xhdW5jaFN0YXR1cycpO2lmKGVsKXtlbC50ZXh0Q29udGVudD10ZXh0O2VsLmNsYXNzTGlzdC50b2dnbGUoJ2dvb2QnLGdvb2QpO319','ZnVuY3Rpb24gc2V0TGF1bmNoU3RhdHVzKHRleHQsZ29vZD1mYWxzZSl7Y29uc3QgZWw9ZG9jdW1lbnQucXVlcnlTZWxlY3RvcignI2xhdW5jaFN0YXR1cycpO2lmKGVsKXtjb25zdCBtZXNzYWdlPVN0cmluZyh0ZXh0fHwnJyk7ZWwudGV4dENvbnRlbnQ9bWVzc2FnZTtlbC5jbGFzc0xpc3QudG9nZ2xlKCdnb29kJyxnb29kKTtlbC5jbGFzc0xpc3QudG9nZ2xlKCdoaWRkZW4nLCFtZXNzYWdlKTt9fQ==','Launch status behavior')
app=replace_once(app,'YXBwLmFkZEV2ZW50TGlzdGVuZXIoJ2lucHV0JyxlPT57aWYoZS50YXJnZXQuaWQ9PT0ndG9rZW5TZWFyY2gnKXtjbGVhclRpbWVvdXQoc2VhcmNoVGltZXIpO3N0YXRlLmV4cGxvcmUucXVlcnk9ZS50YXJnZXQudmFsdWU7c2VhcmNoVGltZXI9c2V0VGltZW91dChhc3luYygpPT57dHJ5e2F3YWl0IHJlZnJlc2hUb2tlbnMoKTtjb25zdCBncmlkPWRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJyNsYXVuY2hHcmlkJyk7aWYoZ3JpZClncmlkLmlubmVySFRNTD1zdGF0ZS50b2tlbnMubWFwKGV4cGxvcmVUb2tlbkNhcmQpLmpvaW4oJycpfHwnPGRpdiBjbGFzcz0iZXhwbG9yZS1lbXB0eSI+PHNwYW4+Tm8gbGF1bmNoZXMgbWF0Y2ggdGhpcyBzZWFyY2guPC9zcGFuPjwvZGl2Pic7fWNhdGNoe319LDE4MCk7fWlmKGUudGFyZ2V0LmlkPT09J2xhdW5jaEhhbmRsZScpe2NsZWFyVGltZW91dChsYXVuY2hYTG9va3VwVGltZXIpO2xhdW5jaFhMb29rdXBUaW1lcj1zZXRUaW1lb3V0KCgpPT5sb29rdXBMYXVuY2hYQWNjb3VudChlLnRhcmdldC52YWx1ZSksMzUwKTt9aWYoWydsYXVuY2hOYW1lJywnbGF1bmNoVGlja2VyJywnbGF1bmNoSGFuZGxlJ10uaW5jbHVkZXMoZS50YXJnZXQuaWQpKXVwZGF0ZUxhdW5jaFByZXZpZXcoKTt9KTs=','YXBwLmFkZEV2ZW50TGlzdGVuZXIoJ2lucHV0JyxlPT57aWYoZS50YXJnZXQuaWQ9PT0ndG9rZW5TZWFyY2gnKXtjbGVhclRpbWVvdXQoc2VhcmNoVGltZXIpO3N0YXRlLmV4cGxvcmUucXVlcnk9ZS50YXJnZXQudmFsdWU7c2VhcmNoVGltZXI9c2V0VGltZW91dChhc3luYygpPT57dHJ5e2F3YWl0IHJlZnJlc2hUb2tlbnMoKTtjb25zdCBncmlkPWRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJyNsYXVuY2hHcmlkJyk7aWYoZ3JpZClncmlkLmlubmVySFRNTD1zdGF0ZS50b2tlbnMubWFwKGV4cGxvcmVUb2tlbkNhcmQpLmpvaW4oJycpfHwnPGRpdiBjbGFzcz0iZXhwbG9yZS1lbXB0eSI+PHNwYW4+Tm8gbGF1bmNoZXMgbWF0Y2ggdGhpcyBzZWFyY2guPC9zcGFuPjwvZGl2Pic7fWNhdGNoe319LDE4MCk7fWlmKGUudGFyZ2V0LmlkPT09J2xhdW5jaEhhbmRsZScpe2NsZWFyVGltZW91dChsYXVuY2hYTG9va3VwVGltZXIpO2xhdW5jaFhMb29rdXBUaW1lcj1zZXRUaW1lb3V0KCgpPT5sb29rdXBMYXVuY2hYQWNjb3VudChlLnRhcmdldC52YWx1ZSksMzUwKTt9aWYoZS50YXJnZXQuaWQ9PT0nbGF1bmNoUGF5bWVudE5vdGUnKXtjb25zdCBjb3VudD1kb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcjbGF1bmNoUGF5bWVudE5vdGVDb3VudCcpO2lmKGNvdW50KWNvdW50LnRleHRDb250ZW50PVN0cmluZyhlLnRhcmdldC52YWx1ZS5sZW5ndGgpO31pZihbJ2xhdW5jaE5hbWUnLCdsYXVuY2hUaWNrZXInLCdsYXVuY2hIYW5kbGUnXS5pbmNsdWRlcyhlLnRhcmdldC5pZCkpdXBkYXRlTGF1bmNoUHJldmlldygpO30pOw==','Launch input listener')
css += dec('Ci8qIGxhdW5jaC1mb3JtLXBvbGlzaC12MSAqLwoubGF1bmNoLXNvY2lhbC1kZXRhaWxzewogIGRpc3BsYXk6Z3JpZDsKICBnYXA6OXB4Owp9Ci5sYXVuY2gtc29jaWFsLWRldGFpbHMgc3VtbWFyeXsKICBsaXN0LXN0eWxlOm5vbmU7CiAgZGlzcGxheTpmbGV4OwogIGFsaWduLWl0ZW1zOmNlbnRlcjsKICBnYXA6NXB4OwogIGN1cnNvcjpwb2ludGVyOwogIGNvbG9yOiNjZmNmY2Y7CiAgZm9udC1zaXplOjEycHg7CiAgZm9udC13ZWlnaHQ6NjAwOwogIHRleHQtdHJhbnNmb3JtOm5vbmU7Cn0KLmxhdW5jaC1zb2NpYWwtZGV0YWlscyBzdW1tYXJ5Ojotd2Via2l0LWRldGFpbHMtbWFya2Vye2Rpc3BsYXk6bm9uZX0KLmxhdW5jaC1zb2NpYWwtZGV0YWlscyBzdW1tYXJ5IHNtYWxsewogIGNvbG9yOiM2NjY7CiAgZm9udC13ZWlnaHQ6NTAwOwp9Ci5sYXVuY2gtc29jaWFsLWNoZXZyb257CiAgbWFyZ2luLWxlZnQ6YXV0bzsKICBjb2xvcjojNzA3MDcwOwogIGZvbnQtc2l6ZToxMnB4OwogIHRyYW5zaXRpb246dHJhbnNmb3JtIC4xNnMgZWFzZTsKfQoubGF1bmNoLXNvY2lhbC1kZXRhaWxzOm5vdChbb3Blbl0pIC5sYXVuY2gtc29jaWFsLWNoZXZyb257CiAgdHJhbnNmb3JtOnJvdGF0ZSgxODBkZWcpOwp9Ci5sYXVuY2gtc29jaWFsLWJvZHl7CiAgZGlzcGxheTpncmlkOwogIGdhcDo5cHg7Cn0KLmxhdW5jaC1wYXltZW50LW5vdGUtZmllbGQgdGV4dGFyZWF7CiAgbWluLWhlaWdodDo4OHB4Owp9Cg==')

app_path.write_text(app)
css_path.write_text(css)
print('Launch Form Polish v1 installed.')

PY

node --check src/app.js
npm run check

node <<'NODE'
const fs=require('fs');
const app=fs.readFileSync('src/app.js','utf8');
const css=fs.readFileSync('src/styles.css','utf8');

const checks=[
  ['no Launch token heading added', !app.includes('<h2>Launch token</h2>')],
  ['collapsible Social links', app.includes('class="launch-social-details" open')],
  ['Website preserved', app.includes('id="launchWebsite"')],
  ['Telegram preserved', app.includes('id="launchTelegram"')],
  ['X preserved', app.includes('id="launchX"')],
  ['Payment note textarea', app.includes('<textarea id="launchPaymentNote" maxlength="250"')],
  ['Payment note counter', app.includes('id="launchPaymentNoteCount"')],
  ['Live payment note counter', app.includes("e.target.id==='launchPaymentNote'")],
  ['status starts hidden', app.includes('id="launchStatus" class="status-box hidden"')],
  ['status reveals only with text', app.includes("el.classList.toggle('hidden',!message)")],
  ['polish CSS', css.includes('/* launch-form-polish-v1 */')],
];

let bad=0;
for(const [name,ok] of checks){
  console.log(`${ok?'PASS':'FAIL'} ${name}`);
  if(!ok)bad++;
}
if(bad)process.exit(1);
NODE

git add src/app.js src/styles.css

if git diff --cached --quiet; then
  echo "No staged changes; nothing to commit."
else
  git commit -m "Polish Launch form controls"
fi

git push origin main

echo
echo "DONE: Launch Form Polish v1 checked, committed, and pushed to GitHub."
echo "No Launch token heading was added."
echo "Old ZIP files and .conversation entries were intentionally ignored."
echo "No server restart was performed."
echo "Restart Console/Run manually once to load the updated Launch form."
