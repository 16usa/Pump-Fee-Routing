Pump Fee Routing — Launch Form Polish v1

Applies the requested Launch form polish EXCEPT the Launch token heading.

- Social links becomes collapsible (open by default)
- Website / Telegram / X remain unchanged
- Payment note becomes multiline with a live 0-250 counter
- Empty Launch status box is hidden until there is a real status/error
- No Launch token heading is added

Installer checks, commits, and pushes origin/main. It does not restart the server.
